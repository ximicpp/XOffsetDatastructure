#!/usr/bin/env python3
# PR269 report-only analysis of the SLG demo cases (embedded in run_pr269.sh; the cloud recomputes it from the raw files).
#   pr269_an.py DIR   DIR/<seq>_<point>.jsonl, slg_bench --mode bench raw (SLG_CASES=demo SLG_REUSE=1, M, xoffset)
# points: head = 8753965d with bench/slg 62533ded; anc = 30fb525c with the same bench/slg 62533ded (library effect, #269 P1);
# own = 30fb525c with its own bench/slg 17b7919b (P1 + P2, the UL in-place refill is a bench/slg change).
# Per metric: one value per process = the median over cycles 1.. (cycle 0 dropped, as L2); head/anc and head/own =
# median of the head processes / median of the other point's, 95% percentile bootstrap (4000 draws, fixed seed).
# Bytes: per point and byte metric, the set of values over every cycle and process. Report only.
import json, os, random, statistics, sys

KEYS = ('EB.send', 'UC.send', 'UP.send', 'UL.send', 'EB.recv', 'UC.recv', 'UP.recv', 'UL.recv', 'UC.apply', 'UP.apply')


def ratio_ci(h, a, n=4000, seed=19):
    r = random.Random(seed)
    point = statistics.median(h) / statistics.median(a)
    bs = []
    for _ in range(n):
        hh = [h[r.randrange(len(h))] for _ in h]
        aa = [a[r.randrange(len(a))] for _ in a]
        bs.append(statistics.median(hh) / statistics.median(aa))
    bs.sort()
    return point, bs[int(0.025 * n)], bs[int(0.975 * n) - 1]


def main(d):
    per, byts, nproc = {}, {}, {}
    for f in sorted(os.listdir(d)):
        if not f.endswith('.jsonl'):
            continue
        pt = f[:-6].split('_', 1)[1]
        nproc[pt] = nproc.get(pt, 0) + 1
        m = {}
        for line in open(os.path.join(d, f)):
            try:
                j = json.loads(line)
            except ValueError:
                continue
            if j.get('format') != 'xoffset':
                continue
            if 'bytes' in j and 'metric' in j:
                byts.setdefault(j['metric'], {}).setdefault(pt, set()).add(j['bytes'])
            if 'metric' in j and 'ns' in j and j.get('cycle', 0) >= 1:
                m.setdefault(j['metric'], []).append(j['ns'])
        for k, v in m.items():
            per.setdefault(k, {}).setdefault(pt, []).append(statistics.median(v))
    print('# PR269 SLG demo cases (report only): xoffset, SLG_CASES=demo SLG_REUSE=1, M, processes '
          + ', '.join(f'{p} {nproc.get(p, 0)}' for p in ('head', 'anc', 'own')))
    print()
    print('head and anc both use bench/slg 62533ded (library effect of #269 P1); own = the anchor with its own bench/slg 17b7919b (P1 + P2).')
    print()
    print('| metric | head ns | anc ns | own ns | head/anc | 95% interval | head/own | 95% interval |')
    print('|---|---|---|---|---|---|---|---|')
    lead = []
    rows = sorted(per, key=lambda k: (KEYS.index(k) if k in KEYS else len(KEYS), k))
    for k in rows:
        h, a, o = (per[k].get(p, []) for p in ('head', 'anc', 'own'))
        if len(h) < 2:
            continue
        cells = [f'{statistics.median(h):.0f}', f'{statistics.median(a):.0f}' if a else '', f'{statistics.median(o):.0f}' if o else '']
        ra = ro = ('', '')
        if len(a) >= 2 and statistics.median(a) > 0:
            p, lo, hi = ratio_ci(h, a); ra = (f'{p:.4f}', f'[{lo:.4f}, {hi:.4f}]')
            if k in KEYS[:4]: lead.append(f'{k} {p:.3f}')
        if len(o) >= 2 and statistics.median(o) > 0:
            p, lo, hi = ratio_ci(h, o); ro = (f'{p:.4f}', f'[{lo:.4f}, {hi:.4f}]')
            if k in KEYS[:4]: lead.append(f'{k}/own {p:.3f}')
        print(f'| {k} | ' + ' | '.join(cells) + f' | {ra[0]} | {ra[1]} | {ro[0]} | {ro[1]} |')
    print()
    print('| byte metric | head | anc | own |')
    print('|---|---|---|---|')
    diff = []
    for k in sorted(byts):
        v = byts[k]
        show = lambda p: ', '.join(str(x) for x in sorted(v.get(p, set()))[:4]) + (' …' if len(v.get(p, set())) > 4 else '')
        if v.get('head') != v.get('anc') or v.get('head') != v.get('own') or k.startswith(('UL.', 'ULZ.', 'EB.', 'UC.', 'UP.')):
            print(f'| {k} | {show("head")} | {show("anc")} | {show("own")} |')
        if v.get('head') != v.get('own'):
            diff.append(k)
    print()
    print('byte metrics where head and own differ: ' + (', '.join(diff) if diff else 'none'))
    print()
    print('demo: ' + ', '.join(lead))


if __name__ == '__main__':
    main(sys.argv[1])
