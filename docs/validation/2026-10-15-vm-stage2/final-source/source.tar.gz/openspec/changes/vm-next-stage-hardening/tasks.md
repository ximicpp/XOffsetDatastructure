# Development tasks

Date: 2026-10-15. The first and second implementation batches are recorded in
[stage 1](../../../docs/VM_STAGE1_RESULTS.md) and [stage 2](../../../docs/VM_STAGE2_RESULTS.md).
Remaining platform and quiet-host prerequisites stay open. Work package IDs refer to
[the design](../../../docs/VM_NEXT_STAGE_PLAN.md).

## Analysis delivered

- [x] Inspect current F source, branch/base, previous adoption and rejection evidence.
- [x] Review build/release, performance/policies and allocator design independently.
- [x] Define invariants, dependencies, experiment controls and adoption gates.
- [x] Produce a concrete staged development plan without modifying implementation.

## Batch I — trustworthy validation and measurement

- [x] N0: Record fixed source/toolchain/dependency/runtime manifests for the validated Linux/macOS profiles.
- [x] N0: Pin canonical CI to a verified pullable digest and compiler source recipes to commits; document remaining Ubuntu/apt variability in source rebuilding.
- [x] N0: Add maintained portable validation entry points with explicit archive inputs; remove undeclared local build/runtime dependencies from new runners.
- [x] N0: Create log directories before use; test clean source/build paths and stale storage-only cache recovery.
- [x] N0: Add a positive compilation control and expected-error validation; fail unexpected negative-test success.
- [x] N0: Generate accurate program/CTest inventories and update developer guidance.
- [x] N0: Derive future variant labels from manifests; add historical-label errata without rewriting archived evidence.
- [x] N1: Make C++17 OS-only configuration independent of P2996 and compiler-family flags.
- [x] N1: Add a real reflection compile/link capability check for full-library mode.
- [ ] N1: Validate OS storage/pool on native Linux/macOS/Windows; distinguish compile and execution status.
- [x] N1: Maintain full P2996, sanitizer, TSan and historical wire validation paths with explicit support boundaries.
- [ ] N1: Assess Windows full-library toolchain separately; record any unmet prerequisite instead of claiming support.
- [x] N3: Define existing metric meanings, estimates and unavailable diagnostics; freeze ordinary timing builds, validate semantics and source/binary attribution.
- [ ] N3: Implement exact allocator/copying/owner/lock diagnostic instrumentation separately from formal timing builds.
- [ ] N3: Run A/A calibration and independent-window D/F default-path reproduction; perform one-change ablation only after reproducibility.

Stage 1 delivered 3 diagnostic windows (252 measured + 36 warmups), audited data,
and a corrected fail-closed window completion protocol. Background contention
prevented quiet-host regression attribution; the last N3 task is not complete.
Native macOS/Linux storage passed; Windows CI is configured but has not run.

## Batch II — consumption and optional policies

- [x] N2: Add configurable subdirectories, portable interface targets and install/export configuration.
- [x] N2: Declare and validate TypeLayout/Boost/header/toolchain/Threads dependencies and license packaging.
- [x] N2: Pass an out-of-tree installed consumer and multi-translation-unit ownership/lifecycle test.
- [x] N2: Publish an experimental support matrix distinguishing OS, full library and performance environments.
- [x] N4: Compare fixed/mixed/bimodal capacities, phase changes and 1/2/4/8 threads with equal total pool budgets.
- [x] N4: Measure idle/reuse curves, contention and concurrent clear; separate live-owner shrink/reclaim/regrow from pooled-owner retain/clear/reacquire.
- [x] N4: Prototype capacity indexing, shorter lock scope or sharding only for a measured bottleneck; retain no-allocation return and global bounds.
- [x] N4: Adopt a verified candidate or document retaining F with measured applicability limits.
- [x] N5: Compare preallocated/Explicit/Automatic using identical traces and independent initial-capacity/insertion-cadence parameters.
- [x] N5: Explain the existing +6.60% used_end result through allocation/growth events.
- [x] N5: Prototype the smallest justified change and verify hard-limit/nested-failure/cached-block behavior; adopt or retain F with evidence.

Stage 2 delivered N2 packaging and N4/N5 evidence. Pool optimization was not
justified by the screening; a generated Automatic tail-flush candidate was rejected
for exact finite-lifetime space/copy regressions. Both production headers remain F.
Pool lock/scan and allocator-event diagnostics are available, but the broader N3
owner-index/host-metadata instrumentation and quiet-host attribution stay open.

## Batch III — allocator research

- [ ] N6: Establish interval-model and randomized release/size/alignment/pressure workloads plus fail-after-N metadata injection.
- [ ] N6-A: Compare first-fit splitting with physical-tail donors preserved whole, Core and wire independently.
- [ ] N6-B: Separately evaluate high-address allocation from tail donors with legal alignment/header/remainder handling.
- [ ] N6-C: Keep whole-block policy fixed; define donor selection/tie-breaks and compare indexed versus linear search with identical selection, then compare against F end to end; report host metadata costs and complete fallback search.
- [ ] N6: Verify unique ownership and prepare-before-publish transitions, including wire-to-Core transfer and partial index failures.
- [ ] N6: Combine only independently successful candidates and rerun default/growth/pressure guards.
- [ ] N6-D: If justified by residual fragmentation, compare failure-triggered batch coalescing before adding an address index.
- [ ] N6: Complete final compatibility/sanitizer/platform evidence for an adopted candidate, or archive rejection while retaining F.

## Batch IV — conditional I/O research and final delivery

- [ ] N7: Profile an actual input/output consumer; distinguish owner reuse, staging direct read and external borrowed input; include F pooled loading as an owner-reuse comparator.
- [ ] N7: If justified, define rollback, partial read/cancellation, validation publication and asynchronous output lifetimes before prototyping.
- [ ] N7: Adopt only with end-to-end evidence; otherwise document why the API is not added.
- [ ] Freeze the final adopted source and run the applicable full validation matrix; use actual new test counts.
- [ ] Audit raw performance results, version labels, hashes, platform limitations and negative results.
- [ ] Update migration/consumer examples and per-package adoption/rejection/prerequisite status.
- [ ] Review the final change independently; keep integration/publication actions separate from evidence completion.
