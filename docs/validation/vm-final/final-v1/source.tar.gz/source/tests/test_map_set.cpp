// ============================================================================
// Test: Map and Set Operations
// Purpose: Test XMap and XSet containers
// ============================================================================

#include <iostream>
#include <cassert>
#include "../xoffsetdatastructure.hpp"

using namespace XOffsetDatastructure;

struct MapSetTest {
    template <typename Allocator>
    MapSetTest(Allocator allocator) 
        : intSet(allocator),
          stringSet(allocator),
          intMap(allocator),
          stringMap(allocator) {}
    
    XSet<int> intSet;
    XSet<XString> stringSet;
    XMap<int, XString> intMap;
    XMap<XString, int> stringMap;
};

bool test_map_set_operations() {
    std::cout << "\n[TEST] Map and Set Operations\n";
    std::cout << std::string(50, '-') << "\n";
    
    // Fixed-schema buffers now carry allocator state plus frozen container
    // metadata, so this legacy map/set scenario needs a slightly larger arena.
    XBuffer xbuf(8192);
    auto* obj = xbuf.make<MapSetTest>();
    
    // Test 1: Set insertion
    std::cout << "Test 1: Set insertion... ";
    for (int i = 0; i < 50; ++i) {
        obj->intSet.insert(i);
    }
    // Insert duplicates (should be ignored)
    for (int i = 0; i < 25; ++i) {
        obj->intSet.insert(i);
    }
    assert(obj->intSet.size() == 50); // Only unique values
    std::cout << "[OK]\n";
    
    // Test 2: Set find
    std::cout << "Test 2: Set find operations... ";
    assert(obj->intSet.find(25) != obj->intSet.end());
    assert(obj->intSet.find(100) == obj->intSet.end());
    std::cout << "[OK]\n";
    
    // Test 3: String set
    std::cout << "Test 3: String set operations... ";
    for (int i = 0; i < 10; ++i) {
        std::string str = "Item_" + std::to_string(i);
        obj->stringSet.emplace(str.c_str());
    }
    assert(obj->stringSet.size() == 10);
    std::cout << "[OK]\n";
    
    // Test 4: Map insertion
    std::cout << "Test 4: Map insertion... ";
    for (int i = 0; i < 20; ++i) {
        std::string value = "Value_" + std::to_string(i);
        
        obj->intMap.emplace(i, value.c_str());
    }
    assert(obj->intMap.size() == 20);
    std::cout << "[OK]\n";
    
    // Test 5: Map access
    std::cout << "Test 5: Map access... ";
    auto it = obj->intMap.find(10);
    assert(it != obj->intMap.end());
    assert(it->second == "Value_10");
    std::cout << "[OK]\n";
    
    // Test 6: String key map
    std::cout << "Test 6: String key map... ";
    for (int i = 0; i < 15; ++i) {
        std::string key = "Key_" + std::to_string(i);
        
        obj->stringMap.emplace(key.c_str(), i * 10);
    }
    assert(obj->stringMap.size() == 15);
    
    
    auto it2 = obj->stringMap.find("Key_5");
    assert(it2 != obj->stringMap.end());
    assert(it2->second == 50);
    std::cout << "[OK]\n";
    
    // Test 7: Iteration
    std::cout << "Test 7: Map iteration... ";
    int count = 0;
    for (const auto& pair : obj->intMap) {
        count++;
    }
    assert(count == 20);
    std::cout << "[OK]\n";
    
    // Test 8: Persistence
    std::cout << "Test 8: Persistence test... ";
    auto buffer = xbuf.get_buffer();
    XBuffer loaded_buf(buffer.data(), buffer.size());
    auto& loaded_obj = loaded_buf.unsafe_root<MapSetTest>();
    assert(loaded_obj.intSet.size() == 50);
    assert(loaded_obj.intMap.size() == 20);
    assert(loaded_obj.stringMap.size() == 15);
    std::cout << "[OK]\n";
    
    std::cout << "[PASS] All map/set tests passed!\n";
    return true;
}

int main() {
    try {
        return test_map_set_operations() ? 0 : 1;
    } catch (const std::exception& e) {
        std::cerr << "[FAIL] Exception: " << e.what() << "\n";
        return 1;
    }
}
