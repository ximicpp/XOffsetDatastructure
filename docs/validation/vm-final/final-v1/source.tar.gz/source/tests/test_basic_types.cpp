// ============================================================================
// Test: Basic Types
// Purpose: Test basic POD types (int, float, double, etc.)
// ============================================================================

#include <iostream>
#include <cassert>
#include "../xoffsetdatastructure.hpp"

using namespace XOffsetDatastructure;

struct BasicTypes {
    template <typename Allocator>
    BasicTypes(Allocator allocator) {}
    
    int mInt;
    float mFloat;
    double mDouble;
    char mChar;
    bool mBool;
};

// Type safety validation
static_assert(is_byte_copy_safe_v<BasicTypes>,
              "BasicTypes must be safe for XBuffer");

bool test_basic_types() {
    std::cout << "\n[TEST] Basic Types\n";
    std::cout << std::string(50, '-') << "\n";
    
    // Create buffer
    XBuffer xbuf(1024);
    
    // Create and initialize object
    auto* obj = xbuf.make<BasicTypes>();
    obj->mInt = 42;
    obj->mFloat = 3.14f;
    obj->mDouble = 2.71828;
    obj->mChar = 'A';
    obj->mBool = true;
    
    // Verify
    assert(obj->mInt == 42);
    assert(obj->mFloat == 3.14f);
    assert(obj->mDouble == 2.71828);
    assert(obj->mChar == 'A');
    assert(obj->mBool == true);
    
    // Test persistence
    auto buffer = xbuf.get_buffer();
    XBuffer loaded_buf(buffer.data(), buffer.size());
    auto& loaded_obj = loaded_buf.unsafe_root<BasicTypes>();
    
    assert(loaded_obj.mInt == 42);
    assert(loaded_obj.mFloat == 3.14f);
    assert(loaded_obj.mDouble == 2.71828);
    assert(loaded_obj.mChar == 'A');
    assert(loaded_obj.mBool == true);
    
    std::cout << "[PASS] All basic type tests passed!\n";
    return true;
}

int main() {
    try {
        return test_basic_types() ? 0 : 1;
    } catch (const std::exception& e) {
        std::cerr << "[FAIL] Exception: " << e.what() << "\n";
        return 1;
    }
}
