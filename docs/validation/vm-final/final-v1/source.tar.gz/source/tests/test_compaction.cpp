// ============================================================================
// Test: Memory Compaction
// Purpose: Test memory compaction functionality
// ============================================================================

#include <iostream>
#include <cassert>
#include "../xoffsetdatastructure.hpp"

using namespace XOffsetDatastructure;

struct CompactTestType {
    template <typename Allocator>
    CompactTestType(Allocator allocator) 
        : data(allocator), strings(allocator) {}
    
    int value;
    XVector<int> data;
    XVector<XString> strings;
};

bool test_memory_compaction() {
    std::cout << "\n[TEST] Memory Compaction\n";
    std::cout << std::string(50, '-') << "\n";
    
    // Create initial buffer with extra space
    XBuffer xbuf(16384);
    auto* obj = xbuf.make<CompactTestType>();
    
    // Test 1: Fill with data
    std::cout << "Test 1: Fill buffer with data... ";
    obj->value = 999;
    for (int i = 0; i < 100; ++i) {
        obj->data.push_back(i);
    }
    for (int i = 0; i < 20; ++i) {
        std::string str = "TestString_" + std::to_string(i);
        obj->strings.push_back(str.c_str());
    }
    std::cout << "[OK]\n";
    
    // Test 2: Check memory stats before compaction
    std::cout << "Test 2: Memory stats before compaction... ";
    auto stats_before = memory_stats(xbuf);
    std::cout << "\n  Total size: " << stats_before.total_size << " bytes\n";
    std::cout << "  Used:       " << stats_before.used_size << " bytes\n";
    std::cout << "  Free:       " << stats_before.free_size << " bytes\n";
    std::cout << "  Efficiency: " << stats_before.usage_percent() << "%\n";
    std::cout << "[OK]\n";
    
    // Test 3: Perform automatic compaction (C++26 reflection-based)
    std::cout << "Test 3: Compact memory (automatic)... ";
    XBuffer compact_buf = XCompactor::compact<CompactTestType>(xbuf);
    assert(compact_buf.get_size() > 0);
    std::cout << "[OK]\n";
    
    // Test 4: Check memory stats after compaction
    std::cout << "Test 4: Memory stats after compaction... ";
    auto stats_after = memory_stats(compact_buf);
    std::cout << "\n  Total size: " << stats_after.total_size << " bytes\n";
    std::cout << "  Used:       " << stats_after.used_size << " bytes\n";
    std::cout << "  Free:       " << stats_after.free_size << " bytes\n";
    std::cout << "  Efficiency: " << stats_after.usage_percent() << "%\n";
    
    // Verify size reduction
    assert(stats_after.total_size < stats_before.total_size);
    double reduction = (1.0 - (double)stats_after.total_size / stats_before.total_size) * 100.0;
    std::cout << "  Reduction:  " << reduction << "%\n";
    std::cout << "[OK]\n";
    
    // Test 5: Verify data integrity after compaction
    std::cout << "Test 5: Verify data integrity... ";
    auto* compact_obj = &compact_buf.unsafe_root<CompactTestType>();
    assert(compact_obj->value == 999);
    assert(compact_obj->data.size() == 100);
    assert(compact_obj->strings.size() == 20);
    assert(compact_obj->data[50] == 50);
    assert(compact_obj->strings[10] == "TestString_10");
    std::cout << "[OK]\n";
    
    // Test 6: Verify all data elements
    std::cout << "Test 6: Verify all elements... ";
    for (int i = 0; i < 100; ++i) {
        assert(compact_obj->data[i] == i);
    }
    for (int i = 0; i < 20; ++i) {
        std::string expected = "TestString_" + std::to_string(i);
        assert(compact_obj->strings[i] == expected.c_str());
    }
    std::cout << "[OK]\n";
    
    std::cout << "[PASS] All compaction tests passed!\n";
    return true;
}

int main() {
    try {
        return test_memory_compaction() ? 0 : 1;
    } catch (const std::exception& e) {
        std::cerr << "[FAIL] Exception: " << e.what() << "\n";
        return 1;
    }
}
