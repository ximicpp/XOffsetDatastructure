// ============================================================================
// XOffsetDatastructure - Comprehensive Demo (C++26 Reflection Version)
// Purpose: Showcase the main features and C++26 reflection capabilities
// ============================================================================

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include <cassert>
// Conditional chrono include to avoid Clang-14 + libstdc++-14 conflicts
#if !defined(__clang__) || __clang_major__ >= 15
#include <chrono>
#define HAS_CHRONO 1
#else
#define HAS_CHRONO 0
#endif
#include "../xoffsetdatastructure.hpp"
#include "game_data.hpp"

using namespace XOffsetDatastructure;

XOFFSET_REGISTER_SCHEMA_NAME(GameData, "example.GameData")

// ============================================================================
// Demo Utilities
// ============================================================================

void print_section(const std::string& title) {
    std::cout << "\n";
    std::cout << "+"; 
    for (int i = 0; i < 68; i++) std::cout << "=";
    std::cout << "+\n";
    std::cout << "| " << std::left << std::setw(66) << title << " |\n";
    std::cout << "+";
    for (int i = 0; i < 68; i++) std::cout << "=";
    std::cout << "+\n";
}

void print_subsection(const std::string& title) {
    std::cout << "\n+- " << title << "\n";
}

void print_check(const std::string& msg) {
    std::cout << "  [OK] " << msg << "\n";
}

void print_info(const std::string& key, const std::string& value) {
    std::cout << "  " << std::left << std::setw(20) << key << ": " << value << "\n";
}

// ============================================================================
// Demo 1: Basic Usage
// ============================================================================

void demo_basic_usage() {
    print_section("1. Basic Usage - Creating and Accessing Data");
    
    // Create buffer
    print_subsection("Creating XBuffer with 4KB");
    XBuffer xbuf(4096);
    print_check("Buffer created");
    
    // Create game data
    print_subsection("Creating Game Data");
    auto* game = xbuf.make<GameData>();
    
    // Set player data
    game->player_name = "Hero";
    game->player_id = 12345;
    game->level = 42;
    game->health = 100.0f;
    
    print_check("Player created: " + std::string(game->player_name.c_str()));
    print_info("Player ID", std::to_string(game->player_id));
    print_info("Level", std::to_string(game->level));
    print_info("Health", std::to_string(game->health));
    
    // Add items — reflection auto-injects allocator for each member
    print_subsection("Adding Items to Inventory");
    for (int i = 0; i < 5; i++) {
        game->items.emplace_back();
        auto& item = game->items.back();
        item.item_id = i + 1;
        item.item_type = i % 3;  // 0=Potion, 1=Weapon, 2=Armor
        item.quantity = (i + 1) * 10;
        std::string item_name = "Potion " + std::to_string(i+1);
        item.name = item_name.c_str();
    }
    print_check("Added " + std::to_string(game->items.size()) + " items");
    
    // Add achievements (using integers)
    print_subsection("Unlocking Achievements");
    std::vector<int> achievements = {1, 5, 10, 25, 50, 100};  // Achievement IDs
    for (int ach_id : achievements) {
        game->achievements.insert(ach_id);
    }
    print_check("Unlocked " + std::to_string(game->achievements.size()) + " achievements");
    
    // Add quest progress — string keys auto-constructed via wrapper operator[]
    print_subsection("Quest Progress");
    game->quest_progress["Main Quest"] = 75;
    game->quest_progress["Side Quest A"] = 100;
    game->quest_progress["Side Quest B"] = 50;
    print_check("Tracking " + std::to_string(game->quest_progress.size()) + " quests");
    
    // Display inventory
    print_subsection("Inventory Details");
    const char* item_types[] = {"Potion", "Weapon", "Armor"};
    for (size_t i = 0; i < game->items.size(); i++) {
        const auto& item = game->items[i];
        std::cout << "  [" << item.item_id << "] " 
                  << std::left << std::setw(15) << item.name.c_str()
                  << " x" << std::setw(3) << item.quantity
                  << " (Type: " << item_types[item.item_type] << ")\n";
    }
}

// ============================================================================
// Demo 2: Memory Management
// ============================================================================

void demo_memory_management() {
    print_section("2. Memory Management - Buffer Operations");
    
    print_subsection("Initial Buffer");
    XBuffer xbuf(1024);
    auto stats = xbuf.stats();
    print_info("Total Size", std::to_string(stats.total_size) + " bytes");
    print_info("Free Size", std::to_string(stats.free_size) + " bytes");
    print_info("Usage", std::to_string(static_cast<int>(stats.usage_percent())) + "%");
    
    print_subsection("Adding Data");
    auto* game = xbuf.make<GameData>();
    game->player_name = "TestPlayer";
    // The allocator exposes the logical extent, so grow before this batch.
    if (!xbuf.grow(8192)) throw XBadAlloc();
    for (int i = 0; i < 100; i++) {
        game->achievements.insert(i);  // Add achievement IDs
    }
    
    stats = xbuf.stats();
    print_info("After Adding Data", std::to_string(stats.used_size) + " bytes used");
    print_info("Usage", std::to_string(static_cast<int>(stats.usage_percent())) + "%");
    
    // VM growth preserves the arena base and this independently allocated root.
    // Container reserve/insert/erase may still invalidate element pointers.
    print_subsection("Growing Buffer (Stable Root Address)");
    const auto* root_before_grow = game;
    if (!xbuf.grow(4096)) throw XBadAlloc();
    assert(game == root_before_grow && game == &xbuf.root<GameData>());
    print_check("Root pointer preserved after grow()");
    stats = xbuf.stats();
    print_info("New Total Size", std::to_string(stats.total_size) + " bytes");
    print_info("Usage", std::to_string(static_cast<int>(stats.usage_percent())) + "%");
    print_check("Buffer grown successfully");
    
    print_subsection("Shrinking to Fit");
    xbuf.shrink_to_fit();
    // Logical shrink retains the reservation and enabled pages.
    assert(game == &xbuf.root<GameData>());
    stats = xbuf.stats();
    print_info("After Shrink", std::to_string(stats.total_size) + " bytes");
    print_info("Usage", std::to_string(static_cast<int>(stats.usage_percent())) + "%");
    print_check("Logical payload trimmed; enabled pages retained");
    
    // ── XHandle: Epoch-Cached Safe Handle ──
    // XHandle<T> caches the pointer + buffer epoch. On dereference it checks
    // if the epoch changed (O(1) integer comparison). If not, it returns the
    // cached pointer directly. If yes, it re-finds the root object once.
    print_subsection("XHandle - Safe Pointer Access");
    
    XBuffer hbuf(2048);
    hbuf.make<GameData>();
    
    // Create a handle — no manual pointer management needed
    auto h = hbuf.handle<GameData>();
    h->player_name = "HandleHero";
    h->level = 77;
    print_check("XHandle created, player_name = " + std::string(h->player_name.c_str()));
    
    // Growth preserves the cached root and its epoch.
    if (!hbuf.grow(4096)) throw XBadAlloc();
    print_info("After grow()", std::string("level = ") + std::to_string(h->level));
    print_check("XHandle retained the same root through grow()");
    
    // Logical shrink also preserves the cached root.
    hbuf.shrink_to_fit();
    print_info("After shrink()", std::string("player_name = ") + std::string(h->player_name.c_str()));
    print_check("XHandle survived shrink_to_fit()");
    
    // make_handle() — create + handle in one call
    XBuffer hbuf2(1024);
    auto h2 = hbuf2.make_handle<GameData>();
    h2->player_name = "OneCall";
    h2->level = 42;
    print_check("make_handle() — create + handle in one step");
    print_info("Result", std::string(h2->player_name.c_str()) + " (Level " + std::to_string(h2->level) + ")");
}

// ============================================================================
// Demo 3: Serialization
// ============================================================================

void demo_serialization() {
    print_section("3. Serialization - Save and Load");
    
    print_subsection("Creating Source Data");
    XBuffer src_buf(2048);
    auto* src_game = src_buf.make<GameData>();
    src_game->player_name = "SavedHero";
    src_game->player_id = 99999;
    src_game->level = 99;
    src_game->health = 100.0f;
    
    print_check("Created game state");
    print_info("Player", std::string(src_game->player_name.c_str()));
    print_info("Player ID", std::to_string(src_game->player_id));
    print_info("Level", std::to_string(src_game->level));
    
    print_subsection("Serializing to Binary");
    std::string binary_data = src_buf.save_verified<GameData>();
    print_check("Serialized to " + std::to_string(binary_data.size()) + " bytes");
    
    print_subsection("Deserializing from Binary");
    XBuffer dst_buf = XBuffer::load_verified<GameData>(binary_data);
    
    if (dst_buf.has_root<GameData>()) {
        auto& dst_game = dst_buf.root<GameData>();
        print_check("Deserialization successful!");
        print_info("Player", std::string(dst_game.player_name.c_str()));
        print_info("Player ID", std::to_string(dst_game.player_id));
        print_info("Level", std::to_string(dst_game.level));
        
        // Verify integrity
        bool integrity_ok = (
            std::string(dst_game.player_name.c_str()) == "SavedHero" &&
            dst_game.player_id == 99999 &&
            dst_game.level == 99
        );
        
        if (integrity_ok) {
            print_check("Data integrity verified");
        }
    } else {
        std::cout << "  [FAIL] Deserialization failed\n";
    }
}

// ============================================================================
// Demo 4: C++26 Reflection Type Signatures
// ============================================================================

void demo_type_signatures() {
    print_section("4. C++26 Reflection - Type Signature System");
    
    print_subsection("Reflection Capability");
    
    std::cout << "  Status: [OK] C++26 Reflection ENABLED\n\n";
    
    print_info("Feature Macro", "__cpp_reflection >= 202306L");
    print_info("Implementation", "std::meta namespace");
    print_info("Key Operations", "members_of, offset_of, type_of");
    
    print_subsection("Type Signature Display (via boost::typelayout)");
    
    // Display Item definition signature
    constexpr auto item_sig = boost::typelayout::get_layout_signature<Item>();
    std::cout << "  Item (definition):\n    " << item_sig.value << "\n\n";
    
    // Display GameData definition signature
    constexpr auto game_sig = boost::typelayout::get_layout_signature<GameData>();
    std::cout << "  GameData (definition):\n    " << game_sig.value << "\n";
    
    print_subsection("Key Advantages over Boost.PFR (next_practical)");
    print_check("No code generation required");
    print_check("No separate ReflectionHint types");
    print_check("Direct type introspection with constructors");
    print_check("Compiler-provided offset accuracy");
    print_check("std::meta::members_of - iterate fields at compile-time");
    print_check("std::meta::offset_of - direct offset access");
    print_check("template for - compile-time member iteration");
    
    print_subsection("Compile-Time Safety");
    print_check("Binary compatibility across compilations");
    print_check("Automatic verification (no manual checks)");
    print_check("Prevents data corruption from layout changes");
    print_check("Type-safe offset calculations");
}

// ============================================================================
// Demo 5: Automatic Memory Compaction (C++26 Reflection)
// ============================================================================

void demo_automatic_compaction() {
    print_section("5. Automatic Memory Compaction (C++26 Reflection)");
    
    print_subsection("Creating Fragmented Buffer");
    XBuffer xbuf(8192);  // 8KB buffer
    
    // Create game data with items
    auto* game = xbuf.make<GameData>();
    game->player_name = "FragmentedHero";
    game->player_id = 77777;
    game->level = 50;
    game->health = 85.5f;
    
    // Add items — reflection auto-injects allocator
    for (int i = 0; i < 20; i++) {
        game->items.emplace_back();
        auto& item = game->items.back();
        item.item_id = i;
        item.item_type = i % 3;
        item.quantity = i * 5;
        std::string item_name = "Item_" + std::to_string(i);
        item.name = item_name.c_str();
    }
    
    // Add achievements
    for (int i = 0; i < 50; i++) {
        game->achievements.insert(i);
    }
    
    auto stats_before = xbuf.stats();
    print_info("Total Size", std::to_string(stats_before.total_size) + " bytes");
    print_info("Used Size", std::to_string(stats_before.used_size) + " bytes");
    print_info("Free Size", std::to_string(stats_before.free_size) + " bytes");
    print_info("Usage", std::to_string(static_cast<int>(stats_before.usage_percent())) + "%");
    
    print_subsection("Creating Fragmentation");
    // Remove some items to create holes
    game->items.pop_back();
    game->items.pop_back();
    game->items.pop_back();
    
    auto stats_frag = xbuf.stats();
    print_info("After Deletions", std::to_string(stats_frag.used_size) + " bytes used");
    print_info("Fragmented Space", std::to_string(stats_frag.free_size) + " bytes free");
    print_check("Buffer is now fragmented");
    
    print_subsection("Automatic Compaction (C++26 Reflection)");
    std::cout << "  Using XCompactor::compact<GameData>()\n\n";
    
    // Compact using C++26 reflection — returns XBuffer directly
    XBuffer compacted = XCompactor::compact<GameData>(xbuf);
    
    auto stats_after = compacted.stats();
    long long size_delta =
        static_cast<long long>(stats_before.total_size) -
        static_cast<long long>(stats_after.total_size);
    print_info("Compacted Size", std::to_string(stats_after.total_size) + " bytes");
    print_info("Used Size", std::to_string(stats_after.used_size) + " bytes");
    print_info("Efficiency", std::to_string(static_cast<int>(stats_after.usage_percent())) + "%");
    if (size_delta >= 0) {
        print_info("Saved Memory", std::to_string(size_delta) + " bytes");
    } else {
        print_info("Size Change", "+" + std::to_string(-size_delta) + " bytes");
    }
    print_check("Memory compacted successfully!");
    
    print_subsection("Data Integrity Verification");
    if (compacted.has_root<GameData>()) {
        auto& compacted_game = compacted.root<GameData>();
        bool integrity_ok = (
            std::string(compacted_game.player_name.c_str()) == "FragmentedHero" &&
            compacted_game.player_id == 77777 &&
            compacted_game.level == 50 &&
            compacted_game.items.size() == 17 &&  // 20 - 3 removed
            compacted_game.achievements.size() == 50
        );
        
        if (integrity_ok) {
            print_check("All data verified after compaction");
            print_info("Player Name", std::string(compacted_game.player_name.c_str()));
            print_info("Items Count", std::to_string(compacted_game.items.size()));
            print_info("Achievements", std::to_string(compacted_game.achievements.size()));
        } else {
            std::cout << "  [FAIL] Data integrity check failed\n";
        }
    }
    
    print_subsection("How It Works (C++26 Reflection)");
    print_check("std::meta::members_of - Iterate all fields at compile-time");
    print_check("std::meta::type_of - Detect field types (POD, containers, nested)");
    print_check("Automatic recursive migration - No manual migrate() needed");
    print_check("Type-safe - Compiler ensures correctness");
    print_check("Zero runtime discovery - All done at compile-time");
}

// ============================================================================
// Demo 6: Performance Insights
// ============================================================================

void demo_performance() {
    print_section("6. Performance Characteristics");
    
    print_subsection("Container Growth Strategy");
    print_info("Growth Factor", "1.1x (10% incremental)");
    print_info("Benefit", "Reduced memory overhead");
    print_info("Trade-off", "More frequent reallocations");
    
    print_subsection("Memory Layout");
    print_info("Allocator", "Sequential-fit (fast)");
    print_info("Alignment", "8-byte (BASIC_ALIGNMENT)");
    print_info("Pointers", "Relative offsets; stable arena base");
    
    print_subsection("Platform Requirements");
    print_info("Architecture", "64-bit only");
    print_info("Byte Order", "Little-endian");
    print_info("Compatibility", "x86-64, ARM64");
    
    print_subsection("Benchmarking Example");
    XBuffer xbuf(65536);  // 64KB buffer for 1000 items
    
#if HAS_CHRONO
    auto start = std::chrono::high_resolution_clock::now();
#endif
    
    // Insert 1000 items — reflection auto-injects allocator
    auto* game = xbuf.make<GameData>();
    game->items.reserve(1000);
    for (int i = 0; i < 1000; i++) {
        game->items.emplace_back();
        auto& item = game->items.back();
        item.item_id = i;
        item.item_type = i % 3;
        item.quantity = i;
        std::string item_name = "Item_" + std::to_string(i);
        item.name = item_name.c_str();
    }
    
#if HAS_CHRONO
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    
    print_info("Operations", "1000 item insertions");
    print_info("Time", std::to_string(duration.count()) + " us");
    print_info("Avg per Item", std::to_string(duration.count() / 1000.0) + " us");
#else
    print_info("Operations", "1000 item insertions");
    print_info("Note", "Timing skipped (chrono unavailable on this compiler)");
#endif
}

// ============================================================================
// Demo 7: Advanced Features
// ============================================================================

void demo_advanced_features() {
    print_section("7. Advanced Features & Comparisons");
    
    print_subsection("Container Types");
    print_check("XVector<T> - Dynamic array (like std::vector)");
    print_check("XSet<T> - Unique elements (flat_set implementation)");
    print_check("XMap<K,V> - Key-value pairs (flat_map implementation)");
    print_check("XString - Offset-aware string container");
    
    print_subsection("next_cpp26 vs next_practical");
    std::cout << "\n";
    std::cout << "  +---------------------+-------------------+---------------------+\n";
    std::cout << "  | Feature             | next_practical    | next_cpp26          |\n";
    std::cout << "  +---------------------+-------------------+---------------------+\n";
    std::cout << "  | Reflection          | Boost.PFR         | C++26 std::meta     |\n";
    std::cout << "  | Code Generation     | Required (Python) | Not needed          |\n";
    std::cout << "  | ReflectionHint      | Required          | Not needed          |\n";
    std::cout << "  | Field Offset        | Manual calculation| std::meta::offset_of|\n";
    std::cout << "  | Member Iteration    | Template recursion| template for        |\n";
    std::cout << "  | External Deps       | Boost.PFR         | None (stdlib)       |\n";
    std::cout << "  | Compiler Support    | GCC/Clang/MSVC    | C++26 required      |\n";
    std::cout << "  +---------------------+-------------------+---------------------+\n";
    
    print_subsection("Memory Features");
    print_check("Dynamic buffer growth");
    print_check("Shrink-to-fit optimization");
    print_check("Memory usage statistics");
    print_check("Zero-decode loading into a copied, validated VM payload");
    
    print_subsection("C++26 Reflection Features (Active)");
    print_check("std::meta::members_of - Get all struct members");
    print_check("std::meta::offset_of - Direct field offset");
    print_check("std::meta::type_of - Get member type");
    print_check("std::meta::name_of - Get member name (debugging)");
    print_check("template for - Compile-time iteration");
    print_check("Direct struct introspection (no aggregates needed)");
}

// ============================================================================
// Main Demo Entry Point
// ============================================================================

int main() {
    std::cout << R"(
+======================================================================+
|                                                                      |
|     XOffsetDatastructure - Comprehensive Demo (C++26 Edition)      |
|                                                                      |
|     Offset-Based Data Structures with C++26 Reflection              |
|                                                                      |
+======================================================================+
)";

    std::cout << "  [OK] C++26 Reflection: ENABLED\n";
    std::cout << "\n";

    try {
        // Run all demos
        demo_basic_usage();
        demo_memory_management();
        demo_serialization();
        demo_type_signatures();
        demo_automatic_compaction();
        demo_performance();
        demo_advanced_features();
        
        // Summary
        print_section("Demo Complete");
        std::cout << "\n";
        std::cout << "  * All demonstrations completed successfully!\n";
        std::cout << "\n";
        std::cout << "  For more information:\n";
        std::cout << "     - Overview: README.md\n";
        std::cout << "     - Examples: examples/\n";
        std::cout << "     - Tests: tests/\n";
        std::cout << "\n";
        std::cout << "  Key Takeaways (next_cpp26):\n";
        std::cout << "     - C++26 reflection-based type signatures\n";
        std::cout << "     - No code generation required\n";
        std::cout << "     - Direct type introspection\n";
        std::cout << "     - Zero-decode serialization with explicit output copies\n";
        std::cout << "     - Memory-efficient growth strategy\n";
        std::cout << "\n";
        
        return 0;
        
    } catch (const std::exception& e) {
        std::cerr << "\n[ERROR] " << e.what() << "\n";
        return 1;
    }
}
