// ============================================================================
// XOffsetDatastructure Hello World Demo (C++26 Reflection Version)
// Purpose: Simple introduction to basic usage
// ============================================================================

#include <iostream>
#include <iomanip>
#include "../xoffsetdatastructure.hpp"
#include "player.hpp"

using namespace XOffsetDatastructure;

XOFFSET_REGISTER_SCHEMA_NAME(Player, "example.Player")

int main() {
    std::cout << "\n=== XOffsetDatastructure Hello World (C++26) ===\n\n";
    
    // 1. Create buffer
    std::cout << "1. Creating buffer...\n";
    XBuffer xbuf(4096);
    
    // 2. Create an object
    std::cout << "2. Creating player...\n";
    auto* player = xbuf.make<Player>();
    player->id = 1;
    player->level = 10;
    player->name = "Alice";
    
    // 3. Add some data
    std::cout << "3. Adding items...\n";
    player->items.push_back(101);
    player->items.push_back(102);
    player->items.push_back(103);
    
    // 4. Display data
    std::cout << "4. Player info:\n";
    std::cout << "   Name: " << player->name << "\n";
    std::cout << "   ID: " << player->id << ", Level: " << player->level << "\n";
    std::cout << "   Items: ";
    for (int item : player->items) {
        std::cout << item << " ";
    }
    std::cout << "\n";
    
    // 5. Serialize to string (shrinks first for compact output)
    std::cout << "\n5. Serializing...\n";
    auto data = xbuf.save_verified<Player>();
    std::cout << "   Serialized size: " << data.size() << " bytes\n";
    
    // 6. Deserialize from string
    std::cout << "6. Deserializing...\n";
    XBuffer loaded = XBuffer::load_verified<Player>(data);
    if (loaded.has_root<Player>()) {
        auto& loaded_player = loaded.root<Player>();
        std::cout << "   Loaded player: " << loaded_player.name 
                  << " (Level " << loaded_player.level << ")\n";
        std::cout << "   Items count: " << loaded_player.items.size() << "\n";
    }
    
    // 7. Memory Statistics
    std::cout << "\n7. Memory statistics before compaction:\n";
    auto stats_before = xbuf.stats();
    std::cout << "   Total size: " << stats_before.total_size << " bytes\n";
    std::cout << "   Used size: " << stats_before.used_size << " bytes\n";
    std::cout << "   Free size: " << stats_before.free_size << " bytes\n";
    std::cout << "   Usage: " << std::fixed << std::setprecision(1) 
              << stats_before.usage_percent() << "%\n";
    
    // 8. Memory Compaction Demo (C++26 only)
    std::cout << "\n8. Memory Compaction:\n";
    std::cout << "   [OK] C++26 reflection: ENABLED\n";
    std::cout << "   [OK] Automatic memory compaction available\n\n";
    
    // Create some fragmentation by adding and removing data
    std::cout << "   Creating fragmentation...\n";
    // Saving normalized the logical length; expose more bytes before mutation.
    if (!xbuf.grow(4096)) throw XBadAlloc();
    player->items.push_back(201);
    player->items.push_back(202);
    player->items.push_back(203);
    player->items.pop_back();
    player->items.pop_back();
    
    // Show stats after fragmentation
    auto stats_frag = xbuf.stats();
    std::cout << "   After operations - Used: " << stats_frag.used_size 
              << " bytes (" << std::setprecision(1) << stats_frag.usage_percent() << "%)\n";
    
    // Compact the buffer — returns XBuffer directly
    std::cout << "\n   Compacting buffer...\n";
    XBuffer compacted = XCompactor::compact<Player>(xbuf);
    
    // Show stats after compaction
    auto stats_after = compacted.stats();
    long long size_delta =
        static_cast<long long>(stats_before.total_size) -
        static_cast<long long>(stats_after.total_size);
    std::cout << "   After compaction:\n";
    std::cout << "   - Total size: " << stats_after.total_size << " bytes\n";
    std::cout << "   - Used size: " << stats_after.used_size << " bytes\n";
    if (size_delta >= 0) {
        std::cout << "   - Saved: " << size_delta << " bytes\n";
    } else {
        std::cout << "   - Size change: +" << -size_delta << " bytes\n";
    }
    std::cout << "   - Efficiency: " << std::setprecision(1) 
              << stats_after.usage_percent() << "%\n";
    
    // Verify data integrity after compaction
    if (compacted.has_root<Player>()) {
        auto& compacted_player = compacted.root<Player>();
        std::cout << "\n   [OK] Data integrity verified:\n";
        std::cout << "     Name: " << compacted_player.name << "\n";
        std::cout << "     Level: " << compacted_player.level << "\n";
        std::cout << "     Items: ";
        for (int item : compacted_player.items) {
            std::cout << item << " ";
        }
        std::cout << "\n";
    }
    
    // 9. Show type signature (compile-time calculated via boost::typelayout)
    std::cout << "\n9. Type Signature (compile-time, zero runtime cost):\n";
    std::cout << "   Player definition signature:\n   ";
    constexpr auto sig = boost::typelayout::get_layout_signature<Player>();
    std::cout << sig.value;
    std::cout << "\n\n   Explanation:\n";
    std::cout << "   - [64-le]: 64-bit little-endian platform\n";
    std::cout << "   - record[s:72,a:8]: Size 72 bytes, aligned to 8 bytes\n";
    std::cout << "   - @0[id]:i32:  Field 'id' at offset 0\n";
    std::cout << "   - @4[level]:i32:  Field 'level' at offset 4\n";
    std::cout << "   - @8[name]:...:  Field 'name' (XString) at offset 8\n";
    std::cout << "   - @40[items]:...: Field 'items' (XVector) at offset 40\n";
    std::cout << "\n   [OK] Type signature matches memory layout!\n";
    
    std::cout << "\n=== Done! ===\n\n";
    return 0;
}
