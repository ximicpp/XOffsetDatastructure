// Shared source compiled unchanged against every version. Checks survive NDEBUG.
#include "xoffsetdatastructure.hpp"
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>

using namespace XOffsetDatastructure;
struct WireMatrixItem {
    std::int32_t id{};
    XString text;
    XVector<std::int32_t> values;
};
struct WireMatrixRoot {
    std::uint32_t phase{};
    XVector<std::int32_t> numbers;
    XString text;
    XVector<WireMatrixItem> items;
    XVector<std::int64_t> terminal;
    XVector<XVector<std::uint8_t>> reuse_rows;
};
XOFFSET_REGISTER_SCHEMA_NAME(WireMatrixRoot, "vm.improvement.WireMatrix.v1")

void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
std::string expected_text(std::uint32_t phase) {
    return std::string(257 + phase * 137, static_cast<char>('a' + phase));
}
void verify(WireMatrixRoot& r, std::uint32_t phase) {
    require(r.phase == phase, "phase");
    require(r.text == expected_text(phase), "text");
    require(r.numbers.size() == 193 + phase * 73, "numbers size");
    for (std::uint32_t i = 0; i < r.numbers.size(); ++i)
        require(r.numbers[i] == static_cast<std::int32_t>(i * 17 - 301), "numbers value");
    require(r.items.size() == 9 + phase * 3, "items size");
    for (std::uint32_t i = 0; i < r.items.size(); ++i) {
        auto& item = r.items[i];
        require(item.id == static_cast<std::int32_t>(i + 100), "item id");
        require(item.text == std::string(41 + i * 3, static_cast<char>('A' + i)), "item text");
        require(item.values.size() == 11 + i, "item values size");
        for (std::uint32_t j = 0; j < item.values.size(); ++j)
            require(item.values[j] == static_cast<std::int32_t>(i * 31 + j), "item value");
    }
    require(r.terminal.size() == 513 + phase * 101, "terminal size");
    for (std::uint32_t i = 0; i < r.terminal.size(); ++i)
        require(r.terminal[i] == static_cast<std::int64_t>(i) * 10000003 - 77, "terminal value");
    require(r.reuse_rows.size() == 8, "reuse row count");
    for (std::uint32_t i = 0; i < r.reuse_rows.size(); ++i) {
        require(r.reuse_rows[i].size() == 64 + phase, "reuse row size");
        for (std::uint32_t j = 0; j < r.reuse_rows[i].size(); ++j)
            require(r.reuse_rows[i][j] == static_cast<std::uint8_t>(phase * 17 + i * 23 + j),
                    "reuse row value");
    }
}

void reset_row(XVector<std::uint8_t>& row) {
    const auto allocator = row.binding();
    std::destroy_at(&row);
    std::construct_at(&row, allocator);
}

void fill_reuse(WireMatrixRoot& r, std::uint32_t phase) {
    if (r.reuse_rows.empty()) {
        r.reuse_rows.reserve(8);
        for (unsigned i = 0; i < 8; ++i) r.reuse_rows.emplace_back();
    }
    for (auto& row : r.reuse_rows) reset_row(row);
    // Retire one large physical block, then exercise smaller reuse requests.
    // This also creates split layouts when an experimental split allocator is used.
    r.reuse_rows[0].reserve(4096u << phase);
    reset_row(r.reuse_rows[0]);
    for (auto& row : r.reuse_rows) row.reserve(256 + phase * 16);
    // Transfer adjacent retired allocations from the wire cache into Core,
    // then request different sizes. Semantics must survive every allocator policy.
    reset_row(r.reuse_rows[1]);
    reset_row(r.reuse_rows[2]);
    fixed_detail::release_cached_blocks(
        fixed_detail::allocator_ref_of(r.reuse_rows.binding()).state);
    r.reuse_rows[1].reserve(400 + phase * 32);
    r.reuse_rows[2].reserve(96 + phase * 8);
    for (std::uint32_t i = 0; i < r.reuse_rows.size(); ++i)
        for (std::uint32_t j = 0; j < 64 + phase; ++j)
            r.reuse_rows[i].push_back(static_cast<std::uint8_t>(phase * 17 + i * 23 + j));
}

void fill(WireMatrixRoot& r, std::uint32_t phase) {
    fill_reuse(r, phase);
    // Exercise tail reserve first, then non-tail reserve after interleaved storage.
    for (std::size_t cap : {4u, 8u, 32u, 128u, 256u, 512u})
        r.numbers.reserve(cap);
    for (std::uint32_t i = r.numbers.size(); i < 193 + phase * 73; ++i)
        r.numbers.push_back(static_cast<std::int32_t>(i * 17 - 301));
    for (std::size_t cap : {8u, 32u, 128u, 512u, 1024u}) r.text.reserve(cap);
    r.text = expected_text(phase);
    for (std::uint32_t i = r.items.size(); i < 9 + phase * 3; ++i) {
        auto& item = r.items.emplace_back();
        item.id = static_cast<std::int32_t>(i + 100);
        item.text = std::string(41 + i * 3, static_cast<char>('A' + i));
        for (std::uint32_t j = 0; j < 11 + i; ++j)
            item.values.push_back(static_cast<std::int32_t>(i * 31 + j));
    }
    // This last allocation is intentionally enlarged several times in place on V2.
    for (std::size_t cap : {4u, 16u, 64u, 256u, 1024u}) r.terminal.reserve(cap);
    // Enlarge again on each post-load mutation, after interleaved nested allocations.
    r.terminal.reserve(1024u << phase);
    r.terminal.reserve(1536u << phase);
    for (std::uint32_t i = r.terminal.size(); i < 513 + phase * 101; ++i)
        r.terminal.push_back(static_cast<std::int64_t>(i) * 10000003 - 77);
    r.phase = phase;
    verify(r, phase);
}
std::string read_file(const char* path) {
    std::ifstream input(path, std::ios::binary | std::ios::ate);
    require(static_cast<bool>(input), "input open");
    auto length = input.tellg();
    require(length >= 0 && length <= 16 * 1024 * 1024, "input size");
    std::string bytes(static_cast<std::size_t>(length), '\0');
    input.seekg(0);
    input.read(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    require(input.gcount() == static_cast<std::streamsize>(bytes.size()), "input read");
    return bytes;
}
void write_file(const char* path, const std::string& bytes) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output.write(bytes.data(), static_cast<std::streamsize>(bytes.size()));
    require(static_cast<bool>(output), "output write");
}
int main(int argc, char** argv) {
    try {
        require(argc >= 3, "arguments");
        if (std::string_view(argv[1]) == "seed") {
            auto buffer = TypedXBuffer<WireMatrixRoot>::create(256 * 1024);
            fill(buffer.root(), 0);
            auto bytes = buffer.save_verified();
            write_file(argv[2], bytes);
            auto roundtrip = TypedXBuffer<WireMatrixRoot>::load(bytes);
            verify(roundtrip.root(), 0);
            std::cout << "seed phase=0 bytes=" << bytes.size() << '\n';
            return 0;
        }
        require(argc >= 4, "phase argument");
        const auto phase = static_cast<std::uint32_t>(std::stoul(argv[3]));
        require(phase <= 2, "phase range");
        auto buffer = TypedXBuffer<WireMatrixRoot>::load(read_file(argv[2]));
        verify(buffer.root(), phase);
        if (std::string_view(argv[1]) == "mutate") {
            require(argc == 5 && phase < 2, "mutate arguments");
            require(buffer.grow(256 * 1024), "grow after load");
            fill(buffer.root(), phase + 1);
            const auto bytes = buffer.save_verified();
            write_file(argv[4], bytes);
            auto roundtrip = TypedXBuffer<WireMatrixRoot>::load(bytes);
            verify(roundtrip.root(), phase + 1);
            require(roundtrip.grow(256 * 1024), "grow after resave");
            roundtrip.root().numbers.push_back(1234567);
            require(roundtrip.root().numbers.back() == 1234567, "second continued mutation");
            std::cout << "mutate phase=" << phase + 1 << " bytes=" << bytes.size() << '\n';
        } else {
            require(std::string_view(argv[1]) == "check", "operation");
            std::cout << "check phase=" << phase << " numbers=" << buffer.root().numbers.size()
                      << " items=" << buffer.root().items.size() << '\n';
        }
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "wire matrix failed: " << error.what() << '\n';
        return 1;
    }
}
