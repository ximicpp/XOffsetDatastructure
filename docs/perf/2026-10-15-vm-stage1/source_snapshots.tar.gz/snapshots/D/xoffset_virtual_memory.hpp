#pragma once

#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <new>
#include <stdexcept>
#include <utility>

#if defined(_WIN32)
#  ifndef NOMINMAX
#    define NOMINMAX
#  endif
#  include <windows.h>
#elif defined(__linux__) || defined(__APPLE__)
#  include <sys/mman.h>
#  include <unistd.h>
#else
#  error "XOffset virtual memory storage requires Windows, Linux, or macOS"
#endif

namespace XOffsetDatastructure {
namespace detail {

// Deterministic, thread-local, one-shot failure injection. Enable is consumed
// only when additional pages are required; Prepare precedes logical publication.
enum class VmOperation : std::uint8_t { Reserve, Enable, Prepare };

inline thread_local unsigned vm_pending_failures = 0;

inline unsigned vm_operation_bit(VmOperation operation) noexcept {
    switch (operation) {
        case VmOperation::Reserve: return 1u;
        case VmOperation::Enable: return 2u;
        case VmOperation::Prepare: return 4u;
    }
    return 0;
}

inline void fail_next_vm_operation(VmOperation operation) noexcept {
    vm_pending_failures |= vm_operation_bit(operation);
}

inline void clear_vm_failures() noexcept { vm_pending_failures = 0; }

inline bool consume_vm_failure(VmOperation operation) noexcept {
    const unsigned bit = vm_operation_bit(operation);
    const bool fail = (vm_pending_failures & bit) != 0;
    vm_pending_failures &= ~bit;
    return fail;
}

inline bool checked_vm_round_up(std::size_t bytes, std::size_t alignment,
                                std::size_t& rounded) noexcept {
    if (alignment == 0) return false;
    const std::size_t remainder = bytes % alignment;
    const std::size_t extra = remainder == 0 ? 0 : alignment - remainder;
    if (bytes > (std::numeric_limits<std::size_t>::max)() - extra) return false;
    rounded = bytes + extra;
    return true;
}

// OS storage only: no allocator metadata or process-local information is stored
// in the reservation. Accessible means page permissions are read/write; it does
// not measure resident physical memory or promise future fault-free allocation.
class VirtualMemoryStorage {
public:
    VirtualMemoryStorage() noexcept = default;

    VirtualMemoryStorage(std::size_t logical_bytes, std::size_t maximum_capacity) {
        if (logical_bytes > maximum_capacity) {
            throw std::invalid_argument("VM initial length exceeds maximum capacity");
        }
        if (maximum_capacity > static_cast<std::size_t>(
                (std::numeric_limits<std::ptrdiff_t>::max)())) {
            throw std::length_error("VM capacity exceeds pointer difference range");
        }
        query_page_geometry();
        std::size_t reserved = 0;
        if (!checked_vm_round_up(maximum_capacity, page_size_, reserved) ||
            reserved > static_cast<std::size_t>(
                (std::numeric_limits<std::ptrdiff_t>::max)())) {
            throw std::length_error("VM reservation page rounding overflows");
        }
        maximum_capacity_ = maximum_capacity;
        if (reserved == 0) return;
        if (consume_vm_failure(VmOperation::Reserve)) throw std::bad_alloc();
#if defined(_WIN32)
        base_ = static_cast<char*>(::VirtualAlloc(
            nullptr, reserved, MEM_RESERVE, PAGE_NOACCESS));
        if (!base_) throw std::bad_alloc();
#else
        void* mapping = ::mmap(nullptr, reserved, PROT_NONE,
                               MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (mapping == MAP_FAILED) throw std::bad_alloc();
        base_ = static_cast<char*>(mapping);
#endif
        reserved_bytes_ = reserved;
        // A throwing constructor does not run this object's destructor.
        if (!grow_to(logical_bytes)) {
            release();
            throw std::bad_alloc();
        }
    }

    // Internal fresh-owner load path. A complete copy initializes every logical
    // byte; normal growth (including reused pages after shrink) still zeroes.
    static VirtualMemoryStorage from_bytes(const char* bytes, std::size_t length,
                                           std::size_t maximum_capacity) {
        if (length > maximum_capacity) {
            throw std::invalid_argument("VM input length exceeds maximum capacity");
        }
        if (length != 0 && bytes == nullptr) {
            throw std::invalid_argument("VM input is null");
        }
        VirtualMemoryStorage owner(0, maximum_capacity);
        if (length == 0) return owner;
        if (!owner.enable_prefix(length) || consume_vm_failure(VmOperation::Prepare)) {
            throw std::bad_alloc();
        }
        std::memcpy(owner.base_, bytes, length);
        owner.logical_bytes_ = length;
        return owner;
    }

    ~VirtualMemoryStorage() { release(); }

    VirtualMemoryStorage(const VirtualMemoryStorage&) = delete;
    VirtualMemoryStorage& operator=(const VirtualMemoryStorage&) = delete;

    VirtualMemoryStorage(VirtualMemoryStorage&& other) noexcept { swap(other); }

    VirtualMemoryStorage& operator=(VirtualMemoryStorage&& other) noexcept {
        if (this != &other) {
            VirtualMemoryStorage old(std::move(other));
            swap(old);
        }
        return *this;
    }

    char* data() noexcept { return base_; }
    const char* data() const noexcept { return base_; }
    std::size_t size() const noexcept { return logical_bytes_; }
    std::size_t logical_bytes() const noexcept { return logical_bytes_; }
    std::size_t capacity() const noexcept { return maximum_capacity_; }
    std::size_t maximum_capacity() const noexcept { return maximum_capacity_; }
    std::size_t reserved_bytes() const noexcept { return reserved_bytes_; }
    std::size_t accessible_bytes() const noexcept { return accessible_bytes_; }
    std::size_t page_size() const noexcept { return page_size_; }
    std::size_t reservation_granularity() const noexcept { return reservation_granularity_; }
    bool empty() const noexcept { return logical_bytes_ == 0; }

    // A failed growth retains all old bytes and the old logical length. Pages
    // enabled before a Prepare failure remain accurately recorded, but are not
    // published to the upper allocator. Only newly exposed bytes are zeroed.
    bool grow_to(std::size_t new_logical_bytes) noexcept {
        if (new_logical_bytes < logical_bytes_ ||
            new_logical_bytes > maximum_capacity_) return false;
        if (new_logical_bytes == logical_bytes_) return true;
        if (!enable_prefix(new_logical_bytes)) return false;
        if (consume_vm_failure(VmOperation::Prepare)) return false;
        std::memset(base_ + logical_bytes_, 0, new_logical_bytes - logical_bytes_);
        logical_bytes_ = new_logical_bytes;
        return true;
    }

    // Logical shrink keeps the reservation and page permissions. Regrowth
    // zeroes the newly exposed range even when it lies in previously used pages.
    void resize_logical(std::size_t new_logical_bytes) {
        if (new_logical_bytes > maximum_capacity_) {
            throw std::length_error("VM length exceeds maximum capacity");
        }
        if (new_logical_bytes <= logical_bytes_) {
            logical_bytes_ = new_logical_bytes;
        } else if (!grow_to(new_logical_bytes)) {
            throw std::bad_alloc();
        }
    }

    void swap(VirtualMemoryStorage& other) noexcept {
        using std::swap;
        swap(base_, other.base_);
        swap(reserved_bytes_, other.reserved_bytes_);
        swap(maximum_capacity_, other.maximum_capacity_);
        swap(accessible_bytes_, other.accessible_bytes_);
        swap(logical_bytes_, other.logical_bytes_);
        swap(page_size_, other.page_size_);
        swap(reservation_granularity_, other.reservation_granularity_);
    }

    friend void swap(VirtualMemoryStorage& lhs, VirtualMemoryStorage& rhs) noexcept {
        lhs.swap(rhs);
    }

private:
    // Publish permissions separately from logical bytes. Both initialization
    // paths keep an accurate accessible extent if preparation later fails.
    bool enable_prefix(std::size_t new_logical_bytes) noexcept {
        std::size_t new_accessible_bytes = 0;
        if (!checked_vm_round_up(new_logical_bytes, page_size_, new_accessible_bytes) ||
            new_accessible_bytes > reserved_bytes_) return false;
        if (new_accessible_bytes > accessible_bytes_) {
            if (consume_vm_failure(VmOperation::Enable)) return false;
            const std::size_t extra = new_accessible_bytes - accessible_bytes_;
#if defined(_WIN32)
            void* committed = ::VirtualAlloc(base_ + accessible_bytes_, extra,
                                             MEM_COMMIT, PAGE_READWRITE);
            if (!committed) return false;
#else
            // This owner keeps a read/write prefix and one contiguous PROT_NONE
            // tail. Enabling its prefix does not traverse multiple VMAs with
            // different attributes. External protection or mapping changes to
            // this reservation are unsupported; mprotect over arbitrary VMAs
            // need not roll back earlier VMA changes when a later one fails.
            if (::mprotect(base_ + accessible_bytes_, extra,
                           PROT_READ | PROT_WRITE) != 0) return false;
#endif
            accessible_bytes_ = new_accessible_bytes;
        }
        return true;
    }
    void query_page_geometry() {
#if defined(_WIN32)
        SYSTEM_INFO info{};
        ::GetSystemInfo(&info);
        page_size_ = static_cast<std::size_t>(info.dwPageSize);
        reservation_granularity_ = static_cast<std::size_t>(info.dwAllocationGranularity);
#else
        const long page = ::sysconf(_SC_PAGESIZE);
        if (page <= 0) throw std::bad_alloc();
        page_size_ = static_cast<std::size_t>(page);
        reservation_granularity_ = page_size_;
#endif
        if (page_size_ == 0 || reservation_granularity_ == 0) throw std::bad_alloc();
    }

    void release() noexcept {
        if (base_) {
#if defined(_WIN32)
            ::VirtualFree(base_, 0, MEM_RELEASE);
#else
            ::munmap(base_, reserved_bytes_);
#endif
        }
        base_ = nullptr;
        reserved_bytes_ = maximum_capacity_ = accessible_bytes_ = logical_bytes_ = 0;
        page_size_ = reservation_granularity_ = 0;
    }

    char* base_{nullptr};
    std::size_t reserved_bytes_{0};
    std::size_t maximum_capacity_{0};
    std::size_t accessible_bytes_{0};
    std::size_t logical_bytes_{0};
    std::size_t page_size_{0};
    std::size_t reservation_granularity_{0};
};

} // namespace detail
} // namespace XOffsetDatastructure
