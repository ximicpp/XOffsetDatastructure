## XOffset / baseline, t1 / t0 (default build)

| case | baseline | class | t0 GM | t1 GM | t1 / t0 | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.726 | 0.725 | 0.998 | 0.995–1.000 | 0.995, 1.000 |  |
| hero.mid_insert.ord | std::vector | G9 | 0.759 | 0.756 | 0.996 | 0.992–0.999 | 0.997, 0.994 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.366 | 0.367 | 1.002 | 0.999–1.005 | 1.005, 0.999 |  |
| map.erase.fresh | std::flat_map | G9 | 0.936 | 0.940 | 1.004 | 1.001–1.007 | 1.007, 1.002 | worse |
| map.find.fresh | std::flat_map | G9 | 0.807 | 0.808 | 1.001 | 0.998–1.004 | 0.999, 1.003 |  |
| map.insert.fresh | std::flat_map | G9 | 0.869 | 0.869 | 1.000 | 0.997–1.003 | 0.993, 1.007 |  |
| nested.build.ord | std | G9 | 0.327 | 0.318 | 0.972 | 0.967–0.977 | 1.000, 0.944 |  |
| reset | std | G9 | 0.254 | 0.237 | 0.934 | 0.926–0.941 | 0.948, 0.919 |  |
| set.erase.fresh | std::flat_set | G9 | 1.085 | 1.087 | 1.002 | 0.999–1.005 | 1.004, 0.999 |  |
| set.find.fresh | std::flat_set | G9 | 0.756 | 0.752 | 0.996 | 0.994–0.998 | 0.995, 0.997 |  |
| set.insert.fresh | std::flat_set | G9 | 0.996 | 0.999 | 1.004 | 1.001–1.006 | 1.005, 1.002 | worse |
| str.append | std::string | G9 | 0.419 | 0.425 | 1.014 | 1.009–1.019 | 1.020, 1.008 | worse |
| str.assign_long | std::string | G9 | 0.867 | 0.800 | 0.922 | 0.921–0.924 | 0.923, 0.922 |  |
| str.assign_short.view | std::string | G9 | 0.344 | 0.344 | 1.000 | 0.996–1.004 | 1.000, 1.000 |  |
| vec.iterate | std::vector | G9 | 1.001 | 1.001 | 1.000 | 0.997–1.002 | 1.000, 0.999 |  |
| vec.mid_erase | std::vector | G9 | 1.017 | 1.022 | 1.005 | 1.003–1.007 | 1.008, 1.003 | worse |
| vec.mid_insert | std::vector | G9 | 0.956 | 0.957 | 1.001 | 0.998–1.004 | 1.001, 1.001 |  |
| vec.push_back | std::vector | G9 | 1.109 | 1.100 | 0.992 | 0.988–0.996 | 1.001, 0.983 |  |
| vec.push_back_grow | std::vector | G9 | 0.767 | 0.769 | 1.003 | 1.001–1.006 | 1.012, 0.995 |  |
| hero.mid_erase.plain | std::vector | report | 4.062 | 4.041 | 0.995 | 0.991–0.998 | 0.998, 0.992 |  |
| hero.mid_insert.plain | std::vector | report | 4.224 | 4.192 | 0.992 | 0.989–0.996 | 0.991, 0.993 |  |
| hero.push_back_grow.plain | std::vector | report | 0.404 | 0.408 | 1.010 | 1.008–1.013 | 1.017, 1.004 | worse |
| map.erase.fresh | std::map | report | 0.746 | 0.737 | 0.989 | 0.986–0.992 | 0.980, 0.998 |  |
| map.erase.reused | std::flat_map | report | 1.083 | 1.081 | 0.998 | 0.994–1.001 | 0.995, 1.000 |  |
| map.erase.reused | std::map | report | 1.683 | 1.625 | 0.966 | 0.960–0.972 | 0.960, 0.971 |  |
| map.find.fresh | std::map | report | 0.325 | 0.325 | 1.002 | 0.998–1.007 | 1.001, 1.003 |  |
| map.find.reused | std::flat_map | report | 0.807 | 0.807 | 1.000 | 0.998–1.002 | 1.001, 0.999 |  |
| map.find.reused | std::map | report | 0.718 | 0.701 | 0.977 | 0.973–0.981 | 0.982, 0.971 |  |
| map.insert.fresh | std::map | report | 0.741 | 0.747 | 1.008 | 1.005–1.012 | 1.001, 1.016 | worse |
| map.insert.reused | std::flat_map | report | 1.000 | 1.001 | 1.002 | 0.999–1.004 | 1.001, 1.002 |  |
| map.insert.reused | std::map | report | 1.821 | 1.772 | 0.973 | 0.968–0.978 | 1.006, 0.941 |  |
| nested.build.plain | std | report | 0.337 | 0.331 | 0.982 | 0.976–0.988 | 0.992, 0.972 |  |
| set.erase.fresh | std::set | report | 0.677 | 0.663 | 0.979 | 0.976–0.983 | 0.976, 0.983 |  |
| set.erase.reused | std::flat_set | report | 1.142 | 1.144 | 1.002 | 0.998–1.006 | 1.000, 1.004 |  |
| set.erase.reused | std::set | report | 1.344 | 1.354 | 1.008 | 0.999–1.016 | 1.013, 1.002 |  |
| set.find.fresh | std::set | report | 0.299 | 0.297 | 0.991 | 0.987–0.996 | 0.991, 0.992 |  |
| set.find.reused | std::flat_set | report | 0.755 | 0.755 | 1.000 | 0.998–1.002 | 0.998, 1.002 |  |
| set.find.reused | std::set | report | 0.680 | 0.755 | 1.110 | 1.107–1.114 | 1.135, 1.086 | worse |
| set.insert.fresh | std::set | report | 0.654 | 0.654 | 1.001 | 0.999–1.004 | 1.005, 0.997 |  |
| set.insert.reused | std::flat_set | report | 1.079 | 1.079 | 1.000 | 0.997–1.003 | 0.998, 1.002 |  |
| set.insert.reused | std::set | report | 1.432 | 1.393 | 0.972 | 0.964–0.981 | 1.002, 0.944 |  |
| str.assign_short | std::string | report | 1.769 | 1.764 | 0.997 | 0.993–1.001 | 1.001, 0.994 |  |
| str.assign_short.copy | std::string | report | 1.150 | 1.149 | 0.999 | 0.997–1.001 | 1.000, 0.998 |  |

worse at t1 than t0 (by the rule): map.erase.fresh / std::flat_map (G9) 1.004; set.insert.fresh / std::flat_set (G9) 1.004; str.append / std::string (G9) 1.014; vec.mid_erase / std::vector (G9) 1.005; hero.push_back_grow.plain / std::vector (report) 1.010; map.insert.fresh / std::map (report) 1.008; set.find.reused / std::set (report) 1.110

above 1.01 but not worse by the rule: none

## XOffset ns/op alone, t1 / t0 (default build)

| case | t0 ns/op | t1 ns/op | t1 / t0 | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 163.6 | 163.4 | 0.999 | 0.997–1.000 | 0.996, 1.001 |  |
| hero.mid_erase.plain | 916.2 | 907.7 | 0.991 | 0.988–0.994 | 0.998, 0.983 |  |
| hero.mid_insert.ord | 228.5 | 227.6 | 0.996 | 0.994–0.998 | 0.995, 0.997 |  |
| hero.mid_insert.plain | 1270 | 1253 | 0.987 | 0.985–0.989 | 0.992, 0.982 |  |
| hero.push_back_grow.ord | 31.94 | 31.92 | 0.999 | 0.997–1.002 | 0.992, 1.007 |  |
| hero.push_back_grow.plain | 35.27 | 35.3 | 1.001 | 0.999–1.003 | 1.000, 1.002 |  |
| map.erase.fresh | 33.05 | 33.06 | 1.000 | 0.998–1.002 | 1.001, 1.000 |  |
| map.erase.reused | 29.77 | 29.66 | 0.996 | 0.994–0.998 | 0.995, 0.997 |  |
| map.find.fresh | 5.289 | 5.298 | 1.002 | 0.999–1.004 | 1.002, 1.001 |  |
| map.find.reused | 5.298 | 5.299 | 1.000 | 0.999–1.001 | 1.000, 1.000 |  |
| map.insert.fresh | 32.25 | 32.28 | 1.001 | 0.999–1.003 | 1.000, 1.002 |  |
| map.insert.reused | 29.5 | 29.49 | 1.000 | 0.998–1.001 | 0.999, 1.000 |  |
| nested.build.ord | 271.8 | 271 | 0.997 | 0.994–1.000 | 0.994, 1.001 |  |
| nested.build.plain | 279.4 | 279.9 | 1.002 | 0.997–1.006 | 0.999, 1.005 |  |
| reset | 30.38 | 29.13 | 0.959 | 0.955–0.963 | 0.939, 0.979 |  |
| set.erase.fresh | 29.79 | 29.84 | 1.002 | 1.000–1.004 | 1.002, 1.001 |  |
| set.erase.reused | 23.31 | 23.32 | 1.001 | 0.997–1.004 | 1.002, 0.999 |  |
| set.find.fresh | 4.885 | 4.881 | 0.999 | 0.998–1.000 | 0.999, 0.999 |  |
| set.find.reused | 4.879 | 4.885 | 1.001 | 1.000–1.003 | 1.001, 1.001 |  |
| set.insert.fresh | 28.92 | 28.87 | 0.998 | 0.997–1.000 | 0.998, 0.998 |  |
| set.insert.reused | 22.85 | 22.81 | 0.998 | 0.996–1.000 | 0.997, 0.999 |  |
| str.append | 1.56 | 1.561 | 1.001 | 0.996–1.005 | 1.006, 0.995 |  |
| str.assign_long | 2.959 | 2.716 | 0.918 | 0.916–0.920 | 0.923, 0.912 |  |
| str.assign_short | 0.9464 | 0.9354 | 0.988 | 0.983–0.993 | 1.001, 0.976 |  |
| str.assign_short.copy | 0.6281 | 0.6249 | 0.995 | 0.990–1.000 | 1.006, 0.984 |  |
| str.assign_short.view | 0.9487 | 0.9465 | 0.998 | 0.993–1.003 | 1.001, 0.994 |  |
| vec.iterate | 0.03317 | 0.03322 | 1.001 | 0.999–1.004 | 1.000, 1.003 |  |
| vec.mid_erase | 40.35 | 40.31 | 0.999 | 0.997–1.001 | 0.998, 1.000 |  |
| vec.mid_insert | 40.45 | 40.44 | 1.000 | 0.998–1.001 | 1.000, 0.999 |  |
| vec.push_back | 0.2931 | 0.2893 | 0.987 | 0.977–0.998 | 0.995, 0.979 |  |
| vec.push_back_grow | 0.2753 | 0.2761 | 1.003 | 0.998–1.008 | 1.008, 0.998 |  |

XOffset slower at t1 than t0 (worse by the rule): none

## XOffset / baseline, t1a / t0a (functions aligned to 64 B, layout check)

| case | baseline | class | t0a GM | t1a GM | t1a / t0a | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.724 | 0.728 | 1.005 | 1.002–1.008 | 1.003, 1.006 | worse |
| hero.mid_insert.ord | std::vector | G9 | 0.760 | 0.756 | 0.995 | 0.991–0.998 | 0.997, 0.992 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.358 | 0.359 | 1.003 | 0.999–1.007 | 0.982, 1.024 |  |
| map.erase.fresh | std::flat_map | G9 | 0.942 | 0.939 | 0.997 | 0.994–1.000 | 0.995, 0.999 |  |
| map.find.fresh | std::flat_map | G9 | 0.808 | 0.809 | 1.001 | 0.998–1.003 | 1.001, 1.000 |  |
| map.insert.fresh | std::flat_map | G9 | 0.868 | 0.868 | 0.999 | 0.997–1.002 | 0.996, 1.003 |  |
| nested.build.ord | std | G9 | 0.310 | 0.307 | 0.991 | 0.984–0.997 | 0.977, 1.004 |  |
| reset | std | G9 | 0.239 | 0.210 | 0.878 | 0.864–0.892 | 0.821, 0.939 |  |
| set.erase.fresh | std::flat_set | G9 | 1.088 | 1.088 | 1.000 | 0.997–1.003 | 0.995, 1.005 |  |
| set.find.fresh | std::flat_set | G9 | 0.756 | 0.755 | 0.998 | 0.995–1.000 | 0.999, 0.997 |  |
| set.insert.fresh | std::flat_set | G9 | 0.996 | 0.997 | 1.001 | 0.998–1.004 | 0.998, 1.004 |  |
| str.append | std::string | G9 | 0.434 | 0.430 | 0.991 | 0.986–0.997 | 0.980, 1.003 |  |
| str.assign_long | std::string | G9 | 0.864 | 0.867 | 1.003 | 1.001–1.006 | 1.003, 1.003 | worse |
| str.assign_short.view | std::string | G9 | 0.343 | 0.340 | 0.993 | 0.990–0.997 | 0.999, 0.988 |  |
| vec.iterate | std::vector | G9 | 1.002 | 1.003 | 1.001 | 0.999–1.003 | 1.000, 1.002 |  |
| vec.mid_erase | std::vector | G9 | 1.017 | 1.023 | 1.006 | 1.004–1.009 | 1.004, 1.009 | worse |
| vec.mid_insert | std::vector | G9 | 0.960 | 0.976 | 1.017 | 1.014–1.019 | 1.022, 1.012 | worse |
| vec.push_back | std::vector | G9 | 1.117 | 1.118 | 1.001 | 0.996–1.006 | 0.996, 1.006 |  |
| vec.push_back_grow | std::vector | G9 | 0.771 | 0.763 | 0.990 | 0.986–0.993 | 0.991, 0.988 |  |
| hero.mid_erase.plain | std::vector | report | 4.019 | 4.052 | 1.008 | 1.004–1.012 | 1.011, 1.006 | worse |
| hero.mid_insert.plain | std::vector | report | 4.161 | 4.174 | 1.003 | 1.000–1.007 | 1.005, 1.002 |  |
| hero.push_back_grow.plain | std::vector | report | 0.400 | 0.399 | 1.000 | 0.996–1.004 | 0.985, 1.014 |  |
| map.erase.fresh | std::map | report | 0.740 | 0.744 | 1.006 | 1.003–1.009 | 0.997, 1.015 |  |
| map.erase.reused | std::flat_map | report | 1.084 | 1.080 | 0.996 | 0.993–1.000 | 0.996, 0.997 |  |
| map.erase.reused | std::map | report | 1.613 | 1.570 | 0.973 | 0.966–0.981 | 0.958, 0.989 |  |
| map.find.fresh | std::map | report | 0.324 | 0.324 | 0.999 | 0.995–1.003 | 1.000, 0.998 |  |
| map.find.reused | std::flat_map | report | 0.808 | 0.808 | 1.000 | 0.997–1.003 | 1.001, 0.999 |  |
| map.find.reused | std::map | report | 0.719 | 0.718 | 0.997 | 0.993–1.002 | 0.978, 1.017 |  |
| map.insert.fresh | std::map | report | 0.743 | 0.749 | 1.009 | 1.005–1.013 | 0.993, 1.025 |  |
| map.insert.reused | std::flat_map | report | 1.006 | 1.000 | 0.994 | 0.992–0.997 | 0.993, 0.996 |  |
| map.insert.reused | std::map | report | 1.781 | 1.810 | 1.016 | 1.010–1.023 | 1.043, 0.990 | worse? |
| nested.build.plain | std | report | 0.328 | 0.318 | 0.971 | 0.965–0.977 | 0.977, 0.965 |  |
| set.erase.fresh | std::set | report | 0.669 | 0.675 | 1.009 | 1.006–1.012 | 1.003, 1.014 | worse |
| set.erase.reused | std::flat_set | report | 1.138 | 1.137 | 0.999 | 0.995–1.003 | 0.998, 1.000 |  |
| set.erase.reused | std::set | report | 1.338 | 1.288 | 0.962 | 0.955–0.970 | 0.948, 0.977 |  |
| set.find.fresh | std::set | report | 0.300 | 0.299 | 0.999 | 0.994–1.004 | 0.998, 0.999 |  |
| set.find.reused | std::flat_set | report | 0.756 | 0.757 | 1.002 | 0.999–1.005 | 1.002, 1.002 |  |
| set.find.reused | std::set | report | 0.685 | 0.684 | 0.999 | 0.996–1.003 | 0.979, 1.021 |  |
| set.insert.fresh | std::set | report | 0.653 | 0.656 | 1.005 | 1.001–1.008 | 0.997, 1.012 |  |
| set.insert.reused | std::flat_set | report | 1.080 | 1.084 | 1.004 | 1.002–1.007 | 1.006, 1.003 | worse |
| set.insert.reused | std::set | report | 1.387 | 1.394 | 1.005 | 0.996–1.014 | 1.038, 0.973 |  |
| str.assign_short | std::string | report | 1.766 | 1.767 | 1.001 | 0.999–1.002 | 1.000, 1.001 |  |
| str.assign_short.copy | std::string | report | 1.152 | 1.153 | 1.001 | 0.997–1.005 | 1.000, 1.002 |  |

worse at t1a than t0a (by the rule): hero.mid_erase.ord / std::vector (G9) 1.005; str.assign_long / std::string (G9) 1.003; vec.mid_erase / std::vector (G9) 1.006; vec.mid_insert / std::vector (G9) 1.017; hero.mid_erase.plain / std::vector (report) 1.008; set.erase.fresh / std::set (report) 1.009; set.insert.reused / std::flat_set (report) 1.004

above 1.01 but not worse by the rule: map.insert.reused / std::map (report) 1.016

## XOffset ns/op alone, t1a / t0a (functions aligned to 64 B, layout check)

| case | t0a ns/op | t1a ns/op | t1a / t0a | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 164.4 | 164.3 | 0.999 | 0.998–1.001 | 0.995, 1.004 |  |
| hero.mid_erase.plain | 905.7 | 911.7 | 1.007 | 1.004–1.009 | 1.007, 1.006 | worse |
| hero.mid_insert.ord | 230.1 | 228.9 | 0.995 | 0.993–0.997 | 0.993, 0.996 |  |
| hero.mid_insert.plain | 1254 | 1255 | 1.001 | 0.999–1.003 | 1.004, 0.998 |  |
| hero.push_back_grow.ord | 32.01 | 31.69 | 0.990 | 0.988–0.992 | 0.984, 0.996 |  |
| hero.push_back_grow.plain | 35.48 | 35.13 | 0.990 | 0.988–0.992 | 0.988, 0.992 |  |
| map.erase.fresh | 33.04 | 33.01 | 0.999 | 0.997–1.001 | 0.997, 1.001 |  |
| map.erase.reused | 29.73 | 29.67 | 0.998 | 0.996–1.000 | 0.995, 1.001 |  |
| map.find.fresh | 5.293 | 5.294 | 1.000 | 0.998–1.002 | 1.000, 1.000 |  |
| map.find.reused | 5.306 | 5.308 | 1.000 | 0.998–1.003 | 1.002, 0.999 |  |
| map.insert.fresh | 32.25 | 32.3 | 1.001 | 0.999–1.003 | 1.000, 1.003 |  |
| map.insert.reused | 29.53 | 29.55 | 1.001 | 0.998–1.003 | 0.999, 1.002 |  |
| nested.build.ord | 268.6 | 267.2 | 0.995 | 0.993–0.997 | 0.990, 0.999 |  |
| nested.build.plain | 276.4 | 276.3 | 1.000 | 0.997–1.002 | 0.994, 1.006 |  |
| reset | 30.83 | 27.98 | 0.908 | 0.903–0.912 | 0.889, 0.927 |  |
| set.erase.fresh | 29.74 | 29.81 | 1.002 | 1.001–1.004 | 1.001, 1.003 | worse |
| set.erase.reused | 23.24 | 23.23 | 0.999 | 0.996–1.002 | 0.999, 0.999 |  |
| set.find.fresh | 4.885 | 4.887 | 1.000 | 0.998–1.002 | 1.001, 1.000 |  |
| set.find.reused | 4.886 | 4.886 | 1.000 | 0.998–1.002 | 1.000, 1.000 |  |
| set.insert.fresh | 28.9 | 28.97 | 1.002 | 1.000–1.005 | 1.002, 1.002 | worse |
| set.insert.reused | 22.79 | 22.89 | 1.004 | 1.002–1.006 | 1.003, 1.005 | worse |
| str.append | 1.572 | 1.565 | 0.995 | 0.990–1.000 | 0.992, 0.999 |  |
| str.assign_long | 2.952 | 2.949 | 0.999 | 0.996–1.002 | 1.001, 0.997 |  |
| str.assign_short | 0.9411 | 0.9482 | 1.008 | 1.003–1.012 | 1.011, 1.005 | worse |
| str.assign_short.copy | 0.6278 | 0.6326 | 1.008 | 1.002–1.013 | 1.009, 1.007 | worse |
| str.assign_short.view | 0.9484 | 0.9536 | 1.005 | 1.001–1.010 | 1.010, 1.001 | worse |
| vec.iterate | 0.03326 | 0.0334 | 1.004 | 1.002–1.007 | 1.005, 1.003 | worse |
| vec.mid_erase | 40.37 | 40.62 | 1.006 | 1.005–1.008 | 1.003, 1.009 | worse |
| vec.mid_insert | 40.67 | 40.69 | 1.000 | 0.999–1.002 | 1.001, 1.000 |  |
| vec.push_back | 0.2725 | 0.2722 | 0.999 | 0.996–1.002 | 0.998, 1.000 |  |
| vec.push_back_grow | 0.272 | 0.2697 | 0.991 | 0.989–0.994 | 0.991, 0.992 |  |

XOffset slower at t1a than t0a (worse by the rule): hero.mid_erase.plain 1.007; set.erase.fresh 1.002; set.insert.fresh 1.002; set.insert.reused 1.004; str.assign_short 1.008; str.assign_short.copy 1.008; str.assign_short.view 1.005; vec.iterate 1.004; vec.mid_erase 1.006

## layout check: what is worse at t1 in the default build, in the aligned build

| comparison | t1 / t0 | t1a / t0a | 95% interval (aligned) | aligned |
| --- | ---: | ---: | --- | --- |
| hero.push_back_grow.plain / std::vector (report) | 1.010 | 1.000 | 0.996–1.004 | not worse |
| map.erase.fresh / std::flat_map (G9) | 1.004 | 0.997 | 0.994–1.000 | not worse |
| map.insert.fresh / std::map (report) | 1.008 | 1.009 | 1.005–1.013 | not worse |
| set.find.reused / std::set (report) | 1.110 | 0.999 | 0.996–1.003 | not worse |
| set.insert.fresh / std::flat_set (G9) | 1.004 | 1.001 | 0.998–1.004 | not worse |
| str.append / std::string (G9) | 1.014 | 0.991 | 0.986–0.997 | not worse |
| vec.mid_erase / std::vector (G9) | 1.005 | 1.006 | 1.004–1.009 | still worse |
