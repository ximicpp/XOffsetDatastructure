// g9r2_probe: splits the fixed per-op gap of vec.mid_insert / vec.mid_erase
// (PERF_GOAL G9, Mac 30af216: xo/std 1.10 / 1.06, 2.4-4.8 ns per op) into
// three parts, in one binary, on the same data as bench/reloc:
//   - container code: XVector::insert / erase against "raw" functions that do
//     the same memmove, element write, size_ update and scrub on the same head
//     and block, without the container's checks (candidate lever L10);
//   - store forwarding: raw functions that write size_ after the memmove (the
//     library's order) against ones that write it before (libc++'s order for
//     insert; candidate L11);
//   - placement: raw code on a block at std::vector's page offset, and
//     std::vector on a buffer at XOffset's page offset (candidate L12).
// M = 2048, K = 512 as in bench/reloc: K inserts at the middle of an M-element
// vector, K erases at the middle of an (M + K)-element one, refilled untimed.
// Within a round the variants of a case run back to back in rotating order,
// each after its own refill; all variants of a case must end with the same
// contents. Measures only: design thread 「G9 重定位税诊断」, Mac batch G9R2.
//
//   g9r2_probe [--rounds N] [--warmup N] [--out raw.jsonl]

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <new>
#include <string>
#include <vector>
#if defined(__APPLE__)
#include <pthread.h>
#endif

#include "xoffsetdatastructure.hpp"

namespace g9 {
using namespace XOffsetDatastructure;
struct alignas(8) IntVec { XVector<int32_t> v; };
using Head = XFixedVector<int32_t>;

constexpr uint32_t M = 2048, K = 512;

template <class T> inline void keep(T const& v) { asm volatile("" : : "r,m"(v) : "memory"); }
inline void clobber() { asm volatile("" : : : "memory"); }

template <class F> double timed(F&& f) {
    clobber();
    const auto t0 = std::chrono::steady_clock::now();
    f();
    clobber();
    const auto t1 = std::chrono::steady_clock::now();
    return double(std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count());
}

// ---- raw operations: the trivially copyable paths of
// XFixedVector<int32_t>::insert_construct / erase_index with spare capacity,
// minus ensure_bound, the index / max_size checks, the staged copy and the
// null check on data(). The first head read is pinned on arm64 to the
// instruction the library's code starts with on the Mac (G9R disasm_t1):
// insert `ldp w, w, [head, #8]` {size_, capacity_}, erase `ldp w, w,
// [head, #4]` {data_delta, size_}. Read::Single reads the same two fields
// with one 4-byte load each. Insert is out of line and erase inline, as in
// the library; the erase index comes from the size_ just read, as there.
enum class Read { Pair, Single };

template <Read R> inline void read_size_cap(const Head& h, uint32_t& n, uint32_t& cap) {
#if defined(__aarch64__)
    if constexpr (R == Read::Pair)
        asm volatile("ldp %w0, %w1, [%2, #8]" : "=r"(n), "=r"(cap) : "r"(&h), "m"(h));
    else
        asm volatile("ldr %w0, [%2, #8]\n\tldr %w1, [%2, #12]" : "=&r"(n), "=r"(cap) : "r"(&h), "m"(h));
#else
    n = h.size_;
    cap = h.capacity_;
#endif
}
template <Read R> inline void read_delta_size(const Head& h, int32_t& dd, uint32_t& n) {
#if defined(__aarch64__)
    if constexpr (R == Read::Pair)
        asm volatile("ldp %w0, %w1, [%2, #4]" : "=r"(dd), "=r"(n) : "r"(&h), "m"(h));
    else
        asm volatile("ldr %w0, [%2, #4]\n\tldr %w1, [%2, #8]" : "=&r"(dd), "=r"(n) : "r"(&h), "m"(h));
#else
    dd = h.data_delta;
    n = h.size_;
#endif
}
inline int32_t* block_of(Head& h, int32_t dd) {
    return reinterpret_cast<int32_t*>(reinterpret_cast<unsigned char*>(&h.data_delta) + dd);
}

template <Read R, bool SizeFirst>
[[gnu::noinline]] int32_t* raw_insert(Head& h, uint32_t i, int32_t v) {
    uint32_t n, cap;
    read_size_cap<R>(h, n, cap);
    if (n >= cap || i > n) [[unlikely]] std::abort();  // the library grows or throws here
    int32_t* d = block_of(h, h.data_delta);
    if constexpr (SizeFirst) h.size_ = n + 1u;         // libc++'s order for insert
    std::memmove(d + i + 1, d + i, std::size_t(n - i) * sizeof(int32_t));
    d[i] = v;
    if constexpr (!SizeFirst) h.size_ = n + 1u;        // the library's order
    return d + i;
}
template <Read R, bool SizeFirst, bool Scrub>
[[gnu::always_inline]] inline void raw_erase_mid(Head& h) {
    int32_t dd;
    uint32_t n;
    read_delta_size<R>(h, dd, n);
    const uint32_t i = n / 2;
    if (i + 1 >= n) [[unlikely]] std::abort();          // the library pops here
    int32_t* d = block_of(h, dd);
    if constexpr (SizeFirst) h.size_ = n - 1u;
    std::memmove(d + i, d + i + 1, std::size_t(n - i - 1) * sizeof(int32_t));
    if constexpr (!SizeFirst) h.size_ = n - 1u;        // the library's order
    if constexpr (Scrub) d[n - 1] = 0;                 // M4 scrub of the vacated slot, as erase_index
}

// ---- placement -------------------------------------------------------------

// A page-aligned pool: page 0 holds a head, pages 1.. a block at a chosen page
// offset; std::vector buffers come from a second pool the same way.
struct Pool {
    unsigned char* base = nullptr;
    explicit Pool(std::size_t pages) {
        base = static_cast<unsigned char*>(std::aligned_alloc(4096, pages * 4096));
        if (!base) std::abort();
        std::memset(base, 0, pages * 4096);
    }
};

// A head outside any arena whose block sits at a chosen page offset. Only the
// raw functions touch it; its fields are reset before destruction so that
// release() has nothing to free.
struct PlacedHead {
    Head* h;
    int32_t* block;
    PlacedHead(Pool& p, std::size_t page_offset, uint32_t cap) {
        h = new (p.base) Head();
        block = reinterpret_cast<int32_t*>(p.base + 4096 + page_offset);
        h->data_delta = int32_t(reinterpret_cast<unsigned char*>(block) - reinterpret_cast<unsigned char*>(&h->data_delta));
        h->capacity_ = cap;
        h->size_ = 0;
        if (h->data() != block) std::abort();
    }
    ~PlacedHead() { h->data_delta = 0; h->capacity_ = 0; h->size_ = 0; h->~Head(); }
    void refill(uint32_t n) {
        for (uint32_t i = 0; i < n; ++i) block[i] = int32_t(i);
        std::memset(block + n, 0, std::size_t(h->capacity_ - n) * sizeof(int32_t));
        h->size_ = n;
    }
};

template <class T> struct PoolAlloc {
    using value_type = T;
    static inline unsigned char* slot = nullptr;
    static inline std::size_t slot_bytes = 0;
    static inline bool used = false;
    PoolAlloc() = default;
    template <class U> PoolAlloc(const PoolAlloc<U>&) noexcept {}
    T* allocate(std::size_t n) {
        if (used || n * sizeof(T) > slot_bytes) throw std::bad_alloc();
        used = true;
        return reinterpret_cast<T*>(slot);
    }
    void deallocate(T*, std::size_t) noexcept { used = false; }
    template <class U> bool operator==(const PoolAlloc<U>&) const noexcept { return true; }
};
using PlacedStd = std::vector<int32_t, PoolAlloc<int32_t>>;

// ---- digests -------------------------------------------------------------------

uint64_t digest(const int32_t* d, uint32_t n) {
    uint64_t h = 1469598103934665603ull ^ n;
    for (uint32_t i = 0; i < n; ++i) h = (h ^ uint32_t(d[i])) * 1099511628211ull;
    return h;
}

struct Variant {
    const char* name;
    double (*rep)(uint64_t& dig);  // untimed refill, one timed region, digest
};

// ---- state shared by the variants ---------------------------------------------

XBuffer* g_xb = nullptr;
XVector<int32_t>* g_xv = nullptr;   // the bench/reloc data: IntVec in a 64 KiB buffer
std::vector<int32_t>* g_sv = nullptr;
PlacedHead* g_raw_stdpos = nullptr; // raw code, block at std::vector's page offset
PlacedStd* g_std_xopos = nullptr;   // std::vector, buffer at XOffset's page offset

void refill_xo(uint32_t n) { g_xv->clear(); for (uint32_t i = 0; i < n; ++i) g_xv->push_back(int32_t(i)); }
template <class V> void refill_std(V& v, uint32_t n) { v.clear(); for (uint32_t i = 0; i < n; ++i) v.push_back(int32_t(i)); }

// insert
double ins_xo(uint64_t& dig) {
    refill_xo(M);
    auto& xv = *g_xv;
    const double t = timed([&] {
        for (uint32_t k = 0; k < K; ++k) xv.insert(xv.begin() + xv.size() / 2, int32_t(k));
        keep(xv.data());
    });
    dig = digest(xv.data(), xv.size());
    return t;
}
template <Read R, bool SizeFirst> double ins_raw(uint64_t& dig) {
    refill_xo(M);
    Head& h = *g_xv;
    const double t = timed([&] {
        for (uint32_t k = 0; k < K; ++k) raw_insert<R, SizeFirst>(h, h.size_ / 2, int32_t(k));
        keep(h.data());
    });
    dig = digest(h.data(), h.size_);
    return t;
}
double ins_raw_stdpos(uint64_t& dig) {
    g_raw_stdpos->refill(M);
    Head& h = *g_raw_stdpos->h;
    const double t = timed([&] {
        for (uint32_t k = 0; k < K; ++k) raw_insert<Read::Pair, false>(h, h.size_ / 2, int32_t(k));
        keep(h.data());
    });
    dig = digest(h.data(), h.size_);
    return t;
}
template <class V> double ins_std_on(V& sv, uint64_t& dig) {
    refill_std(sv, M);
    const double t = timed([&] {
        for (uint32_t k = 0; k < K; ++k) sv.insert(sv.begin() + std::ptrdiff_t(sv.size() / 2), int32_t(k));
        keep(sv.data());
    });
    dig = digest(sv.data(), uint32_t(sv.size()));
    return t;
}
double ins_std(uint64_t& dig) { return ins_std_on(*g_sv, dig); }
double ins_std_xopos(uint64_t& dig) { return ins_std_on(*g_std_xopos, dig); }

// erase
double era_xo(uint64_t& dig) {
    refill_xo(M + K);
    auto& xv = *g_xv;
    const double t = timed([&] {
        for (uint32_t k = 0; k < K; ++k) xv.erase(xv.begin() + xv.size() / 2);
        keep(xv.data());
    });
    dig = digest(xv.data(), xv.size());
    return t;
}
template <Read R, bool SizeFirst, bool Scrub> double era_raw(uint64_t& dig) {
    refill_xo(M + K);
    Head& h = *g_xv;
    const double t = timed([&] {
        for (uint32_t k = 0; k < K; ++k) raw_erase_mid<R, SizeFirst, Scrub>(h);
        keep(h.data());
    });
    dig = digest(h.data(), h.size_);
    return t;
}
double era_raw_stdpos(uint64_t& dig) {
    g_raw_stdpos->refill(M + K);
    Head& h = *g_raw_stdpos->h;
    const double t = timed([&] {
        for (uint32_t k = 0; k < K; ++k) raw_erase_mid<Read::Pair, false, true>(h);
        keep(h.data());
    });
    dig = digest(h.data(), h.size_);
    return t;
}
template <class V> double era_std_on(V& sv, uint64_t& dig) {
    refill_std(sv, M + K);
    const double t = timed([&] {
        for (uint32_t k = 0; k < K; ++k) sv.erase(sv.begin() + std::ptrdiff_t(sv.size() / 2));
        keep(sv.data());
    });
    dig = digest(sv.data(), uint32_t(sv.size()));
    return t;
}
double era_std(uint64_t& dig) { return era_std_on(*g_sv, dig); }
double era_std_xopos(uint64_t& dig) { return era_std_on(*g_std_xopos, dig); }

// "raw": the library's order and reads; each other raw variant changes one thing.
const Variant kInsert[] = {
    {"xo", ins_xo},
    {"raw", ins_raw<Read::Pair, false>},
    {"raw.size_first", ins_raw<Read::Pair, true>},
    {"raw.ldr", ins_raw<Read::Single, false>},
    {"raw.stdpos", ins_raw_stdpos},
    {"std", ins_std},
    {"std.xopos", ins_std_xopos},
};
const Variant kErase[] = {
    {"xo", era_xo},
    {"raw", era_raw<Read::Pair, false, true>},
    {"raw.size_first", era_raw<Read::Pair, true, true>},
    {"raw.ldr", era_raw<Read::Single, false, true>},
    {"raw.noscrub", era_raw<Read::Pair, false, false>},
    {"raw.stdpos", era_raw_stdpos},
    {"std", era_std},
    {"std.xopos", era_std_xopos},
};

double median(std::vector<double> v) {
    std::sort(v.begin(), v.end());
    return v[v.size() / 2];
}

int g_fail = 0;

template <std::size_t N>
void run_case(const char* name, const Variant (&vs)[N], int rounds, int warmup, std::FILE* out) {
    std::vector<std::vector<double>> ns(N);
    for (int r = -warmup; r < rounds; ++r) {
        std::vector<double> t(N);
        std::vector<uint64_t> dig(N, 0);
        for (std::size_t j = 0; j < N; ++j) {
            const std::size_t s = (j + std::size_t(r < 0 ? -r : r)) % N;  // rotate the order
            t[s] = vs[s].rep(dig[s]);
        }
        for (std::size_t s = 1; s < N; ++s)
            if (dig[s] != dig[0]) {
                std::printf("CHECK FAILED: %s round %d: %s digest %016llx, %s %016llx\n", name, r, vs[s].name,
                            (unsigned long long)dig[s], vs[0].name, (unsigned long long)dig[0]);
                ++g_fail;
            }
        if (r < 0) continue;
        for (std::size_t s = 0; s < N; ++s) ns[s].push_back(t[s]);
        if (out) {
            std::fprintf(out, "{\"case\":\"%s\",\"round\":%d,\"ops\":%u,\"ns\":{", name, r, K);
            for (std::size_t s = 0; s < N; ++s) std::fprintf(out, "%s\"%s\":%.0f", s ? "," : "", vs[s].name, t[s]);
            std::fprintf(out, "}}\n");
        }
    }
    for (std::size_t s = 0; s < N; ++s)
        std::printf("%-4s %-18s %9.2f ns/op (median of %d rounds)\n", name, vs[s].name, median(ns[s]) / K, rounds);
}

std::size_t page_off(const void* p) { return std::size_t(reinterpret_cast<std::uintptr_t>(p) & 4095u); }

}  // namespace g9

int main(int argc, char** argv) {
    using namespace g9;
    int rounds = 101, warmup = 3;
    const char* out_path = nullptr;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--rounds") && i + 1 < argc) rounds = std::atoi(argv[++i]);
        else if (!std::strcmp(argv[i], "--warmup") && i + 1 < argc) warmup = std::atoi(argv[++i]);
        else if (!std::strcmp(argv[i], "--out") && i + 1 < argc) out_path = argv[++i];
        else { std::fprintf(stderr, "usage: g9r2_probe [--rounds N] [--warmup N] [--out raw.jsonl]\n"); return 2; }
    }
    if (rounds < 1 || warmup < 0) return 2;
#if defined(__APPLE__)
    pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
#endif
    std::FILE* out = nullptr;
    if (out_path && !(out = std::fopen(out_path, "w"))) { std::fprintf(stderr, "cannot write %s\n", out_path); return 1; }

    // The XOffset side exactly as bench/reloc builds it (Automatic growth, VM
    // storage, 16 MiB limit); one untimed insert pass settles its capacity.
    XBuffer xb = XBuffer::create<IntVec>(64 * 1024,
        XBuffer::maximum_capacity(std::size_t(16) << 20).with_growth(XGrowPolicy::Automatic));
    g_xb = &xb;
    g_xv = &xb.root<IntVec>().v;
    std::vector<int32_t> sv;
    g_sv = &sv;
    refill_xo(M);
    for (uint32_t k = 0; k < K; ++k) g_xv->insert(g_xv->begin() + g_xv->size() / 2, int32_t(k));
    refill_std(sv, M);
    for (uint32_t k = 0; k < K; ++k) sv.insert(sv.begin() + std::ptrdiff_t(sv.size() / 2), int32_t(k));
    const uint32_t cap = g_xv->capacity();
    if (cap < M + K || sv.capacity() < M + K) { std::printf("capacity below M + K\n"); return 1; }

    Pool raw_pool(1 + (cap * sizeof(int32_t) + 8191) / 4096);
    PlacedHead raw_stdpos(raw_pool, page_off(sv.data()), cap);
    g_raw_stdpos = &raw_stdpos;
    const std::size_t std_bytes = sv.capacity() * sizeof(int32_t);
    Pool std_pool(1 + (std_bytes + 8191) / 4096);
    PoolAlloc<int32_t>::slot = std_pool.base + 4096 + page_off(g_xv->data());
    PoolAlloc<int32_t>::slot_bytes = std_bytes;
    PlacedStd std_xopos;
    std_xopos.reserve(sv.capacity());
    g_std_xopos = &std_xopos;

    std::printf("g9r2_probe: M %u, K %u, %d rounds (+%d warm-up)\n", M, K, rounds, warmup);
    std::printf("placement (address %% 4096 / %% 64): xo head %zu/%zu data %zu/%zu cap %u; std data %zu/%zu cap %zu; "
                "raw.stdpos data %zu/%zu; std.xopos data %zu/%zu\n",
                page_off(g_xv), page_off(g_xv) % 64, page_off(g_xv->data()), page_off(g_xv->data()) % 64, cap,
                page_off(sv.data()), page_off(sv.data()) % 64, sv.capacity(),
                page_off(raw_stdpos.block), page_off(raw_stdpos.block) % 64,
                page_off(std_xopos.data()), page_off(std_xopos.data()) % 64);
    if (out)
        std::fprintf(out, "{\"meta\":{\"probe\":\"g9r2\",\"M\":%u,\"K\":%u,\"rounds\":%d,\"warmup\":%d,"
                          "\"xo_head_off\":%zu,\"xo_data_off\":%zu,\"std_data_off\":%zu,\"cap\":%u}}\n",
                     M, K, rounds, warmup, page_off(g_xv), page_off(g_xv->data()), page_off(sv.data()), cap);

    run_case("ins", kInsert, rounds, warmup, out);
    run_case("era", kErase, rounds, warmup, out);
    if (g_xv->capacity() != cap || std_xopos.data() != reinterpret_cast<int32_t*>(PoolAlloc<int32_t>::slot)) {
        std::printf("CHECK FAILED: a block moved during the run\n");
        ++g_fail;
    }
    if (out) std::fclose(out);
    std::printf("checks: %s\n", g_fail ? "FAILED" : "all passed");
    return g_fail ? 1 : 0;
}
