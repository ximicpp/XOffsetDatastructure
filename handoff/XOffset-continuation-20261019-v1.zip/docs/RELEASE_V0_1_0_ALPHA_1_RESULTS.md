# v0.1.0-alpha.1 首版准备与验收

日期：2026-10-17（北京时间）。本地首版准备及限定范围验收通过；未提交、推送、正式发布、创建远端 release 或触发远端 CI。定位为实验性 alpha，生产 F 双头与 V1 格式未变，不提供生产稳定性认证。

## 发行文件

产物位于 [本地交付目录](../build/release-v0.1.0-alpha.1-20261017/artifacts/README_RELEASE.md)，附 [总校验清单](../build/release-v0.1.0-alpha.1-20261017/artifacts/SHA256SUMS)。各子目录另有独立 manifest 和 `SHA256SUMS`，归档内也包含成员清单。

| 文件 | 大小 | 内容 |
| --- | ---: | --- |
| [源码包](../build/release-v0.1.0-alpha.1-20261017/artifacts/source/xoffsetdatastructure-0.1.0-alpha.1.tar.gz) | 1,117,006 B | 957 个 payload 文件；核心源码、CMake、测试/例子、必要工具/文档和固定依赖闭包，无 `.git` |
| [full 安装包](../build/release-v0.1.0-alpha.1-20261017/artifacts/full/xoffsetdatastructure-0.1.0-alpha.1-full.tar.gz) | 979,284 B | 864 个 payload 文件；双头、851 个依赖头、CMake、版本/兼容说明和许可证 |
| [storage 安装包](../build/release-v0.1.0-alpha.1-20261017/artifacts/storage/xoffsetdatastructure-0.1.0-alpha.1-storage.tar.gz) | 14,285 B | 8 个 payload 文件；C++17 OS 头、CMake、版本/兼容说明和项目许可证 |

成员数不含归档内的 `SOURCE_MANIFEST.json` / `INSTALL_MANIFEST.json`。三个包均不包含编译器、SDK、runtime 或原生程序二进制。完整性哈希不是签名或来源认证。

```text
source  5a8647736d1145676c503299d704bc37e2dd035d730ccc2ffca2e5e96a28c658
full    f28cb6ba53c2d0db45ef23a9c2d1e9098f126c10d341bde539d983883609366e
storage a480971b5ce2e52a6acf94f6948602fa303939c3b06e9fdabc794242e7a83280
```

## 三项收尾结果

1. [README](../README.md)、[打包指南](VM_PACKAGING.md)、[CHANGELOG](../CHANGELOG.md) 与 [兼容说明](ALPHA_COMPATIBILITY.md) 已更新。明确 Windows 仅验证 storage、WSL/Docker 可用于后续 Linux 性能工作、历史与本次运行范围分开，以及 N3/N7 不属于首版承诺。
2. [VERSION](../VERSION) 唯一维护完整版本 `0.1.0-alpha.1`；CMake project 数字部分为 `0.1.0`。安装包导出完整版本、numeric 与 prerelease 信息。数字、EXACT、范围查找全部保守拒绝，消费方式为无版本 `find_package` 后对完整字符串作 `STREQUAL` 断言。alpha 间 API/ABI、任意 schema/ABI 的长期 wire 兼容均不作承诺。
3. 新增 [发行工具](../tools/prepare_alpha_release.py) 与回归测试。源码包带入固定 11 个 include tree / 3 个许可证；安装包携带经过验收的 prefix。归档使用规范元数据、成员清单、外部校验和，拒绝覆盖、链接、越界、重复、大小写目录别名、文件目录冲突和超限数据。

原有包验证器仍执行精确内容审计、安装重定位、原生产源码路径失效以及 installed/subproject 各三项消费验证，新增完整版本查询及四项数字版本拒绝检查。日期专用 Windows 源码快照入口也已兼容新版本元数据；11 项回归及旧 `current-05` 离线审计通过，原证据未修改。

## 实际最终包验收

全部原生构建均从上表固定源码归档解压后开始，没有用工作区源码或原仓库依赖替代发行内容。原工作区仅提供已显式绑定的外部工具链；源码包本身不承担编译器分发。

| 环境与对象 | 实际结果 | 范围 |
| --- | --- | --- |
| WSL2 Ubuntu 22.04 x86_64，最终源码包 | full **48/48**，storage **2/2** | full 为 38 程序、7 子进程场景、3 工具检查；另 3 个 configure 检查；精确 inventory/JUnit，无 skip |
| 同一 WSL 源码包，full/storage 安装验证 | 每类 installed **3/3** + subproject **3/3** | 安装重定位、原生产源码路径不可用、精确文件/许可证/版本策略、源与 prefix 前后不变 |
| Windows x64 MSVC 19.44 / SDK 10.0.26100 / Ninja，最终源码包 | storage **2/2**；installed **3/3** + subproject **3/3** | 958 个解压文件前后不变；完整版本查询和四项数字请求拒绝通过；Windows full 未运行 |
| 实际 full 安装 tar，WSL 重新解压 | **3/3** 消费测试 | 移走原已验 prefix，仅用实际 tar 解压后的新 prefix，编译命令指向新 include |
| 实际 storage 安装 tar，WSL 重新解压 | **3/3** 消费测试 | 同上；归档 payload 与已验 prefix 逐字节相同 |
| 同一 storage 安装 tar，Windows 解压并再次移动 prefix | **3/3** 消费测试 | WSL 产出的无二进制包跨平台消费；完整 alpha 查询、包/fixture/helper 前后字节不变 |
| README 原样最小例子 + 实际 full 安装 tar | 编译、运行成功 | 直接提取 README 的 C++ 与 CMake 段落；不是另写等价示例 |
| 干净源码解压树自行重新生成源码包 | **逐字节一致** | 从 Windows 生成的最终包在 WSL 解压后自行打包，SHA-256 仍为 `5a8647…c658` |

工具回归方面，版本/包审计 14 项与归档 16 项在 Windows、WSL 分别通过；独立审查额外核对 8 项缩小上限的拒绝行为。最终源码解压树内的 30 项也实际运行通过。它们与原生 CTest 的 48/2 项分别计数，不汇总为单个测试总数。

本次 WSL full 48 项使用 `linux-current-complete-v2-20261016`，P2996 Clang commit `9ffb96e3ce362289008e14ad2a79a249f58aa90a`，配套 libc++ 和私有 glibc2.39 链接 profile，CMake 4.2.3。它是本次发行包的新运行，与 10 月 16 日初始 profile 的 full 结果分开。宿主系统头仍如实作为外部输入。Windows 使用 CMake 3.28.1、MSVC 14.44.35207；没有修改系统工具链或系统长路径设置。

## 诊断与保留范围

- Windows 首次在较深工程路径解压到 261 字符的 Boost 路径时失败，尚未编译。保留 `windows-clean-v1`，在新 `windows-clean-v2` 以本次专属临时短盘符映射验证同一归档成功；映射已核对并移除。Windows 使用者应选择短解压/构建目录，随交付的 `README_RELEASE.md` 已说明。
- WSL 初次 `/tmp` 干净运行全部通过后，观察到 WSL 重启及该临时目录消失。日志、JUnit、清单和身份已保存；原 `/tmp` 构建二进制不再可取得，不能把这些日志说成完整二进制归档。在新持久 ext4 目录重新解压同一源码，仅重建两类安装 prefix 及其消费验证，用于打包并验收实际安装 tar；没有重复 full 48 项或性能测量。
- 独立代码审查的两项发现（校验/提取重复读取的身份不一致、目录层级大小写别名）均在首次冻结发行包前修复并补回归，具体 proof 和修复身份保留在 review 中。

两个环境事件及修正见 [记录](coordination/release-v0.1.0-alpha.1-20261017/environment-events.json)。未重跑历史性能、sanitizer、TSan 或 wire 研究；这些历史证据按原范围保留，不扩大为本次新运行。

## 验收与未承诺事项

[独立实现审查](coordination/release-v0.1.0-alpha.1-20261017/implementation-review.json)、[实际归档与运行证据审查](coordination/release-v0.1.0-alpha.1-20261017/artifact-review.json)、[最终验收](coordination/release-v0.1.0-alpha.1-20261017/final-acceptance.json)、[源码/历史差异](coordination/release-v0.1.0-alpha.1-20261017/source-and-history-delta.json) 和 [小型证据入口](validation/release-v0.1.0-alpha.1-20261017/README.md) 固定本轮范围。小型证据 manifest 覆盖 266 个成员 / 2,880,217 B；大型本机环境、完整源码资产和原生二进制不重复纳入。

原有 690 文件中 679 个保持原字节，11 个为明确的文档、CMake 和包审计改动；没有缺失文件。此前接续新增的 729 文件中，727 个保持不变，另两项仅为 Windows 快照 helper 及其测试的兼容修复。生产双头及全部历史研究/运行证据保持原样。957 个最终发行 payload 成员均与当前工作区对应文件一致；两项依赖 gitlinks、工作区与暂存区干净，主仓库没有 staged 内容，HEAD 仍为交接提交。

本地 alpha 发布准备已完成；整体研究路线图仍有开放项。Windows full P2996、动态库/插件/跨 CRT、真实业务异步网络、N7 可选 I/O 扩展及 N3 稳定性能归因均未获此验收。未来 Linux 性能环境允许 WSL 或 Docker，但现有噪声失败结果不自动变为合格性能结论。
