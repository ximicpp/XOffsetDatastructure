# 修复工具后的五库正式比较验收

2026-10-17。本轮使用已修复的工具，重新构建、完成门禁并在新目录冻结，随后执行了唯一一轮正式窗口。原权限失败窗口和上一轮结果文档保持原样。

## 验收结论

本轮未取得正式库间比较资格，不能报告速度排名、收益、等价或 p99。

窗口状态 `failed`，启动尝试 55，成功原生库子进程 55，未启动 230；新 wire 960308701 字节。
停止原因：`ProtocolError: anchor qualification failed: pre`。新窗口次数 1，重试 0；审计为 `audit-preserved-failure`。
队列清理：`{"live": [], "process_groups": [], "zombies": []}`。

## 重新执行的门禁

| 项目 | 新目录中的实际结果 |
| --- | --- |
| 完整库正常 / sanitizer | 各 47/47 CTest、各 3 配置检查 |
| 五库适配器正常 / sanitizer | 各 16/16 CTest、各 5 模型 golden |
| ASan / UBSan / LSan 正控 | UAF、overflow、leak 均检出 |
| 修复版工具正常 / Python -O | 各 40/40，无 skip |
| 正常 / sanitizer S/M/L | 各 80/80 子进程、15/15 场景 |
| 最终真实冻结包复制预检 | 五个真实 bin 均 0755、字节身份一致，describe 全部通过 |

四个构建均为新目录；固定生产源码和已验依赖 runtime 作为输入，没有运行旧构建的 CTest 去覆盖历史 Testing 日志。
新 normal/SAN profile 各有 1,518 / 1,521 项闭包标签，实际编译依赖包含候选头且不混入旧 alpha。
两套 80 项门禁均重新捕获修复版工具的 runtime-before/after，并使用各自新外部双清单 pin 审计。
最终冻结后，使用正式运行相同的 copy_bundle 复制整个真实包，再以同一 taskset 前缀逐个执行 describe；预检记录绑定最终 frozen 清单。

## 场景与测量边界

对象为 XOffset 区间索引候选、cista 0.16、FlatBuffers 25.12.19、Cap'n Proto 1.5.0、cereal 1.3.2。
正式 cell 为 `V1-M-mixed-growth-trusted-detached-range-index-v1`：可信输入、固定 schema、16,384 条初始记录、28,673 次修改、55,299 个查询项及九阶段修改 oracle。
五库都提供 detached 拥有型可变结果。主计时从内存中的 wire 加载开始，包含查询、变长修改、导出拥有字节、销毁、重新加载、再查询和清理八段。
输入文件读取、trace 解析、预分配查询结果缓冲、最终正确性审计及文件输出不在主计时内；这是八段原生生命周期指标。
不同库的内部结构检查和原生重建路径仍不同；结果只适用于这套适配器和场景，不代表不可信 U、图、borrowed/mmap、跨语言或全部工作负载。

环境为 WSL2 x86-64，固定 Clang 21 P2996/libc++ profile，同一编译器和 Release/O3；只有 XOffset 开启 reflection 所需选项。
五库统一 taskset 到虚拟 CPU 2，该选择继承前轮且在本轮数据产生前固定。没有宣称物理核独占或宿主噪声隔离。
统计规则未改：最大 285 子进程、20 秒/child、45 分钟、16 GiB 新 wire；15 warmup、三组 A/A、30 个轮转顺序比较 block。
A/A 比值与顺序中位数要求 0.98–1.02、scaled log-MAD 不超过 ln(1.02)，锚点漂移不超过 1.02；任一组失败即停整格，不放宽或追加样本。

## A/A 自比资格

| 锚点 | 库 | A/B 中位数 | AB 顺序中位数 | BA 顺序中位数 | scaled log-MAD | 该库累计资格 |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| pre | capnproto | 0.991198 | 1.044693 | 0.984209 | 0.010456 | False |
| pre | cereal | 0.984509 | 0.980912 | 0.995668 | 0.024412 | False |
| pre | cista | 1.017166 | 0.998752 | 1.017166 | 0.036739 | False |
| pre | flatbuffers | 1.037160 | 1.061853 | 1.012211 | 0.034684 | False |
| pre | xoffset | 1.001088 | 1.000846 | 1.010375 | 0.017728 | True |

表中是同库 A/A 自比资格，不能作为五库速度排名。完整配对值、漂移和逐进程结果见 result-data-v1.json 及原始档案。

## 比较结果边界

预注册的整格资格未满足；工具按停止条件结束，未为了取得资格再测。即使原始子进程成功并留下时间，也不据其输出速度表、收益区间、等价或性能回退结论。
本轮没有可用于 P9 归因的合格差异，未启动采样归因。

## 身份与交付

生产候选未改：双头规范内容 SHA 为 `412e1fa3c1c59c874645f12714f761daa762ec2a7302b81cb9689b5fb63f4b4c`。修复后的 campaign SHA 为 `6d11c4ebfa6a493f29825577fad6cfcacc04d1d238ef2ad273fb597fba60275e`。
冻结清单执行前外部 SHA：`3fa4c42b05edfeae109a0851cc601cee2f1964a964a1162f1b093607dc6a4c86`。
执行后双清单复合 pin：`ff3c1ef96ae664cedb3621265f49efcd44763e889f475e83511f2d364ab9d3c6`。

新完整档案：`/root/xoffset-verified-ranges/20261017/candidate-v1/repaired-campaign-v2`。
源码仍为 `/root/xoffset-verified-ranges/20261017/candidate-v1/source-v1`，Windows 可编辑候选位于原独立 worktree。
[门禁与统计数据](coordination/verified-ranges-repaired-campaign-20261017/result-data-v1.json) · [阶段计划](coordination/verified-ranges-repaired-campaign-20261017/plan.json) · [证据副本说明](validation/2026-10-17-repaired-five-library/README.md)。
小型证据副本仅提供 metadata、协议、回执及日志；大 wire/canonical、二进制和完整 runtime/源码闭包仍保留在 WSL，不是离线自包含包。
原权限失败档案仍位于父目录的 formal-v1/frozen-v1；[前轮报告](VERIFIED_RANGE_INDEX_RESULTS.md)保持原字节，旧失败不被本轮通过补写。
本轮没有改生产代码，也没有重做旧计数研究。原生 Windows full/P2996、N3 原 D/F 归因和 N7 真实消费者前提仍开放。
没有暂存、提交、推送、合并、发布或触发远端 CI。
