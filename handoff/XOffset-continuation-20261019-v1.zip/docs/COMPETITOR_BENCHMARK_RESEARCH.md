# 竞品应用场景与功能等价性研究

日期：2026-10-17。范围是 XOffset、cista、FlatBuffers、Cap’n Proto、cereal 的功能研究和后续实验设计输入；zpp_bits 不作为本轮主要候选。本文件没有实施适配器、编译候选库、运行性能或形成新排名。下文“可支持”表示源码或官方文档描述的能力；“待验”表示所选版本和本机组合尚须功能验证，不表示测试已经通过。

具体共同模型和 gate 见[系统设计](COMPETITOR_BENCHMARK_DESIGN.md)，分阶段实施与验收顺序见[实施计划](COMPETITOR_BENCHMARK_PLAN.md)。本研究保留能力全貌；系统设计从中选择更窄的首轮共同模型，例如不含浮点、使用 sorted entries 表示字典。

建议以**固定 schema、可信来源、C++ 可变状态快照**作为共同核心；同时保留只读快照、逻辑图、对象身份和文件映射的独立比较。XOffset 与其他库有可直接竞争的使用场景，但没有覆盖其他库所有公共功能。把所有需求合成一张“序列化速度”榜会掩盖这些差异。

## 输入版本与证据等级

下列是拟锁定的 release 基线，不是“各项目最新版本”的声明。版本 ref 核查由统筹保存；本轮尚未执行这些 release 的跨库等价功能验收。在线官方文档可能描述更新的实现，因此后续必须在固定源码上完成小型功能探针，不能只凭文档启动计时。

| 对象 | 基线身份 | 本研究可据以断言的范围 |
| --- | --- | --- |
| XOffset | `0.1.0-alpha.1`；F 双头与交接提交 `7539433ab96d69c4a07b1db5c0a13786da85cdcd` 中相同 | 当前源码、现有功能测试和限定平台验收；alpha 包装没有修改生产头 |
| cista | [v0.16 / `015b94e66c4c0d7c1ef29742383a024c84fbbba1`](https://github.com/felixguendling/cista/tree/015b94e66c4c0d7c1ef29742383a024c84fbbba1) | 已读该版 README、mode 与 vector 源码；应用适配和生命周期待验 |
| FlatBuffers | [v25.12.19 / `7e163021e59cca4f8e1e35a7c828b5c6b7915953`](https://github.com/google/flatbuffers/tree/7e163021e59cca4f8e1e35a7c828b5c6b7915953) | 官方能力说明；固定 flatc、生成代码与 C++ runtime 的组合待验 |
| Cap’n Proto | [1.5.0 / `373e61ec89e2359f1c362e9b2eadc552f4779306`](https://github.com/capnproto/capnproto/tree/373e61ec89e2359f1c362e9b2eadc552f4779306) | 官方 Reader/Builder、编码与演进契约；本轮适配待验 |
| cereal | [v1.3.2 / `ebef1e929807629befafbb2918ea1a08c7194554`](https://github.com/USCiLab/cereal/tree/ebef1e929807629befafbb2918ea1a08c7194554) | 官方 archive、智能指针及版本机制；本轮适配待验 |

cista 后续修复敏感性可另设 `bde0f01af0ec8f764baae106bd0a46a80e9e7b92` profile；不能把 master 的结果混入 v0.16。FlatBuffers 的所选 release 也不能与其他同前缀 tag 混同。任何切换版本、容器表示、检查模式、allocator 或生成选项都应成为新 profile。

F 身份：`xoffsetdatastructure.hpp` SHA-256 `9bc8f1f533bee83a9e111e05d67319383775dbca1844ef33b1aa717047640bb2`；`xoffset_virtual_memory.hpp` SHA-256 `22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad`。后续冻结应同时绑定工具链、依赖、生成器和生成产物；此处的版本表不代替完整构建锁。

XOffset 实施输入采用已封存 alpha 源码 tar，SHA-256 `5a8647736d1145676c503299d704bc37e2dd035d730ccc2ffca2e5e96a28c658`；不把这些新增研究文档或当前工作树当作新的被测 alpha 包。固定提交链接用于定位其中未变的生产源码和已有测试，不表示整个工作树与该旧提交一致。

## 场景拆分与共同结果

| 轨道 | 调用者实际需要的结果 | 共同工作与比较边界 |
| --- | --- | --- |
| R：只读快照 | 从已到达的字节访问指定值或遍历数据 | 分别报告建立访问入口、校验、首次访问、完整遍历；允许库保留其直接视图优势。不能额外要求所有库都复制成 XOffset 的 owner |
| M：可变状态生命周期，候选核心 | 恢复后完成相同业务操作，产生下一份独立可恢复快照并释放本轮资源 | `restore → read → mutate → checkpoint → release`；计入必需转换、重建、复制、输出和析构。独立的阶段时间用于解释总成本，不代替生命周期总量 |
| G-ID：以 ID 表示的逻辑图 | 节点/边和关联关系的值相同，可由索引解析 | 所有库都可把图编码为记录、序列和 ID；这是应用图模型，不证明保存了任意 C++ 指针身份 |
| G-identity：对象身份 | 两条引用仍指向同一个对象，循环与指定 alias 关系保持 | 先逐项验证共享、循环、空引用、子对象 alias；不支持的子项记 N/A。改成 ID 表必须标成另一种应用实现并计入解析成本 |
| F：文件映射/启动 | 以文件内容为只读后端，按需访问 | mmap、page fault、page cache、文件读取和内存副本分开；不能拿热缓存入口建立时间冒充完整冷启动 |
| S：不可信输入 | 有限资源内拒绝非法输入，成功发布后的使用符合明确安全契约 | 专门研究威胁域、限制和失败发布；不以“带校验”三个字宣布五库安全等价，也不直接并入可信 M 排名 |

候选 M 可模拟游戏/仿真状态、可变索引或业务内存状态的周期检查点；这些是**待验证的代表性假设**。没有业务 trace 时只能称合成状态。只读资产/路由数据的真实应用可以证明另一类需求存在，不能证明 M 的操作比例与生产环境一致。

首轮核心 schema 采用固定宽度整数、无嵌入 NUL 的有效 UTF-8 字符串、记录、序列和字典，排除浮点。浮点的 NaN、负零与比较规则可另立合同，不能在首窗临时加入。多态、任意指针和跨 schema 演进也先排除，避免共同核心因 XOffset admission 而暗中变化。排除项仍应在能力矩阵公开列为边界，而不是从功能比较中消失。

## 能力矩阵

“直接”指所选 API 的自然结果；“转换”不等于不支持，但必须记入成本。表中的外部能力以文末各库说明的官方来源为依据，固定版本实证仍待后续探针。

| 能力 | XOffset F | cista offset | FlatBuffers C++ | Cap’n Proto C++ | cereal |
| --- | --- | --- | --- | --- | --- |
| 类型描述 | C++ P2996 反射、admission、root schema 注册 | 原生 C++ 类型及库容器，可定制成员描述 | IDL + flatc；生成访问器/可选对象 API | schema 编译器；Reader/Builder | 用户序列化函数及类型适配 |
| 读字节时重建 native 对象 | load 复制到新 reservation 后访问 | 同 endian offset 路径可借用字节 | 可直接使用 wire 视图 | 可直接使用 segment Reader | 反序列化重建 C++ 对象 |
| 加载后变长修改 | admitted X 容器有相应 API，非完整 STL 接口 | 支持，扩容可转为独立 heap 分配 | Object API unpack/mutate/pack；有限原地修改另列 | Builder 可修改；变长序列须使用替换/重建等明确算法 | native/std 容器正常修改，再归档 |
| 字典/集合 | 有序 flat map/set | hash map/set | keyed table 的排序向量可查找；对象 API 可再适配 | 序列/应用索引建模 | 可序列化适配后的 STL 容器 |
| 通用持久引用与共享图 | 无公共 admitted offset-pointer 图模型 | 有 indexed 目标、offset ptr 和循环图能力 | 可复用 wire table 构成 DAG；对象 API 的外部引用需 resolver | 消息对象模型为树；业务图用 ID 等建模 | shared/weak/unique 指针有专门支持；raw/reference 与 shared_ptr aliasing 有限制 |
| 文件 mmap 直接只读 | 无公共 file/shared-memory attach API | 有 mmap 序列化/读取路径 | contiguous wire 可置于映射内访问 | 官方支持 regular、非 packed 文件映射读取 | archive 重建对象，不提供等价 wire 对象视图 |
| schema 演进 | 固定 schema/layout 匹配，不提供迁移 | 可选 type hash 检出变化，不是迁移 | 遵守 table/field ID 等规则的格式演进 | 遵守 ordinal/type 等规则的协议演进 | 可选 class version + 用户 load 分支 |
| 跨语言格式生态 | 本库无对应 IDL/其他语言 reader | release README 面向 C++ | 有 | 有 | 面向 C++，不是跨语言 schema 系统 |
| 增长与地址 | 同一 owner 的 arena base 稳定；元素仍可失效 | vector 增长可移动元素和分配外部存储 | builder/对象容器都有各自失效规则 | 多 segment 增长无需搬迁已有 segment；替换对象仍有寿命规则 | 按 native 容器/智能指针规则 |

### XOffset 的直接证据与不能外推的边界

V1 admission 递归要求 byte-copy-safe，并拒绝指针、引用、成员指针、union；记录还需 standard-layout、无基类、非多态、对齐不超过 8。普通 `std::vector/std::string` 不会因此成为 arena 容器。见[准入源码](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffsetdatastructure.hpp#L2509)和[拒绝类型测试](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/tests/test_wire_admission.cpp#L65)。因此共同核心应明确为 admitted 的树形所有权/容器数据，而非声称支持任意现有 C++ 对象图。

`XVector` 提供 push、insert、erase、resize、assign；`XString` 有 assign/reserve/clear，不能承诺完整 `std::string` API。`XMap/XSet` 的 flat 基类用 lower_bound 定位并维护严格顺序，不能以 hash 容器命名或假设其更新复杂度。见[向量 API](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffsetdatastructure.hpp#L2253)、[字典实现](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffsetdatastructure.hpp#L2039)及[容器顺序测试](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/tests/test_fixed_layout_containers.cpp#L317)。二分查找与中间插入移动的成本是代码可推导的性质，尚不是实测结论。

`XHandle` 保存进程内 buffer 指针、缓存地址和 resolver，不是可保存进 wire 的 offset pointer。[校验器拒绝重叠 owned ranges](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffsetdatastructure.hpp#L2591)，也不会把任意整数识别为自定义图边。[handle 实现](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffsetdatastructure.hpp#L3381)不建立共享对象身份/循环的持久化契约。用户可以自己设计 ID 图，但其验证和 compaction 修正规则须另行实现；不能把内部 rel32 容器头当作通用 offset-pointer 支持。

[save_verified](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffsetdatastructure.hpp#L3619)规范化后生成 owning byte copy；[from_bytes](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffset_virtual_memory.hpp#L191)创建 owner 并 memcpy 输入。[OS 映射](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffset_virtual_memory.hpp#L163)是私有匿名 reservation，不是已有文件或共享段 attach。R/F 轨道不能将它写成零复制加载。

[verified load](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffsetdatastructure.hpp#L3720)在允许 typed root 前检查 header、schema、allocator 和结构图。schema hash 包含注册名与递归 size/align/成员 offset/type 签名，字段名字本身不进入该布局签名；它不能证明业务语义未变，也不能迁移旧布局。[签名实现](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffsetdatastructure.hpp#L3069)及[同类型 compactor](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/xoffsetdatastructure.hpp#L3962)都不提供 schema migration。V1 CRC 字段写入且要求为 0；合法 scalar 的变化可以通过结构校验，见[bit-flip 测试](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/tests/test_wire_validation.cpp#L118)。verified 不等于内容 checksum、认证或任意资源上限。

同一 owner grow/save 的 base 稳定有[生命周期测试](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/tests/test_stable_storage.cpp#L416)。这个保证不延长元素、借用视图或 handle 的寿命；load/compact 是新 owner。独立 buffer 可分线程使用，同一 buffer 修改仍需外部同步；[线程测试](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/tests/test_stable_storage.cpp#L738)不证明共享可变 root 的线程安全。完整范围见[alpha 兼容文档](ALPHA_COMPATIBILITY.md)。

### 其他库的能力与成本解释

cista v0.16 明确面向 C++17 native struct，提供 offset/raw 两族、可变反序列化数据与复杂图；reader/writer 指针宽度需一致，跨 endian 需要转换。[release README](https://github.com/felixguendling/cista/blob/015b94e66c4c0d7c1ef29742383a024c84fbbba1/README.md)。v0.16 的 vector reserve 在容量不足时 malloc、move 元素，区分 borrowed 与 self-allocated 存储；M 不能只计算原输入 buffer，必须覆盖新增 heap 和正确清理。[固定源码](https://github.com/felixguendling/cista/blob/015b94e66c4c0d7c1ef29742383a024c84fbbba1/include/cista/containers/vector.h#L348)。indexed 目标可以支持持久引用，但 vector resize 不提供元素地址稳定保证；type hash 是变化检测。[官方序列化参考](https://github.com/felixguendling/cista/wiki/Serialization-Reference)。

cista 的默认检查、DEEP_CHECK、WITH_VERSION、WITH_STATIC_VERSION、WITH_INTEGRITY、UNCHECKED/CAST 应作为不同契约披露，不能挑最低检查成本却沿用最强安全表述；静态/动态 type hash 也须记录实际选择。[v0.16 mode 定义](https://github.com/felixguendling/cista/blob/015b94e66c4c0d7c1ef29742383a024c84fbbba1/include/cista/mode.h)。官方还明确警告：修改来自不可信来源的反序列化数据后，不能保证继续访问安全；因此本研究不把 S→可变操作作为已建立的共同能力。[官方安全说明](https://github.com/felixguendling/cista/wiki/Security)。这不否认可信快照的可变 API，也不构成对某个固定版漏洞的新增结论。

FlatBuffers 的 Object API 可将 wire UnPack 到 C++ 对象和 STL 容器，修改后 Pack 成新 wire；不能写成“不支持变更”。直接 wire 修改的覆盖面更窄，实验 reflection resizing 需要另定 profile。keyed table 向量可实现有序查询；外部引用 resolver 不等于自动保存任意 native 共享图。[官方 C++ 指南](https://flatbuffers.dev/languages/cpp/)。其跨语言与 table 演进能力超出 XOffset 当前承诺；演进仍需遵守 field ID/default/deprecation 等规则，不能称任意 schema 自动迁移。[官方演进规则](https://flatbuffers.dev/evolution/)。

Cap’n Proto 的 Reader 和 Builder 均借用消息寿命；Builder 可以 set/init/adopt，list 创建时有确定长度。变长更新可采用替换/重建，需把实际算法和复制成本冻结，不能把只读 Reader 当成可变恢复已完成。旧对象占用与 checkpoint 清理方式也须审计。非 packed 文件可 mmap 读，packed 输入另有解包成本。[官方 C++ 指南](https://capnproto.org/cxx.html)。多 segment 可避免搬迁既有 segment，但对象关系按编码契约为树，不能据此承诺任意共享/循环 native 图。[官方编码规范](https://capnproto.org/encoding.html)。协议演进遵守自身规则，不依赖 C++ struct ABI。[官方 schema 文档](https://capnproto.org/language.html)。

cereal 读取 archive 后得到可普通修改的 C++ 状态；它支持 shared/weak/unique 指针的跟踪，raw pointer/reference 和 shared_ptr aliasing constructor 不属于相同支持域。[官方指针文档](https://uscilab.github.io/cereal/pointers.html)。class version 只向用户的序列化函数提供版本，迁移逻辑仍由应用编写。[官方版本机制](https://uscilab.github.io/cereal/serialization_functions.html)。Binary 与 PortableBinary 不能混用为同一 profile；后者处理 endian，仍要求应用确保类型大小一致。[v1.3.2 PortableBinary 源码](https://github.com/USCiLab/cereal/blob/ebef1e929807629befafbb2918ea1a08c7194554/include/cereal/archives/portable_binary.hpp#L55)。

以上能力不自动建立同一威胁模型、事务保证或并发承诺。特别是 FlatBuffers upfront Verifier、Cap’n Proto 访问时的界限/遍历限制、cista 的各模式、XOffset 的结构图验证、cereal 的类型反序列化不是同一项工作。核心 M 可统一为可信 producer 输出，同时完整披露各库实际启用检查；S 再单独规定攻击输入、深度/长度/分配预算、异常处理及发布点。

## M 轨道的成本矩阵与适配契约

此表是待实施的成本核算要求，不是已有 benchmark 成果。相同的逻辑结果不要求相同 wire 字节数，也不要求所有库采用同样的内存表示。

| 实现 | 恢复为可变状态必须保留/计入 | 变长更新和 checkpoint 必须计入 | release 核查重点 |
| --- | --- | --- | --- |
| XOffset | 新 reservation、输入复制、verified load 和进程内登记 | arena 分配/搬移、显式或自动增长、规范化及 owning save copy | 输入、state、输出三种寿命；硬上限失败；不将 accessible/reserved 当作 RSS |
| cista offset | 对齐输入及其寿命、固定检查模式；是否需要复制由 API 和输入所有权决定 | 库容器 heap 扩容、外置存储、再次 serialize 输出 | borrowed bytes 与新增 owned allocations 都释放；正确析构，避免重复 free；共享图失效规则另验 |
| FlatBuffers Object API | Verifier、UnPack、新对象与输入重叠的峰值 | 标准容器修改、Pack、builder 输出 | native tree、builder、输入/输出均销毁；不保留上轮 builder 数据充当无成本复用 |
| Cap’n Proto Builder | 有界 Reader、复制/转换到可修改 builder 所需的真实工作 | 替换 list/text 的分配与复制，旧占用，segment 输出或 flat 输出 | 不再可达对象/arena 的保留；scratch/拷贝；明确是否经过额外 compact copy |
| cereal Binary | archive 读取、native 容器分配/构造 | std 容器操作、归档与 owning 输出提取 | stream、临时对象、archive 跟踪表与 state；不把复用目的对象的结果混作 fresh restore |

上表列出 checked 路径的候选成本，不把它规定为首窗一律强制的入口。系统设计的 `T-trusted` 允许对已封存、来源可信 fixture 使用事前登记的最小安全入口，库强制检查保留；首窗实际 mode 由 P0 冻结。例如 cista UNCHECKED/CAST 是否进入某个 T profile，必须在功能 gate 前决定并如实标注，不能沿用 U 的安全表述。XOffset typed verified、FlatBuffers Verifier + Object API、Cap’n Proto 有界 Reader→Builder 等可作为明确检查模式；不同属性仍须写在结果旁。本研究 S 对应设计中的 `U-untrusted`，其 U-read 与 U-mutable 分开准入。portable archive、packed、reflection resizing、pool/custom allocator、专门 compact 等不得静默替换既定主轨。

操作语义先固定，再选择 API。候选操作包括整数更新、替换不同长度字符串、序列 append/insert/erase/resize、字典 insert/update/erase 和按 key 读取；每个步骤须由独立参考模型核对，不仅核对最终数量。对字典先决定需求：仅 key/value 结果可允许 hash/flat 不同实现并披露；若要求顺序遍历/range query，就必须计入为达成顺序所需的排序或索引工作，不能省略后仍宣称等价。

业务批次的失败原子性应独立于单容器异常保证。若要求旧发布状态在失败后仍可用，各库都要保留旧值并在新值完整通过后提交；相关复制、双状态峰值和销毁计入生命周期。XOffset 的单次分配失败测试不证明一组业务操作天然构成事务。[失败测试](https://github.com/ximicpp/XOffsetDatastructure/blob/7539433ab96d69c4a07b1db5c0a13786da85cdcd/tests/test_mutation_failures.cpp#L28)。

R 可以测试少量字段与全遍历两种访问密度；M 必须完成相同读写与下一份快照。G-identity 须额外核对两条路径解析出的 identity，以及从一条引用修改后另一条引用能否看到该变化。仅 checksum 相同不能证明 identity 相同；shared_ptr 强循环的释放也需应用明确处理。

## 既有 benchmark 能证明什么

作者的 [cpp-serialization-benchmark](https://github.com/felixguendling/cpp-serialization-benchmark/tree/f8216ebe69de31a41d390e9b1d7618a4ed641faf) 是公开可检查的图序列化、反序列化和遍历实验。其 README 自述为 cista 发布配套；不能由此推出它无价值，也不能把该结果当成本项目 M/G/S 的等价性证明。本研究不搬用其数字形成新排名。

以下不是“库性能已判定”的证据，而是重用该 harness 前必须解释或修正的工作量差异：

| 原源码事实 | 对本轮结论的影响 |
| --- | --- |
| cista slim edge 使用 11/11/10 位域；cereal/Cap’n Proto 使用三个 16-bit 值 | 信息域和存储表示不同；共同核心禁止只替一个库压缩字段范围。[slim](https://github.com/felixguendling/cpp-serialization-benchmark/blob/f8216ebe69de31a41d390e9b1d7618a4ed641faf/include/csb/benches/cista_offset_slim.h)、[cereal](https://github.com/felixguendling/cpp-serialization-benchmark/blob/f8216ebe69de31a41d390e9b1d7618a4ed641faf/include/csb/benches/cereal.h) |
| FlatBuffers 一份 Edge table 被 in/out 两组引用复用，slim/cereal/Cap’n Proto 则保存边的值副本 | 逻辑遍历可相同，wire identity/重复量仍不同，不能称共同原生指针图。[FlatBuffers](https://github.com/felixguendling/cpp-serialization-benchmark/blob/f8216ebe69de31a41d390e9b1d7618a4ed641faf/include/csb/benches/fbs.h)、[Cap’n Proto](https://github.com/felixguendling/cpp-serialization-benchmark/blob/f8216ebe69de31a41d390e9b1d7618a4ed641faf/include/csb/benches/capnp.h) |
| Cap’n Proto reader traversal limit 被提到 uint64 最大值；FlatBuffers depth/table 上限也被提高 | “safe deserialize”标签不表示相同有界安全策略；不能继承为 S 的合格配置。见同上两个 adapter |
| FlatBuffers fast deserialize 是空函数；Cap’n Proto 检查可延后到访问 | 入口建立时间不能与完整对象恢复/完整校验直接相除；必须同时看访问完成点 |
| 重复 serialize 共用一个 Bench；FlatBuffers adapter 未显示 Clear，cereal 清空 stream；反序列化目的对象也可复用 | 输出 buffer 和目的容量的复用策略不同，必须另验增长与 reset；不据静态观察直接断言旧数字的误差大小 |
| restore 在 PauseTiming 内；遍历预先完成 fast deserialize；没有变更再保存 | 这些边界适合其原问题，不包含本轮完整 M 生命周期。[计时主程序](https://github.com/felixguendling/cpp-serialization-benchmark/blob/f8216ebe69de31a41d390e9b1d7618a4ed641faf/src/main.cc) |

论文/旧主页与当前 README 的表格有不同代际，不能抽取其中一行与另一代的行拼接。历史硬件、编译器、依赖、模式和计时边界也不能改标为本机复现。XOffset 现有 D/F 和 N3 实验研究的是本项目内部变化，不含这五个库的共同适配器，同样不能作为跨库排名来源。

## 后续功能验收的设计输入

本文件不实现下面的探针；它们是进入系统实施计划前应冻结的可执行条件。

1. **能力探针先于计时。** 在固定 release 上验证字符串变长、空/单元素序列、容量跨界、嵌套容器、map 更新、save/load 多轮；核对具体 API、异常/析构路径和实际启用检查。失败据实分类，不临时改成较弱操作。
2. **共同 schema 与独立 oracle。** 不共享候选库的 serializer 作为真值；逐字段、逐步骤核对有符号性、宽度、边界值、字符串和顺序。浮点 NaN/负零、字符串编码等特殊语义若要纳入须先单独定义。
3. **生命周期可审计。** 用 owner/借用关系记录输入、可变 state、临时区、旧发布状态和输出；先证明迁移/销毁后不再访问旧地址。只保留同一状态反复 mutate 与每轮 fresh restore 必须分 profile。
4. **能力缺口保留为 N/A。** XOffset 的通用 offset-pointer/alias/cycles、native file attach、跨语言、schema 演进不通过性能数字补齐；FlatBuffers/Cap’n Proto/cereal 也不因采用转换路径被误记为不支持可变状态。
5. **诊断与正式样本分开。** allocator、RSS、page fault、复制量等可用单独诊断构建解释；不把插桩数据混成无插桩计时。峰值需覆盖转换/检查点双表示；VM reservation、可访问页、live allocation 和 RSS 分别报告。
6. **版本敏感性提前声明。** 新 cista commit、特殊内存池/手工紧凑表示、FlatBuffers reflection、Cap’n Proto packed 等在看到主结果之前确定是否研究。不能反复调参直到某库获胜再只发表最优项。

功能 probe、结果解析器、oracle 与预算审查通过以后，才具备申请有限测量窗口的技术前提。此处不规定未得到业务支持的操作比例，也不把这项研究自动升级为执行授权。

## 当前可得结论、假设与开放项

| 结论类别 | 当前状态 |
| --- | --- |
| 有直接证据的能力交集 | 五库可表达固定 schema 的记录/序列/字符串状态；都有达成修改后再保存的路径，转换/寿命成本不同 |
| 有直接证据的功能差异 | XOffset 无通用持久指针图、file/shared-memory attach、自动 schema migration 或跨语言 SDK；base 稳定不等于任意元素地址稳定，也不是只有 XOffset 能避免增长搬迁 |
| 可由源码推导、仍待本轮功能确认 | cista 扩容后的 heap 所有权、Cap’n Proto 替换分配与旧占用、FlatBuffers unpack/pack 的双表示、cereal 目的对象复用都影响生命周期成本 |
| 尚无证据的收益假设 | XOffset 在某种状态密度/修改比例/检查点频率下总成本更低；cista 某模式较优；某库峰值更少或更适合目标业务。这些都不能写成结果 |
| 尚无证据的代表性 | 合成 M 的 schema、大小、读写比例、失败模型是否代表真实业务 |
| 测量资格 | [现有 WSL F/F 窗口](VM_N3_CURRENT_RESULTS.md)未取得预定 2% 噪声资格；不能继承为新跨库窗口的资格或因果归因 |

用户已允许后续 Linux 性能在 WSL 或 Docker 内开展，独立物理 Linux 机不再是本轮研究的启动门槛；环境类别、宿主/容器限制、缓存和内存口径仍需如实记录。历史 N3 的原始结果、当时门槛与失败证据保持原样；新的有限窗口另行设计，不能通过重试旧窗口获得期望结论。

N7 的真实业务入口仍不存在：用户 2026-10-16 已答复“暂不具备”，状态保持 `prerequisite_unmet_retain_F`。[现有前提记录](coordination/vm-continuation-20261016/N7-prerequisites.md)。本研究没有获得代表性消费者、生产异步 transport、实际 trace、并发/取消/SLA 或网络预算；合成状态实验不关闭 N7、不证明生产采用，也不引入其三项 I/O 扩展。

后续对外可以回答“在这个明确的固定 schema C++ 生命周期里，哪些实现达成了相同结果、花费了哪些成本”。在能力和代表性尚未补齐时，不应回答“XOffset 完整替代全部竞品”或给出脱离语义的总体冠军。
