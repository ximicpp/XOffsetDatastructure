# 多档虚拟地址槽位池评估

日期：2026-10-18。结论状态：**有条件加入后续研究清单；当前不采用新的生产槽位后端。**

建议先以现有 API 做显式容量策略和有界复用对照。统一大区间切槽仅在该对照不能解决已量化的 owner 创建/销毁成本时进入原型。内部字符串/数组各占巨大稀疏槽、借此改变 V1 表示的方案不纳入本路线。此结论不依赖新的测试或性能测量；本轮没有执行它们。

## 1. 决策依据与范围

本评估使用指定的已验收 V5 开发候选，而非根目录历史 F 或正在修改的 V6。这里的“验收”包括既有功能门禁及测量资格，**不表示 V5 已证明总提速或已晋升性能基线**。本轮只核对两个头的实际字节身份并只读分析；没有重新审计 V5 的全部原始测量输出。

| 基线文件 | 实际 SHA256 |
| --- | --- |
| `C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp` | `c4acc7f2005711452e12f0cd7c5d7bc57efe2d4ca0fabc207b6f711b1dbb9964` |
| 同目录 `xoffset_virtual_memory.hpp` | `22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad` |

重要证据按优先级区分：当前 V5 源码决定本轮“实际实现”；[V5 验收](../PERFORMANCE_V5_ACCEPTANCE.md)描述已有实测；[迁移契约](../STABLE_VM_STORAGE_MIGRATION.md)与[兼容说明](../ALPHA_COMPATIBILITY.md)界定公开行为；旧阶段计划和结果用于恢复设计取舍。旧文档中的平台待办、索引结构或“不采用池”的阶段决定不能覆盖后来的实现。读取范围与源码定位见 [SOURCES.md](SOURCES.md)，身份记录见 [EVIDENCE.json](EVIDENCE.json)。

理由是：

1. 稳定 arena、按需启用、显式回收、跨线程独立 owner 与空闲复用均已存在。容量分档大部分可以由调用端策略实现，无需重新发明存储后端。
2. 大量独立 owner 的 churn、峰值 VA 和池容量匹配仍有值得验证的问题，但当前缺少业务容量/寿命分布和目标指标，不能预先断言节约 RSS 或改善 tail latency。
3. 统一切槽可能摊薄 reservation acquisition，但不能消除每个 owner 的清零/复制、页启用、注册、完整验证和输出所有权成本；还会增加整块池寿命、容量碎片和平台失败处理。
4. V5 固定 M 场景已有 owner 缓存命中 98,303/98,304，stage7 新分配为 0。V6 正在处理小块申请/退休和修改后重载精确校验，本提案没有理由占用其关键路径。

## 2. 源码核验与容易混淆的概念

`VirtualMemoryStorage` 在创建时对 maximum 做页取整，Windows 用 `MEM_RESERVE`，POSIX 用匿名 `PROT_NONE` 映射；grow 在该范围启用前缀，不移动 base。普通 grow 仍 `memset` 新暴露的逻辑范围，shrink/regrow 也如此。fresh load 完整复制输入后才发布 logical；仅 POSIX、非池化、输入长度等于 maximum 的特例合并 reserve/enable。池化并非对该特例天然更快。

默认 maximum 是 `max(initial, 64 MiB)`，legacy hint 仍取 `max(initial, default, hint)`；显式 `maximum_capacity(n)` 保留精确硬上限。`MAX_PAYLOAD=0x7ffffff8`。逻辑长度/可访问长度/预留长度彼此不同，页舍入不能增加硬上限。不存在超限自动换槽、搬迁或后端 fallback。

**当前 V5 owner 冷路径是 `std::map`，热路径是四槽 TLS OwnerRecord 缓存。** `OwnerRecord` 的 payload 身份不变，原子 owner 指向在 move/swap 时更新；注销置空，旧 record 永不复活。节点准备和可能触发用户回调的释放在锁外。旧迁移文档描述的哈希索引是历史版本，不能当作指定 V5 当前结构。owner 查询入口已知 arena 起点，不需要新增“任意内部地址找 owner”的能力。

“地址相隔很远”不是增长保证：必须持有中间所需 reservation。整个 arena 稳定也不保证内部容器稳定；非尾 string/vector 扩容、插删或重建仍可搬动数据。外部 host-only 槽位池只改变**各独立 owner** 的地址/回收管理，不改变各 owner 内部连续 payload。

V1 rel32 限制单图内部的相对距离，MAX_PAYLOAD 进一步限制连续段长度；不同独立 owner 可以远隔，不能因此建立跨 owner V1 引用。20 万个子分配每个隔 64 KiB，首末位置差约 12.21 GiB，已经超出当前连续段契约。未启用的洞不能被现有连续 memcpy/save 读取；把洞启用并输出、特殊填充或 compact 都另有成本和语义。本评估否决以此直接替代 V1 内部布局，不设计稀疏 wire。

10 万个等容量槽的纯 VA 算术如下，未计 guard、对齐、元数据和进程其它映射，也不代表这些地址可成功申请：

| 单槽跨度 | 总 VA |
| --- | ---: |
| 64 KiB | 6.1035 GiB |
| 1 MiB | 97.6563 GiB |
| 16 MiB | 1.5259 TiB |
| 64 MiB | 6.1035 TiB |
| 1 GiB | 97.6563 TiB |

以上不是物理内存。降低 maximum 可能减少 VA，但也减少可增长额度；只有调用者明确知道需求时才可选择，不能把缩减能力记作无代价优化。

## 3. 已有池能力及候选对照

`XBufferPool` 是 `detail::VmStoragePool` 的公开别名。一个池就可缓存混合 maximum，acquire 在缓存 vector 中按**精确 maximum** 线性匹配；不只是比较页取整后的 reserved。缓存 metadata 一次预留；return/move/swap 不分配。池自身有 mutex，`clear()` 在锁内释放 idle 映射。活 owner 持有共享池状态；idle 映射不反持有该状态，避免环。缓存超限则释放整个独立 mapping；miss 正常新建独立 reservation。

现有三个 limits 只约束 idle 数量、idle reserved、idle accessible；命中/未命中不限制 live 总量，也不是固定容量槽库耗尽协议。return 不保留上一个 owner 的 root/schema/身份，下一次创建清零逻辑区、load 完整覆盖；旧指针已失效，地址再用不能使其恢复有效。

| 候选 | 新增内容/可能收益假设 | 代价及决定 |
| --- | --- | --- |
| A0：现有独立 reservation，无池 | 当前默认对照；每 owner 已稳定增长 | 保留。所有时间、VA、内存比较须有此对照 |
| A1：调用端显式选 maximum，复用当前池 | 工厂按已知寿命上界选档；单个混合池或配额相加的分档池；暖复用少 reserve/release | **优先研究**。不改头即可做到基本分档。须与相同 maximum 的 A0 比，另列“缩小默认上限”的策略差额 |
| B：独立 reservation 的容量索引/回收优化 | 仅在观测到扫描/锁内释放为瓶颈后，替换缓存查找或摘取释放顺序 | 条件候选，复用已有池所有权。改变 clear 线性化语义须设计；先不增加 TLS 池、后台 TTL、默认回收 |
| C：每档一个或多个预留大块、块内固定槽 | 有界槽数、批量预留；可能降低冷 reserve 次数、支持显式 admission | **暂缓实现**。保留其作为 A1/B 仍不足时的研究分支，不与掩码 owner 查找捆绑 |

A1 已能解决“不同单位按容量档预留、按需启用、归还复用”这一主体诉求。真正要求 C 的理由应是：固定并发规模下的 reservation/内核映射成本仍显著、需要可证明的固定槽 admission，或冷启动 reservation tail 已超业务 SLO。单纯要四个档位或稳定基址不足以引入 C。

C 也不保证减少 VMA 总数：不同槽的可写前缀和不可访问尾部会形成保护边界；空闲槽分散使块难释放。一个存活大槽可钉住整个大块的 VA。多档会同时出现“本档耗尽、别档有大量闲置”的 stranded capacity，不能用隐式借大档、更改 maximum、临时独立分配掩盖。首个 C 原型应在该档耗尽时明确失败，或由调用者事前选择有独立配额的 overflow 策略；本报告不授权后者。

## 4. 平台可行性：API 存在不等于目标规模可行

Windows：reservation 与 commit charge 不同，物理页可延迟到访问。预留地址对齐与提交页粒度不同，应运行时查询 `GetSystemInfo`，不把 4 KiB/64 KiB 写死。[VirtualAlloc](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualalloc)

普通整段 `VirtualAlloc` reservation 的 `MEM_RELEASE` 必须使用原始 base、size=0，释放整段；块内槽不能沿用当前逐 mapping 析构。C 可在槽退还时 decommit，保留大块；仅最后租约和在途操作消失时整段 release。另一条路线是 placeholder 的拆分、替换、还原与合并，但须另做状态机及具体版本/API 可用性门禁，不将其当作原 VirtualAlloc 的等价替换。[VirtualFree](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualfree)、[VirtualAlloc2](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualalloc2)

微软列出的 x64、LARGEADDRESSAWARE 进程 VA 上限在 Windows 8.1/Server 2012 R2 及以后为 128 TB，早期为 8 TB；这不是可获得连续区间或应用剩余预算。模块、栈、堆、ASLR 和其它映射仍占地址空间。10 万个 1 GiB 槽约 97.66 TiB，绝不是安全的普遍默认。[Windows limits](https://learn.microsoft.com/en-us/windows/win32/memory/memory-limits-for-windows-releases)

Linux：可用用户地址位宽取决于硬件、内核和 ABI；x86 五级页表支持 56 位用户空间，但默认分配仍避免超过 47 位，不可按指针宽度推导空间。[x86 五级页表](https://docs.kernel.org/arch/x86/x86_64/5level-paging.html) AArch64 的地址位宽还取决于页大小与配置，39/48/52 位等配置不能互相代替。[AArch64 layout](https://www.kernel.org/doc/html/latest/arch/arm64/memory.html)

`mprotect` 可因内核 metadata 或保护分段数不足报 ENOMEM，统一大 mmap 不能消除槽级保护切换引起的分裂。[mprotect](https://man7.org/linux/man-pages/man2/mprotect.2.html) `max_map_count` 覆盖 mmap/mprotect/madvise 等产生的区域，应读取实际值而不假定发行版默认；本轮不改 sysctl。[内核 sysctl](https://kernel.org/doc/html/latest/admin-guide/sysctl/vm.html) `RLIMIT_AS` 也能拒绝预留，不能只看 RSS。[getrlimit](https://man7.org/linux/man-pages/man2/getrlimit.2.html)

可写匿名映射和 mprotect 变为可写参与 overcommit accounting；模式 0/1/2 行为不同。PROT_NONE 预留、可写权限、commit accounting 和 RSS 必须分开。成功启用不能在所有模式下保证日后触页都能恢复成 C++ 异常。[overcommit](https://www.kernel.org/doc/html/latest/mm/overcommit-accounting.html) 匿名私有页 `MADV_DONTNEED` 后重新访问有 demand-zero 语义，但回收/重触会有成本；当前 Linux 还保留 discard 成功而 protect 失败的部分结果。[madvise](https://man7.org/linux/man-pages/man2/madvise.2.html)

macOS：具备匿名 mmap、保护和映射失败机制；页边界/区域权限需按真实环境验证。当前 OS 头的 reclaim 使用受控 `MAP_FIXED` 匿名替换，不能在未知地址上套用，更不能先 unmap 再抢回。[Apple mmap](https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man2/mmap.2.html)、[Apple mprotect](https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man2/mprotect.2.html) 这些是归档 API 资料，只支持接口语义，不能给现代 macOS 的可用 VA、区域数或内核 metadata 每项字节数背书。具体上限和 native 行为仍需 profile/设备门禁；本评估没有该平台运行结果。

iOS：Extended Virtual Addressing 是允许访问扩展地址空间的 entitlement，不能与更高 memory limit 混为一谈；官方两项说明均不保证任意 app/device 可申请多 TiB。设备、系统版本、签名 capability、前后台生命周期、内存压力及目标 app 资格是实施前输入。[扩展地址 entitlement](https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.developer.kernel.extended-virtual-addressing)、[提高内存限制 entitlement](https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.developer.kernel.increased-memory-limit) 不引用旧 Apple 文档“约 18 EB”的抽象描述作为现代可用地址保证。

Android：继承具体 Linux/arm64 的限制，同时必须覆盖真实 4 KiB/16 KiB 环境，逐 owner 页尾和 guard 开销会随页大小变化。[AOSP 页大小](https://source.android.com/docs/core/architecture/16kb-page-size/optimize) 指针高位也不应当作自由 metadata 位；Android heap tagging/TBI/MTE 是额外约束，不能由此反推所有匿名 mmap 指针都被同样打 tag。[AOSP tagged pointers](https://source.android.com/docs/security/test/tagged-pointers) Android/iOS 的完整库工具链、应用权限、资源和生命周期支持本轮均未验证。

因此 OS 层采用矩阵必须按“OS/架构/版本/页大小/运行环境/签名与资源限制/后端”分别记录。普通 C++17 存储层通过不替代 P2996 全库；WSL 不替代独立 Linux 设备；任一平台通过不扩大为全平台生产支持。不能给一个全平台固定 mapping 数上限或每槽内核开销常数。

## 5. 容量、失败与生命周期的必要契约

**容量选择**：调用方先给初始 logical 和期望精确 maximum。A1 的工厂可以在创建前明确选择档位，但不能把已经传入的 n 静默变成向上/向下的档位。C 即使用大槽承载非档位 n，也必须独立保存并检查 n，未使用的槽尾不可算作可增长额度。小于 bootstrap/初始 payload、超过 MAX_PAYLOAD、舍入溢出均按原规则拒绝。不能在存活期间升档、扩大上限或移动；调用方需另一 owner 时使用现有显式复制/compact 并承担指针和 epoch 后果。

**创建/加载**：取得槽租约 → 准备页面 → 清零或完整输入覆盖 → 建立合法 header/allocator → 注册独立 OwnerRecord → 按原顺序完成 verified 准入再发布 typed access。构造抛出也要释放临时租约；replacement 继续新 owner 成功后切换，旧值保持原保证。资源限额检查不能无意重排已有坏 wire 错误优先级。新后端不缓存“上次该槽已验证”的结论。

**增长/回收**：每槽只管理自己的 RW 前缀和不可访问尾部，不能保护邻居页；slot/guard 边界要按页对齐。准备失败可留下已启用页，必须如实统计，logical/已有值不可半发布。reclaim 仅作用逻辑末尾之后整页，最后部分页保留；保留现有部分成功结果。不能将保护撤销等同物理回收或 RSS 立即下降。save/shrink 默认仍不自动回收。

**销毁/clear**：先使该 owner record 失效并从可查集合注销，再允许地址再用。C 的 slot lease 持有 chunk/state，最后活 owner、正在 return 的操作和清理操作结束前不可 release chunk。`clear()` 对 idle 的承诺必须明确：对单块池只能 decommit/退还空闲槽，不能假称已释放全部 idle VA；若保留原 `clear()` 释放 idle mapping 的效果，应使用可独立释放的后端或另设 API，不能静默改变含义。可按多块降低钉住效应，代价是管理更多块/碎片。

**跨线程/move/swap/回调**：独立 owner 可跨线程转交并在其它线程析构；需要 release/acquire 或等价同步，禁止同一 owner 并发修改/销毁。move/swap 连同 lease、maximum、growth policy、类型状态和 record 转移，handle 仍跟 C++ buffer 对象并遵守 epoch；raw pointer 仍只跟实际 reservation 寿命。return/move/swap 的 noexcept/无新增 host 分配要求不能丢失。不能在池/registry 锁内触发可替换 new/delete、new_handler 或用户回调；锁顺序、失败回滚和可重入释放必须先设计。回调后重新解析 owner，不能带裸 Core 地址跨回调。

状态建议为 `free → acquiring → live → retiring → idle/free`；OS 回收部分失败进入明确的保留/隔离状态并继续计预算，不将未处理页面伪装为空闲成功。发布前持有预分配 metadata credit；预算检查和状态转换同一同步域完成，不发生“并发各看余量均足够”的超额。当前不改变现有公开线程契约。

## 6. 预算必须覆盖的不同量

至少报告下列账本，不用一列“内存”代替：

| 量 | 必须计入 |
| --- | --- |
| owner/slot 数 | live、idle、acquiring/retiring、隔离槽、每档未借出槽；对象数与 OS reservation 数分列 |
| VA | 独立 mapping 的实有范围；C 按所有 chunk 总范围计一次，含从未借出的槽，不再与 live/idle 重复相加 |
| usable maximum 与浪费 | 各 owner 精确 maximum、槽内 maximum 之外 slack、页舍入、guard gap、对齐 padding、块内未分配槽分别列 |
| accessible | live/idle/在途/回收失败实际 RW 页，不是逻辑有效字节 |
| commit | Windows 已提交页及相关进程提交指标；Linux 系统 Committed_AS 是系统值，不能归为该池独占 |
| RSS/working set/footprint | 全进程实测基线、峰值和空闲轨迹，不能从 reserved 或 accessible 换算 |
| host/scratch/output | chunk/slot/OwnerRecord/TLS/索引实际保留容量、验证临时空间、输入、副本及在途 owning 输出 |

对独立池，`VA_managed = VA_live + VA_idle + VA_inflight`；对 C，`VA_managed = Σ(chunk spans)`。在任意时刻 total-managed admission 包括 live+idle+在途，不是仅缓存预算。全进程总预算还包括其它分配器、共享库和业务数据；除非确实由全局调度与监控覆盖，不能宣称池限制了全进程。RSS 采样峰值应注明采样可能漏峰，exact accessible/commit 账与之分列。

页表/内核 metadata 也有成本，但不是每预留一字节都立刻分配相同比例页表；稀疏触页的位置会影响页表占用。不能假定连续块一定减少页表或内核对象，必须在目标系统观测。guard gap 增加保护边界和 VA，可作为正确性实验变量，不能默认免费。

## 7. 不纳入首个原型：地址掩码定位 owner

多档不共享单一掩码；即使每档 power-of-two 对齐，也必须先安全证明 pool/chunk membership、档位、slot index、有效 payload 边界，才能读 host metadata。不能向任意输入地址附近探读控制页。强对齐也可能额外预留近一个对齐单位并引入跨平台释放问题。

每次重新借槽必须建立新的 host 身份。slot generation 要与预期 generation/租约一起核对，回绕前停用槽或提供等价证明；仅从裸地址读出“当前 generation”不能识别旧指针指向的新 owner。活/退役状态、pool/chunk 寿命、并发回收同步及 ABA 都需要证明。metadata 不能置于会被 reclaim、清零或输入覆盖的 payload。move/swap 后仍须正确解析当前 Core，checked handle 的对象身份不跟 slot 简化。

首个 C 原型保留 V5 OwnerRecord/registry，不将查找、锁模型与存储后端一起改动。即使未来掩码被证明有效，它也不证明输入 graph 合法、offset 属于 live allocation 或 type/schema 匹配，不能替代完整 wire 校验和合法 owner 检查。

## 8. 与 V6 无冲突的后续边界

本目录的 [TASKS.md](TASKS.md) 是**本评估自有的条件任务清单**，不更改 V6 或其它路线图。V6 主会话「接续 XOffsetDatastructure 开发」（`01a1436d-dd29-71b3-be72-f2878f9f7c3e`）继续负责当前修改链/重载优化；无 P2996 离线代码生成评估也不在本任务范围。

后续优先级：收集业务输入 → A0/A1 等容量比较设计 → 获得单独原型授权和共享租约 → 固定输入的小实验 → 按收益/资源决定是否需要 B/C。没有代表性业务输入，只可交付合成负载可行性，不能晋升默认策略。若 V6 已稳定，后续先冻结其新身份，再在该身份上重复必要门禁；V5 研究结果不直接证明与 V6 组合有效。

任何构建、大量复制/哈希/扫描、profile、测试或计时必须服从现有**全局共享租约**，覆盖 WSL/Windows/其它项目。不能另建只管本目录的锁冒充协调。租约获取失败就等待或结束，绝不与 V6 或其它项目计时争用；各任务先准备清单，取得租约后才做重操作。本轮没有创建工作区或执行这些操作，也没有向其它会话发消息。

后续实验的输入、固定资源上限、正确性 oracle 与停止条件见 [EXPERIMENT.md](EXPERIMENT.md)。它是设计，不是执行授权，也不是正式性能晋升协议。

## 9. 实施前缺少的业务输入

1. 独立 owner 是否对应单位/组件/请求；同时 live 峰值、创建销毁速率、线程转交和退出顺序。
2. initial、最大实际 logical/used_end、未来增长上界的分布和联合轨迹；哪些调用方能承诺精确 maximum，不能只给平均 payload。
3. 冷启动、暖复用、突发—空闲—再突发、长驻增长比例；idle 多长时间后值得回收，以及可接受的再触页停顿。
4. 目标设备/OS/页大小、Android/iOS app 资格与 entitlement、VA/commit/RSS/footprint/slot/输出并发上限；不以桌面 x64 代表移动端。
5. 要解决的是创建 CPU、p99、VA、commit 还是 RSS；业务可接受的数值收益及回退预算，池耗尽时失败/排队的调用语义。
6. 加载/保存的输入输出大小及同时在途数量、原输入与旧 owner 保留多久、取消/超时/异常行为和实际消费者。

在这些输入缺失时，明确结论为：**把显式分档和现有池的评估纳入有条件后续清单；统一大区间槽位后端暂缓；不改默认值、不改 V1、不承诺速度或物理内存收益。**
