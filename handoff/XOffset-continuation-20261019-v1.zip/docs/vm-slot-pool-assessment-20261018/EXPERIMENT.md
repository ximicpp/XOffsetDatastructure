# 最小后续实验设计（未执行）

本文件只提出最小实验。当前授权止于调研；没有原型代码、构建、测试、采样或计时结果。各上限是将来研究的停止预算，不是对 V6 的新正式窗口授权或生产 SLO。实施前须另获原型执行授权，确认全局共享租约入口并冻结输入/环境/候选身份；不能靠本文件启动。

## 1. 问题、顺序和最少角色

E0：冻结一个实际平台 profile，记录 page size、reservation granularity、地址位宽/实际资源限额、可用 VA、Linux overcommit/max_map_count/进程与容器限制，或 Windows commit/进程限制。Apple app 另记录签名、entitlement、设备与 lifecycle；缺失就不进入该平台实验。不提升权限或修改 sysctl/entitlement 来消除失败。资源探测不做遍历地址空间的破坏性试分配。

E1：首先仅写独立 harness/工厂，不改生产头。使用核验过的 V5 两头和固定依赖/工具链，比较以下三角色；复用既有依赖，不大规模复制源码或数据：

| 角色 | 配置 |
| --- | --- |
| R0 | 每 owner 独立预留、无池；explicit maximum 与 trace 相同 |
| R1 | 现有一个混合容量 `XBufferPool`；当前精确 maximum 匹配 |
| R2 | 四个现有 `XBufferPool`，调用端按已声明 maximum 路由；配额总和严格等于 R1 |

R2 不修改缓存结构。它检验外部路由是否已经足够；R1/R2 的差别是扫描/共享状态及额度分区，不能把差值全归为单个锁。R0/R1 比较只说明已有池的收益，不构成新槽后端的独立贡献。默认 64 MiB 与较小显式上限的容量策略差异单列，不放入本次等容量时间比较。

独立harness对全部角色维护相同的managed admission账：申请前预占live/在途额度，命中时从idle转移，失败后退还，归还/释放完成前不撤账。它只约束该实验，不冒称现有池具有全进程硬上限；每个定向非档位/满容量用例开始前先销毁并clear上一用例资源，避免改变比较工作量或额度。

E2：仅当 E1 和业务输入证明仍有 reservation/匹配瓶颈，才提交 C 的独立最小原型设计与新的写入边界；本次不实现。C 使用每档 chunk、固定槽、预分配 slot lease metadata、每槽 RW 前缀、共享 state 寿命和显式耗尽失败；保留 V5 owner 解析、wire 与 validator。首版只做当前有设备的一个 OS storage 原型，full P2996 集成另有门禁。Windows 不用普通槽地址调用 MEM_RELEASE；POSIX 不在槽退还时先 munmap 再重新抢占。首版不做 placeholder、掩码查找、后台线程、TTL 或隐式 overflow。

C 的对照是 R1/R2 中适合相同预算的既有方案，而非只有 R0。若 C 要保留 chunk VA、改变 clear 效果，必须在执行前决定采用独立显式 API，或否决该兼容方式；不能在原 `XBufferPool` 上悄悄替换含义。E2 不复用 E1 的计时额度，需新冻结协议和授权。

## 2. 固定容量、数据与生命周期

四个档位 `64 KiB / 1 MiB / 16 MiB / 64 MiB` 仅是跨量级合成探针，不是推荐的生产档位。跨度很大的相邻档可能浪费严重，实际档位需业务分布决定。

| 精确 maximum | 每档最大 managed owner/slot | 每档最大 reserved（不含 guard） | 典型 grow 目标 |
| --- | ---: | ---: | ---: |
| 64 KiB | 64 | 4 MiB | 48 KiB |
| 1 MiB | 32 | 32 MiB | 256 KiB |
| 16 MiB | 8 | 128 MiB | 4 MiB |
| 64 MiB | 2 | 128 MiB | 16 MiB |
| 合计 | 106 | 292 MiB | 全部典型 live 为 75 MiB |

共同初始 logical 为 16 KiB；页大于该值时按 OS 实际 accessible 计，logical 不变。若实际 bootstrap 或页几何使输入不合法，E0 报该 profile 不满足本设计，停止，不偷偷换更小工作量。C 若未来加 guard，每槽最多一实际 OS 页、每 chunk 对齐 padding 最多 64 KiB；页不大于 64 KiB 的本设计总 guard ≤6.625 MiB，额外开销须实计，不能算进 payload。

R1 的 idle limits 为 `{106, 292 MiB, 96 MiB}`。R2 count/reserved 按表分摊，idle accessible 配额依次 `{4, 16, 32, 44} MiB`，总计 96 MiB，足够缓存典型 trace 的各档 3/8/32/32 MiB。对照每次启动从无缓存状态开始；分别记录池构造、填暖、clear 和最后释放，不把预热成本丢出总账。将来 C 的所有未借出槽同样计入 managed slots 与全部 chunk VA，不能只记“已使用槽”。

固定四条 trace，所有角色均用同一清单。生成器为 SplitMix64、seed `0x202610180001`，每条独立从此 seed 重置；在执行前把具体事件文件、生成器版本、长度及 SHA256 冻结。本轮尚未生成事件文件，不能宣称已冻结可执行输入。

1. **短命 churn**：4,096 次生命周期，small/1 MiB 档交替，各初始 16 KiB；每次填入由 `(owner_id, byte_offset)` 确定的非零图样、校验、销毁。peak live=1，R0/R1/R2 共同操作数相同，首个 cold 与 warm 分开。
2. **混合突发**：按表创建 106 个 owner，依次 grow `16 KiB → 该档典型目标/2 → 典型目标`，每步检查旧值及新范围清零；按固定 Fisher–Yates 次序销毁，再完整重复一波。第一次冷、第二次暖；clear 和再建另记录，不将已 clear 的池称暖池。四档 exact maximum 不变。
3. **长驻增长/显式回收**：每档一个 owner；相同三个增长点，shrink 到 16 KiB；分别记录 retain 与显式 reclaim，再 grow 回典型目标。reclaim 的结果/实际页账单列，不把 NoOp 记作已回收。此 trace 顺序执行，不与混合波的缓存叠加。
4. **拥有数据的加载/继续修改**：固定 admitted root（标量、XString、XVector），有效数据上限 32 KiB，四档各 128 次 `create → 修改 → save_verified → load_verified → 再修改 → save_verified → 再 load`，每次保留旧 owner 到新 owner 验证成功；最多两个同档 owner 并存。V5 原生 demo/trace 不改动，这个独立 fixture 不冒充 V6 的业务场景。source/value 由同 seed 决定，输出只保留当前两份，不累积归档所有大 payload。

线程配置固定为 1 和 4；每个线程只操作独立 owner。多线程按全局 owner_id 分配，**总 live/idle/VA 配额不乘线程数**。跨线程销毁只在有同步的移交后发生。move/swap 与并发 clear 在正确性进程中用固定 barrier 日程覆盖，不作为抖动来源混进单线程计时。OS 不保证实际调度顺序，记录观察次序，语义以 barrier/独立 owner oracle 为准。

额外定向正确性输入不计时：初始/maximum 边界、`maximum=65,537` 与 `1,048,575` 的非档位值、page±1、maximum/maximum+1、空/移动后对象、reserve/enable/prepare/reclaim/protect、注册和宿主分配故障。非档位请求必须保持精确 maximum；E1 原 API 正常处理，C 若不支持须明确拒绝，不能舍入语义。对合法 full maximum，独立清空其它 trace 后每档逐一启用至 maximum、超一字节失败、旧内容不变；不同时将所有槽填满触破 accessible 预算。`MAX_PAYLOAD` 级别仅做拒绝边界/算术分析，不在此小预算内成功预留约 2 GiB；该大规模覆盖保持未验证。

## 3. 固定资源与运行次数（拟议）

| 资源 | 硬上限/口径 |
| --- | --- |
| managed live+idle+在途/隔离 | 总数 ≤106，每档不超过表内上限；不计共享句柄副本为新 owner |
| payload reservation VA | ≤292 MiB；包括 idle 和 C 从未借出的槽 |
| 实验存储 VA（含 guards/padding/临时 reservation） | ≤512 MiB；与 sanitizer shadow/工具链 VA 分开，后者仍报告全进程 |
| accessible / Windows payload commit | live+idle+在途合计各 ≤192 MiB；idle accessible ≤96 MiB |
| 新增池/slot/索引 host metadata | 实际 retained capacity ≤16 MiB，不只计有效元素 |
| validation scratch | ≤64 MiB；超限停止，不关校验 |
| 输入及在途 owning 输出 | 合计 ≤132 MiB，单个最大合法输出约64 MiB加header仍可容纳 |
| 工作进程 RSS/working set | 含运行时、输入/输出、scratch 的采样值 ≤1 GiB；记录基线和峰值，采样间隔100 ms，页账精确维护 |
| Linux 额外 VMA | 比启动基线最多 +1,024，且总数不得超过读取到的 max_map_count 的75%；不足直接不运行 |
| 并行 | 一个构建 `-j1` 或一个运行进程，最多4个工作线程；计时期间无编译、SAN、扫描、profile或其它重任务 |
| 磁盘 | 本实验新文件合计 ≤2 GiB；不下载工具链，不复制冻结大包/测量档案；缺工具链即前提不足 |
| 构建/功能/诊断 | 合计最多20分钟；correctness 6进程（3角色×2线程），额外定向/失败进程最多12，总计≤18，不循环直到通过 |
| 筛选计时 | 总计最多10分钟、60进程；单进程超30秒失败即停止，不加样本 |

timing 60 进程固定为：两个线程配置各有 6 对 R0/R0 A/A（12进程），以及六轮每轮 R0/R1/R2（18进程），共 `2×(12+18)=60`。六轮顺序为 `012,120,201,210,102,021`，各角色每个位置两次；每进程执行四条 trace。A/A 和候选输出均留存，不删离群、不在看到结果后选择 trace。若预算不足完成，报告不完整，不将已完成子集用于采用。

这是少量进程的筛选；报告配对分布、批次时间和所有负例。可以记录每次操作耗时的经验分位数及事件数，但线程相关/时钟开销与小样本限制必须写明，**不声称生产 p99 或正式显著性**。A/A 仅判断本窗能否分辨事前业务要求；业务最小收益尚缺，未补齐不得给性能采用结论。小实验之后若值得做正式确认，另登记统计单元、数值门槛、窗口数和预算，不能从此结果倒推门槛或追加到显著。

SAN/TSan、全库/V1 历史矩阵和干净消费端属于后续实施门禁，需各自新租约和资源清单，不挤入此预算、不声称已完成。只有 storage 原型时，报告止于 storage；不得以不需要 P2996 的 smoke 替代完整校验集成。

## 4. 正确性 oracle

使用独立的 owner/租约区间账本和业务值模型，不复制候选的 freelist/选槽算法。每个事件检查：唯一拥有、活动区间不重叠、slot/chunk 边界、`logical≤accessible≤usable reservation`、`logical≤精确maximum`、相同 owner 基址稳定、相同字节图样、回收部分页保持、回收/重用后再次暴露清零或完整覆盖。模型保留退役身份，记录复用同址但不同 generation；不解引用已失效指针以制造 UB。

host-only 存储策略使用相同 admitted schema、相同业务操作/allocator 选择，要求 V1 输出逐字节一致；旧/新 reader 双向读取、继续修改两轮、save/load 值一致，OS 地址、池/档位/generation 不进入 wire。若任意字节不同，先判 oracle 失败并定位，不随意改成只比最终值。

坏输入覆盖 header/schema/type/layout、长度/offset、allocator、owned/free 重叠和错误优先级；原完整 validator 仍在线运行。相同 wire 在任意槽地址重载都要重新完整验证。失败 replacement 旧对象可用；页面已启用但 preparation 失败按现有允许状态记录；构造/注册失败无活身份泄漏。

生命周期定向覆盖 move/swap/replace、pool handle 早于 live owner 销毁、线程退出、全局析构、并发 clear/return、重复释放拒绝、地址重用、回调/new_handler 重入、noexcept 无新增 host 分配。C 的任意中途失败不得影响相邻槽，最后一个 chunk 租约释放后才可解除映射；clear 后残留 VA 必须按已声明契约记账。

## 5. 观测与否决

诊断与非插桩计时分开。记录 reserve/commit/enable/protect/discard/release 的实际调用及失败数、缓存命中/扫描、锁持有/等待、清零/输入复制/输出复制字节、owner 注册/释放、payload逻辑/used_end、每档空闲和耗尽。计数不能换算成毫秒，也不能将 arena 申请数当作系统调用数。

Windows 结合 VirtualQuery 的状态与进程 commit/working set，Linux 结合 maps/smaps_rollup、VmPTE、实际 map count 与 faults；Linux 系统 Committed_AS 单列，不归给单个池。Apple 在有资格设备上用对应 region/footprint 工具；不可观测项标未知，不用 RSS 反推。RSS/内核工具只在独立诊断进程用，正式计时用预分配轻日志，采样开销两侧相同且明示。峰值及回收后的0/100/1000ms观测属诊断，不把等待当业务吞吐。

立即停止且否决该候选：任一数据/字节/校验/错误顺序/生命周期 oracle 失败，静默更改 maximum、隐式搬迁/fallback、邻槽破坏、clear/失败契约无法兼容、超资源上限、租约失效、残留子进程或其它计时活动出现。保留首个失败，不盲重试，不修改输入/缩短 trace 继续报成功。

性能结论保持未知：A/A 无分辨能力、未完成预算内样本、业务收益门槛仍未定义、只有计数下降/初载改善但没有目标生命周期收益。若 A1 已满足业务目标，停止 C；若当前热点主要是完整 payload 复制/精确验证，且 reservation 只占很小预算，停止槽后端方向。C 若仅胜 R0 却不胜同预算暖池，或 VA/commit/RSS/尾延迟成本超已登记业务预算，同样不采用。

实验不创建工期承诺。停止、失败、前提不足、不确定和通过均是独立状态；不能从某次普通功能或单平台结果推导全平台生产支持。
