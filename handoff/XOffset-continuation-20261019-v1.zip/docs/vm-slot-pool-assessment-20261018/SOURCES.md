# 证据索引与适用范围

访问/核对日期：2026-10-18。源码只读，平台资料仅用于 API/约束推理；本目录没有产生平台测试或性能证据。未读/未复算全部 V5 原始运行数据，引用的机制数及统计结论来自已验收说明，不冒称本轮复测。所有架构收益、预算和后续步骤均为本评估推论或提议。

## 本地资料

| 资料 | 本次用途 |
| --- | --- |
| [AGENTS.md](../../AGENTS.md)、[HANDOFF.md](../../HANDOFF.md) | 写入隔离、历史事实、稳定地址/兼容约束；不恢复旧队列/执行授权 |
| [STABLE_VM_STORAGE_MIGRATION.md](../STABLE_VM_STORAGE_MIGRATION.md) | maximum、增长/回收、池和生命周期契约；索引结构文字属于旧实现 |
| [VM_STORAGE_IMPROVEMENT_PLAN.md](../VM_STORAGE_IMPROVEMENT_PLAN.md) | 分层优化、已后置强对齐掩码、显式容量及历史采用顺序 |
| [VM_NEXT_STAGE_PLAN.md](../VM_NEXT_STAGE_PLAN.md) | N4已有混合池、容量索引/锁外释放/分档的条件研究，避免重复立项；历史F状态有时点限制 |
| [VM_STAGE3_RESULTS.md](../VM_STAGE3_RESULTS.md) | 六allocator候选拒绝、宿主容量预算、正确性不等于采用；不是槽位池实验 |
| [ALPHA_COMPATIBILITY.md](../ALPHA_COMPATIBILITY.md) | V1准入、完整验证边界、owning复制、线程/工具链/平台支持范围 |
| [PERFORMANCE_V5_ACCEPTANCE.md](../PERFORMANCE_V5_ACCEPTANCE.md) | 指定实际V5身份；owner命中、stage7零申请、修改/重载差额及未晋升基线 |
| [V5 final-acceptance.json](../coordination/performance-v5-20261018/final-acceptance.json) | 只读核对开头的functional/measurement/target/baseline状态和两头身份；未审计其完整引用闭包 |
| [PERFORMANCE_V6_DESIGN.md](../PERFORMANCE_V6_DESIGN.md) | 当前优先级、单集成者和全局共享租约；本目录不改该计划 |
| [V6 plan.json](../coordination/performance-v6-20261018/plan.json)、[租约事件](../coordination/performance-v6-20261018/worktree-lease-incident-v1.json) | 小型只读查询重负载约束；事件中的租约是历史观察，不冒充当前持有人 |

这些文档描述的历史F、V5、V6是不同身份。未将根目录F或变化中的V6源码作为本次V5。实际核对的文件长度与SHA256见 [EVIDENCE.json](EVIDENCE.json)；未创建工作区、复制源码/依赖/大档案或扫描整仓。

## 核对的 V5 源码定位

以下行号只绑定本目录 EVIDENCE 中的两头身份。源码可能位于未提交工作区，不能用Git HEAD替代哈希；若文件变化，需重新核对。

| 定位 | 核验事实 |
| --- | --- |
| [OS头：139](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:139) | 页舍入、reserve、pool acquisition、full-copy特例 |
| [OS头：191](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:191) | from_bytes完整覆盖后发布logical |
| [OS头：241](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:241) | grow_to固定maximum及清零 |
| [OS头：269](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:269) | 各OS reclaim路径和DiscardedButAccessible |
| [OS头：332](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:332) | 每owner RW前缀、页启用与实际几何 |
| [OS头：371](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:371) | 独立mapping整段释放，不能直接复用为chunk内槽析构 |
| [OS头：394](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:394) | State预留metadata、锁内clear、maximum精确匹配、idle预算及共享寿命 |
| [主头：327](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:327) | MAX_PAYLOAD、默认maximum、显式配置、legacy hint |
| [主头：549](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:549) | 稳定OwnerRecord、std::map冷路径、四槽TLS |
| [主头：708](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:708) | move/retire、注销、锁外准备节点、原子owner发布 |
| [主头：1176](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:1176) | rel32写入范围检查 |
| [主头：4662](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:4662) | verified save owning输出及连续payload复制 |
| [主头：4773](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:4773) | V1头/长度/身份检查，fresh owner，完整graph验证后开放typed访问 |

## 一手平台资料

| ID | 官方/维护者资料 | 支持的窄范围 |
| --- | --- | --- |
| W1 | [Microsoft VirtualAlloc](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualalloc) | reserve/commit、页面与预留地址对齐 |
| W2 | [Microsoft VirtualFree](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualfree) | MEM_RELEASE原始base/整段，MEM_DECOMMIT及placeholder操作 |
| W3 | [Microsoft VirtualAlloc2](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualalloc2) | placeholder创建/替换、精确范围要求；具体部署仍需API可用性门禁 |
| W4 | [Microsoft memory limits](https://learn.microsoft.com/en-us/windows/win32/memory/memory-limits-for-windows-releases) | 特定x64版本与LARGEADDRESSAWARE条件下用户VA上限，不是可申请连续空间 |
| L1 | [Linux kernel overcommit accounting](https://www.kernel.org/doc/html/latest/mm/overcommit-accounting.html) | 模式、匿名可写映射与mprotect计费，不等同RSS |
| L2 | [Linux kernel vm sysctl](https://kernel.org/doc/html/latest/admin-guide/sysctl/vm.html) | max_map_count与区域限制；不假定目标机默认值 |
| L3 | [Linux man-pages mprotect](https://man7.org/linux/man-pages/man2/mprotect.2.html) | 页对齐、权限分裂/内核metadata失败 |
| L4 | [Linux man-pages mmap](https://man7.org/linux/man-pages/man2/mmap.2.html) | 匿名映射、地址hint和固定映射危险；不将hint当拥有地址 |
| L5 | [Linux man-pages madvise](https://man7.org/linux/man-pages/man2/madvise.2.html) | 私有匿名MADV_DONTNEED后的demand-zero语义 |
| L6 | [Linux man-pages getrlimit](https://man7.org/linux/man-pages/man2/getrlimit.2.html) | RLIMIT_AS约束预留 |
| L7 | [Linux kernel x86 five-level paging](https://docs.kernel.org/arch/x86/x86_64/5level-paging.html) | 56位用户空间及默认47位分配范围 |
| L8 | [Linux kernel AArch64 memory layout](https://www.kernel.org/doc/html/latest/arch/arm64/memory.html) | 架构/页配置相关VA位宽，不推导所有Android/iOS布局 |
| A1 | [Apple mmap归档手册](https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man2/mmap.2.html) | 映射/固定地址接口，非现代设备资源上限 |
| A2 | [Apple mprotect归档手册](https://developer.apple.com/library/archive/documentation/System/Conceptual/ManPages_iPhoneOS/man2/mprotect.2.html) | 页保护/错误接口，非平台运行验证 |
| A3 | [Apple Extended Virtual Addressing](https://developer.apple.com/documentation/BundleResources/Entitlements/com.apple.developer.kernel.extended-virtual-addressing) | 扩展地址capability，不给统一VA数字保证 |
| A4 | [Apple increased-memory-limit](https://developer.apple.com/documentation/bundleresources/entitlements/com.apple.developer.kernel.increased-memory-limit?changes=l_3) | 部分设备更高memory limit，额外内存不保证可用 |
| D1 | [AOSP 16KB优化](https://source.android.com/docs/core/architecture/16kb-page-size/optimize) | 页取整/浪费与实际页大小相关 |
| D2 | [AOSP tagged pointers](https://source.android.com/docs/security/test/tagged-pointers) | heap tagging/TBI/MTE约束，非“所有mmap均同样打tag”的证明 |

访问限制：Apple entitlement正文端点返回JavaScript占位；其官方Markdown入口在本浏览工具返回unsupported content-type。A3/A4的窄结论依据官方域名的搜索索引正文（含A4 discussion），未假装已读取设备支持矩阵或实际签名状态。初次kernel.org x86路径不可访问，改用官方docs.kernel.org规范路径后读取成功。其它搜到的二手站点、百科和论坛不作为技术结论依据。

另外查看了 [Apple归档虚拟内存介绍](https://developer.apple.com/library/archive/documentation/Performance/Conceptual/ManagingMemory/Articles/AboutMemory.html)。其抽象地址空间、历史iOS/backing-store与内核每项字节数描述有年代限制，故不用于本报告的现代VA上限、swap能力或metadata常数判断。
