# 页粒度浪费与槽位池的综合收益分析

日期：2026-10-18；承接 [总体评估](ASSESSMENT.md)。本轮仅补充只读源码核验、公开一手资料和算术分析，没有构建、测试、profile或性能测量，未改变生产实现、V6或其它计划。

结论：**页面浪费确实存在，在大量独立小 owner、较大页面平台上可能成为主要成本。多档槽位池本身不能消除每 owner 的页尾浪费；它主要改善容量策略和复用，是否抵得过保留页、映射管理及生命周期成本，需要同容量对照。** 原建议维持：先评估当前显式 maximum＋现有有界池，统一大区间切槽暂缓。

## 1. 四种“空闲”不是同一种内存成本

| 成本 | 含义 | 当前V5/新槽池的关系 |
| --- | --- | --- |
| 未启用的预留地址 | maximum/slot中尚未启用的尾部、未借出的槽、对齐与guard | 主要消耗VA及管理资源，不能等额算RSS；分档可减少过量VA，但不自动减少已启用页 |
| 页尾内部碎片 | 一个owner最后一页只有部分有效logical字节 | 独立保护/回收的owner要占完整页面；统一切槽通常仍保留此成本 |
| 已启用但暂时不用的页 | grow高水位、shrink后保留、归池保留的dirty页 | 可能占commit/RSS；为再次使用换取更少启用/缺页成本。当前shrink和归池不会自动回收 |
| 逻辑区内部空间及metadata | 容器spare capacity、free blocks、arena/header、host OwnerRecord/索引等 | 不全是可消除的浪费；槽池不改内部allocator，不能一并宣称节省 |

Windows reserve不分配同等物理存储；commit产生资源计费，实际物理页可在访问时分配。[Microsoft VirtualAlloc](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualalloc) Linux可写匿名映射与mprotect权限变化受overcommit规则影响，也不能等同当前RSS。[Linux overcommit](https://www.kernel.org/doc/html/latest/mm/overcommit-accounting.html)

例如一个64 MiB槽当前只用6 KiB，不意味着已消耗64 MiB物理内存。若页大小16 KiB、没有历史保留页，启用前缀为16 KiB。把槽缩成64 KiB，若logical仍为6 KiB，启用前缀仍为16 KiB；此时主要节省VA，不节省这一个已启用页。

## 2. 可量化的页尾成本

设P是实际页大小，L是owner的当前logical长度，包含该logical范围内的库头与业务数据。对于新建、没有历史保留页，或完整尾页回收成功的owner：

```text
A_min = ceil(L / P) * P
W_tail = A_min - L              （0 ≤ W_tail < P）
W_tail_total = Σ W_tail_i
```

这是可访问页范围与logical之差。它不是直接测得的RSS；仅在有关页均驻留等条件下，才对应相应物理页内的未利用容量。实际占用受驻留、回收、压缩等影响。不能把“64位”或“预留很大”当作无页成本证明。

以下为10万个独立owner的纯算术示例，非业务测量：

| 每owner的L | 4 KiB页：启用/页尾余量 | 16 KiB页：启用/页尾余量 | 10万个owner页尾余量：4 KiB / 16 KiB页 |
| --- | --- | --- | --- |
| 1 KiB | 4 / 3 KiB | 16 / 15 KiB | 292.97 / 1464.84 MiB |
| 6 KiB | 8 / 2 KiB | 16 / 10 KiB | 195.31 / 976.56 MiB |
| 20 KiB | 20 / 0 KiB | 32 / 12 KiB | 0 / 1171.88 MiB |

这里的1/6/20 KiB指整个owner的logical，不是“每个字符串各自浪费一页”。一个XBuffer内部的多个字符串/数组仍可紧凑分配，只有为它们各建独立owner或单独页槽才会逐个付页成本。AOSP也明确提醒16 KiB环境下小mmap的页取整浪费，应依据实际页大小分析。[AOSP页大小优化](https://source.android.com/docs/core/architecture/16kb-page-size/optimize)

6 KiB案例中，10万个owner的logical合计约585.94 MiB；4 KiB页启用约781.25 MiB，16 KiB页约1562.50 MiB。16 KiB页环境下页尾余量占启用容量62.5%，不能忽略。此时把每owner的预留上限从64 MiB改到64 KiB，仍不改变上述启用页算术。

若假定各owner的L模P均匀分布，页尾余量均值才近似P/2；没有真实容量分布，不能把这个假设写成真实平均浪费。特别是大小恰好贴近页倍数时，变化很不连续。

## 3. 高水位保留可能比页尾更贵

实际已启用范围A可能大于A_min。在维护当前前缀模型且A≥A_min时：

```text
A - L = (A - A_min) + (A_min - L)
        历史/策略保留页     当前页尾
```

V5 `grow_to`清零新暴露logical区间；`resize_logical`缩小时保留已启用页；`reclaim_tail`只回收logical末尾之后完整页，最后一个部分页不动。源码定位：[OS头241](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:241)、[OS头269](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:269)。

例如曾启用1 MiB又缩到6 KiB的owner，在16 KiB页下，未主动回收前可保留1 MiB的accessible，而不是16 KiB。归池时V5将logical归零并缓存原accessible前缀；随后小owner命中该mapping，也可能继续保留原1 MiB，直至显式回收/释放。对应源码：[OS头444](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:444)。

1000个各保留1 MiB的idle mapping，就是1000 MiB的accessible缓存（不是已证明1000 MiB RSS）。因此应优先同时限制idle accessible，而不是只限制缓存个数或VA。现有池已经有该限额，不需先实现统一槽池。若新池全部槽始终启用，或将较大档位一次启用到底，反而会放大这一问题；不建议这样实现。

回收有系统调用、重新触页和清零成本；频繁grow/shrink时逐次回收可能增加CPU与tail latency。冷热寿命差异必须单独报告，不默认后台回收或每次归还都回收。

## 4. 分档、guard与统一大块分别改变什么

分档能让调用端明确选择较适合的maximum，减少默认64 MiB预留的过量VA，也可提高相同maximum的复用机会；它不改变OS页大小。档位过粗会新增槽内VA余量：若工厂在创建前明确选择1 MiB档承载70 KiB需求，槽中有954 KiB不承载该需求；在16 KiB页下只启用80 KiB时，真正的当前页尾余量为10 KiB。二者不能相加后都宣称物理内存浪费，也不能将调用者已指定的70 KiB精确maximum静默改成1 MiB。

普通未启用guard间隔主要占VA；若每10万个槽增加一个16 KiB guard，额外VA约1.526 GiB，不能等额算RSS。若又为每槽单独提交一页控制页，则出现额外可访问/提交页成本，因而首版不建议这种owner定位设计。现有OwnerRecord是host对象，不等于每owner独占一页。

统一预留大块可以减少部分cold reserve/release调用，但每槽独立启用/保护/回收仍需页边界。不同前缀与guard会产生保护分段，Linux可能增加VMA，且mprotect可因区域数或内核metadata不足失败。[Linux mprotect](https://man7.org/linux/man-pages/man2/mprotect.2.html) 页表与映射metadata不按整个VA简单线性计费，也不能假定大块一定更省；需目标平台观测。

Windows预留地址的allocation granularity与commit页粒度也不同。即使独立reservation间因地址粒度出现空隙，也不能把该空隙算成已提交物理内存；一个大reservation内部可按页切槽，不必强迫每个内部槽都使用独立预留粒度。但这改变整段释放责任，无法沿用原逐owner MEM_RELEASE；相关生命周期评估见总体报告。

## 5. 收益与问题的同口径比较

| 目标 | 可能得到的收益 | 对照与问题 |
| --- | --- | --- |
| 稳定基址/增长不搬迁 | 有利于arena增长 | 当前V5已具备，不能记作新槽池的新增收益；内部容器仍可能迁移 |
| 短命owner暖复用 | 少reserve/release，可能减少部分enable/缺页 | 现有池已提供主体能力；保留dirty页消耗内存且新logical仍需清零/覆盖 |
| 降低大量小owner的VA | 显式选小maximum/较细容量策略 | 可能减少未来增长能力；须调用方事前明确。对页尾物理碎片无直接改善 |
| 降低cold reservation成本 | 大块批量预留可能摊薄调用开销 | 槽级enable/清零/注册未消失；整块被少数live owner钉住，档间空闲无法自由互借 |
| 限制资源与耗尽行为 | 固定slot数、managed VA和admission更可控 | 必须覆盖live+idle+在途/隔离槽；只限制idle不能代表全进程 |
| 减少页尾浪费 | 相邻多个小对象共享一个物理页时才可能减少 | 在当前独立VM owner边界下不能仅靠统一切槽实现；跨owner共享页须另设计引用计数和整页回收，改变保护/释放粒度 |
| 修改/修改后重载 | 无已证实直接收益 | 小块申请/退休、完整payload复制、精确owned/free校验仍在；不替代V6工作 |

将多个业务单位纳入同一个XBuffer，可在同一arena内紧凑分配，可能摊薄页尾和owner metadata；但它把释放、增长上限和故障域改成共享owner，删除一个单位不等于可独立向OS归还其页。compaction也有复制和指针寿命后果。这属于另一种业务所有权设计，**本任务不实施，也不作为遇到困难后的默认降级方案**。

## 6. 综合建议

大量owner的logical只有几KiB、目标平台16 KiB页：先量化最小页成本是否符合总内存预算。若不符合，多档槽池通常解决不了关键问题；需要单独评估业务能否共享owner/页，或保留当前语义并接受下界，不能用“大VA几乎免费”遮掩。

owner较大、长驻且需要稳定增长：现有独立VM方案已提供主要收益。继续使用合理maximum，按实际idle时长决定显式回收；没有reservation瓶颈证据时，引入统一切槽的边际收益较弱。

owner频繁创建销毁且容量可预测：现有有界池是最值得先验证的选择。用相同maximum、相同live集合、相同输出/校验工作比较冷/暖；同时看生命周期延迟、回收后再增长、VA、accessible、commit、RSS和在途输出。新统一槽池必须额外胜过这个已有对照。

总判断维持“有条件研究，暂不实施新生产后端”。先获得真实owner数量、logical/峰值容量分布、生命周期和设备页大小，再决定分档和缓存上限。任何潜在提速都要覆盖新增锁/metadata、清零、回收/缺页及碎片成本；只减少系统调用计数或VA数字不足以采用。完整V1、校验、精确maximum和独立owner生命周期继续作为硬门槛。

本补充的算术与文档身份见 [PAGE_COST_EVIDENCE.json](PAGE_COST_EVIDENCE.json)。原 [EVIDENCE.json](EVIDENCE.json)保留原交付时身份，不回写为本次补充。
