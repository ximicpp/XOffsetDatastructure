# 当前性能与差距分析

2026-10-17。分析对象为已完成 load/mutate 三项优化的候选：生产主头 SHA256 `2c50cfbbb53747a38cab6273a5c195e7fb6d5c97d07d13a9c9dc7e57782390b3`。本次只读既有源码、计数和计时结果，增加独立派生统计；没有执行编译、native benchmark 或新的性能窗口。旧失败、冻结包及验收证据保持原样。

**判断：当前主要差距集中在加载与重载。** 本批未合格样本中查询耗时接近 cista，保存耗时较低；修改的重复扫描和压缩删除深复制已经减少，但扩容增长仍有旧元素深复制。不能把全部加载差距归因于安全保证，也不能把已有操作量下降直接写成墙钟加速。

**数据资格与场景。** 唯一实际测量窗口停在 pre A/A：55 个成功子进程包含 15 个 warmup 与 40 个 pre A/A 样本，每库 8 个。五库均未通过既定 A/A 门禁，正式 comparison blocks 为 0。下表是全部 40 个样本的算术均值，只用于诊断，无筛选、重跑或剔除异常值；不是合格排名、一般速度倍率或显著性结论。顺序沿用固定库顺序。

固定场景是 WSL2/Linux x86-64、M 数据集，16,384 条初始 record、28,673 次修改、55,299 次查询、九阶段 mixed-growth trace。输入在加载后脱离原缓冲；随后查询、修改、保存、释放旧状态、重载、再查询和清理。库版本为 cista v0.16、FlatBuffers v25.12.19、Cap’n Proto v1.5.0、cereal v1.3.2；具体源码及二进制身份见原冻结与验收记录。

| 库 | 初次加载 ms | 修改 ms | 保存 ms | 修改后重载 ms | 完整生命周期 ms |
| --- | ---: | ---: | ---: | ---: | ---: |
| XOffset | 53.21 | 15.36 | 5.41 | 43.30 | 131.30 |
| cista | 10.08 | 6.91 | 11.03 | 8.86 | 50.98 |
| FlatBuffers | 6.46 | 7.27 | 11.94 | 3.95 | 52.13 |
| Cap’n Proto | 9.33 | 23.88 | 11.04 | 17.29 | 101.51 |
| cereal | 7.52 | 7.18 | 11.57 | 4.74 | 50.34 |

完整生命周期还包含两次查询、释放修改后状态及最终清理，不能只相加表中四个阶段。原生结果的八阶段之和逐条等于 total。生命周期中位数分别为 129.94、51.74、51.98、99.10、50.38 ms；XOffset 观察范围 118.98–143.60 ms，cista 45.79–54.90 ms。中位数不具有阶段可加性，下面的差额分解始终使用均值。

阶段口径也有差别：load 包含释放原始输入缓冲；reload 保留 final_wire，二者并非完全相同作用域。emit 保留各库原生 owning wire，没有强加统一 vector 的二次复制；文件写出、输出 SHA 与独立 canonical 审计在生命周期计时外。cista 清理还显式递归访问容器，不能把它描述为只释放一个 blob。

**与 cista 的差额分布。**

| 阶段 | XOffset 均值 ms | cista 均值 ms | XOffset − cista ms |
| --- | ---: | ---: | ---: |
| 初次加载 | 53.215 | 10.079 | +43.136 |
| 修改前查询 | 6.334 | 5.819 | +0.515 |
| 修改 | 15.358 | 6.911 | +8.446 |
| 保存 | 5.410 | 11.026 | −5.616 |
| 释放修改后状态 | 0.619 | 1.629 | −1.009 |
| 重载 | 43.302 | 8.861 | +34.442 |
| 修改后查询 | 6.627 | 6.232 | +0.395 |
| 最终清理 | 0.436 | 0.420 | +0.017 |
| 生命周期 | 131.302 | 50.978 | +80.324 |

两次加载合计 96.517 ms，占 XOffset 生命周期约 73.5%；对应差额 77.577 ms，约占相对 cista 净差额的 96.6%。这是样本均值的算术分解，不是因果 CPU 占比；由于保存和释放阶段追回部分时间，各正向差额占比之和可以超过 100%。即使单独消除当前观察中的全部修改差额，也只减少约 8.45 ms，无法填平约 80.32 ms 的整体差距。

从均值中扣除两次加载，其余六阶段为 XOffset 34.78 ms、cista 32.04 ms，差额 2.75 ms。这只说明本生命周期的成本分布；它不是另行实测的长驻、多次修改工作负载，也不能外推为该场景的速度结论。

**加载：额外保证和实现成本并存。** cista 所选 `mode::NONE` 仍会递归检查指针边界、对齐、长度/容量和字符串结构；它跳过选配的版本、完整性及 DEEP_CHECK 第二遍。XOffset 还检查 arena allocator 元数据、容器绑定、owned 区间互斥、free-list 及 owned/free 不相交。两者当前模式均没有内容校验和扫描；XOffset schema 摘要在编译期生成，load 比较常量，不是运行时重新计算整个 schema。

XOffset 已复用 `lower_bound` 结果进行 `emplace_hint`，消除了重复树查找，但仍为每次验证建立两棵临时 `std::map`。当前初载有 196,612 个节点、6,029,520 次 key 比较、9,437,376 字节节点请求；重载有 212,996 个节点、8,394,648 次 key 比较、10,223,808 字节节点请求。重载节点中 owned 204,804、free 8,192。节点实际请求为 48 字节；这些是临时验证索引的计数，不是业务索引、CPU 指令或含 malloc 开销的 RSS。

所有权检查需要存在，但逐节点独立分配、树指针追逐和分配器调用属于实现选择。保留两索引、在线早拒绝、异常清理和既有错误优先级，仍可研究验证专用的分块 node pool。不能先收集全部区间再排序、改变恶意输入的拒绝行为，或关闭验证来制造同等保证下的提升。

旧版独立采样曾把热点定位到区间登记，但当前版本没有新的分阶段 CPU profile。因此不能把旧版“约九成在图校验”直接套到当前 53.21/43.30 ms，更不能把当前 77.58 ms 加载差额全部称作额外安全成本。当前还实际复制 13,702,016/17,830,784 字节 arena payload；没有证据证明 memcpy 或系统映射是现阶段主因。

**修改：已移除什么，还剩什么。** 以下为独立计数，不把诊断插桩计时混入生产窗口。

| 工作量 | 优化前 | 当前 |
| --- | ---: | ---: |
| 九阶段 arena 分配入口 | 258,632 | 86,016 |
| 空闲链表 predicate 与跳过尾部检查合计 | 5,898,485 | 116,878 |
| stage7 删除压缩 arena 分配入口 | 172,616 | 0 |

重复扫描和同 arena 移动赋值深复制已得到实质性工作量削减。arena 分配入口不等于 host malloc；计数下降也不自动等于同比墙钟提升。

当前最明确的剩余重复工作在 stage6：`attrs.resize(4→5)` 的增长分支仍通过 rebuild/transfer_construct 深复制原有 4 个 Attr 的 key/value。4096 次操作共 45,056 次 arena 申请，占剩余申请的 52.4%。按当前构造路径可分解为每次父 buffer 1 次、旧 4 个 Attr 的嵌套存储 8 次、新 Attr 的嵌套存储 2 次。若能在所有可能抛异常的新尾部构造及 rel32 准备完成后，对旧前缀使用已证明不抛异常的资源迁移，设计目标可减少旧前缀的 32,768 次申请。这是待验证的机制目标，不是已经取得的结果；不能简单先 reserve、尾部构造失败后容量已变，却声称保持原异常保证。

stage8 的 24,576 次申请占剩余申请的 28.6%，但本 fixture 是在已有外层容量末尾新增 2048 条 record，按每条 12 次嵌套申请构造新数据，没有搬移整个旧 records 前缀。不能把 stage6+8 约 81% 的申请一律当成可消除的深复制。

新路径也有成本：全程 owner lookup 为 172,032 次，owner registry 使用 mutex；free-list 缓存维护比较为 1,337,495 次，stage7 还保留 24,576 次 retire/owner lookup。移动保护的 320,465 次 helper 调用也应纳入后续采样。它们与树比较、arena 申请不属于相同原语，不能相加或换算成 CPU 百分比。固定 16 个 cursor 保持 first-fit，但不意味着所有申请都变为对数复杂度。

**查询、保存与其他库的成本位置。** XOffset 两次查询合计 12.96 ms，cista 12.05 ms；两者都经共用查询逻辑直接访问字段与容器视图。XOffset 的整图验证每次 load 执行一次，不在 query/mutate/emit 中重复进行，因而没有证据支持“相对指针或 P2996 反射让所有访问都慢”的解释。

XOffset 的 `save_verified` 在类型/root/state 检查及尾部裁剪后复制 header 与 arena，不再次做完整所有权图验证。cista 保存时遍历存活值，写数据并重建 offset/容量/ownership 标记；不是直接返回原 private blob。这与观察到的 XOffset 保存较轻、加载较贵相符，但还不能量化每种机制分别贡献多少时间。

FlatBuffers 当前 trusted `UnPack` 生成可变对象树，没有 upfront Verifier；保存用新 builder 重新 `Pack`。cereal 加载解码为 std 容器，保存重新写 BinaryOutputArchive。二者的释放需要逐对象处理，而 XOffset 主要回收 VM owner。它们能完成同一业务 trace，但输入检查、修改表示和保存承诺不同；6.46/7.52 ms 的 load 不能直接当作 XOffset 保留全部检查时必须达到的目标。

Cap’n Proto 的两次查询观察合计 39.16 ms。共用循环经生成 getter、PointerReader/ListReader 反复访问嵌套 records/attrs/samples，是待采样的候选机制。此处查询使用 builder 的 `asReader()`，不是重新解码 DTO，且 builder reader 使用无限读额度；不能归因于 load ReaderOptions 的 traversal 限额，也不能把全部差额确定为检查开销。

**体积与内存。**

| 库 | 修改后 wire 字节 | 审计前进程峰值 RSS 中位数 MiB |
| --- | ---: | ---: |
| XOffset | 17,830,872 | 102.68 |
| cista | 12,095,936 | 86.44 |
| FlatBuffers | 10,757,704 | 83.44 |
| Cap’n Proto | 33,623,952 | 122.03 |
| cereal | 9,772,151 | 88.01 |

XOffset 最终 wire 比 cista 大 5,734,936 字节，约 47.4%。XOffset 保留可继续修改的 arena、容量、allocator/绑定信息和内部空洞，cista emit 重新组织存活数据；体积差既包含不同承诺，也包含可优化布局，不能全部称为必需元数据。当前 XOffset 产物由旧版 21,051,048 缩至 17,830,872 字节，约减少 15.3%，这是确定的产物大小变化。

RSS 是 `RUSAGE_SELF.ru_maxrss` 的整个进程累计高水位，包含计时前输入、trace、查询数据，以及 state/wire 重叠和分配器；它不是库独占内存、阶段峰值或两次测量之差。512 MiB 是 XOffset adapter 的 arena 虚拟地址容量上限，不是实际复制量或 RSS。不得从 wire 差直接推出内存差。

**本轮优化的时间收益尚不能验收。** 旧未合格窗口的 XOffset 均值为 load 49.07、mutate 40.98、reload 56.02、total 168.83 ms；当前分别为 53.21、15.36、43.30、131.30 ms。修改和重载呈下降观察，初载没有出现更快观察。两窗口均未合格，又没有同一窗口内旧/新候选配对，因此不能宣布总时间下降 22.2%、初载退化 8.4%，或用这些比值证明因果。已确认的是语义/兼容门禁通过、具体工作量下降及最终产物缩小；正式速度结论仍缺合格样本。

**后续优先级取决于应用。** 对当前包含两次加载的完整生命周期，应先验证加载索引的分块节点分配与局部性，再优化 `resize` 增长旧前缀迁移；对长期驻留、频繁增长的对象，后者应排第一。随后用当前版本采样判断 owner registry、缓存维护、局部移动保护中谁实际占时。wire 压缩/整理必须同时核算保存、重载、临时内存和可修改性，不能只追求某个阶段的表面收益。当前数据不支持先优化常量 header 比较或关闭验证。

下一次性能验收需要预先固定旧/新控制、场景与同等契约，在独立目录保留失败并遵守单一测量窗口和现有 A/A 门禁；不能放宽阈值，或反复重试直到出现好看的结果。本次分析没有启动该工作。

**来源与复核。** 本次三代理分别只读检查全部 40 条样本、当前容器/索引路径及五库适配器。派生统计包含每条输入的 SHA256、样本选择、均值、中位数、IQR、MAD、范围和资源口径，未改动旧验收包。

- [完整派生统计](../build/current-performance-analysis-v1/aa-phase-summary.json)、[逐样本记录](../build/current-performance-analysis-v1/aa-selected-samples.json)、[离线分析脚本](../build/current-performance-analysis-v1/aa-phase-analysis.py)。
- [本轮已封存验收](LOAD_MUTATION_OPTIMIZATION_RESULTS.md)、[操作量证据](coordination/load-mutate-optimization-20261017/operation-count-summary-v1.json)、[原始 pre A/A 状态](validation/2026-10-17-load-mutate-optimization/campaign/recovery-v1/formal-v1/status.json)。
- [旧版本独立归因及边界](LOAD_MUTATION_ATTRIBUTION.md)。
- 当前可编辑候选 [resize 增长路径](C:/Users/gzsufanchen/.codex/worktrees/load-mutate-optimization-v1/xoffsetdatastructure开发/xoffsetdatastructure.hpp:2119)、[验证索引](C:/Users/gzsufanchen/.codex/worktrees/load-mutate-optimization-v1/xoffsetdatastructure开发/xoffsetdatastructure.hpp:2815)、[保存路径](C:/Users/gzsufanchen/.codex/worktrees/load-mutate-optimization-v1/xoffsetdatastructure开发/xoffsetdatastructure.hpp:3956)。
