# Performance v4 实施与验收结果

2026-10-18。独立、未提交的开发候选，未发布。

**超过全部四个固定竞品的目标：尚未达到。** 本窗口未通过全部 A/A 资格检查，不能发布正式胜负或加速结论。

已实施 hybrid 精确位图、保持全局错误优先级的配对查询、无作用标量递归裁剪、有限 helper 内联、非尾块提前拒绝、标量尾部增长及新增受约束批量赋值。完整校验、既有 API 和 V1 兼容门禁均保留。功能通过不代表竞争目标通过；没有合格改善证据时，v4保持实验候选，不晋升为推荐性能基线。

## 同一业务完整生命周期

M mixed-growth trusted-detached：16,384 records、28,673 mutations、两轮各55,299 queries。包含 owning 初载、查询、变长修改、owning 输出、退休修改状态、重载、再查询及清理。以下为96行/角色的算术均值，单位ms；排除预先指定的warmup和全部conditioners，不删除异常样本。

| 角色 | 初载 | 查询前 | 修改 | 保存 | 退休 | 重载 | 查询后 | 清理 | 总计 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| XOffset v3 | 8.692 | 6.495 | 12.393 | 5.927 | 0.611 | 14.629 | 6.777 | 0.419 | 55.945 |
| XOffset v4 | 9.298 | 6.570 | 12.184 | 6.115 | 0.608 | 14.838 | 6.816 | 0.415 | 56.842 |
| cista v0.16 | 10.494 | 6.332 | 7.558 | 12.600 | 1.855 | 8.830 | 6.415 | 0.453 | 54.537 |
| FlatBuffers v25.12.19 | 7.211 | 7.045 | 8.177 | 13.046 | 6.415 | 3.522 | 6.995 | 4.409 | 56.821 |
| Cap’n Proto v1.5.0 | 9.490 | 19.092 | 24.157 | 11.481 | 0.827 | 16.923 | 19.338 | 0.005 | 101.313 |
| cereal v1.3.2 | 7.959 | 6.580 | 7.413 | 12.422 | 3.905 | 4.829 | 6.569 | 2.581 | 52.258 |

阶段均值描述成本；下面的比值来自八个平衡 macrocycle 的配对 log 推断，与算术均值比不是同一统计量。仅列未合格窗口的诊断观察，comparison=null。

| v4 / 对照 | 几何延迟比 | 同时单侧上界 | 固定目标 |
| --- | ---: | ---: | ---: |
| XOffset v3 | 1.0155 | 1.0338 | 1.00 |
| cista v0.16 | 1.0422 | 1.0763 | 0.80 |
| FlatBuffers v25.12.19 | 1.0018 | 1.0473 | 0.80 |
| Cap’n Proto v1.5.0 | 0.5609 | 0.5742 | 0.80 |
| cereal v1.3.2 | 1.0884 | 1.1217 | 0.80 |

四竞品的点估计及同时单侧上界均须≤0.80，另须全部A/A合格，才标记“明显超过”；旧新改进采用独立判据。这不是对所有硬件、数据形状、功能或未来版本的普遍胜出承诺。

| A/A角色 | 实际先执行/后执行同时区间 | 证成等价 |
| --- | --- | --- |
| XOffset v3 | [0.9162, 1.0350] | False |
| XOffset v4 | [0.9337, 1.0595] | False |
| cista v0.16 | [0.9039, 1.0484] | False |
| FlatBuffers v25.12.19 | [0.9444, 1.0262] | False |
| Cap’n Proto v1.5.0 | [0.9386, 1.0879] | False |
| cereal v1.3.2 | [0.9185, 1.0841] | False |

失败/未决原因：`["AA_equivalence_not_established:old_xoffset", "AA_equivalence_not_established:new_xoffset", "AA_equivalence_not_established:cista", "AA_equivalence_not_established:flatbuffers", "AA_equivalence_not_established:capnproto", "AA_equivalence_not_established:cereal"]`。

## 实际机制与剩余成本

两次固定M计数进程（v3/v4各1次、无时钟）逐一核九阶段canonical与两轮query；两版最终wire均17,830,872B，SHA256相同。

| 计数 | v3 | v4 |
| --- | ---: | ---: |
| 修改阶段真实 Core owner 查询入口 | 106,496 | 98,304 |
| 进入 Core 的尾部扩展/成功 | 8,192 / 0 | 0 / 0 |
| 非尾块提前拒绝 | 0 | 8,192 |
| 修改阶段 arena 申请 | 53,248 | 53,248 |
| 非空有效 retire 调用 | 45,056 | 45,056 |
| 初载 scratch 上游请求次数/字节 | 6 / 1,686,576 | 1 / 1,713,608 |
| 重载 scratch 上游请求次数/字节 | 7 / 4,423,888 | 2 / 4,459,664 |

owned/free登记初载196,612/0，重载204,804/8,192，完整校验数量保持。v4初载/重载dense index为1/2、paged allocation为0；trait marker累计潜在源层元素迭代数3,670,016/4,521,984，父payload与所有必要子检查仍执行。旧版这些非bool scalar叶函数实例化本已为空，O3有权消除旧循环；这个逻辑计数不能当作实际CPU调用减少或提速证据。scratch请求字节略增，不能声称内存占用下降；上游请求也不是RSS或耗时份额。每阶段live scratch均归零，调用与字节释放平衡。

新增bulk路径完成24,576次fresh全量赋值、逻辑源2,490,368B，没有减少本业务的arena申请次数。M未命中真实尾部扩展，不能把新增scalar尾部能力当成本场景的收益。未引入跨new_handler回调的裸owner缓存。旧new_handler/move反例继续受测试约束。

裸二进制ELF .text由121,160B变为122,728B；有限helper不再有独立符号。符号消失本身不能证明节省毫秒、常量传播份额或某个除法成本；没有重复CPU采样。

## 公平性与测量范围

XOffset接入新增公共assign_range(span)；cista同时采用其固定版本已有的set(begin,end)，FlatBuffers/cereal原有批量赋值、Cap’n Proto合法builder路径保持。旧新效果包含库实现与合法集成变化，不是单独某个patch的因果份额。详见[API说明](PERFORMANCE_V4_API.md)。

共同业务不等于完全相同的安全功能：XOffset完整allocator/owned-free/typed准入保留；cista NONE有结构检查；FlatBuffers为可信ObjectAPI路径而非额外Verifier；Cap’n Proto bounded reader后detached builder；cereal native DTO。没有为追逐速度改成unchecked，也没有用只读mmap或长期驻留替换主场景。

WSL2 Ubuntu22.04、i9-13900K、CPU2亲和、固定P2996 Clang21/libc++、裸Release -O3。1200 fresh native children：600固定同role全生命周期conditioners＋24主warmup＋576推断行。conditioners实际body和receipt同样全审，但统计权重始终为0；不据其耗时调节节奏。相同直接前驱不保证更早缓存历史、频率或宿主独占。

内层统计源码逐字保留：48 blocks、八macrocycle、df7；六A/A同时区间须全在[1/1.05,1.05]。五contrast各单侧99%、Bonferroni family nominal95%；A/A是另一family95%，不是11区间联合95%。近似独立正态模型及宿主条件是推断前提；不是分布无关或给定A/A通过后的覆盖保证。一个全局租约窗口，三代理quiet，无编译/重测试/归档并行，未追加样本、修改门槛或性能重试。

## 验收与开放项

- 全库normal/SAN各57项，另各3项configure checks；adapter各16项、各5goldens，UAF/overflow/leak三正控有效。
- 五库S/M/L normal/SAN各80个顺序进程、15cells、九阶段及query通过。
- 四旧控制V1双向48cases；alpha-S补充2，resize/string/newAPI schema双向各2。
- 干净relocated安装及子工程消费端各3项通过，核851个实际依赖头。
- 工具40×2、统计21×2、conditioned runner57×2、机制14×2纯检查通过。
- 新候选独立worktree；旧v3/v2/alpha/失败证据保留。保护清单含7,783项；逐一核验的完成状态和结果由最终验收记录中的preservation字段确认。
- 首次P1失败来自测试前提，修正测试后生产头逐字一致；runner两处身份/闭包审查修复保留原版。消费端首次仅遇外部性能租约busy，命令未启动；排队取得租约后完成，未争用测量。

测后原审计器误拒队列合法的2700.0浮点秒数：整数限定不符合实际runner的float参数类型。首次失败与原冻结七工具均保留；独立离线适配器仅修正这一AST类型谓词，数值仍须等于2700，随后调用原完整审计函数重读本次1200个实际输出。没有重测、改输出、改统计或放宽预算。 另一次父调度误将收据文件名写成receipt.json，在导入审计器前退出；修正为已冻结的author-receipt-v1.json后，才完成实际完整重审。两次失败记录均保留。

N7仍缺真实业务消费者入口；原生Windows完整P2996验证仍开放。下一阶段先建立合格测量条件，再以真实生成代码及实际阶段成本选择优化；保留完整保证。不能通过换场景、放宽A/A或重复窗口制造达标。后续决策见[证据驱动的后续路线](PERFORMANCE_V4_FOLLOWUP.md)。

详细设计与阶段roadmap见[PERFORMANCE_V4_DESIGN.md](PERFORMANCE_V4_DESIGN.md)。验收入口：`coordination/performance-v4-20261018/final-acceptance.json`。完整原生证据保留于 `/root/xoffset-performance-v4/20261018/v1`；便携metadata归档不冒称可独立执行的全量包。

未提交、推送、合并、发布或触发远端CI。
