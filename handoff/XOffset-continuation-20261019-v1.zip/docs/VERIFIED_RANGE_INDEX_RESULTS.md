# Typed verified load 有序区间索引：实施与验收

2026-10-17。本轮按 `COMPETITOR_BENCHMARK_NEXT_IMPLEMENTATION.md` 实施独立候选，
生产优化和功能验收已完成；正式性能窗口因测量工具的执行权限缺陷停止，未取得性能排名。
原 alpha.1、旧失败档案及 N3/N7 开放项均保留，没有提交、推送、发布或远端 CI。

## 候选和实现边界

候选为 `xoffset-verified-range-index-v1`。可编辑源码位于：

`C:\Users\gzsufanchen\.codex\worktrees\verified-range-index-v1\xoffsetdatastructure开发`

实际 Linux 构建使用字节一致的 WSL ext4 镜像：

`/root/xoffset-verified-ranges/20261017/candidate-v1/source-v1`

基于 alpha.1 源码归档 `5a8647736d1145676c503299d704bc37e2dd035d730ccc2ffca2e5e96a28c658`，
原提交 `7539433ab96d69c4a07b1db5c0a13786da85cdcd` 只标识基点，不单独标识未提交候选。
VERSION 和历史清单仍是基点元数据，本轮没有重打发行包。

| 生产文件 | 候选 SHA-256 |
| --- | --- |
| xoffsetdatastructure.hpp | `6f815b1ab5dd8a482248b2ef97dd90d02a4ec8feea3e6c882f15274f32a7a00e` |
| xoffset_virtual_memory.hpp | `22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad` |

双头规范内容身份为 `412e1fa3c1c59c874645f12714f761daa762ec2a7302b81cb9689b5fb63f4b4c`。
[身份文件](coordination/verified-ranges-20261017/candidate-source-identity-v1.json)
与[生产及测试补丁](coordination/verified-ranges-20261017/production-and-tests-v1.patch)供复核，
另有[实验及工具支持补丁](coordination/verified-ranges-20261017/experiment-support-v2.patch)。
实验支持补丁表示文本差异；两个原带 CRLF 的 JSON 成员以 v2 源码副本和身份记录为原字节准据，
不能把该文本补丁单独视为字节归档。

生产改动只涉及结构校验期的 owned/free 两组临时区间。每组采用以 arena 内偏移为键的
`std::map`，在地址与长度验证后检查 lower_bound 的前驱和后继；两组检查通过后才登记，
随后才遍历子对象。每组已有区间互不重叠，因此相邻区间检查足够，整体登记成本为
O(R log R)。保留 owned 优先的错误次序、原四类重叠错误文本、空区间和相邻半开区间规则。
V1 wire、公开 API、allocator、compact 和所有权语义未修改。

## 功能和安全验收

| 验证 | 实际结果 |
| --- | --- |
| 完整库正常构建 | 47/47 CTest，另 3 项配置期检查通过 |
| 完整库 ASan/UBSan/LSan | 47/47 CTest，另 3 项配置期检查通过 |
| 五库适配器正常与 sanitizer | 各 16/16 CTest；各 5 个模型 golden 通过 |
| sanitizer 正控 | UAF、signed overflow、leak 均检出 |
| 五库正常 S/M/L 功能门禁 | 80/80 子进程、15/15 场景完成 |
| 五库 sanitizer S/M/L 功能门禁 | 80/80 子进程、15/15 场景完成 |
| 实际区间计数与内存诊断 | 候选 6 例、旧 alpha S 2 例通过 |

完整库包含 38 个 reflection/C++26 程序、2 个 C++17 storage 程序和 7 个子进程场景；
测试断言保持启用。实际工具链为固定 Clang 21 P2996 profile、匹配的 libc++/ABI 和
compiler-rt；五库测量驱动使用同一编译器，sanitizer Cap'n Proto/KJ runtime 也已完整插桩。

新增独立两两区间 oracle 覆盖 257,102 次操作、362,154 次 helper 检查、4,635 种有效插入排列
及 512 条固定随机流；覆盖包含、重复、同端点、交叉 owned/free、邻接、空区间、边界及拒绝后状态。
真实分配失败注入包含 4 个直接登记点与 49 个 typed load 点，其中 48 个为 `std::bad_alloc`，
1 个为 registry 的 XBadAlloc；检查异常前后原字节、恢复能力和作用域内资源平衡。
这不等同于穷尽所有 malloc、OS 或事务失败路径。

原 hostile-wire 回归在正常和 sanitizer 模式均记录 940 个拒绝、420 个安全可变输入。
带计数的旧 alpha reader 成功读取候选生成的 S 初始和修改后 wire；兼容证明限于这两例，不能外推全部
历史版本、任意 schema 或全部平台。

五库统一场景为可信输入、固定 schema 的可变值快照，使用 detached 拥有型结果，包含变长修改、
查询、导出及独立进程重载。S/M/L 分别覆盖规模变化，逐阶段 canonical、查询结果、最终 wire 和
独立进程 inspect 全部核对。独立审查完成 90 次 canonical 全字节对照、30 次查询对照、
270 次阶段摘要和 60 次 wire 全哈希核对。各库内部校验和重建成本仍不同，未建立 U 不可信输入共同合同。

候选的 M/L 功能场景已完成，解决了旧 alpha 在既定功能预算内无法完成的问题。
正常 M 完整生命周期 `run` 子进程的最大墙钟为 0.566358334 秒，供 20 秒正式 child 预算可行性判断；
这不是正式性能样本，也不是与旧 alpha 配对的加速比。旧 alpha 的超时仍为失败。

## 复杂度证据和内存代价

以下是专用插桩二进制的实际 comparator 调用数加邻居不等式检查数，不是 CPU 指令数或计时结果。
输入与生产候选固定；生成头、差异、实际 include 和独立 oracle 均留证。

| 输入 | 登记区间 R | 实际比较/检查 | 索引峰值申请字节 |
| --- | ---: | ---: | ---: |
| S 初始 | 1,540 | 74,094 | 73,920 |
| S 修改后 | 1,749 | 76,163 | 83,952 |
| M 初始 | 196,612 | 17,695,338 | 9,437,376 |
| M 修改后 | 223,700 | 17,677,653 | 10,737,600 |
| L 初始 | 1,572,868 | 169,870,038 | 75,497,664 |
| L 修改后 | 1,789,905 | 174,247,751 | 85,915,440 |

结果与有序索引的 O(R log R) 成本一致。旧 alpha 在相同 S wire 上实际执行 1,185,030 /
1,528,626 次两两检查，峰值申请 49,152 / 53,248 字节。旧 M/L 初始的静态两两检查数为
19,328,040,966 / 1,236,956,086,278；没有重新运行旧 M/L，也不能把这些比值当成时间收益。

这套 libc++ map 每节点实际请求 48 字节，最大实测 R 为 1,789,905，对应约 81.94 MiB。
它是观察到的规模，不是新增硬上限。全部索引请求在 load 返回前归零；峰值不包含 malloc 开销、
其他加载分配或 RSS。S 上 map 的峰值申请高于旧 vector，必须接受这个时间复杂度与临时空间的取舍。

计数上界 `12*R*(ceil(log2(R+1))+1)` 在诊断执行前写入运行脚本，但没有独立的执行前密码学 pin；
独立审查核对了实际计数、公式和生成差异，不能将其表述为严格预注册的性能实验。

## 唯一正式窗口：启动权限失败，零原生样本

所有代理停止重负载后，主会话使用原全局 W3 timing 队列执行唯一窗口。五库统一固定到
虚拟 CPU 2；这是先于功能时序选择的第三个可用 CPU，不能证明物理核独占或宿主无噪声。
冻结沿用 285 child 上限、20 秒/child、45 分钟窗口、16 GiB 新 wire 预算及原 A/A/统计停止条件；
预测新 wire 为 4,976,145,087 字节。候选源码、实际 Ninja 依赖、工具链、runtime、协议和二进制均绑定。

冻结清单执行前外部 SHA 为
`26a8fb0ca49299fe64e3c892de3f3f0538af873669956c5a2c970419412145ad`。
第一条 taskset 启动返回 126：`Permission denied`。原冻结程序为 0755，复制到 run 内的
`frozen/bin` 后变为 0644；字节相同，但 `copy_bundle` 只复制内容而未恢复可执行权限。
测量前对复制后实际执行能力的覆盖不足，导致此缺陷进入正式窗口。

结果为 1 条启动尝试、0 个成功 native child、284 条未启动、0 字节新 wire；没有超时，队列清理为空。
A/A、比较 block 和 bootstrap 都没有执行。外部执行后双清单 pin 已固定，audit/report 均为
`audit-preserved-failure`，`measurement_qualified=false`，`comparison=null`。
这既不是噪声资格失败，也不是库性能回退；没有速度排名、百分比收益、等价或 p99 结论。

按单次窗口规则，本轮没有重启正式计时。候选工具现仅对 sc-frozen 已登记的五个普通程序恢复
0755，并使用 O_NOFOLLOW、fstat/fchmod 检查复制目标，拒绝未知 bin 和符号链接，普通成员不加执行位。
最终权限修复在正常和 `python -O` 模式各通过 40 项工具测试，其中 5 项新增 POSIX 回归包含
真实、有界的无害临时脚本执行，以及未知成员、源/目标符号链接和权限恢复失败。
修复后的验证没有调用 campaign run 或五库程序；中间 39/39 和最终 40/40 日志分别保留。
它们属于失败后的新工具身份，不回写旧冻结包。若后续开展正式比较，必须重新记录完整输入闭包、
功能门禁和新冻结，不能复用本轮 pin 或覆盖失败结果。P9 的合格差异前提未满足，未启动归因。

## 交付与限制

[组合门禁](coordination/verified-ranges-20261017/combined-p4-acceptance-v1.json)、
[阶段状态](coordination/verified-ranges-20261017/plan.json)及新审查记录位于
`docs/coordination/verified-ranges-20261017/`。
小型证据副本见[证据说明](validation/2026-10-17-verified-ranges/README.md)，保留原始身份和来源；
完整 wire、canonical、二进制、runtime 和构建仍在上述 WSL 实验目录，不构成离线自包含包。

首次 NTFS 构建失败于根目录 VERSION 遮蔽 libc++ 的 `<version>`；失败档案保留，使用 ext4 镜像后
完成验证，没有删除或重命名源文件。这里的通过属于 WSL Linux，原生 Windows full/P2996 仍未验证。
N3 原 D/F 性能归因保留开放；N7 缺真实消费者/协议前提，沿用用户“暂不具备”的决定。
共享身份/循环图、borrowed attach、不可信 U、格式演进/跨语言都没有因本轮优化自动完成。

原工作区保护核对另留独立记录。上轮结束后旧 `final-document-review-v1.json` 曾被迟到代理覆盖，
本轮开始时已记录该身份差异，不回写旧验收清单；不能宣称那份旧最终文档清单仍逐项匹配。
本轮所有正式失败和独立审查采用新文件名并一次封存，候选保持未提交状态。
