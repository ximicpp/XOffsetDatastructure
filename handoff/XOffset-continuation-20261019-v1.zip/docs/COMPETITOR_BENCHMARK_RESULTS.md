# 五库功能对照系统：实现与验收结果

2026-10-17。已实现 XOffset、cista、FlatBuffers、Cap’n Proto、cereal 的独立适配器、
共同值模型、独立逐操作 reference/状态检查、九阶段完整值摘要、串行驱动和离线审计。
**原定五库整体功能门禁未通过；正式性能测量为 0，不能给出性能排名。**
阻塞是冻结 alpha.1 在 M 档完整功能命令中超过 60 秒，另有 M 档 sanitizer 验证超时。
没有降低校验要求、缩小原场景或重试正式窗口。

当前阶段状态见 [实施状态](coordination/competitor-implementation-20261017/plan.json)，
后续生产修复的完整边界和验收顺序见 [下一步实施方案](COMPETITOR_BENCHMARK_NEXT_IMPLEMENTATION.md)。
原 [研究](COMPETITOR_BENCHMARK_RESEARCH.md)、[设计](COMPETITOR_BENCHMARK_DESIGN.md)和
[P0–P11 计划](COMPETITOR_BENCHMARK_PLAN.md)保留当时的历史状态。

## 实现了什么

核心应用合同固定为：**可信来源、固定 schema、拥有独立可修改状态的快照**。
每个库完成相同的加载、释放输入、查询、标量修改、字符串/序列/属性增长、删除和追加、
输出独立快照、销毁旧状态、重载查询及清理。S/M/L 分别为 128/16,384/131,072 条记录。
每条记录使用相同的整数位宽、字符串、样本、payload 和属性，未给某库减字段或使用更窄位域。

所有候选运行时代码使用同一固定 P2996 Clang 21、libc++ 和 GNU++26；Cap’n Proto/KJ
运行库也由同一编译器构建。反射选项只给 XOffset。所有构建与原生验证使用原有全局队列锁。
独立系统位于 [实验目录](../experiments/serialization_comparison/README.md)和
[驱动工具](../tools/serialization_comparison/README.md)。实际身份锁见
[environment-p1-v1.json](../experiments/serialization_comparison/locks/environment-p1-v1.json)。

| 库和固定版本 | 主轨实际入口与成本 |
| --- | --- |
| XOffset alpha.1 | 封存 source tar；Typed verified load/save；Automatic 增长显式启用，pool 关闭 |
| cista v0.16 | offset 原生容器；NONE 默认结构检查；私有 blob copy，修改后的自分配子容器显式正确清理 |
| FlatBuffers v25.12.19 | Object API UnPack → 原生对象修改 → Pack；T 入口无额外 upfront verifier |
| Cap’n Proto v1.5.0 | 正常有限 Reader → 私有 MessageBuilder → 修改 → owning flat word array；不含 RPC |
| cereal v1.3.2 | BinaryArchive → native DTO/std 容器 → 修改 → owning binary string |

共同的是应用结果和所有权合同，不是相同布局或相同检查强度。
保留各 API 的自然 owning 输出，未强制某些库额外复制为 vector。
所有必要的 copy/unpack/builder/析构成本进入对应主阶段；完整值审计在主计时外，
仍受 child 时间预算约束。没有把这些入口称为同等不可信输入安全。

## 实际验收

| 验收项 | 结果及范围 |
| --- | --- |
| 基础契约、能力及失败清理 | 16 项不同 CTest，普通和 ASan/UBSan profile 各通过；另核 5 组模型 golden |
| sanitizer 有效性 | UAF、整数 UB、泄漏三个正控均被对应 sanitizer 检出 |
| 驱动/审计离线测试 | 29 项，普通和 Python `-O` 各通过；跨作者审查及修复已封存 |
| XOffset 普通 S | 完整五动作通过，包括独立进程重载 |
| XOffset 普通 M | encode、初始 inspect、九阶段完整值校验通过；完整 run 在 60.003896954 秒超时，未形成完整输出 |
| XOffset 普通 L | 未启动，保留 not_run；不从较小规模外推 |
| 其他四库普通 S/M/L | 12 个完整场景、64 个串行原生子进程全部通过；这是后续独立功能验证，不补替主门禁失败 |
| XOffset sanitizer | S 四动作通过；M encode 通过、validate 在 60.013541057 秒超时，无 sanitizer stderr；L 未运行 |
| 其他四库 sanitizer | S/M 八个完整场景、32 个子进程全部通过；L 未运行 |
| 正式比较/统计 | P4 未通过，P6 冻结和 P7 正式窗口均未启动；没有横向速度结论、区间或 p99 |

Sanitizer 使用匹配 compiler-rt 21，Cap’n Proto/KJ 运行库完整插桩。
资源失败探针在已经发生真实变长修改后，向 stage7 的 C++ new bookkeeping 注入一次 bad_alloc，
验证 RAII 退出以及初始快照字节不变且仍可恢复。它不覆盖所有内部 allocator、cista malloc、
XOffset OS 失败或多操作事务。没有用这些有限探针升级完整 U 安全保证。

主 80 项功能队列精确启动前 10 项：9 成功、最后 1 项超时、70 项未启动，唯一完整 cell 为
XOffset S。离线审计返回 `audit-preserved-failure`，运行前后源码/工具/运行库身份相同，
队列 live/process_groups/zombies 均为空。主档案外部 composite pin 为
`c47c940af34225a10a84b4fc9bc25720f3484ae9052f5a9e14e369cdfae3c1fc`。
其余四库的后续验证没有改写这份失败。

在此之前的 functional-v1 仅在准备阶段遇到上游已跟踪的悬空构建系统链接，原生启动数为 0。
审计工具随后明确绑定链接拼写和缺失目标状态，保留已存在目标的字节校验及循环拒绝；
修复经回归和独立审查后才使用新目录 functional-v2，原始失败未删除。

## 功能竞争边界

| 能力 | XOffset | cista | FlatBuffers | Cap’n Proto | cereal |
| --- | --- | --- | --- | --- | --- |
| 共同值模型的原生修改/增长/保存 | 小契约/S 完整通过；M 全流程预算失败 | S/M/L 通过 | S/M/L 通过 | S/M/L 通过 | S/M/L 通过 |
| 不复制读取探针 | 未建立 | const live blob 通过 | live wire view 通过 | live aligned Reader 通过 | BinaryArchive 主轨不提供 |
| 共享身份/环的限定探针 | 当前 admitted wire 无通用指针图合同 | 两节点 offset 别名/环及重载通过 | 共享 wire table + 标量原地改通过；不能据此称 Object API 保持图身份 | 本次 tree Object API 不提供所需身份合同 | shared_ptr DAG/自环通过；强环显式打断清理 |
| 共同 U 输入修改合同 | 未建立 | 未建立 | 未建立 | 未建立 | 未建立 |
| mmap/长期格式迁移/跨语言共同验收 | 未验 | 未验 | 未验 | 未验 | 未验 |

FlatBuffers 的共享 wire table 探针不等于支持循环图或修改后 Object API 保持别名；
cereal 探针也不覆盖 shared_ptr aliasing constructor/raw pointer。
因此五库可以在固定值快照场景竞争，扩展能力并不一致，不能用一个总分代表全部用途。
本轮未获得合格性能数据，也不能把可能的差异直接归因为“支持修改导致慢”。

## 已定位的问题与下一步

冻结 alpha 的区间登记每次线扫此前的 owned/free ranges，Typed load 必须执行它。
初始 fixture 登记的 owned 区间总数为 K=12N+4；M 的首次 owned-owned 检查为
19,328,040,966 对，L 为 1,236,956,086,278 对，具有 O(R²) 规模成本。
这是源码与实际 fixture 的静态推导，支持明确的复杂度诊断；尚无采样栈、耗时占比或优化收益证明。
也无法从超时确认 run 具体停止在哪一阶段。
详见 [定量证据](coordination/competitor-implementation-20261017/P4-xoffset-scaling-analysis.json)
及 [诊断范围](coordination/competitor-implementation-20261017/P4-sanitizer-timeout-diagnosis.md)。

下一步优先设计并验证 O(R log R) 的在线区间检查，保持原有拒绝语义和 wire 格式。
使用新的候选源码身份，先做区间 oracle/恶意 wire/资源失败/sanitizer，再恢复 S/M/L 门禁。
门禁满足后才登记新正式窗口；不能用 unchecked、缩小数据或改名 Docker 规避原失败。
当前生产 F 和 alpha.1 均保留，未将计划中的算法修复记为完成。

N7 仍缺真实消费者资料；原生 Windows full P2996 和旧 N3 D/F 归因也继续开放。
本任务没有用新竞品系统代替这些验收。

## 证据与保留

- [P1/P3/P5 复核](coordination/competitor-implementation-20261017/P1-P3-P5-independent-review-v1.json)
- [P4 支撑复核](coordination/competitor-implementation-20261017/P4-independent-review-v1.json)
- [P4 主失败复核](coordination/competitor-implementation-20261017/P4-main-functional-review-v1.json)
- [P5 实际主队列复核](coordination/competitor-implementation-20261017/P5-actual-functional-review-v1.json)
- [后续四库独立功能复核](coordination/competitor-implementation-20261017/P4-other-four-functional-review-v1.json)
- [小证据清单](validation/2026-10-17-serialization-comparison/manifest.json)
- [完整原始目录与保留边界](validation/2026-10-17-serialization-comparison/retained-originals.json)
- [既有成果保护检查](coordination/competitor-implementation-20261017/preservation-check-v1.json)

小证据副本约 1.47 MB、585 个复制成员；大型 wire/canonical/query、二进制、完整身份清单和依赖
仍保留在 WSL2 Ubuntu-22.04 持久 ext4 的
`/root/xoffset-serialization-comparison/20261017/implementation/` 和 `p1-v1/`。
小副本不是可独立重算全部 wire 或完整重建的发行档案；迁移/删除 WSL 前必须保留这些原始目录。

691 个既有受跟踪文件、957 个冻结 alpha 源成员、10 个交付成员及总校验和均保持原字节；
依赖 revision、HEAD 和暂存区未改变。本轮没有暂存、提交、推送、合并、发布或触发远端 CI。
