# 性能优化路线图 v2

2026-10-17。当前请求授权研究、设计、分工与实施；不提交、推送、合并、发布或触发远端 CI。Superpowers 未启用。当前已验收候选、alpha 包、历史研究与失败窗口保持原样，新改动在独立 worktree、新 Linux ext4 构建和结果目录完成。

## 起点、功能与应用场景

基线是 `xoffset-load-mutate-optimization-v1`，不是交接 Git HEAD，也不是根工程的 alpha 头。主头 SHA256 `2c50cfbbb53747a38cab6273a5c195e7fb6d5c97d07d13a9c9dc7e57782390b3`，OS 头 `22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad`。来源为 `/root/xoffset-load-mutate-optimization/20261017/v1/final-v1/source`。本次候选为 `xoffset-performance-roadmap-v2`，仍是未提交开发候选，不更新 VERSION 或重新生成发行包。

功能承诺以 README、ALPHA_COMPATIBILITY、当前生产头及测试为准：地址稳定的 VM arena、显式增长默认、严格容量上限、可选 Automatic/owner pool、arena 容器与嵌套反射构造、verified detach load、load 后继续修改、owning save、V1 schema/layout admission、所有权/空闲链表检查、现有异常和并发边界。保存与加载均有复制；并非外部 mmap 零复制。容器元素允许随修改移动；同 owner 并发写需外部同步。

优先场景 A 是已冻结的 M mixed-growth detached 生命周期：16,384 record、28,673 修改、55,299 查询，包含初载与修改后重载。场景 B 是长期驻留的多轮增长/删除/保存，后续应另建固定场景，不能用 A 减去加载时间冒充 B 的测量。场景 C 是只读可信映射、跨语言协议或生产异步网络：功能契约不同，不通过改比较模式将其混入本轮。N7 真实业务前提仍未具备，保持开放。

先前唯一实际窗口未通过 pre A/A，每库 8 条原始观察只能诊断。XOffset/cista 生命周期均值 131.30/50.98 ms，两次加载差额 77.58 ms，约为净差额 96.6%；修改差额 8.45 ms，保存观察少 5.62 ms。加载约占 XOffset 总计 73.5%。这些是可加均值分解，不是正式排名或因果占比。具体数据与限制见 [当前分析](CURRENT_PERFORMANCE_GAP_ANALYSIS.md)。

## 调研与架构选择

验证索引保持 owned/free 两棵有序树和在线登记。它们在单次 graph validation 内创建并统一销毁，符合单调内存资源的生命周期；标准 `monotonic_buffer_resource` 将子分配与上游分配分离，deallocate 不立即回收，上游 chunk 在资源释放时统一归还。[C++ 工作草案](https://eel.is/c++draft/mem.res.monotonic.buffer)。LLVM 同样将 bump allocation 放在多个 slab 内，显示这种方式不要求无限连续预留；仅作为设计参考，不增加 LLVM 依赖。[LLVM Allocator 源码](https://llvm.org/doxygen/Allocator_8h_source.html)。

P1 优先采用标准 PMR 单调资源与 pmr map，显式绑定 new_delete_resource，按小的固定初始规模惰性申请，不根据不可信对象数一次性预分配。不改比较器、查询/登记顺序和 emplace_hint。资源必须先于 maps 声明，确保异常和正常路径先销毁树，再释放 chunks。禁止共享全局池、线程局部常驻缓存、偷偷改变进程默认 PMR、catch OOM 后跳过检查，或新增合法输入节点上限。标准的增长因子是实现选择，因此内存预算只针对固定本机 profile 验收，不能声称标准保证同样比例。

P2 对 `can_relocate_without_allocation<T>()` 的元素优化 resize 超容量增长。先分配新父 buffer、验证/计算所有会抛出的描述符关系，并在新尾部完成默认或 fill 构造；此时原 prefix 不动，fill 参数引用旧元素也有效。所有可能抛异常工作成功后，才无抛迁移旧 prefix，结束源对象生命周期并发布新描述符、退休旧 buffer。非该 trait 保留旧 rebuild/copy fallback；缩小、容量内增长、容量策略、公共 API 与 wire 字段不变。不能仅做 reserve 再构造尾部。

标准 vector 对增长有复杂度与异常规定，但它不是本库 rel32/allocator 合同的替代；本库以原路径的实际保证及 fault tests 为准。[C++ vector 容量规定](https://eel.is/c++draft/vector.capacity)。README 对整个容器库只承诺分配失败时逻辑内容保留，并不承诺所有路径的容量/allocator 元数据事务回滚；本次超容量路径仍须保留原 descriptor/size/capacity/data 内容，不能降低原路径保证。

竞品用于检查成本位置，而非放松契约。cista offset 适用于同架构原生对象图；不同模式的检查范围须看固定版本源码。[cista 官方说明](https://cista.rocks/)。FlatBuffers object API 明确经 UnPack/Pack 在 wire 与可变对象表示之间转换，不能与直接 wire getter 混为一谈。[官方 C++ 文档](https://flatbuffers.dev/languages/cpp/#object-based-api)。本轮保持已有五库适配器的业务语义、trust_mode、输入脱离、native owning wire 和计时边界。不会把 XOffset 改为 unchecked 来追平 trusted 路径。

## 阶段、边界与验收

本会话交付 P0–P5；P6/P7 是有明确启动条件的后续路线，不把待研究项算完成。阶段状态记录在 `docs/coordination/performance-roadmap-v2-20261017/plan.json`。当前工具没有 TaskCreate/TaskUpdate 接口，使用这份可审计状态账本拆分任务并逐阶段更新。

| 阶段 | 实施范围 | 验收与退出条件 | 负责人 |
| --- | --- | --- | --- |
| P0 基线与隔离 | 新 worktree、源码/工具链/旧证据身份、任务和预算冻结 | 旧候选及根工程不覆盖；准确区分 Git 祖先与实际生产头 | 主会话 |
| P1 加载索引资源 | 单次验证专属 PMR/chunk 分配；两树算法保持 | 同 wire 的逻辑节点、owned/free、key/neighbor 判定不变；OOM 无泄漏/typed root 不发布；normal/SAN 与独立拒绝 oracle 通过 | linux_validation 实施，主会话集成 |
| P2 增长事务迁移 | resize 新尾部先构造，再无抛转移旧 prefix | 同/跨 arena fill alias、嵌套、trait fallback、尾部晚失败、父/子分配失败、原生命周期和 V1 测试通过 | windows_validation 实施，主会话集成 |
| P3 集成门禁 | 裸生产头完整构建；五库 S/M/L；旧新 reader/writer；包消费 | full normal、兼容 ASan/UBSan/LSan、实际正控、模型/拒绝/故障、新增测试、安装及子工程消费；不可用平台单列 | 主会话执行，n7_prerequisites 审查 |
| P4 机制诊断 | 一次固定 M 计数；必要时固定一次当前版本 phase profile | 九阶段 canonical/query 均正确；插桩与裸头逐字变换绑定；记录逻辑 node 与真正 chunk/arena 申请，计数不作时间样本 | 主会话唯一 native 执行者 |
| P5 冻结与报告 | 独立 review；最终五库唯一新正式窗口；离线 audit | 实际依赖绑定最终裸头，完整 pin/inventory/mode，禁止 pyc；沿用 A/A 和预算，失败即停；结果资格与实现验收分开 | 主会话测量，子代理只读审查 |
| P6 当前热点驱动 | owner registry/cache/局部移动保护；批量替换/赋值路径 | P4 当前版本采样证明占时后才立项，先设计同步/生命周期/异常合同；不得凭调用次数直接选热点 | 后续，有条件 |
| P7 布局与场景拓展 | compact/capacity/内部空洞；长期驻留场景 B；严格同保证竞品对照 | 固定 workload 与总成本，公开 save/reload/临时内存，V1 双向兼容；新公共 API 或信任模式单独评审，不偷偷改默认 | 后续，有条件 |

P1、P2 可以在独立补丁/测试目录并行，主会话顺序集成 P1→P2 到唯一生产头；子代理不直接同时修改共享头或 CMake。每个阶段源码、首次失败、修正与验证使用新目录。验证失败先定位原因再改代码/夹具，不覆盖失败日志，也不把重复跑通当性能证据。

P1 固定本机 M 初载/重载机制门槛：同一 wire 的逻辑节点数、owned/free、key 和 neighbor 检查不变；各阶段实际 upstream chunk 申请 ≤128，upstream 请求总字节 ≤2.25×逻辑节点请求字节+64KiB；资源退出 live chunk/live bytes 为 0。不限制所有合法输入到这个节点规模，不根据当前输入缩窄准入；不同标准库需要独立报告。若预算不通过，诊断并修正设计，不事后放宽。

P2 固定 M stage6 目标是 arena 申请 45,056→12,288，消除旧前缀 32,768 次嵌套申请；这是实施前机制目标，不是毫秒收益承诺。stage8 的 24,576 次是 2048 条新增 record 的嵌套存储，外层容量充足，不能被当成旧前缀浪费。保持每个阶段 canonical/query 与最终载入后继续修改正确；比较最终 wire 及其重载 owned/free 数的真实变化，不要求物理碎片逐字相同。

原 global new fault sweep 在池化后不能再代表“每个 logical node 都实际 host new”；新增直接上游 chunk 边界失败、资源销毁、隔离/嵌套验证测试，保留逐节点登记/overlap oracle。失败后复用或重载恢复只属正确性检查，不计入性能样本。P2 单独覆盖 fill 参数引用旧元素/子对象、构造若干新尾部后再抛、alloc/rel32 准备失败，以及非 relocation trait 的原 fallback。

## 测量与采用规则

沿用当前 Release -O3、固定 P2996 Clang/libc++/兼容 sanitizer runtime、相同第三方版本和 CPU2 虚拟 CPU。编译/重测试/归档与正式测量不并行；主会话持原稳定全局 W3 队列锁执行，子代理先停止一切重负载。不能宣称物理宿主机隔离。诊断、功能、sanitizer、正式计时分别记账。

P5 仍用既有五库协议，而不临时塞入第六个“旧 XOffset”再沿用旧资格。旧→新因果速度结论需要另行预注册的同窗控制研究，本轮不得从两次未合格窗口百分比推断。可用 P4 证明机制工作量改变，用 P5 检查最终候选在当前场景的资格与成本位置。

唯一正式窗口预算保持 285 children、15 warmup、pre/mid/post A/A、30 comparison blocks、20秒/child、45分钟、16GiB wire；A/A 中位比和 AB/BA 顺序中位比 0.98–1.02，scaled log-MAD≤ln(1.02)，漂移≤1.02。任何库资格失败则整格停止；不放宽阈值、改变样本、不性能重跑。新任务计数从 0 开始但旧计数完整保留，启动尝试和实际 native 窗口分别记账；即使启动前拒绝也保留证据，不无记账重启。

冻结工具只使用 `python -B` 和纯读取/AST 审查，禁止导入冻结模块产生 pyc。复制后的 inventory/内容/0755、真实 Ninja 头依赖、外部冻结 pin 和 post-run 双清单 pin 全部检查。正式计时包含实际校验、cache 维护和保存开销，canonical/hash/落盘边界按原 driver，不移动成本。

功能可采用、机制改善、正式性能合格是三种不同结论。A/A 失败只能交付“功能/兼容已验证的优化候选，速度仍未合格”，不得报告正式倍率或整体路线图完成。最终报告公开测试、差距、wire/整个进程峰值 RSS 的口径、限制、开放项和可编辑位置。

## 工作目录与分工

- 主会话唯一生产写入：`C:/Users/gzsufanchen/.codex/worktrees/performance-roadmap-v2/xoffsetdatastructure开发`；Linux ` /root/xoffset-performance-roadmap/20261017/v2` 下各阶段独立 source/build/log/results。
- linux_validation：只写根工程 `build/performance-roadmap-v2/load-index/` 的补丁、测试和设计。
- windows_validation：只写 `build/performance-roadmap-v2/resize-growth/` 的补丁、测试和设计；名称不代表本轮建立 Windows P2996 支持。
- n7_prerequisites：只写 `build/performance-roadmap-v2/review/` 及新协调目录 review 子目录，独立检查研究、测试漏洞、最终源码/冻结/验收；本轮不实施 N7。
- 所有旧 docs/coordination、validation、Linux measured/frozen/source 目录只读；新报告与便携证据另建目录。

P4 完成后的条件路线细化见 [v2 后续设计](PERFORMANCE_OPTIMIZATION_V2_FOLLOWUP.md)：当前采样仍指向区间登记为加载主热点，先研究索引边界快路径，再按证据研究 scratch 余量及修改保护。该增量说明不回写 Linux 候选内的实施前计划快照，不修改本轮 P1/P2 候选或测量预算。

## 2026-10-18 增补：多档虚拟地址槽位池的后续开发与评测

用户已要求将此方向纳入roadmap。登记为 **VM-SLOT：后续条件开发与评测，尚未启动**；排在当前V6修改链与修改后重载优化之后，不成为V6依赖，不占用其资源窗口。本次只更新路线图，不启动实现、构建、测试或测量，也不沿用上文历史P5窗口预算。

顺序为：业务容量/寿命及平台页大小输入 → 基于现有精确maximum与XBufferPool的容量策略/有界复用 → 同容量冷暖、混合及跨线程生命周期评测 → 仅在已有方案仍存在明确瓶颈时开发统一切槽原型 → 功能、V1、资源与性能门禁后决定采用或保留现状。分档不自动消除页尾浪费，稳定基址也不是新后端的新增收益。

分阶段范围、启动/否决条件见 [VM-SLOT路线与任务](vm-slot-pool-assessment-20261018/ROADMAP.md)；依据见 [综合评估](vm-slot-pool-assessment-20261018/ASSESSMENT.md)、[页成本分析](vm-slot-pool-assessment-20261018/PAGE_COST_ANALYSIS.md)和[未执行的最小实验草案](vm-slot-pool-assessment-20261018/EXPERIMENT.md)。重新启动时冻结届时实际开发基线，不将旧V5评估或本路线图v2起始身份冒充V6组合验证。

持续保留完整在线校验、V1 bytes与继续修改语义、精确maximum、超限失败、活owner不搬迁和既有生命周期/异常保证。全部重操作继续使用现有全局共享租约，不与V6或其它项目计时争用；平台、资源和性能结果按实际证据分别验收。
