# 加载与修改优化验收结果

2026-10-17。三项实现及本机正确性门禁通过；唯一正式窗口已执行，但未通过整格 A/A 资格，性能比较验收保持开放。本轮没有提交、推送、合并、发布或触发远端 CI。

实施计划：[LOAD_MUTATION_OPTIMIZATION_PLAN.md](C:/Users/gzsufanchen/Documents/ChatGPT/xoffsetdatastructure开发/docs/LOAD_MUTATION_OPTIMIZATION_PLAN.md)。候选可编辑工程：[CANDIDATE.md](C:/Users/gzsufanchen/.codex/worktrees/load-mutate-optimization-v1/xoffsetdatastructure开发/CANDIDATE.md)。构建、诊断、兼容与正式原始结果保留在 `/root/xoffset-load-mutate-optimization/20261017/v1`，所有旧目录和 O12-v1 测试夹具失败证据留存。

候选 `xoffset-load-mutate-optimization-v1` 基于交接提交 `7539433ab96d69c4a07b1db5c0a13786da85cdcd`，保持未提交。实际 main 为 `2c50cfbbb53747a38cab6273a5c195e7fb6d5c97d07d13a9c9dc7e57782390b3`（201,834B），OS 头为 `22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad`（未改），双头内容 digest 为 `af807e1fef99fd9b2eb23381848dff8ec140a55710bea209ffe55c0c783c12f7`。Git 提交和 alpha archive 字段表示来源，候选身份以实际内容及完整编译/运行闭包绑定。

## 实现与校验边界

1. [区间登记](C:/Users/gzsufanchen/.codex/worktrees/load-mutate-optimization-v1/xoffsetdatastructure开发/xoffsetdatastructure.hpp:2821)复用 overlap 检查的 lower_bound iterator，通过 emplace_hint 插入，保留两棵树、owned/free 冲突优先级、范围与溢出检查、逐次登记后才访问子对象的在线拒绝逻辑。仅 O1 时 owned/free/邻居检查数及48B树节点总字节完全相同。
2. [空闲前缀缓存](C:/Users/gzsufanchen/.codex/worktrees/load-mutate-optimization-v1/xoffsetdatastructure开发/xoffsetdatastructure.hpp:208)每个 Core 使用16个固定游标，按 state 身份、epoch、桶、请求字节及对齐缓存已拒绝区间；新增退休头先检查，选择与原 first-fit 完全相同。不同查询和外部 epoch、Core move/swap/load/release/reset 等失效或同步。不改 V1 桶、块头、state 或 LIFO 策略。N=512/1024/2048/4096 混合与持续退休用例均通过预先冻结的节点与维护操作上界。
3. [同 arena 移动](C:/Users/gzsufanchen/.codex/worktrees/load-mutate-optimization-v1/xoffsetdatastructure开发/xoffsetdatastructure.hpp:1586)仅在双方已绑定、真实 segment/state 相同、descriptor 位于 arena 且双向祖先保护通过时转移资源；先计算 rel32，再释放旧目的，清空源资源而保留绑定供复用。vector 还要求元素支持既有重定位规则。跨 arena、不同 state、未绑定及祖先关系保留原回退路径；未开放已删除的 move constructor，也未改重建算法。

V1 arena header48B、allocator state88B、string/vector descriptor16B保持原布局。Core 是宿主运行时对象，实测544B，其中缓存400B；这项变化不代表保留 C++ 二进制 ABI，消费者应重新编译。缓存针对重复同型请求，交替尺寸/对齐仍可能回到原扫描复杂度。原边界、所有权、空闲重叠、绑定、分配块元数据及完整图遍历仍执行，没有引入跳过校验入口。

## 可验证的操作量变化

单次固定 M 诊断，使用独立插桩头，九阶段 canonical 及前后查询全部一致；不作为耗时样本。

| 相同物理输入/产物 | 优化前 key 比较 | 仅 O1 后 | 下降 |
| --- | --- | --- | --- |
| load | 17,498,727 | 6,029,520 | 65.5% |
| reload | 16,823,481 | 8,669,766 | 48.5% |

| M 工作负载指标 | 优化前 | O1+O2+O3 |
| --- | --- | --- |
| 阶段5 空闲节点检查（含跳过尾节点） | 2,232,651 | 8,776 |
| 阶段6 空闲节点检查（含跳过尾节点） | 2,441,216 | 45,056 |
| 阶段7 动态分配 | 172,616 | 0 |
| 阶段7 退休块 | 258,591 | 24,576 |
| 九阶段动态分配总数 | 258,632 | 86,016 |
| 九阶段空闲节点检查总数（含跳过尾节点） | 5,898,485 | 116,878 |
| 九阶段 owner 查询 | 42,121 | 172,032 |

最终九阶段缓存维护比较共 1,337,495 次。阶段7仍退休24,576块、执行24,576次 owner 查询；O3 的诊断 helper 调用320,465次、范围谓词251,846次、非 trivial vector 元素访问68,619次。它们不是全部 primitive 指令数，三列不能相加当作完整 CPU 成本。节点列把 skip_jumps 对应的尾节点读取也计入，维护及 registry 成本另外列明；不能只用旧扫描循环次数宣称净提速。

最终 M wire 从21,051,048B变为17,830,872B，内容等价，原因是减少了移动深复制产生的分配/空闲布局。reload 的 free 区间由18,896降到8,192、树节点字节由10,737,600降到10,223,808；最终 reload 的比较数8,394,648不能单独归因于 O1，也不能说最终物理布局完全没变。

## 门禁

| 项目 | 实际结果 |
| --- | --- |
| 完整库 normal / ASan+UBSan+LSan | 50 / 50，通过，无跳过 |
| 五库 adapter normal / sanitizer | 各16项通过；各5份模型golden通过 |
| sanitizer 正控 | UAF、signed overflow、LSan均真实触发 |
| 工具 normal / Python -O | 各40项通过 |
| 五库 S/M/L normal / sanitizer | 各80个原生动作、15个功能单元，通过并完成外部 pin 审计 |
| V1 双向兼容 | 必选12例通过：S/M/L × initial/modified × 旧writer→新reader/新writer→旧reader |
| alpha 旧reader额外兼容 | 补充独立门禁2例通过（仅新writer→alpha旧reader的S initial/modified；不扩展成alpha全尺寸双向声明） |
| 独立审查 | 生产、runtime/gates、counts/V1及最终冻结包prelaunch均无阻断/未决项 |
| 真正 copy_bundle 预检 | 五库最终副本内容一致、0755、describe一致；runtime前后及冻结manifest不变 |

原 typed-load 分配失败/ownership oracle、既有早拒绝与 allocator 故障用例保持；新增 range hint、first-fit独立模型、缓存生命周期、同 arena 源复用/跨state回退/嵌套稳定压缩和真实 new/VM Enable 故障测试。O12-v1的失败来自夹具在已有空闲块之后建立第二state，违反原有正向offset约束；v2只修正夹具顺序并保留原错误布局的异常负例，生产补丁和预注册阈值不变，normal及SAN失败均保留。

主V1门禁的可选alpha路径不存在，原12例结果及其不可用记录保持；随后定位真实 `implementation/build-v1/bin/sc_xoffset`，核对与旧runtime pin相同的二进制、实际Ninja依赖及alpha头SHA9bc8f1f...，在独立新目录补充S两例通过。未用预期值代替已执行用例。

实际编译来自 Linux ext4 新目录，固定 Clang21/P2996+匹配libc++/ABI/私有glibc、相同 Release -O3；正式程序的 Ninja 依赖明确指向裸生产头，不使用诊断 generated 头。范围仅为本机 WSL2/Linux，不冒充 Windows 原生 P2996 或其他平台结果。

## 唯一正式窗口

固定 `V1-M-mixed-growth-trusted-detached-load-mutate-optimization-v1`，初始16,384条记录、相同九阶段变更与查询、输入脱离原始缓冲。五库固定版本为 cista v0.16、FlatBuffers v25.12.19、Cap'n Proto v1.5.0、cereal v1.3.2及本候选，实际commit/二进制/依赖由冻结包记录。XOffset额外的 arena 所有权/空闲区间保证仍保留，不能把该结果泛化成各库全部功能等价。

第一次launcher在0.205657秒、任何基准子进程之前拒绝：启动前审查脚本未禁用Python字节码，导入冻结protocol后生成2个pyc，破坏成员清单。原冻结包、错误review、拒绝回执和计数全部保留；该次无warmup/A/A/比较样本。随后在新 `recovery-v1` 目录作一次工具恢复，原生产/五个binary/runtime/functional/gates/policy/schedule身份不变，改为-B、AST/纯读取审查，并在启动前最后复核完整inventory、无cache/symlink及0755。

累计launcher尝试2次（包括上述0样本拒绝），实际native性能窗口1次，性能资格重跑0次。该区别明确记录在恢复决策、双账本及最终验收中；没有重置旧启动计数，也没有观察计时结果后换新窗口。原启动前review的passed结论因其写入副作用失效，以恢复目录中新prelaunch review为准。

主会话通过原稳定 W3 lock 独占执行实际测量；子代理全部 completed/quiet，无并行编译。仅约束本会话负载，不宣称物理宿主机完全隔离。正式 CPU2、20秒/child、45分钟、16GiB、285子进程计划、15 warmup、三组 A/A及30比较block全部保持。A/A中位/顺序中位比0.98–1.02、scaled log-MAD≤ln(1.02)、漂移≤1.02；任何实际native/预算/A/A失败停整格，不放宽阈值，不重跑。

实际完成 55/285 个成功子进程，排除 warmup 15 个，未执行 230 个；状态 `failed`，错误 `ProtocolError: anchor qualification failed: pre`。`measurement_qualified=False`，离线审计 `audit-preserved-failure`，外部冻结pin及双清单post-run复合pin已核对。既有 `performance_accepted=False`、`old_N3_closed=False` 字段按原协议保留，不作为本轮比较资格的替代布尔。

| 库 | pre A/A 合格 | 中位比 | AB 中位比 | BA 中位比 | scaled log-MAD |
| --- | --- | --- | --- | --- | --- |
| capnproto | False | 0.952415 | 0.981308 | 0.865386 | 0.044114 |
| cereal | False | 0.980398 | 0.975294 | 0.991627 | 0.072590 |
| cista | False | 1.015392 | 1.015392 | 1.011627 | 0.030464 |
| flatbuffers | False | 1.027073 | 1.052822 | 1.027073 | 0.045346 |
| xoffset | False | 1.018390 | 0.982466 | 1.032307 | 0.044704 |

本轮整格未取得比较资格；没有正式速度排名、正式五库倍数或旧版→新版耗时提升结论。原始 stdout/各阶段耗时完整留存，不能用未合格观察补作正式结论。

旧窗口未通过 A/A，本轮也没有“旧XOffset”这一额外参赛者；本报告操作量变化可复核，但不据此声称端到端性能提升多少倍。验证成本与实现成本仍需分开：本轮减少了冗余查找、重复扫描和深复制，仍保留完整图校验、48B std::map节点分配、VM实际payload复制；通用分配器缓存、批量赋值及wire压缩不在本轮实施范围。

## 证据与交付

关键验收：[combined-P4-gate.json](C:/Users/gzsufanchen/Documents/ChatGPT/xoffsetdatastructure开发/docs/coordination/load-mutate-optimization-20261017/combined-P4-gate.json)、[operation-count-summary-v1.json](C:/Users/gzsufanchen/Documents/ChatGPT/xoffsetdatastructure开发/docs/coordination/load-mutate-optimization-20261017/operation-count-summary-v1.json)、[final-verification-v1.json](C:/Users/gzsufanchen/Documents/ChatGPT/xoffsetdatastructure开发/docs/coordination/load-mutate-optimization-20261017/final-verification-v1.json)。新选集存放 `docs/validation/2026-10-17-load-mutate-optimization`，包含实际候选头、补丁/测试/脚本、日志、计数、兼容、冻结/正式元数据与审查；二进制、大wire/canonical及工具链仍在原Linux绝对路径，不将选集描述为独立可搬迁runtime。

最终核对92个旧报告/协调证据及根工程、旧Linux/旧worktree生产头字节不变，最终Linux与可编辑worktree头一致；三处HEAD仍为交接提交、暂存区为空。完整日志与旧失败原样保留。
