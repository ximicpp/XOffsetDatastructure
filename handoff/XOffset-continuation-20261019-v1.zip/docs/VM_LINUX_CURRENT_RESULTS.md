# 2026-10-16 WSL2 Linux 接续验证

当前 F 生产头保持不变。本轮在 Windows 宿主的 WSL2 Ubuntu 22.04.5、
Linux 6.6.87.2-microsoft-standard-WSL2、x86_64 上取得以下新运行结果。
这是同架构虚拟机的功能证据，不代表独立 Linux 物理机性能。

| 验证 | 实际结果 | 工具链与范围 |
| --- | --- | --- |
| storage | 2/2 CTest 通过 | WSL GCC 11.4；普通 C++17 |
| storage 安装消费 | installed 3/3、subproject 3/3 | GCC；安装重定位、三翻译单元 owner/池/静态析构 |
| full | 48/48 CTest 通过 | `linux-current-20261016` profile；38 程序、7 子进程、3 工具检查；另有 3 个 configure 检查 |
| full 安装消费 | installed 3/3、subproject 3/3 | 最终 `linux-current-complete-v2-20261016` profile；匹配 libc++、固定依赖 |
| 新网络 ASan/UBSan | 34 组、182 子场景通过 | 最终 profile；14 actual TCP、18 injected model、2 filesystem 组 |
| sanitizer 生效检查 | 2 个受控缺陷被检出 | 实际 P2996 反射程序分别触发 ASan UAF、UBSan signed overflow |
| 新工具回归 | 5/5 通过 | 参数保真、GNU ld 中文/空格路径、输出保护、缺陷拒绝、真实工具链文件变更检测 |

网络运行设置 `ASAN_OPTIONS=detect_leaks=1:halt_on_error=1`、
`UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1`，未出现 sanitizer 诊断。
最终二进制保留 `__asan_version_mismatch_check_v8`；没有关闭或绕过版本检查。
它验证现有同步 POSIX TCP 回环参考和独立注入生命周期模型，不能扩大为生产异步网络
transport 验证。`test_vm_transport` 也没有被用来替代实际新网络程序。

本轮未执行新的 full ASan 子集、TSan 或历史 wire 504 操作；对应历史记录保持原样。
没有做网络计时、生产候选修改、提交、推送或远端 CI。

证据入口：[本轮索引](validation/2026-10-16-linux-continuation/README.md)。

## 当前工具链

已有 `/opt/p2996-toolchain` 约 3.6 GiB，实际编译器为 Clang 21.0.0git，
提交 `9ffb96e3ce362289008e14ad2a79a249f58aa90a`，target
`x86_64-unknown-linux-gnu`，编译器 SHA-256
`c7fa55437d34c43201da37960251d7d3dab1e06fc92273efe6f6d88f6dae7c6e`。
它不同于历史 Linux 镜像的 `a527082...`，本轮使用新的 profile，没有改写历史锁。
普通 C++26 编译器没有被作为 P2996 替代品。

该编译器直接在 Ubuntu 22.04 启动时缺少 GLIBC 2.36/2.38 和 GLIBCXX 3.4.32。
本轮在工程 `build/toolchains/` 解包固定 Ubuntu noble libc6/libc6-dev 2.39、
libgcc/libstdc++ 14，用私有动态加载器执行编译器；生成程序显式指定私有加载器和
rpath。宿主系统库、系统安全设置与全局加载路径没有修改。

full 48/48 使用最初恢复的 `build/toolchains/linux-current-20261016/bin/clang++`。
随后 sanitizer 链接揭示缺少同版 `libc_nonshared.a`，因此另外创建完整 profile；
原通过 profile 与结果保留。最终完整 profile 为：

```text
build/toolchains/linux-current-complete-v2-20261016/bin/clang++
build/toolchains/linux-current-complete-v2-20261016/toolchain.json
build/toolchains/linux-current-complete-v2-20261016/sanitizer-resource/
```

最终 toolchain JSON SHA-256 为
`fd886461d6c54c54687c717c1902ffb7b073460e5fd5e4f63fe55b1eb17d5349`。
48 项 full 结果和最终 profile 的 package/network 结果是分别运行，不能合写成同次
最终 profile 的 full 48 项通过。

实际 libc++/libc++abi 来自同一 `/opt/p2996-toolchain/lib/x86_64-unknown-linux-gnu/`。
compiler-rt 21.1.8 包 SHA-256
`d6f84c34953b0404ec9648ba7364004a82454f79cc447f67894b9a27317ef6ce`
匹配仓库已有固定输入，新的自包含 resource 同时复制该编译器 builtin headers。
固定 CMake 4.2.3 由 `prepare_vm_cmake.py` 下载并核对已有 archive 锁。

本 profile 的系统头仍来自 WSL 宿主，不宣称完整 sysroot。实际搜索顺序、GCC 11 CRT
与 `/usr/bin/ld` 链接命令保存在 final-profile 的 `preprocess.stderr` 和
`compile-plan.stderr`；N3 另行绑定这些宿主输入。

复用现有编译器、准备相同固定包的入口为：

```sh
python3 tools/prepare_vm_linux_current.py --compiler-root /opt/p2996-toolchain \
  --out build/toolchains/new-linux-profile
python3 tools/validate_vm_linux_current.py --source-dir . --deps external \
  --compiler "$PWD/build/toolchains/new-linux-profile/bin/clang++" \
  --runtime-dir "$PWD/build/toolchains/new-linux-profile/sanitizer-resource" \
  --toolchain-record build/toolchains/new-linux-profile/toolchain.json \
  --out build/new-linux-network-validation
```

输出必须是新目录。该准备入口校验已观测编译器身份；不将其他编译器重标为此版本。

## 固定依赖与失败诊断

Boost 和 TypeLayout 分别按 gitlink `da041154...`、`9a6de1d...` 获取，十个 Boost
组件按父 gitlink 获取，没有升级。初次 Git for Windows 子模块检出虽传
`core.autocrlf=false`，仍因子模块 `.gitattributes text` 和默认 `core.eol=native`
产生 CRLF，full configure 的 include 内容锁真实失败。

只对本轮新克隆且无用户修改的依赖，从对应 Git archive 恢复提交原始字节，并同时
设置每个依赖的 `core.autocrlf=false`、`core.eol=lf`。full configure 此后核对全部
11 个 include tree 和 3 个许可证通过；依赖锁没有修改。更新旧 CRLF stat/index
缓存后，各子模块没有 staged 或工作区内容差异。

另两项准备失败也保留：首次 sanitizer 链接遗漏 nonshared archive；补全后的首次
GNU ld GROUP 脚本没有给中文路径加引号。后者通过解析错误定位，并增加真正执行
GNU ld 的中文/空格回归后修正，没有反复重试同一前提。

最早独立执行的 `cmake/reflection_probe.cpp` 虽成功编译链接，其 `main` 返回 1；
没有将其宣称为反射运行通过。CMake 的该 probe 本来只检查 compile/link；后续真实
full 48 项均实际执行并通过。
