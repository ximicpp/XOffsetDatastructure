# 四条核心路径的固定筛选结果

本轮保持 V1、完整在线校验、旧业务模型与调用边界。当前可合入最终组合的
默认核心仍为已验收的 V8 Word-only；以下原型及全部失败证据保留。新生产接口
另行验证和测量，不计作旧 owning save 的提速，也不替代五库同语义对比。

| 候选 | 功能结果 | 性能/安全准入结果 | 最终默认核心 |
| --- | --- | --- | --- |
| 内部分配最小对齐 8 | normal/SAN 各 12 项、同一旧初始 wire 业务门禁通过 | 固定 72 对/144 子进程，输出比点估计 0.998948，上界 1.049759；方向未证实 | 不采用 |
| CheckedRange 局部范围证明 | normal/SAN 各 12 项及业务门禁通过 | 唯一固定 72 对/144 子进程，reload 点估计 0.993209，上界 1.016868；方向未证实 | 不采用 |
| owned/free 共享页控制 | normal/SAN 各 12 项通过 | 每 owner/进程配额、可选元数据 OOM 回退及跨 DSO 进程边界不满足；计时前否决 | 不采用 |
| 透明 mutable owner locator | 源码反例成立 | 直接 descriptor、Core/allocator epoch 不变时，祖先嵌套移动可改变拥有关系 | 保留原递归判断 |

布局候选在同一 13,702,104 字节旧初始输入上执行原修改轨迹，最终 wire 从
17,830,872 降为 17,798,104 字节，仅节省 32,768 字节（约 0.184%）。这对应
固定成本调查证明的新鲜分配对齐间隙；其他继承空洞不能归为对齐浪费。输出中
allocator/header、存活对象 ABI、自由块和物理 donor 剩余仍在，因此不能预期
这一个修改使约 17.8 MiB owning 输出缩小数倍。

其固定窗口全程 60.549 秒，144 次均成功，AB/BA 各 36 对，无替换或补样。
目标为 emit_after；四候选共同的一侧校正上界是 1.049759。总时间点估计
0.998458，校正区间 [0.968110, 1.029757] 跨过 1。其余阶段未触发已确认回退
否决，但这不构成等价或提速证明。最终审计核对完整 1,164 成员清单、原队列
退出与清理、实际源码/二进制/SDK 绑定、逐子进程小型结果，并精确重算统计。
大型 wire/canonical/query 沿用执行窗口已逐字节验证的身份，未额外回放全部正文。

CheckedRange 的第一次自动判定把“机器码不同”当作足够准入，这是过弱的机制
门禁。保留该 v1 后以 v2 明确取代。旧包装函数尾调用 owned/free 两个独立函数；
新包装函数调用 checked-range 函数。仅比较包装函数的 161 对 174 条指令、
同为 22 个条件分支，不能推导完整路径更快或编译器已经消除了全部重复检查。
不能把机制未知直接解释为收益为零。统筹复核后在 v3 准入记录明确取代这一
过早否决，使用其尚未消耗的唯一固定 72 对端到端窗口，没有追加反汇编。
144 子进程在 62.179 秒内完整通过，reload 比值点估计 0.993209，上界
1.016868；总时间点估计 0.997561，校正区间 [0.968458, 1.027539]。
未触发已确认非目标回退，但仍未证明自改善。因此最终否决依据是这次有界
端到端证据，机制归因保持未知；不追加样本，也不改变已验收的 A/B/D/E 组合。

因此这四条路径尚未支持“明显超过全部竞品”的结论。生产扩展 A/B/D/E 的通过
结果只证明其各自功能门禁；完整组合门禁、真实生产周期成本、最终六角色 A/A
和获准后的五库比较分别验收。C 接收路径的 token 事务与完整数组生命周期仍须
独立解决，不能用 sanitizer 通过替代标准层面的生存期证明。

机器证据索引：

- `docs/coordination/performance-four-paths-20261018/core-screen-selection-v3.json`
- `docs/coordination/performance-four-paths-20261018/checkedrange-timing-admission-v3.json`
- `/root/xoffset-four-paths/20261018/v1/core-evidence-closure-v1/result.json`
- `/root/xoffset-four-paths/20261018/v1/checkedrange-evidence-closure-v1/result.json`
- `build/four-path-implementation-20261018/validation/merged-controls-admission-v2/decision.md`
- `docs/PERFORMANCE_FOUR_PATH_COSTS.md`
