# Receive mutable follow-up lifetime seam for independent standards review

C initial raw activation proof does not by itself cover old helpers: `reflect_init_all`/`reflect_transfer_init_all` memset+member construct on fresh outer; `relocate_construct` destroys/reconstructs members at a dead outer without an explicit enclosing object-creation operation. Production author is preparing a new strictly supported-domain seam, preserving frozen AB/old helpers as evidence, not deleting attrs.erase→resize→reload.

候选A：对已证implicit/no-bases/ordinary-member aggregate，live src→disjoint dead dst先inline sizeof(T) memcpy建立outer，再原memberhead构造/rebase/清src。候选B：在fresh/dead fixed slot成员初始化前placement `std::byte[sizeof(T)]`（无initializer）提供object-creation，不保留dead值。需独立核它与已存在T[capacity] array object/subobject关系、反射fresh构造和扩容tail-growth的生命周期，不能只以SAN通过当标准证明。完整token在接收前已对明确可访问max建立byte[max]，grow不重新new byte-array；不拿该事实无限推断以后所有旧mutation路径。

如果必须在dynamic allocation seam开始整capacity byte array或另加精确grow object-lifetime seam，需保持payload地址/现有values/alias、无额外大payloadcopy和旧V1/回调/OOM；未证明域应显式开放而非称全mutation保证已过。root继续A/B/D/E与核心门禁，C还未宣布完成。
