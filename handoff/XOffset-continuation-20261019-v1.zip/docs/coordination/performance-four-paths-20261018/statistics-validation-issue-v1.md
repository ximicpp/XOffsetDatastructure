# Statistics first leased validation: 28/29, one failure retained

2026-10-18 root执行 `test_phase_protocol.py -v`，queue initialize-v1 run817559d21404435ebe1c4d42820578e0，29项实际28通过。`test_AB_pairs_are_averaged_in_log_space_before_macrocycles` line269期望measurement_qualified=False，实际True。所有输出在 `/root/xoffset-four-paths/20261018/v1/initialize-v1/phase-statistics-tests.{stdout,stderr,receipt.json}`。未运行任何新性能轨迹，layout pure tests尚未到达。source-only统计包由分析会话独占，不直接修改；根先诊断合成数据/断言，不绕过此失败。

原initialize已完成新preservation-before.json与baseline.json以及baseline源码copy；后续不得覆写初次输出，使用resume新目录。

源码诊断：AA明确取chronological first/second，并按6block宏周期平均；失败test给side A恒1M、B恒4M，schedule的AB/BA使chronological差异每6block正负抵消，所以AA True符合既定estimand。候选/竞品A/B几何均值0.2的前三断言已通过；最后两断言数据构造不符chronological bias目的。建议仅修测试change为 `phases["emit_after"] = 1_000_000 if job["side"] == job["order"][0] else 4_000_000`：保留block0.5(log.1+log.4)、macro log.2、point .2，同时每组first/second恒1/4使AA确实失败。数学模块无需为这个测试改规则。作者拥有统计源码写入，根未改包。
