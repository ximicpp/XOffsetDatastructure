# 大页平台可行性研究（仅研究）

2026-10-18 核对官方文档。本轮未改变运行代码、全局配置、进程页策略或权限，未执行大页调用和平台性能测试；没有大页收益证据，不纳入本轮核心候选组合。

## Linux

THP 可降低 TLB 压力，但大页清零、直接回收与内存整理可能增加分配长尾。`MADV_HUGEPAGE` 是请求，成功不等于实际获得大页；架构和内核支持的页尺寸不同。后续独立实验应对库独占的匿名映射局部施策，记录对应 mapping 的 `smaps`、THP fault/fallback 与实际页尺寸证据；不能从一次返回成功或系统级计数推断当前 arena 使用大页。观测也有开销，应放在计时边界之外并保留其成本说明。

依据：[Linux THP 文档](https://docs.kernel.org/admin-guide/mm/transhuge.html)。这是平台机制结论，不是本项目提速结论。

## Windows

显式大页需要 `SeLockMemoryPrivilege`，大小和地址遵守 `GetLargePageMinimum`。大页存储常驻物理内存，必须同时 reserve 与 commit，不能把已预留的普通地址区间逐步提交为大页；碎片化也可能使申请昂贵或失败。与按需增长 owner 的现有成本模型不同，后续若研究必须使用独立存储策略，显式报告权限不足和普通页回退，计入初始化、保留、常驻内存及最终释放。

依据：[Windows 大页支持](https://learn.microsoft.com/en-us/windows/win32/memory/large-page-support)、[VirtualAlloc](https://learn.microsoft.com/en-us/windows/win32/api/memoryapi/nf-memoryapi-virtualalloc)。未检测本机权限，未声称 Windows 已验证。

## 本项目边界

旧输出返回普通 `std::string`，分配范围、页对齐和共享堆页由标准库及分配器决定。对舍入后的堆地址持续施加页策略，可能覆盖其他分配；这不是仅影响该输出的可证明局部优化。Windows 显式大页也不能通过标记现有 string 分配获得。

可行的后续研究对象是库独占、明确对齐和释放方式的 VM 存储；不能以其成绩替代旧 demo 独立 string 输出。实验须固定普通页对照，保留失败回退，分别计入申请、首次写入、完整复制/校验、长尾和释放，区分虚拟预留、提交、实际驻留。大页不会消除旧输出对全部 V1 字节的独立物化，也不会改变网络字节量。
