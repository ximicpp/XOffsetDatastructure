# 后续独立审查补充与写入边界

当前V8协议不改。后续receive必须最终VM payload在先，不能普通XBuffer(size)初始化arena/allocator再收，也不能from_bytes/load_verified(span)复制后称零复制。新增内部noexcept纯storage-adopt；构造完整临时XBuffer后立即建rollback，再做可能throw的arena/registry/root/allocator/graph验证。失败先detach owner再原址移回token，成功才typed/schema发布并消费；成功base必须等于seal前地址。

wire header与payload reservation分开；不得把88B header后interior pointer当VM reservation base。写入未完成或operation lease仍在时不能seal/finish；cancel不释放storage，lease保持到真实completion。失败token地址/字节/maximum_capacity/接收长度应可析构可重试。系统recv写字节不自动提供memcpy的对象创建语义，不得仅launder(reinterpret_cast)声称生命周期成立；必须审查既有V1/TypeLayout admission及byte/typed lifetime能力，完整处理非法bool。无法证明某项已要求能力是本接口实质阻塞，不用内部复制冒充零复制或降级后宣称完成。

ValidationScratch池仅缓存原始host块，保留每块原size/alignment，upstream归还用原参数；lease忙时可独立局部资源。锁仅摘取/归还状态，锁内不调upstream/new_handler/delete。先发布完整cache状态再锁外淘汰。新暴露grow字节按旧契约归零。每次局部membership为空，不能缓存校验结果。

locator对支持域逐项证明完整parent descriptor见证，不能把“descriptor公开”扩大成所有typed locator永不可能；unknown走原递归。稳定删除仍必须交付，预先ceil(n/8)bitmap、一次predicate全决定后，destroy/relocate到dead槽，最后size发布；predicate不结构修改目标/终止元素lifetime/释放owner是明文前提，不扩张原erase回调保证。

**统计纯源包由分析会话独占负责**：`build/four-path-plan-support-20261018/statistics/`。本执行会话不重复开发、不争抢编辑。接口policy(kind)、schedule(kind)、analyze(rows,kind)，严格输入{job,phase_ns,total_ns}和原8阶段，30项阶段/总量A/A、12项竞品主目标；零metric不可判定。分析会话仅写源包/测试草案，不执行测试/queue/重负载；交付后root在共享租约验证/集成。root负责实际admission、源/二进制/原始manifest绑定、runner及完整新输出审计，复用旧t和调度，不把旧total-only分析器误作新phase分析。
