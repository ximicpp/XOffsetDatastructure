# 源码支持的写入边界

分析会话独占 `build/four-path-plan-support-20261018/statistics/` 与 `layout8/` 的源码交付。执行根不重复开发；仅在统一租约中验证、物化和测量。layout8严格基于封存V6，根在V8验收后审查与Word的独立组合。统计包的source-receipt表明作者未运行；根仍须实际运行29个synthetic tests、审查协议及执行器绑定。

执行代理的author-only目录：`build/four-path-implementation-20261018/validation/`、`owner/`、`production/`；根负责`scratch/`与集成。全部新native输出为WSL `/root/xoffset-four-paths/20261018/v1`，旧V8工具和结果不改。

补充：分析会话也独占支持包 scratch/ 的 raw block pool/lease 源码；执行根只接入验证入口，避免重复。

