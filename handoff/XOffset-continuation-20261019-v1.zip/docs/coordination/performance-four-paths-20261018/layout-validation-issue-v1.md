# Layout targeted first build failure (before native tests)

Queue `layout-targeted-v1` run1faae901f5d14bc0ab5fc58cdc2f48be：new `test_internal_min_alignment.cpp` 的 NestedAlignmentRoot 包含 alignas16/32 composite elements；`TypedXBuffer::create/save/load` static_assert failed。现有V1 admission对class明确要求alignof<=8，不能为了test放宽。第一次normal build证据在 `/root/xoffset-four-paths/20261018/v1/layout-targeted-v1/normal-build.stdout`；没有CTests、SAN或任何effects。

纯minimum+metadata修复与Word的两种独立区域组合字节相同已检查，candidate头已物化；旧source未改。高对齐Core/分配头oracle仍应该测试；高对齐嵌套struct不能冒称既有V1支持。建议按真实admission修改最后一个回归：高对齐嵌套用Core+direct graph验证（若其初始化sound），或用admitted align8嵌套V1复用、将高对齐V1拒绝写明staticassert。新目标保持existing admission完整，不跳过实际嵌套复用路径，不扩大V1类型域。
