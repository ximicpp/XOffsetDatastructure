# 接收接口的契约与生命周期复核

2026-10-19，仅只读源码/文档。没有修改冻结候选、编译、测试、native或租约。本记录修正早期审查对“外部元素引用保证”的解读，不宣称C接口已经解决。

## 已有合同与实际测试

以下路径相对 `build/four-path-implementation-20261018/`：

- `delivery-v1/source/xoffsetdatastructure-0.1.0-alpha.1/README.md:178–180` 保证arena/root地址在growth/save中稳定，同时指出容器修改可能移动或销毁元素；`docs/ALPHA_COMPATIBILITY.md:79–81` 明确不能由arena base稳定推断长期元素指针稳定。
- 交付头文件的 `try_expand` 注释只描述物理尾块增长、容量限制及失败不变。没有找到“同址容量增长后所有旧T&都继续有效”的明确公开保证。本轮用户计划也没有明确增加这一条件。
- `tests/test_tail_expansion.cpp:80–98` 检查同址增长、内容和物理头，内容经重新取得的元素读取；`:133–144` 检查嵌套XString的外层地址与独立payload地址；`:270–282` 存在旧 `ptr + 1` 表达式，仍须纳入语言证明。
- `tests/test_scalar_resize.cpp:78–89` 要求同址scalar增长无申请、无退休，并保留前缀及初始化后缀。强制fresh allocation不能作为等价修复。
- 内部自别名是明确支持的调用：`test_resize_growth.cpp:162–194` 的 `resize(5,v[0])`、owned-subobject view、跨arena fill，以及 `test_scalar_resize.cpp:108–124`。操作内部的旧别名必须有效至最后一次读取结束。

标准std::vector的失效规则不能自动替代本库合同；同样不能把物理地址不变自动升级为所有外部元素引用继续有效。

## 仍未完成的生命周期证明

L1：交付头文件reserve、rebuild、resize_construct在申请动态字节后进行元素数组指针算术，提交的逐槽seam尚未建立整个capacity array。seam本身以父数组已存在且边界不变为前提。

L2：物理tail扩展和更新capacity不等于建立更大的语言数组。如何在同址、无新申请、无异常条件下建立完整extent，恢复前缀非隐式owning heads、保持嵌套对象与内部alias读取顺序，仍需严格证明。已有旧指针算术也不能忽略。

“必须透明重定向全部旧外部元素引用”是另一个依赖合同的条件，当前未找到足以将其列为既有保证的证据。早期 `lifetime-review/review-v1.md:109–125` 的假想旧引用见证应按此条件性理解，不得宣称已经证明C在现有合同下不可能实现。

可继续研究fresh/reused完整区域的标准隐式对象创建事件，以及同地址extent重建和原址head激活；它们目前只是待证明方向，不能由SAN成功推定成立，也不能用immutable/copyload替代完整可变接收。

当前准确结论：**C的whole-array生命周期证明尚未完成；外部引用稳定性不能包装为已确立合同。** 正在执行的ABDE冻结候选及唯一Q窗口保持原样。
