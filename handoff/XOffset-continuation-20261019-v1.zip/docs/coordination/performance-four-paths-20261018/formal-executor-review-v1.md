# Actual final candidate required in qualification

The human coordinating review on 2026-10-18 identified that the first frozen
source-only executor incorrectly kept the inherited Q32 two-baseline binding.
The current plan requires all six actual roles in Q32: accepted V8 control,
final candidate, and the four fixed competitors. Each role must qualify its
own five A/A stage contrasts (30 total). F64's own A/A results cannot replace
this prerequisite. The final candidate is mandatory in both Q32 and F64.

`build/four-path-implementation-20261018/formal/` and its receipt remain intact.
It has not been bound, imported, tested or executed by root. The prepared
`start-formal-pure-tests.py` is inactive and will not be used for admission.
A separate `formal-v2/` author package must fix source, tests and README before
root creates a derived bound executor and proposal. No measurement has run and
there are no samples to repeat or replace.

The production author is independently fixing the C receive prototype in a new
`production/receive-v2/` scope: State-only operations after entry pin, a single
atomic phase, terminal Consumed, and callback movement/replacement/destruction
tests. The v1 source is not ready and is not evidence of these fixes. Full
mutable array lifetime and same-address capacity growth remain a separate
blocking proof obligation; no completed C claim is authorized by a token fix.
