# Scratch first integration validation: component trim callback failure

Queue scratch-targeted-v1 487e1c2cd3114806a2897110b1ad6f1f，normal CMake/build成功。4个CTest中 typed wire integration、双TU registry、双DSO registry通过；`validation_scratch_contracts`中 `second explicit trim failed` 抛异常，随后析构noexcept terminate。证据 `/root/xoffset-four-paths/20261018/v1/scratch-targeted-v1/normal-ctest.stdout`。SAN尚未执行，不宣称E已完成。作者包未改，根先核explicit trim的回调和pending/cached状态；后续新版本保留失败。

源码根因候选：Tracking::do_deallocate用 `auto callback = std::move(on_deallocate);` 假定std::function移后空，但其源状态有效未指定，libc++小target可能保留可调用；第二trim再次执行同callback并新建一个cached块，runtime按既定“trim保留重入新状态”契约未清此新块，故live不空。do_allocate同模式也有风险。应将两处测试one-shot callback消费改 `std::exchange(on_deallocate,{})` / `std::exchange(on_allocate,{})`，再用新目录复测；runtime不能为满足错误test强制反复trim或删除重入新块。root typed integration的upstream已使用exchange，因此它通过。待作者修两测试helper，不改pool算法/预算。
