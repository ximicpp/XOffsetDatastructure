# 正式执行器只读审查

审查对象：`build/four-path-implementation-20261018/formal/` 的作者源码层。审查时仍为 `source_complete_unbound_root_admission_pending`。未执行、import、编译、测试或申请租约。以下应在新的绑定派生版本修正，冻结作者包保持不变。

1. `six-role-campaign.py:102,109,196,347` 的 Q32 两个 XOffset 角色都绑定 V8，candidate 可为空。计划要求六角色含最终候选，并分别完成 read_sum/mutate/emit/reload/total A/A，共30项。Q 同样必须绑定最终候选。继承的 `conditioning_envelope.py:24` 中 `qualification_X_role_binaries_identical: true` 也须同步更新为真实策略并冻结新身份，调度和样本数保持原定。
2. `six-role-campaign.py:364–375` 从各角色 origin functional 复制初始 wire，只比较 fixture，没有与历史同库 wire 身份相等检查。冻结各库旧初始 wire，两个 XOffset 使用同一 V8 初始 wire；候选 final-size 和业务真值也应来自该输入。运行时读入 hash 相符不等于历史输入未改变。
3. `six-role-campaign.py:493–504` 的 complete/status 和 elapsed 先于 seal；维护版 `core.py:156–158` 先写状态后清单。最终审计确实强制完整 manifest、queue 成功及完整 wall 预算，未发现可穿透最终验收的路径。但不能凭 status 启动 F；应保留 seal 后终态和失败记录，完整时限包括 seal。

其余源码通路与设计相符：30 A/A、12主目标、40辅助；df来自32/64宏周期；先计算每个 child 的 read_sum；固定24主样本 warmup；conditioner 不入推断；八阶段和二进制、输入、trace、输出及队列身份均有审计通路。这些是源码判断，尚无该执行器实际测试、注册或窗口通过证据。
