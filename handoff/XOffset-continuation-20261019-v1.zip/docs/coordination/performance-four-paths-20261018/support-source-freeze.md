# Support source freeze after first native use

根后续所有prepare将先把作者包复制到新native输出的author/快照，再校验全部FID、从该快照构建。`statistics`、`layout8`、`scratch`原作者目录已经进入实际失败/通过记录；之后修复请另建-v2等目录，勿继续原址覆写已引用输入，旧失败源码与receipt也属于证据。前两次统计/layout修复发生在原路径，日志/实际初始FIDs已保留；如果作者仍有首次完整源码，请额外归档原件并校验其旧FID，不重写旧日志。

根未修改作者包算法；后续新源版本与旧失败必须可区分。所有最终报告会明确首次失败、修复层和重测，不声称首次通过。
