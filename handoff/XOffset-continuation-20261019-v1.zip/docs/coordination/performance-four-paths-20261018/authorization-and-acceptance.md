# 完整四路径实施授权与不可遗漏门禁

2026-10-18，用户经分析会话明确要求PLEASE IMPLEMENT完整方案。本执行会话负责实际集成、构建、验证及持续推进；分析会话只读审查，避免争抢编辑和重负载。先收束V8原216协议，再在新阶段源码/构建/结果目录执行全部台账任务，不能以一轮候选或路线图结束。本授权包括明确的Q32/F64，不再用旧“没有任何新正式预算”结论阻塞，但必须先有合格候选、完整功能门禁、真实资源admission和预注册。不得扩大为未定义额外窗口。

正式主族12项：候选/同批四固定竞品各自read_sum(query_before+query_after)上界<=1.05、mutate<=1.05、旧demo save_verified完整独立拥有输出<=0.20。每个原生进程先算read_sum，再按既有block/macrocycle层聚合；不能把子进程当独立宏周期。联合单侧95%。自身对照只筛候选，生产接口不替代旧demo；reload对四库完整报告，不添加凭空硬比例。其他阶段/总量/wire/host/scratch单列，显著成本转移否决，跨1不等于等价。

Q32资格覆盖6角色×(read_sum,mutate,emit,reload,total)=30项A/A及固定联合误差。旧V5分析器只接收job/total_ns、6总量AA和5总量对比，不能直接套新12项；只复用t数值函数和调度等正确部分。任何phase0不取log、不丢弃，按预定规则不可判定；资格失败不formal，正式不达标不放宽/补样。

成本调查固定S/M/L各一次完整轨迹和M16输出分解，诊断时间不作正式性能；有效数据、capacity spare、header、alignment、free、holes物理账本互不重复。九阶段申请/迁移/owns-address实际扫描，emit规范化/容量申请/完整copy/首次触页，reload copy/range/bitmap/scratch分开。旧17.83MB/2.24ms仅约7.95GB/s工程量级，必须实证，不能保证；已存在resize_and_overwrite/from_bytes单遍copy不得重算新优化。

内部布局候选允许合法新wire尺寸/identity，逻辑真值不变；内部admitted类型申请满足实际类型且最低8B，公开Core max_align_t保证不改。V1头、分配头、rel32/schema/ownership不变，高对齐/firstfit/reuse/tailgrow/OOM/回调/V1双向与四路径均验。CheckedRange局部proof只在原bounds/alignment/header/首错误次序后复用；机器码已消除则否决。owned/free控制合并仍保留两类逐byte精确membership和全局owned优先/原事务；cold/crosspage/growth/sparse和硬预算不改，不能收集后排序改变早拒绝。V8单word不重开。

typed locator只允许严格证实阴性跳递归，阳性仍走原predicate以保steal/copy及moved-from语义。同一仍有效复合数组不同live元素的声明owning subobject需要完整parent descriptor见证；same-arena/地址顺序/非递归标签不够。公开descriptor、逃逸引用、byte-placement任何无法维护域unknown回退；这不自动证明所有locator永不可能。host索引惰性有界2MiB/owner、全进程32MiB，失败关闭优化不限制输入，generation/move/retire/reuse/reentry完整。soundness失败可明确否决透明快路，不能取消生产stable_erase_if。

生产API必须实际交付，按A→B→C→D→E顺序：

A save_verified_into(std::string&)复用容量但输出仍完整独立V1。输出准备后重解析源owner，不能跨分配保存失效base。旧save不直接改委托：test_vm_transport旧契约要求输出分配失败时source已normalize、base/epoch/handle不变。新API可先reserve并给更强输出值保证；new_handler原地grow/append可能改used_end而不改epoch，故需重读schema/root/allocator/payload，最后no-allocation copy容量足够；源增大有限source-changed失败，不无限重试。同out标准string操作重入需明确前提。空/热容量分测，准备不移出旧emit。

B freeze_verified(TypedXBuffer<T>&&)不可变拥有快照，稳定header/payload两段，完整校验先重查magic/header_size/used_end再structural_graph。全部Control/shared_ptr内存准备早于source move；不能shared_ptr(new Control(std::move(source)))后控制块OOM消费source。header位于稳定control，旧segments跨lease移动仍有效。OwnerRecord只验身份不pin映射；若不支持同source回调改写/释放，应明确quiescence，不能事后identity假装防护。失败不消费、旧reader完整加载、控制块/PMR各处OOM实测；调用方停用所有可写别名。owner/header资源保持到真实I/O completion，取消不等于完成，不自建网络框架。

C begin_verified_receive/finish_verified是库拥有、对齐、可增长VM token；完整填入且完整校验成功才转交。失败不消费token；任意span/string不能冒充同等owner。短读/取消/对齐/释放器/lifetime和OOM事务实测。

D索引仅用于不可变快照，不用Core epoch假装发现任意mutable引用。stable_erase_if最小实现受can_relocate_without_allocation<T>约束，先分配ceil(n/8)决定，再按原顺序对const T&恰好一次predicate；全成功后destroy/relocate到dead slot稳定压缩，最后发布size，capacity/data/binding不变。scratch OOM/predicate throw不提交。predicate不得结构性改同目标、结束元素lifetime或释放owner；nothrow析构不代表无callback，不扩张原erase重入保证。复用same_arena_move/owner_identity故障测试，核payload identity、predicate/析构次数。

E显式生产ValidationScratch上下文：全进程空闲池32MiB、每块<=8MiB、lease独占，超限正常释放而非限制合法输入；每次全量重验，不缓存输入结论。不能默认全局池隐藏旧cleanup。生产规模records1/16/256/16384，一次/重复发布/多接收者共享，构建/发布/索引/缓冲准备/背压/最终释放全周期，retained与活跃峰值分列；CPU与网络字节分列，内存模型不是网络延迟。

每个新核心候选最多一次预固定72配对、AB/BA各36，保留八阶段，无滚动补样；先定向normal/SAN/oracle/OOM/alias/lifecycle，后效果，只组合有独立依据者，最终组合完整相关门禁一次。新阶段不提交、推送、合并、发布或远端CI；Superpowers未启用。旧全部封存不回写、不重复无变化历史全文审计；SDK/runner/link/cleanup复用，重负载共享租约。大页只研究不改全局，不对通用string堆默认hint。
