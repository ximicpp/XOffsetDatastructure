# Receive raw component boundary accepted

生产代理 /root/windows_validation 已确认尚未实质写raw walker（仅设计/阅读），因此 `build/four-path-plan-support-20261018/receive-raw/` 由分析会话作者独占，避免重复；生产代理专注token/storageadopt/registry rollback/operationcompletion与A/B。

建议尽快冻结单一点源码合同：namespace `XOffsetDatastructure::detail::receive_raw`，`supported_v<T>`；`validate<T>(char* base, size_t used, uint64_t root_offset, uint64_t allocator_offset, std::pmr::memory_resource*) -> opaque proof`；`proof.activate() noexcept` 无分配/用户回调、原址精确head字段恢复。opaque proof可以持有已准备activationplan，但必须能在激活前失败且原token字节不变。组件不管Core/registry/VM/TypedXBuffer，不调用尚无lifetime的typed-owning verifier。

生产finish顺序：接收前placement std::byte[]；完整wireheader检查→纯storageadopt并立即rollback→arena metadata和registry全失败准备→raw validate全graph→noexcept activate→typed/schema发布→noexcept consume。最终接口小差异可由生产代理单个调用适配；请组件作者保留精确proof/lifetime/invalidbool/预算/错误顺序边界。
