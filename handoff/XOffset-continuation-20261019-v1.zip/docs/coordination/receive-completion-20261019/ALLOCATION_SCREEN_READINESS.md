# Allocation witness 独立筛选：实际就绪状态

候选为独立 B060 九文件域的 `xoffset-allocation-witness-v1`，主头 SHA256 `ffa185a2e0e1aea6b0cf53325e289bbb970469be030632ce12582a19dee47c87`。冻结的 C14 发行包保持原样。

已实际完成：

- 9 normal + 9 SAN 定向测试、两次无时钟旧 M 机制诊断。
- 非插桩原 driver 机器码及独立复核：成功路径绕过原共享引用原子增减；helper 保持 outline，增加检查分支，尚无耗时结论。
- 原 66 normal + 66 SAN 全量测试，各另有 3 项 configure 检查。
- 新业务 normal/SAN 各 80 个功能进程、84 项主 V1 交叉消费、8 项附加检查和 AB 双向消费。
- 新标准包 installed3/subproject3、版本请求拒绝与 851 个依赖头闭包；可选 runtime installed6/subproject6、两个共享库与 DSO 检查。
- 新筛选源码 22 项纯测试、离线全文审计器 6 项纯测试及独立源码审查。
- 新登记和 5 个准备性功能进程完成；新 ready 已冻结。准备过程的计时字段不进入筛选样本。
- 新进程控制仅换 fresh allocation STATE，保留已审的实际 PID/创建时间/映像/SID/句柄检查、独立守护恢复及覆盖校验；11 项控制策略测试、只读计划与窄源码复核通过。尚未暂停任何程序。

拟执行一次固定 72 对、144 个串行进程，AB/BA 各 36 对；使用封存旧 M 输入与 trace，不改 workload。主目标仅 mutate，保持既定严格上界 U<1 与辅助退化否决；无删点、补样、替换、重试，不借 cursor/cell 或旧 Q/F 预算。本次是独立内部筛选，A/A 未建立，不产生五库正式排名。

实际测量预计约 1 分钟。单进程上限 20 秒，完整 worker/实际计时命令上限 600 秒，780 秒只作故障清理及独立恢复上限。原始输出上限 8GiB，启动前双盘至少 16GiB；就绪检查时 guest 可用约 614GiB、C: 可用约 114GiB，开始前还会复核。所有受控重负载队列及子代理必须排空，暂停后获取原共享租约最多等 10 秒。

仅在取得新的明确许可后，临时暂停计划中的游戏客户端和 TGitCache。暂停可能导致游戏连接超时；每个窗口成功或失败都会先恢复程序及电源，再进行全文审计。不会暂停其他 Git 或其他程序，不终止、重启程序，也不修改它们的优先级。

旧 `process-pause-authorization-v1.json` 的 `performance_scope` 绑定已结束的 cursor-only 窗口；它不会自动充当本次 allocation 的新许可。新的许可仍未创建，实际计时样本为零。

就绪证据入口：`allocation-effect-prepare-v1-acceptance.json`、`allocation-effect-prerequisites-v1.json`、`allocation-window-orchestration-source-v1.json`。最后仍需真实许可、单窗口执行、实际覆盖/恢复及 144 份完整产物的独立审计，任何 passed 中间文件都不能替代这些门禁。
