# C 可变接收：完整数组生命周期的独立实施依据

2026-10-19。只读标准、SDK头和交付源码研究；没有修改候选、编译、测试或native执行。本记录给出可进入实现的默认类型域方案，不代替实际全路径审查和门禁。旧ABDE/Q32证据保持原样。

## 1. fresh/reused容量区

调用前检查count、乘法、对齐及整个已分配区域。count为0单独处理，不创建零长数组。

```cpp
void* created = ::operator new(count * sizeof(T), raw);
auto* array = static_cast<T(*)[]>(created);
T* first = *array;
(void)(first + count);
```

数组类型本身是implicit-lifetime；显式标准非分配operator new触发隐式创建并返回suitable-created-object。可选择完整T[count]；T[count]与T[]相似，数组与自身pointer-interconvertible，转换后array decay取得首元素指针。nonimplicit元素尚未活时，只能取构造地址，不能读取其值或成员。务必使用返回指针，不把旧T*的可达区直接扩大。

规范：[intro.object](https://eel.is/c++draft/intro.object)、[conv.qual](https://eel.is/c++draft/conv.qual)、[expr.static.cast](https://eel.is/c++draft/expr.static.cast)、[conv.array](https://eel.is/c++draft/conv.array)、[expr.add](https://eel.is/c++draft/expr.add)。

交付头的接点除reserve/rebuild/resize_construct之外，还包括assign_range、staged T[1]、string的char[capacity+1]；公开arena allocator的同类问题需单列审查。普通implicit outer可用sizeof(T)的同类事件建立对应元素，再执行原逐成员构造；不必用整对象复制来补outer。

## 2. 同址扩容必须保留表示

不能先用operator new结束旧prefix，再假定原对象值仍可读取。可以研究直接使用整个checked extent的self-memmove：

```cpp
void* created = std::memmove(raw_whole, raw_whole,
                             newcap * sizeof(T));
T* fresh = *static_cast<T(*)[]>(created);
(void)(fresh + newcap);
```

C的memmove语义先保存源字符序列，再写入目标；C++把隐式创建安排在目标字符写入之前，并返回suitable-created-object。故抽象顺序是保存表示、建立新数组、写回表示。不能将整个nonTC普通aggregate当作TC对象：证明递归到普通非重叠TC叶子恢复原有效表示；nonimplicit owning heads另外处理。

规范：[C N3096 §7.26.1/4、§7.26.2.3/2](https://www.open-std.org/jtc1/sc22/wg14/www/docs/n3096.pdf)、[cstring.syn](https://eel.is/c++draft/cstring.syn)、[basic.types.trivial](https://eel.is/c++draft/basic.types.trivial)。[P0593R6 §3.2](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2020/p0593r6.html)提供对应解释，不能以提案文字代替现行规范。

仅遍历live prefix的inline layout：从raw bytes复制四整数descriptor到固定快照，placement构造确切最派生head，再赋回四字段。不得读dead-head成员，不调用binding/release或旧析构；遇head就停止，不递归其独立payload。那些out-of-line allocations的生命周期未结束。

spare bool只按unsigned characters搬运，不进行typed load或bit_cast；因此不能用start_lifetime_as_array的整TC-array定值规则混同此方案。固定SDK未找到start_lifetime_as_array API，不依赖它。默认mutable域递归排除未审custom、bases、union、potentially-overlapping及其他不支持成员；custom未来构造需要完整独立策略。

raw_whole必须从canonical arena byte-array基指针和checked offset形成，全新extent已可访问。旧rel32从head字段char*跨对象再launder的来源问题不能由本方案自动洗白，需在C域单独闭合。

## 3. 提交、别名与退役

物理扩容失败时不进行数组重建；成功后的保表示事件、inline-head恢复、容量提交应全部无异常且无用户回调。保留general resize的fresh/tail-first路径：先完成所有fill读取，再搬动旧prefix，避免新增throwing-tail原址事务。insert保留先staging原参数。

string assign先完成原rhs memmove，再做完整char数组事件，最后写terminator和提交size，覆盖rhs含旧终止符的内部别名。reserve无须head遍历。

retire须在live prefix销毁后真实placement创建FreeBlockHeader；fresh数组事件发生在allocator读完并移除旧free header之后。字段和V1头尺寸不变。旧tail测试的同址、无申请/退休、嵌套payload稳定仍须验证；旧ptr+1不能未经证明当作新数组指针，使用扩容前整数地址与扩容后fresh指针可验证相同物理连续性。

## 4. 语言证明与机器成本分开

memmove的抽象temporary不要求真实缓冲区，C库函数不抛C++异常；但标准不逐字承诺所有实现内部绝无分配或读写。锁定SDK的同址复制消除、armed allocation计数及真实成本需要实际检查，不能先称整条链零复制。finish不因此需要新增whole-payload self-memmove。必须继续normal/SAN、OOM、alias、恶意输入、V1消费者及完整生产周期；SAN通过不能单独证明语言规则。
