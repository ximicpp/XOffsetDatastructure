"""Create a new transfer capsule. File copies/hashes/ZIP only; no project import or job.

Run on the old WSL machine with the explicit workspace path. All archived files
remain immutable. This script never builds, executes a test, resumes development,
pushes, or deletes/moves an existing file.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import shutil
import subprocess
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--workspace', required=True)
args = parser.parse_args()
root = Path(args.workspace).resolve()
assert (root / 'HANDOFF_20261019.md').is_file()
target = root / 'handoff' / 'continuation-20261019-v1'
archive = root / 'handoff' / 'XOffset-continuation-20261019-v1.zip'
assert not target.exists() and not archive.exists(), 'A new capsule path is required'
target.mkdir(parents=True)
origins = {}
omitted = []

def fid(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return {'bytes': path.stat().st_size, 'sha256': h.hexdigest()}

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

def copy_file(source, relative, category, required=True):
    source = Path(source)
    if not source.is_file():
        if required:
            raise FileNotFoundError(source)
        omitted.append({'path': str(source), 'reason': 'not present', 'category': category})
        return
    if source.is_symlink():
        raise ValueError('No symlink file copied: ' + str(source))
    destination = target / relative
    assert destination.resolve().is_relative_to(target.resolve())
    assert not destination.exists(), str(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    before = fid(source)
    shutil.copyfile(source, destination)
    assert fid(source) == before == fid(destination), str(source)
    origins[str(Path(relative).as_posix())] = {
        'old_machine_path': str(source), 'category': category, 'identity': before}

def copy_tree(relative, category, suffixes=None):
    source = root / relative
    if not source.is_dir():
        raise FileNotFoundError(source)
    for path in sorted(source.rglob('*')):
        if path.is_symlink():
            omitted.append({'path': str(path), 'reason': 'symlink', 'category': category})
            continue
        if not path.is_file() or '__pycache__' in path.parts or '.git' in path.parts:
            continue
        if path.suffix in ('.pyc', '.pyo'):
            continue
        if suffixes is not None and path.suffix not in suffixes:
            continue
        copy_file(path, path.relative_to(root), category)

copy_file(root / 'HANDOFF_20261019.md', 'HANDOFF_20261019.md', 'current entry')
copy_file(root / 'HANDOFF_20261019.md', 'START_HERE.md', 'current entry alias')
copy_file(root / 'HANDOFF.md', 'HANDOFF.md', 'historical entry')
copy_file(root / 'AGENTS.md', 'AGENTS.md', 'project instructions', required=False)
copy_file(root / '.gitmodules', '.gitmodules', 'historical repository context', required=False)
copy_file(root / '.gitattributes', '.gitattributes', 'historical repository context', required=False)

for relative, category in [
    ('docs/coordination/cross-machine-handoff-20261019', 'new handoff explanations'),
    ('docs/coordination/receive-completion-20261019', 'latest status and decisions'),
    ('docs/coordination/performance-four-paths-20261018', 'previous protocol and decisions'),
    ('docs/codegen-production-assessment-20261018', 'independent codegen research'),
    ('docs/vm-slot-pool-assessment-20261018', 'deferred VM slot research'),
    ('experiments/serialization_comparison', 'maintained benchmark source'),
    ('tools/serialization_comparison', 'maintained benchmark tool source'),
    ('experiments/vm_coordination', 'historical coordinator source; port before use'),
    ('toolchains', 'toolchain documentation and profiles; no compiler'),
]:
    copy_tree(relative, category)

for path in sorted((root / 'docs').glob('*.md')):
    copy_file(path, path.relative_to(root), 'top-level roadmap and historical context')

base = Path('build/receive-completion-20261019')
for directory in [
    'delivery-v2/artifacts', 'delivery-v2/acceptance',
    'delivery-supplemental-v1',
    'new-AA-qualification-design-v1', 'new-AA-runtime-maxima-tools-v2',
    'allocation-screen-result-v1', 'bitmap-effect-results-v1',
    'scoped-specialized-effect-results-v1',
    'performance-allocation-witness', 'bitmap-transition-inline-v1',
    'scoped-owner-borrow-specialized-v1',
]:
    copy_tree(base / directory, 'frozen source package, small evidence, or reference tools')
for name in ['result.json', 'delivery-manifest.json']:
    copy_file(root / base / 'delivery-v2' / name, base / 'delivery-v2' / name,
              'C14 accepted delivery identity')
for name in ['AA-runtime-maxima-worker-v2.py', 'run-AA-runtime-maxima-v2.py', 'common.py']:
    copy_file(root / base / name, base / name,
              'historical path-bound wrapper; do not directly execute on new host')

native = Path('/root/xoffset-receive-completion/20261019/v1')
for source, name in [
    (native / 'new-AA-oldQ-process-maxima-v2/result.json', 'oldQ-process-maxima-v2.json'),
    (native / 'AA-runtime-maxima-dispatch-v2/result.json', 'maxima-dispatch-v2.json'),
    (native / 'queues/AA-runtime-maxima-v2/result.json', 'maxima-queue-v2.json'),
    (native / 'cursor-effect-screen-v1-window/analysis.json', 'cursor-analysis.json'),
    (native / 'cursor-effect-screen-v1-audit-v1/result.json', 'cursor-offline-audit.json'),
    (native / 'final-source-identity-v4.json', 'C14-source-identity.json'),
]:
    copy_file(source, Path('portable-evidence') / name, 'copied old-machine metadata')

fixture = Path('/root/xoffset-serialization-comparison/20261017/implementation/prepared-v1/M')
for source in sorted(fixture.iterdir()):
    if source.is_file():
        copy_file(source, Path('portable-inputs/fixed-M') / source.name,
                  'immutable historical M input; not a measurement')
reference = fixture.parent / 'reference.py'
copy_file(reference, 'portable-inputs/fixed-M/frozen-reference.py', 'historical input generator source')
registration = json.loads((root / 'docs/coordination/receive-completion-20261019/cursor-effect-screen-registration-v1.json').read_text())
wire = registration['fixture']['initial_wire']
copy_file(Path(wire['path']), 'portable-inputs/old-V8-initial-wire.bin',
          'immutable historical XOffset M wire; verify ABI before consumption')
assert fid(target / 'portable-inputs/old-V8-initial-wire.bin') == wire['identity']

git_context = {}
for key, arguments in {
    'head': ['rev-parse', 'HEAD'],
    'branch': ['branch', '--show-current'],
    'remote': ['remote', '-v'],
    'tracked_status': ['status', '--short', '--untracked-files=no'],
}.items():
    result = subprocess.run(['git', *arguments], cwd=root, check=True, capture_output=True)
    git_context[key] = result.stdout.decode('utf-8').strip()
write(target / 'portable-evidence/git-context.json', {
    'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'warning': 'Historical root/HEAD is not C14. Do not blindly apply the context patch to C14.',
    **git_context})
diff = subprocess.run(['git', 'diff', '--binary', '--no-ext-diff'], cwd=root, check=True, capture_output=True)
(target / 'portable-evidence/old-workspace-tracked.patch').write_bytes(diff.stdout)

verify_source = root / 'docs/coordination/cross-machine-handoff-20261019/verify_handoff.py'
copy_file(verify_source, 'verify_handoff.py', 'portable read-only integrity checker')

manifest = {
    'schema_version': 1,
    'kind': 'cross-machine-source-and-evidence-transfer',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'development_status': 'paused_by_explicit_user_request',
    'default_source': 'C14/final-v4; extract the pinned source archive into a new directory',
    'platform_tests_run_here': 0,
    'native_or_performance_executions_run_here': 0,
    'source_zip': str(base / 'delivery-v2/artifacts/source/xoffsetdatastructure-0.1.0-alpha.1.zip'),
    'source_zip_sha256': '3ddeb05afa78f566d4673d4ca19933a74f29edb45f1250be30bf69d34b7495e4',
    'C14_delivery_result': str(base / 'delivery-v2/result.json'),
    'origins': origins,
    'omitted_items': omitted,
    'not_included': [
        'Full old WSL filesystem, compilers, SDKs, runtime, native build/install trees',
        'Complete historical timed wire/canonical/query bodies and all 4656 original Q receipts',
        'All competitor dependency source archives and old executable binaries',
        'Complete .git database and the entire old ignored build directory',
    ],
    'files': {},
}
for path in sorted(target.rglob('*')):
    if path.is_file():
        manifest['files'][path.relative_to(target).as_posix()] = fid(path)
manifest['file_count_excluding_manifest'] = len(manifest['files'])
manifest['total_bytes_excluding_manifest'] = sum(v['bytes'] for v in manifest['files'].values())
write(target / 'TRANSFER_MANIFEST.json', manifest)

with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=1) as output:
    for path in sorted(target.rglob('*')):
        if path.is_file():
            output.write(path, path.relative_to(target).as_posix())
with zipfile.ZipFile(archive) as bundled:
    assert set(bundled.namelist()) == set(manifest['files']) | {'TRANSFER_MANIFEST.json'}
    for name, expected in manifest['files'].items():
        data = bundled.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256'], name
    assert bundled.read('TRANSFER_MANIFEST.json') == (target / 'TRANSFER_MANIFEST.json').read_bytes()

record = {
    'status': 'transfer_created_and_all_zip_members_verified',
    'archive': {'path': str(archive), **fid(archive)},
    'expanded_root': str(target),
    'manifest': fid(target / 'TRANSFER_MANIFEST.json'),
    'files_excluding_manifest': manifest['file_count_excluding_manifest'],
    'bytes_excluding_manifest': manifest['total_bytes_excluding_manifest'],
    'project_tests_or_performance_executed': 0,
    'development_remains_paused': True,
}
write(root / 'docs/coordination/cross-machine-handoff-20261019/TRANSFER_RECEIPT.json', record)
print(json.dumps(record, ensure_ascii=False, indent=2))
