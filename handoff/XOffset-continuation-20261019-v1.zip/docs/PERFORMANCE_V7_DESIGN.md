# V7 修改路径优化

基线为已通过功能验收的V6 B-only：245897字节，主头SHA256 `fb66f9617839e76924ad2422ab54624fbf0c0ba2064bacf393125b5f4fbe26c5`，OS头22f181b5。它是开发与功能控制，不是晋升后的正式性能基线。V5/V6、旧54样本及失败均不改写。新源码/构建在WSL `/root/xoffset-performance-v7/20261018/v1`，工具在`build/performance-v7-20261018`，台账在同名coordination目录。

Classify仅以bit_width替换ceil桶类别循环：<=8仍为0，>262144仍为16。原函数oracle覆盖全缓存域、幂边界和uint32极值/随机值，真实wire错误优先保留。实际V6 allocation机器码确有倍增循环；retire/verified机器码未捕获，保持未知。

Align仅替换dynamic freelist与Core host free_blocks两处取余；输入已排0/非power2/过大alignment，因此unsigned地址掩码精确等价。保留所有guard、first-fit、middle unlink、OOM/回调；独立算术oracle和真实块/非法参数/typed往返负责证伪。实际每处都有互斥32/64位DIV路径，不能算每节点四次除法，更不能换算耗时。

两候选独立targeted normal/SAN为9/10项，共38项；实际main/OS、新test、Ninja、编译参数和binary绑定。两次序组合仅作身份检查，有独立效果后才集成。保留者执行最终完整相关normal/SAN、业务/V1/消费、恶意输入、真实OOM、别名、回调与生命周期验收，不重测未变工具。

另一方向只做一次固定M计数，回答no-growth失败/catch/回收/retry/grow频次及原因、分类输入与两处对齐predicate实际到达数。只在私有adapter加noexcept计数gate，原mutate体、driver/model/trace/八timer不变；时间不作性能样本，核完整端点canonical/query及wire，不宣称九个中间stage均核。source-loop计数不等于bare机器迭代。若只是少数几何增长就否决复杂异常消除，不先写补丁。

内部效果事前固定36平衡triplet=108run，V6/Classify/Align各36，六排列各6，每角色每位置12。复用sealed V6 SD约.11574作规划，SE约.01929、df35主界log宽约.0392；不是新数据，不保证power或独立性。两主目标均mutate，单侧Bonferroni2上界<1才可进入完整验收；18项次要对比用另一双侧联合95%族，非目标或总量下界>1否决。两族分别95%，跨1不证明无退化，零耗时未定义不得晋升。无warmup、剔除、截尾、替换、重试或追加。

原始八阶段、wire、RSS/CPU/fault、验证scratch单列，防成本转移。CPU2、child20s、窗口600s、保留8GiB、guest/backing初始各16GiB并留2GiB余量；执行前完整身份和原七文件投影另注册。prepare5次原业务validate(3normal+2候选SAN)；编译与timing使用独立共享租约，不编四竞品。

旧codegen选择器因demangle与mangled selector不匹配只返回节头，已判无效保留；原4条预算剩余2条取得真实181/269指令体，nm仍1次，无新compile/profile。不为未知符号继续采样。

A空桶摘要、C2捷径、SSO/共享/wire/API/业务调用改变均不加入。正式五库窗口尚无新增预算，不阻塞本轮代码与有限内部验证。不提交、推送、合并、发布或远端CI；Superpowers未启用。
