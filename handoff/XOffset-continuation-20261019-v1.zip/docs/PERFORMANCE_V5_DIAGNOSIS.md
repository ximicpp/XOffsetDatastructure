# V5 R0: precision, order effects and an executable measurement plan

This is a design review, not a registered execution request. It reads only the preserved V4 result. No new native process or timing was run by this review. `collect_v4_metadata.py` was run once by the coordinator under the global lease; its output and the original V4 data remain unchanged.

## What the old data establish

All 1,200 actual children completed: 600 conditioning children and 600 primary-cohort children. Of the latter, 24 were warmups and 576 entered the eight balanced macrocycle summaries. All six simultaneous A/A intervals contain 1, but none fits wholly inside `[1/1.05, 1.05]`. This does **not** establish equivalence; it also does **not** establish a nonzero systematic order effect. The point ratios, in role order old X/new X/cista/FlatBuffers/Cap'n Proto/cereal, are 0.97379/0.99461/0.97345/0.98441/1.01051/0.99786. A/A means chronological first over chronological second, not primary over conditioner and not an arbitrary A/B label contrast.

The distinction between three possible obstacles matters:

1. **Precision:** eight macrocycles give seven degrees of freedom and simultaneous A/A critical `t=3.63580742`. Observed log half-widths are about 4.15%–8.29%, so even a point estimate exactly at 1 would often fail the fixed 5% band.
2. **Possible order bias:** point effects range from about -2.7% to +1.1%. More samples narrow the interval around the true effect; they do not remove a real effect. No finite sample count gives high equivalence power uniformly when the true effect approaches or exceeds the 5% boundary.
3. **Temporal dependence and environmental change:** the 48 within-cycle blocks are not 48 independently established observations. Exploratory serial patterns differ by role. Eight cycles are insufficient to identify a dependable correlation model or a physical cause. Treating all 576 primary children as IID would be especially unjustified.

The CPU and wall observations narrow some hypotheses without identifying a cause. Log CPU/wall correlations are 0.955–0.985, and CPU A/A points are close to wall A/A points. Thus the observed variation is not explained solely by wall-only descheduling. CPU bracketing and accounting granularity also differ from the timer interval; negative CPU-minus-wall values are not a direct wait-time counter. Major faults are zero and per-role minor counts vary little, but stable counts do not establish stable fault service time. Context switches, migrations and scheduler wait were not captured in the old native/receipt schema and cannot be reconstructed.

Primary/immediate-conditioner log correlations are only 0.026–0.222. Conditioning did not make each next primary interval predictable in these data. Late/early cycle time-level ratios range from 0.956 to 0.991, while first-half/last-half A/A changes have mixed signs. These are exploratory trends, not a causal decomposition. Index-lag autocorrelations are descriptive because physical gaps are not uniform; neither absence nor presence of one large coefficient proves independence or a particular hardware mechanism.

The aggregate field `analysis.all_actual_primary_timer_ns` uses “primary” to name the **business timer metric**, not the primary cohort. It totals **all 1,200 actual children**, including conditioners: 75.741366717 s of business timer intervals. The same 1,200 children account for 437.093495243 s of receipt intervals; the interchild gaps total 136.526442031 s, and first-receipt start to last-receipt end is 573.619937274 s. These quantities must not be described as totals for only the 600 primary-cohort children. Controller cadence is material, but the totals alone do not prove that cadence caused A/A failure.

## Sample-size planning, with uncertainty exposed

`sample_size_planning.py` and `sample-size-planning-v1.json` provide the calculation and full grid. They reuse the identity-pinned editable V4 Student-t math, not any imported frozen module. Five pure mathematical tests cover analytic chi-square df=2 values, NIST tabulated anchors, CDF inversions, domains and the original df=7 t critical value.

Let `h=log(1.05)`, let `sigma` be the standard deviation of balanced macrocycle first/second log means, and let `delta` be their true mean. The nominal interval half-width at sample SD equal to `sigma` is

`t_(1-.05/12,n-1) * sigma / sqrt(n)`.

The worst observed old SD is 0.0644674. Six simultaneous one-sided 95% SD upper bounds, using `sigma_U = s * sqrt(7 / chi2_(.05/6,7))`, yield worst 0.157889, a factor 2.449. This upper bound is itself conditional on the **old IID normal-cycle model**. It is not a distribution-free bound, nor a promise that an altered future host environment has the same variance.

| Cycles | Actual children with conditioning | Half-width at old worst SD | Old serial-cadence projection |
|---:|---:|---:|---:|
| 16 | 2,352 | 4.894% log | 18.74 min |
| 32 | 4,656 | 3.212% log | 37.09 min |
| 48 | 6,960 | 2.563% log | 55.45 min |
| 64 | 9,264 | 2.195% log | 73.81 min |

These are not power guarantees or timeout forecasts. In particular, 32 cycles with a 2.7% true log bias would still have an expected interval reaching beyond the band at the old SD.

A conservative family-80%-power **sufficient** calculation splits each role's allowed failure probability `.20/6` between an upper sample-S event and an absolute mean-error event, then uses a union bound. It does not assume independence between roles. Under IID normal cycles, sufficient `n` solves

`abs(delta) + sigma/sqrt(n) * [t_(1-.05/12,n-1) * sqrt(chi2_(1-(.20/6)/2,n-1)/(n-1)) + z_(1-(.20/6)/4)] <= h`.

| Assumed absolute true bias | Required cycles, old worst point SD | Required cycles, old simultaneous SD upper |
|---:|---:|---:|
| 0% | 57 | 293 |
| 1% | 85 | 453 |
| 2% | 145 | 797 |
| 3% | 313 | 1,774 |

This is a conservative sufficient bound, not an exact power calculation and not proof that every smaller count fails. It shows why neither 16 nor 32 cycles should be sold as an 80%-powered solution to the old noise. Variance reduction and control of the execution environment must be tested; increasing sample size alone does not resolve bias or long-range dependence. The earlier extra 2.5% precision-screen suggestion is withdrawn. The qualification threshold remains the original 5% equivalence band.

## Proposed fixed execution design, before any V5 candidate timing

The recommended feasibility budget is **one Q32 qualification** followed, only if qualified, by **one formal64 window**. These counts are a coordinator proposal, not frozen by this document. Q32 means 4,656 actual children (2,328 conditioners, 2,328 primary-cohort children including 24 warmups); formal64 means 9,264 actual children (4,632 each, with 4,608 primary inference children). Both retain six-block balanced macrocycles as inference units. They do not relabel the fine blocks independent. Keep the original Student-t/Bonferroni estimands, all six A/A 5% bands, all four competitor 0.80 point/upper targets, no outlier removal, no optional stopping and all samples required.

Q uses **the same immutable V4 candidate binary for both X labels**, plus the four fixed V4 competitor binaries. It computes only six A/A intervals and descriptives; no cross-library contrast, speed ranking or candidate selection is permitted. Q is a once-only environment feasibility test, not an opportunity to tune the model, power policy or sample count until it passes. Any Q failure preserves its output and prevents the formal launch. Passing Q is evidence for that envelope in that run, not proof that the formal run must qualify; formal must independently pass all six A/A intervals.

Formal uses V4 as old X and the fixed V5 candidate as new X, with current four competitors and identical business work. Suggested hard elapsed budgets are 2,700 s for Q32 and **5,400 s for formal64**, registered before Q. The 90-minute formal bound is a new declared resource budget, not a changed A/A threshold or retroactive extension. If only 45 minutes is permitted, 32 cycles fit the old cadence but retain a substantial low-power risk. Do not hide this by adopting a more favorable independence model. At 64 cycles, the conservative family-80% sufficient bound permits approximately SD <=0.0412 at absolute true bias <=2%; that is a conditional planning target, not an extra pass screen and not a parameter value already established by Q.

Every primary keeps its same-role full-lifecycle conditioner, with full semantic/body validation and no conditioner timing used for admission or rhythm decisions. Fixed conditioning is an explicit warm-cache execution contract for every role; it does not claim cold-start measurement. Preserve the complete native timing boundary and fresh-process owner/cleanup semantics. No in-process batching is introduced to obtain smoother numbers.

The host envelope is recorded rather than overstated. CPU2 affinity is guest affinity. The i9-13900K host reports 24 physical and 32 logical processors, while WSL presents a virtual 16-core/32-thread topology. This does not identify CPU2 as an exclusive physical P-core. Record the high-performance power plan readback if used, and restore the prior plan in `finally` within the same guarded operation. Record concurrent-load observations; do not claim physical exclusivity or stable frequency. Guest governor/current-frequency paths are absent. `sched_schedstats=0`; readable schedstat fields are not evidence that all scheduling statistics are enabled. Capture available software CPU/fault/context-switch/migration observations for diagnosis, while wall lifecycle time remains the sole winner metric. Do not choose a new model after seeing these counters.

## Resource envelope and audit obligations

The previous per-child recursive tree scan is quadratic in the number of files. Replace it with the new coordinator-owned `runtime_resources.Ledger`: one initial census, O(1) known seven-slot admission/recording, and one final membership reconciliation. Always account partial output even after a failed child or failed semantic parse. No winner is emitted until final reconciliation and full maintained native/body audit complete.

Byte-identical deduplication is an explicit V5 storage policy. Full maintained semantic validation precedes pooling. Successful `.wire`, `.canonical` and `.queries` files are hashed and exactly byte-compared to an output-contained same-filesystem anchor before atomic hardlink replacement. File names, payload bytes, receipts and original command paths remain intact. Unique valid files and all invalid/partial outputs are retained; unexpected uniqueness can honestly exhaust a cap and stop the once-only attempt. Dedup does not make logical generated bytes disappear: all actual wire generation, primary wire generation and apparent retained path bytes are separately counted. Unique-inode allocated blocks are a storage measure, not RSS, a library-exclusive measure, or total VHDX allocation. Final audit still reads/verifies every body path and records membership/hardlink policy.

Both free-space domains are mandatory: the guest reports 762,646,978,560 B free but actual Windows C backing free was only 214,428,258,304 B. A guest-only check is insufficient. Record the WSL VHD backing-volume mapping; verify the `/mnt/c` free-space probe against the Windows snapshot. Admission uses both guest and backing free space, a worst-child temporary peak, metadata reserve, and the fixed disk safety margin. Host VHD high-water reclamation/trim is not assumed. The coordinator freezes exact logical and physical caps and a projection for Q plus formal, including the copied frozen closure and pool anchors, before launch. Hardlinks may reduce physical storage, but may not silently reduce logical wire or retained-byte caps.

The legitimate maintained queue request `timeout_seconds=2700.0` is directly accepted as a finite `(int,float)` value equal to the fixed limit; bool, strings, nonfinite values and different values are rejected. Formal64 analogously requires exactly its predeclared 5,400 s value. This scalar-domain correction is in the new tool before freezing. No post-measurement AST repair, frozen import mutation, source replacement or evidence rewrite is permitted.

## Primary references

- [Google Benchmark, Reducing Variance](https://github.com/google/benchmark/blob/main/docs/reducing_variance.md): CPU placement, scaling and interference remain relevant even after affinity or a performance policy is requested.
- [Microsoft, Advanced settings configuration in WSL](https://learn.microsoft.com/en-us/windows/wsl/wsl-config): VM processor settings do not establish physical-core ownership; this plan does not change VM topology or shut down WSL.
- [NIST, Autocorrelation](https://itl.nist.gov/div898/handbook/eda/section3/eda35c.htm): the standard lag interpretation uses evenly spaced observations; these old receipt-index diagnostics have unequal physical gaps.
- [NIST, Calculation of the uncertainty of the mean of autocorrelated measurements](https://www.nist.gov/publications/calculation-uncertainty-mean-autocorrelated-measurements?pub_id=151800): serial dependence affects uncertainty; a random label schedule does not establish independent errors.
- [NIST, Chi-Square Test for the Variance](https://www.itl.nist.gov/div898/handbook/eda/section3/eda358.htm) and [critical-value tables](https://www.itl.nist.gov/div898/handbook/eda/section3/eda3674.htm): the variance-pivot calculation and numerical checks used in the conditional planning grid.

No public source above proves the cause of this machine's variation. All new environment and power claims require actual coordinator evidence. N7 production prerequisites remain absent and are unrelated to this measurement plan.
