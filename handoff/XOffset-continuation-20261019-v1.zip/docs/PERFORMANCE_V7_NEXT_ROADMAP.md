# V7之后：减少高频维护和碎片校验

本文件是尚未实施的后续设计，不是V7通过项。V7 Classify与Align的108次固定内部比较均失败，源码和失败保留；不在这批加样本，也不将两者或旧A组合晋升。当前控制仍为V6实际B-only，最终全库/V1/消费与正式五库比较均未因V7重新执行。

旧六项A/A与V4回退已在V5封存研究，本轮只沿用结论的历史范围。后续正式窗口仍须针对当时实际环境、不可变候选、固定预算和资格重新登记；旧六项通过不自动覆盖未来。单一共享租约负责隔开所有重负载，guest亲和与平衡顺序不冒称物理核心独占。

## 优先一：freelist请求身份比较合并

当前每个bucket都比较`cursor.bytes`、`cursor.alignment`和`cursor.head`；进入节点后还维护拒绝区间。固定M计数有230,066次bucket访问及1,054,866次索引维护比较。它们不是全部实际CPU指令，也不是owner查询计数；旧A已经把比较数降到498,233，仍没证实收益，因此这组大数只支持提出不同算法，不能作为速度承诺。

候选做法是把host-only cursor的请求身份改为无损64位key：`(uint64_t(alignment)<<32)|aligned_bytes`。现有guard确保alignment非零、power-of-two且<=`MAX_PAYLOAD=0x7ffffff8`，aligned_bytes也在32位域；两个值均可从key恢复，没有hash碰撞或新内存分配。每次申请在bucket循环外计算一次，原bytes/alignment两项相等性合并为一项，head比较保留。初始key0仍不能与合法请求相同，因为alignment非零。

保留state/epoch同步、head检查、不同请求导致的middle-unlink失效、first-fit顺序和拒绝区间；不能以key替代它们。retire、release、move/swap、回调重入的更新规则逐项对照原实现。只修改host缓存，不加V1字段、不改变wire或公开调用，不归一化不同alignment，不恢复旧A的mask构建/更新。

否决检查包含：完整输入域key单射oracle；交错bytes/alignment相同head的中间删除；相同地址重用、state切换、epoch变化、release/new_handler重入、Core move/swap、异常及OOM；实际编译确认是否已经被优化成同等比较。计数减少而耗时未过门槛，仍否决。尚未编码、编译或执行。

## 优先二：prepared dense的单64位word路径

V6 B已融合prepared单页检查与提交，后续只考虑其中完全落在**一个64位bitmap word**的范围。该word物理8字节，覆盖64个arena字节；不能称为64字节物理word。若同一个精确mask即可完成owned→free检查和无throw提交，可避免通用Span的双边界状态及重复视图工作。

保持owned全局优先、free其次的原错误顺序，精确邻bit、initialized-word门禁、摘要和bbox更新、逻辑hard budget；跨word/page、冷页、growth、sparse及任何准备失败均走现有路径。不得先修改owned再检查free，不把检查移到计时外，不用摘要代替精确membership。

先证明低/高边界、整word、零长度、最高offset、shift64、先前未初始化word、owned/free双冲突、预算临界和OOM事务。实际eligible比例尚未知；不能把V6的209,844次prepared单页提交全算成单word机会。当前没有为它执行新计数或效果实验。只有原机器码/工作量证明具体剩余工作且有足够工程收益预算后才实施；不为找有利符号继续采样。

固定两页stack融合可作为后备设计，但现有fallback数量上界约3,152/212,996次登记，并非均为两页；不能把小分支扩成大规模改造，也不先分配复杂索引。

## owner：两类问题分别处理

owner_from_payload的稳定OwnerRecord/TLS热路径已在V5实现，旧M命中98,303/98,304；本轮runtime_owner_acquisitions为98,304，只是入口数，不能写成98,304次全局锁查找。未经证据，不再把“加缓存”作为新优化。

递归owns-address负责排除祖先/后代与合法byte-storage内对象，不能用同arena、地址先后或类型标签跳过。旧C2可证明的私有迁移点已不付该递归，公共成员赋值又没有安全证明传入路径；该捷径继续否决。后续allocation locator或subtree envelope必须先证明所有嵌套修改、retire/reuse、跨arena、Core move、回调和释放的失效完整性，以及host OOM返回原精确路径；不把尚无soundness方案写成已实现。

## 接续实施与验收顺序

1. 从不可变V6 B-only控制创建新版本目录；每个新候选独立写源身份、删掉的实际工作、完整语义证明和否决条件。V7两个失败不改动，不对其补测。
2. root统筹和唯一执行重负载。freelist代理只写request-key候选/对应oracle；validation代理只写单word候选/精确模型；另一代理独立审查owner失效和结果方法。不同写入边界先冻结，禁止相互覆盖生产头。
3. 新候选独立正常/SAN、恶意输入、错误优先/OOM/别名/回调/生命周期验证。只为未能由现有证据回答的具体问题登记有限机制观察；不引入新的runner/SDK/恢复框架，不做滚动性能试探。
4. 在看新效果前冻结有限内部窗口及完整八阶段、wire、CPU/fault、进程RSS和独立scratch成本。用已封存方差评估精度：V7修改log SD约0.139–0.172，原36配对预算不适合声称1%级收益；不能事后扩样本。没有足够收益或测量条件时据实否决。
5. 只有独立效果合格者才组成最终候选；未测组合不冒称收益相加。最终组合一次完成全库normal/SAN、原业务九阶段真值、恶意输入、V1旧控制双向、安装/子工程消费。完整校验和V1始终是门槛。
6. 然后在新目录冻结并执行一次资格与单窗口五库正式比较。沿用既定同模型/输入/trace/八边界，读与修改各竞品上界<=1，输出与总量上界<=0.8的工程目标；初载、重载、退休、清理、wire及内存另列。具体宏周期/精度/磁盘/总时长需在执行前完整登记，不能从观察胜率倒推。目标仍是全部竞品，当前没有达到或保证未来可达。

原生Windows P2996与N7业务入口继续开放；不要求用户搬文件、配置工具或运行命令。不提交、推送、合并、发布或触发远端CI；未调用Superpowers。
