# v4 批量赋值接口与保证

`XFixedVector<T>::assign_range(std::span<const T>)` 可经 `XVector<T>` 调用，用于以连续的现存元素替换全部内容。既有 `resize`、赋值及 wire 布局保持兼容；这是开发候选新增 API，并未成为已发布版本。

```cpp
std::vector<std::uint32_t> values{1, 2, 3};
record.samples.assign_range(std::span<const std::uint32_t>(values));
```

`T` 必须非 const/volatile，且满足 `is_trivially_copyable_v`、`is_trivially_destructible_v`、`is_trivially_copy_constructible_v`。这些约束用于直接复制的对象生命周期安全；不能只凭可平凡赋值判定准入。非平凡元素继续使用既有 API。

| 情形 | 行为 |
| --- | --- |
| 空源 | 清空 size，保留绑定、存储和 capacity |
| 元素数不超过 capacity | `memmove` 复制，更新 size，保留 capacity |
| 元素数超过 capacity | 申请新块，准备 rel32，完整复制源，提交新描述符，退休旧块；新 capacity 等于元素数 |
| 超出可表示元素数 | 在修改目标前拒绝 |
| 新块申请或 rel32 准备失败 | 保留原目标；已申请的新块按原分配器路径释放 |

源可以是完整自身、合法自身子 span、同 arena 的其他 live 元素或外部元素。源须在复制完成前保持有效。直接观察私有 allocator 控制字节的视图不属于此保证，因为分配动作本身会修改这些字节。此限制不影响普通 live 对象的别名支持。

增长路径直接构造最终元素内容，避免先初始化全部元素再覆盖；不会调用元素的默认构造回调。既有默认 `resize` 仍对新增后缀执行其承诺的 value initialization。标量 `resize` 只有在原块确实位于物理尾部时才尝试原位扩展，VM 失败继续抛出；不通过另一次申请重试隐藏失败。

实现保持 V1 容器布局与完整 typed-load 校验。没有新增跨用户回调的裸 owner 缓存。计数版用于验证实际工作量，正式速度比较使用裸 Release 二进制。

固定共同业务的 XOffset 接入调用该 API；cista 接入同时改用其已有 `set(begin,end)`，其他库保留合法批量/Builder 路径。旧新比较包括库实现与接入方式的共同变化，不能归因于单一头文件改动。完整验收见同目录 `PERFORMANCE_V4_RESULTS.md`。
