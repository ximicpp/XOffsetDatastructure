# XOffset 新机器接续记录

日期：2026-10-16（Asia/Shanghai）。本文件记录从公开交接提交开始的新工作，不修改既有研究结论。

## 源码与环境

在原本无提交、无文件的工程中获取 `codex/vm-handoff-20261016`，确认远端分支为 `7539433ab96d69c4a07b1db5c0a13786da85cdcd`，创建本地接续分支 `codex/windows-continuation-20261016`。首次只读完整性检查通过：690 文件、24,533,185 字节。没有用旧 `next_cpp26` HEAD 替换源码。

本机 Windows 11 Enterprise x64（10.0.26200）、Intel i9-13900K（24 核/32 线程）、约 127.7 GiB RAM。已安装 VS Community 2022 17.14.42、MSVC 14.44、Windows SDK、Python 3.11.7 与 CMake 3.28.1。实际生效的工具与参数以每次执行证据为准。

WSL2 Ubuntu 22.04 为 x86_64 本地 VM，内核 `6.6.87.2-microsoft-standard-WSL2`；不作为独立原生 Linux 设备或 Windows 完整库证据。现有 P2996 工具链因宿主 glibc/libstdc++ 过旧无法直接启动；新兼容环境解包到项目 `build/toolchains/linux-current-20261016/`，不替换系统库。实际 compiler revision 为 `9ffb96e3ce362289008e14ad2a79a249f58aa90a`，与历史固定 profile 区分，匹配 libc++ 和 sanitizer 分别验证。

生产 F 双头仍按交接身份保留，未采用新的生产优化。依赖按两个 gitlinks 获取，不升级分支，不修改内容锁。没有提交、推送、合并、发布或触发远端 CI。

## 阶段与当前结果

| 项目 | 当前状态 | 新证据/边界 |
| --- | --- | --- |
| A0 交接恢复 | 完成 | 初始 manifest 690 文件通过；D034 已验收范围继续保留 |
| A1 Windows storage/package | 完成并独立验收 | [Windows 结果](VM_WINDOWS_CURRENT_RESULTS.md)；storage 2、installed 3、subproject 3；9 项工具检查 |
| A2 WSL 平台与 sanitizer | 完成并独立验收（来源限制明确） | [Linux 结果](VM_LINUX_CURRENT_RESULTS.md)；full 48、storage 2、两种 package 各 3+3；网络 ASan/UBSan 34 组/182 子例 |
| B1 N3 源码、功能与有界 A/A | 执行完成，噪声资格未通过 | [N3 结果](VM_N3_CURRENT_RESULTS.md)；ABI 独立推导及小探针通过，D/F 6 个等工作量功能进程通过；唯一 F/F 窗口 78/78 成功，但 4 项指标均未达到事前门槛 |
| B2 N3 D/F 与因果归因 | 前提未满足，未执行 | A/A 的 12 个局部资格和 4 个跨锚点漂移资格均失败；未建立 2% 检出资格，不重试或追加样本 |
| C1 N7 生产前提契约 | 文档完成，生产前提未满足 | [新前提契约](coordination/vm-continuation-20261016/N7-prerequisites.md)；用户本轮答复“暂不具备” |
| D1 独立复核与验收 | 本轮限定范围完成 | 平台审计及 N3 独立统计复算通过；总体路线图的未满足前提继续开放 |

## 执行协调

[新任务与写入所有权](coordination/vm-continuation-20261016/plan.json) 将 Windows、Linux 环境、N7/N3 工具分交不同代理；共享生产头和 CMake 仅由统筹持有，本轮尚无修改必要。

现有 POSIX 队列已在当前 WSL 通过 17 项真实子进程自测，覆盖稳定锁、互斥、客户端中断、超时与会话清理、篡改拒绝及离线审计。自测使用隔离测试锁，没有使用正式测量锁。结果在 `build/vm-continuation-20261016/queue-selftest-v1/test-results.json`，runner SHA-256 `6f155fcb1f17d6a01d68c4c9393bc636bf4af82bafdc830ba8dc8b759ea1d909`。WSL 的 POSIX 锁不能约束 Windows 侧构建，正式窗口前由统筹另外确认所有重负载停止。

保留所有已执行失败与诊断；新目录中的环境修复不得回写旧历史档案。初始交接清单固定不变，后续合法开发差异另记新身份，不重写初始 manifest。

N3 正式窗口仅执行一次，UTC 07:36:45.959 至 07:41:02.330（本地 15:36:45.959 至 15:41:02.330），6 个预热加 72 个计量进程，全部使用同一 F 二进制。窗口内未并行编译、重测试或归档；队列结束后无存活子进程。独立统计复算与原汇总逐值一致；[完整离线审计与独立复核的范围](VM_N3_CURRENT_RESULTS.md) 分别列出。宿主采用 Balanced 电源计划且存在后台活动，本轮没有因果归因这些活动。噪声资格未通过，因此没有执行 D/F 性能比较、消融或生产优化。

## 本机新增支持矩阵

| 环境/入口 | 实际结果 | 可接受范围 |
| --- | --- | --- |
| Windows x64 MSVC 19.44 / SDK 10.0.26100 | storage 2/2，installed 3/3，subproject 3/3 | C++17 OS storage/pool 及静态消费闭包；135 文件当前快照 |
| Windows 当前 MSVC full capability | 原反射 probe 编译阶段 C1083 缺 `experimental/meta`；未到链接 | 本机已查工具不能满足完整 P2996 前提；不外推所有 Windows 工具链 |
| WSL2 Ubuntu 22.04 x86_64 GCC | storage 2/2，storage installed 3/3、subproject 3/3 | 本地 VM 功能结果 |
| WSL2 P2996 9ffb96e3，初次可运行私有 glibc profile | full 48/48 CTest，38 程序+7 子进程+3 tooling；另 3 项 configure 检查 | 当前 F 的该实际构建；与后续完善的 linker profile 分列 |
| WSL2 同编译器，complete-v2 私有 glibc 链接 profile | full installed 3/3、subproject 3/3 | 新 profile 的重定位安装、多翻译单元消费 |
| WSL2 complete-v2 + compiler-rt 21.1.8 | 网络 reference 34 组/182 子例；ASan UAF、UBSan overflow 负控识别；v8 guard 保留 | 同步 TCP/注入模型/文件系统覆盖。运行后扩充的身份审计另列，不追写为原运行的全部事前/事后检查 |
| WSL2 N3 timing | 唯一 F/F 窗口 78/78 执行成功；4/4 指标噪声/漂移资格失败 | 本地 VM 不确定性能证据；D/F、归因和独立物理设备前提未关闭 |

新网络 sanitizer 的成功解决的是本机该同步参考及模型的兼容运行缺口；它不证明生产异步 transport、Windows 原生网络或其他 sanitizer 组合。TSan、历史 wire 矩阵未因此重跑。

## 最终核对与证据入口

[本轮验收记录](coordination/vm-continuation-20261016/final-acceptance.json) 固定报告、独立 review 和新增文件清单身份。相对初始交接，原有 690 文件中 687 个保持原字节，3 个变更仅涉及 `HANDOFF.md`、迁移说明和任务清单；没有缺失文件。[差异记录](coordination/vm-continuation-20261016/source-delta.json) 分列原身份与现身份，初始 manifest 保持不变。两项依赖 gitlinks 与内容锁保持固定，已初始化依赖没有工作区或暂存差异。

[新增文件清单](coordination/vm-continuation-20261016/new-files-manifest.json) 覆盖本轮非忽略的新工具、测试、小型证据与说明。完整工具链、依赖、编译产物和大型 wire 留在本机忽略的 `build/`，小证据包据实记录原位置、身份和可独立审计的边界；它不是完整离线运行环境。原有失败及新平台失败分别保留。最终检查包括小型证据 manifest、报告链接与 `git diff --check`，没有再启动原生程序或性能样本。

## 未关闭的总体要求

Windows 完整 P2996 支持、独立原生 Linux 性能设备、N3 默认路径稳定 D/F 复现与归因、N7 真实生产消费者继续开放，不能由 storage、反射 compile/link 或同步参考模型代替。本机同步参考及注入模型的兼容网络 sanitizer 运行缺口已按上述限定范围补齐。N7 业务资料本轮仍不可用，保持 `prerequisite_unmet_retain_F`，不再反复询问。
