# 加载与修改优化实施计划

2026-10-17。用户已授权实现、验证并在门禁通过后执行一轮新的五库正式窗口；不提交、推送、发布、合并或触发远端 CI。Superpowers 不启用。

基线为 `xoffset-verified-range-index-v1`，生产双头内容 SHA256 `412e1fa3c1c59c874645f12714f761daa762ec2a7302b81cb9689b5fb63f4b4c`。旧源码、alpha 包、失败窗口及本轮前的归因报告保持原字节。新候选名为 `xoffset-load-mutate-optimization-v1`；基点提交只表示来源，不冒充新候选已提交。

可编辑工程：`C:/Users/gzsufanchen/.codex/worktrees/load-mutate-optimization-v1/xoffsetdatastructure开发`。Linux 构建、运行及结果根目录：`/root/xoffset-load-mutate-optimization/20261017/v1`。协调及执行状态：[plan.json](coordination/load-mutate-optimization-20261017/plan.json)。

1. **O1：消除区间索引重复查找。** 返回 overlap 检查产生的 lower_bound iterator，使用 emplace_hint。保留原三参 helper、两棵树、地址/长度/溢出检查、owned 优先错误次序、登记后才访问子对象。复用独立 pairwise oracle 和真实 host 分配失败注入，新增 hint 位置、冲突优先级与边界测试。计数版证明相同区间数下 key 比较减少。

2. **O2：缓存已经证明不适用的空闲链表前缀。** 在 Core 的非序列化运行时状态中，以 allocator state 身份、epoch、桶、请求字节及对齐标识已拒绝区间，重复同型请求跳过该区间。新退休节点仍按原 LIFO 接入并先检查，仍选择原 first-fit 块；换型访问、reset/release、Core move/swap/load 等必须失效或同步。使用固定空间，不修改 V1 状态大小、桶编号、空闲块格式、分配策略或失败保证。其效果针对重复请求，不宣称通用对数复杂度。额外 registry 查询和维护成本纳入结果。

   首次 native 执行前冻结确定性 24/32B 混合规则、N=512/1024/2048/4096、包含持续同桶退休的序列、查找加索引建立访问数 ≤8N+1024，以及维护操作上界。逐次选中 offset、free_bytes、epoch、最终 wire/canonical 与独立无缓存 first-fit 模型一致。覆盖不同尺寸/对齐借用较大桶、中间节点摘除、身份/epoch 变化、重载、释放和失败路径。

3. **O1/O2 阶段验收后实施 O3：同 arena 移动转移资源。** 仅对双方已绑定、真实 owner/allocator state 相同且 descriptor 在 arena 内的安全情况转移字符串/向量资源，按新地址重算 rel32，清空源，旧目的资源仅释放一次。自移动、跨 arena、不同 state、未绑定及祖先/后代关系走保留的语义路径。不得 memcpy 相对指针对象，不无条件开放已删除的 move constructor。验证嵌套压缩、reload 后再修改、异常路径和既有容器行为。

4. **集成与 V1 门禁。** 三代理只写各自补丁/测试和新审查文件，主会话按 O1→O2→O3 集成到新候选；独立阶段源码与失败构建留存。完整 normal 与兼容 ASan/UBSan/LSan、真实 sanitizer 正控、原区间拒绝/分配器故障测试、新用例及五库 S/M/L 全部通过。额外执行旧 writer→新 reader、新 writer→旧 reader，包括修改后产物；确认 schema/layout/V1 字段未变。计数诊断与计时分离，包含实际 owner 查询、缓存维护和分配入口，不能仅隐藏原链表循环。

5. **冻结及唯一正式窗口。** 新源码、候选身份、五个二进制、实际编译依赖、固定第三方版本、工具链/runtime、fixture、协议、计划及授权全部绑定。独立审查后，用正式 copy_bundle 复制最终冻结包并运行五库 describe，核对 0755、内容和 runtime 不变。所有子代理停止重负载，主会话作为唯一测量执行者，经原稳定 W3 队列执行新目录的一轮窗口。

   继承现有协议：同一虚拟 CPU 2、285 子进程上限、20 秒/child、45 分钟、16 GiB 新 wire；15 warmup、三组 A/A、30 个比较 block。A/A 比值和顺序中位数 0.98–1.02、scaled log-MAD≤ln(1.02)、漂移≤1.02。不得放宽门槛、临时调整样本或失败后重试。任一库不合格即停整格，保留原始观察但不给正式速度排名。

6. **独立审计及交付。** 在运行前后分别记录外部冻结 pin 和双清单复合 pin，离线 audit/report；审查只读旧证据与新结果，最后核对原生产头、旧候选与既有档案身份未变。最终交付实现位置、各阶段测试和兼容结果、操作计数变化、正式窗口资格及可支持的性能结论、开放限制。

本轮不同时实施 node arena/pool、assign/range API、wire compact 或跳过校验入口，以免混入无关变化。任何优化必须保持现有合法输入范围和校验拒绝能力；不能通过缩窄功能、把工作挪到计时外或改 V1 语义获得表面性能。
