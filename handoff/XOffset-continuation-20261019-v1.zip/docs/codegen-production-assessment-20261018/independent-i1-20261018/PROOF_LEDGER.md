# I1 事前证明台账

本文件在首次生成/编译之前登记。必要目标和 216 个参数组合保持原提案；程序输出 pass 仅表示该固定夹具的局部规则与运行一致，不能覆盖表内尚未闭合的责任。具体 ID 在租约内冻结到 `control/cases-frozen.json`，首次编译前保存 source snapshot。

| 责任 | 路径与规则 | 未闭合责任/执行门 |
|---|---|---|
| A 完整声明 | 同一新 JSON IR 产生声明、字段/数组 leaf 清单、外部 aggregate 初始化和 compiler offsetof 表达式；独立生成负控检查源漂移和遗漏 | 这不是任意已有 C++ 类的 AST 导入。PrivateClosed 无合法 offsetof/构造适配，不能宣称其完整可消费 metadata 已实现 |
| A 构造 | 完整 record 的 placement new + 嵌套 aggregate initializer；Head prvalue 直接初始化非重叠最终子对象，构造时从真实 backing array 定位 this | 关闭可选 elision；潜在重叠 Head 不适用强制 elision，不执行这一未证明路径 |
| B 恢复 | Input 引用独立、存活且不变的 byte-array；每个 HeadInput 先检查 offset、size/capacity，再从输入恢复，目标初始化不覆写输入；没有 sizeof(record) 临时副本 | 不代表完整 V1 graph 校验器。初始 scalar fixture 与容量限定为本 I1 小切片 |
| C fresh/reuse | memcpy 在完整槽位区域隐式建立所需 implicit-lifetime enclosing array；non-implicit Head 不因此存活，逐元素完整 placement new 开始其生命周期；destroy prefix 逆序；从新 placement 返回的首元素指针寻址 | 依据 C++20 intro.object/10、cstring.syn/3、intro.object/2。空 capacity 不建立活 Head。原地尾扩需要更大数组以及原有活元素的共同依据，当前没有闭合，不执行。局部 erase/reconstruction 不证明通用 erase/不分配 relocation |
| D 所有权 | 同 allocator 不抛阶段重绑定 payload，所有完整头建立后 relinquish 源；跨 owner/不同 allocator 先深拷贝；self 身份检查先于更改 | 预先 reserve 的 trace/allocator 元数据不得在不抛提交段申请。ancestor/descendant 真实嵌套事务未证明，不执行。可复用源和完整 allocator 回退语义仍未闭合 |
| E 异常 | aggregate 部分初始化由语言逆序清理已完成子对象；未完成 Head 不调用析构；完整 root 用显式 guard；六个真实路径故障点；重试 | 计数与实际 payload live block 必须一致；故障未触发算失败。测试中 host trace reserve 是夹具前提，不能推广成产品无 host OOM |
| F 表示 | 非 const 非 volatile 非重叠活 scalar 可 memcpy 恢复/观察表示，float 不经值算术；bool 先原始 byte 校验；const 整数经合法初始化；无名 enum 不额外拒绝 | const float、volatile 表示、无协作私有类、潜在重叠非平凡成员仍开放。类型在旧 trait 为真不等于旧全部 API 已合法；oracle 只分类，不运行已知未证明的旧恢复 |
| G 地址 | signed rel32 与乘法先作有界整数检查；typed/byte 地址从仍活着的整个 backing byte-array 派生；不做 int32 字段 char* 越对象加法 | uintptr_t 仅用于当前注册 owner 的实际地址识别，再回到原 byte-array 基址。OS mmap + placement byte-array 的 storage 契约需要实现级依据；运行成功不能补齐，VM 路径保留 unproven |
| H 发布 | 最小头 magic/Head size-cap/range 检查在任何非平凡构造之前；完整 root 及发布资源准备成功后才提供 root/modify/save 能力；失败 staging RAII 回收 | 保存只是小夹具受控 byte 导出，未实现真实 verified V1 writer；H 只能观察能力隔离，不可宣称完整 verified 保存协议通过 |

所有局部 source/destination 都是新夹具。普通消费者不 include 或链接 V5/TypeLayout；P2996 只存在于分离的 oracle 可执行文件。

规范依据（本轮重新读取）：[C++20 对象与隐式创建](https://timsong-cpp.github.io/cppwp/n4861/intro.object)、[生命周期及透明替换](https://timsong-cpp.github.io/cppwp/n4861/basic.life)、[对象表示复制](https://timsong-cpp.github.io/cppwp/n4861/basic.types)、[memcpy/memmove 创建规则](https://timsong-cpp.github.io/cppwp/n4861/cstring.syn)。这些规则限制路径；ASan/UBSan 不证明这些规则。

第一次执行后若存在 fail，先读具体输出和 source snapshot，再决定修复。若只是运行一致但静态责任未闭合，保留 unproven；不得把未执行路径伪装成 expected rejection 或 pass，也不得据此进入 I2。
