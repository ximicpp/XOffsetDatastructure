"""Produce a bounded evidence inventory; this is not another platform test."""
import hashlib
import json
import pathlib
import re

ROOT=pathlib.Path(__file__).resolve().parents[1]
def read(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def audit():
    ledger=read(ROOT/'control/actual-budget.json')
    cases=read(ROOT/'control/cases-frozen.json')
    outputs={};diagnostics=[];oracle={};layouts={};generator=[]
    for job in ledger['jobs']:
        if job['kind']!='test':continue
        text=(ROOT/job['directory']/'stdout.txt').read_text()
        rows=[]
        for line in text.splitlines():
            if line.startswith('{'):rows.append(json.loads(line))
            if line.startswith('LAYOUT\t'):
                _,name,size,align,signature=line.split('\t');layouts[name]={'size':int(size),'align':int(align),'signature':signature}
        if job['label']=='diagnostic-forms':
            assert len(rows)==12
            assert all(x['threw']==1 and x['constructed']==1 and x['destroyed']==0 for x in rows)
            diagnostics=rows
        elif job['label'].startswith('generator-control'):
            assert len(rows)==12 and all(x['status']=='pass' for x in rows);generator+=rows
        elif job['label']=='oracle-observations':
            for line in text.splitlines():
                name,byte,wire,size,align,signature=line.split('\t')
                oracle[name]={'public_byte_copy':bool(int(byte)),'v1_admitted':bool(int(wire)),'size':int(size),'align':int(align),'signature':signature}
            assert len(oracle)==8
        else:
            profile='san' if job['label'].startswith('san-') else 'ordinary'
            assert len(rows)==job['case_charge']
            for row in rows:outputs[(profile,row['case'])]=row
    matrix=[];totals={}
    for profile in ['ordinary','san']:
        totals[profile]={}
        for registered in cases:
            result=outputs.get((profile,registered['id']),{'case':registered['id'],'status':'not-attempted-after-veto','reason':'E-08..E-15-hard-failure;dependent-work-stopped'})
            matrix.append({'profile':profile,'parameters':registered['parameters'],**result})
            status=result['status'];totals[profile][status]=totals[profile].get(status,0)+1
    failures={profile:[row['case'] for row in matrix if row['profile']==profile and row['status']=='fail'] for profile in ['ordinary','san']}
    assert failures['ordinary']==failures['san']==[f'E-{i:02d}' for i in range(8,16)]
    comparisons={}
    for name,new in layouts.items():
        old=oracle[name]
        assert new['size']==old['size'] and new['align']==old['align']
        if old['v1_admitted']:
            assert new['signature']==old['signature'];status='full-signature-equal'
        else:status='old-negative-control;no-wire-signature-comparison'
        comparisons[name]={'status':status,'candidate':new,'oracle':old}
    assert sum(x['status']=='full-signature-equal' for x in comparisons.values())==5
    dependencies={};closure_equal={}
    for profile in ['ordinary','san','oracle']:
        deptext=(ROOT/'build'/f'{profile}.d').read_text().replace('\\\n',' ').replace('\\\r\n',' ')
        # This workspace has no spaces in POSIX paths; fail rather than guess an escaped path.
        tokens=deptext.split(':',1)[1].split()
        paths=[pathlib.Path(token) for token in tokens]
        assert all(path.is_file() for path in paths)
        dependencies[profile]=[{'path':str(path),'sha256':sha(path)} for path in paths]
        if profile!='oracle':
            assert len(paths)==3 and all('snapshot-initial' in str(p) for p in paths)
            assert all('typelayout' not in str(p).lower() and 'performance-v5' not in str(p).lower() for p in paths)
        changed=[]
        for path in paths:
            if 'snapshot-initial' not in str(path):continue
            relative=path.relative_to(ROOT/'control/snapshot-initial')
            if not (ROOT/relative).is_file() or sha(path)!=sha(ROOT/relative):changed.append(str(relative))
        closure_equal[profile]={'current_relevant_sources_equal_executed_snapshot':not changed,'changed':changed}
        assert not changed
    receipts={}
    for name in ['lease-initial','lease-diagnostic','lease-confirm']:
        receipt=read(ROOT/name/'result.json')
        assert not any(receipt['cleanup'].get(key) for key in ['live','process_groups','zombies'])
        receipts[name]=receipt
    identities={}
    for name in ['ordinary','san','oracle']:
        identity=read(ROOT/'build'/f'{name}-identity.json')
        assert sha(ROOT/'build'/name)==identity['binary_sha256'];identities[name]=identity
    diagnosis=read(ROOT/'control/diagnostic-identity.json')
    assert sha(ROOT/'src/diagnostic_forms.cpp')==diagnosis['source_sha256']
    assert sha(ROOT/'build/diagnostic-forms')==diagnosis['binary_sha256']
    write(ROOT/'control/case-results.json',matrix)
    lineage_bytes=sum(p.stat().st_size for p in ROOT.parent.rglob('*') if p.is_file())
    assert lineage_bytes<=512*1024*1024
    result={'verdict':'I1_NO_GO_SELECTED_CONSTRUCTION_ROUTE_ON_GCC_11_4','phase_passed':False,
            'reason':'completed subobjects not destroyed after second-element construction/allocation failure',
            'failing_cases':failures,'candidate_case_counts':totals,'generator_negative_controls':generator,
            'minimal_reduction':diagnostics,'oracle':oracle,'comparisons':comparisons,
            'dependency_closures':dependencies,'source_closure':closure_equal,'binary_identities':identities,
            'receipts':receipts,'native_windows_executed':False,'full_v1_bidirectional_compatibility_executed':False,
            'sanitizer_additional_diagnostics':False,'all_216_cases_completed':False,
            'implementation_source_reused':False,'I2_admitted':False,
            'assessment_lineage_disk_bytes':lineage_bytes,
            'budget_at_audit_start':ledger['stage'],
            'cumulative_at_audit_start':{name:ledger['stage'][name]+ledger['historical'][name] for name in ['compiles','processes','cases','active_seconds']}}
    write(ROOT/'result.json',result)
    inventory={str(p.relative_to(ROOT)):sha(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and '/lease-' not in str(p) and p.name not in ['evidence-inventory.json','actual-budget.json','result.json']}
    write(ROOT/'control/evidence-inventory.json',inventory)
    print(json.dumps({'verdict':result['verdict'],'counts':totals,'comparisons':len(comparisons),'budget':ledger['stage']}))

if __name__=='__main__':audit()
