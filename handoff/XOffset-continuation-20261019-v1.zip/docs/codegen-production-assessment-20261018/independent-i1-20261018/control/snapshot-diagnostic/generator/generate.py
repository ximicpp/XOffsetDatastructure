"""Independent I1 schema emitter. No import of any existing implementation."""
import copy
import hashlib
import json
import pathlib
import re
import sys

SCALARS = {"u32": "std::uint32_t", "u16": "std::uint16_t", "bool": "bool", "head": "Head"}

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def validate(ir):
    if set(ir) != {"version", "profile", "records", "test_layouts", "oracle_shapes"}:
        raise ValueError("schema keys")
    if ir["version"] != 1 or ir["profile"] != "wsl-x86_64-le64":
        raise ValueError("profile/version")
    names = [r["name"] for r in ir["records"]]
    if len(set(names)) != len(names):
        raise ValueError("duplicate record")
    def node(t, trail):
        if isinstance(t, str):
            if t in SCALARS:
                return
            if t in names:
                if t in trail:
                    raise ValueError("by-value recursion")
                rec = ir["records"][names.index(t)]
                for _, sub in rec["fields"]:
                    node(sub, trail + [t])
                return
            raise ValueError("unknown node")
        if not isinstance(t, dict):
            raise ValueError("node")
        if set(t) == {"array", "of"}:
            if not t["array"] or any(type(n) is not int or not 0 < n <= 8 for n in t["array"]):
                raise ValueError("array bounds")
            node(t["of"], trail)
        elif set(t) == {"const"}:
            node(t["const"], trail)
        elif set(t) == {"sequence"}:
            node(t["sequence"], trail)
        else:
            raise ValueError("unknown node keys")
    for r in ir["records"]:
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", r["name"]):
            raise ValueError("identifier")
        if r["kind"] not in {"aggregate", "allocator", "private_closed", "custom_dtor"}:
            raise ValueError("record kind")
        fields = [f[0] for f in r["fields"]]
        if len(set(fields)) != len(fields):
            raise ValueError("duplicate field")
        for name, t in r["fields"]:
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", name):
                raise ValueError("field identifier")
            node(t, [r["name"]])
    if any(n not in names for n in ir["test_layouts"] + ir["oracle_shapes"]):
        raise ValueError("shape reference")

def ctype(t):
    if isinstance(t, str):
        return SCALARS.get(t, t)
    if "const" in t:
        return "const " + ctype(t["const"])
    if "sequence" in t:
        return "SequenceHeader<" + type_expr(t["sequence"]) + ">"
    return ctype(t["of"])

def type_expr(t):
    if isinstance(t, dict) and "array" in t:
        return ctype(t["of"]) + "".join("[" + str(n) + "]" for n in t["array"])
    return ctype(t)

def declaration(name, t):
    suffix = "".join("[" + str(n) + "]" for n in t["array"]) if isinstance(t, dict) and "array" in t else ""
    return ctype(t) + " " + name + suffix + ";"

def initializer(t, expression, borrow=False):
    if isinstance(t, dict) and "array" in t:
        def expand(dims, prefix):
            if not dims:
                return initializer(t["of"], prefix, borrow)
            return "{" + ",".join(expand(dims[1:], prefix + "[" + str(i) + "]") for i in range(dims[0])) + "}"
        return expand(t["array"], expression)
    offset = "offsetof(T," + expression + ")"
    if t == "head":
        if borrow:
            return "Head(borrow_input(owner,input,offset+" + offset + "))"
        return "Head(HeadInput{input,offset+" + offset + "})"
    if isinstance(t, dict) and "sequence" in t:
        return "{}"  # Sequence data operations are a separate proof obligation.
    return "input.scalar<" + ctype(t).replace("const ", "") + ">(offset+" + offset + ")"

def leaf_paths(t, path):
    if isinstance(t, dict) and "array" in t:
        paths = [path]
        for n in t["array"]:
            paths = [p + "[" + str(i) + "]" for p in paths for i in range(n)]
        return [q for p in paths for q in leaf_paths(t["of"], p)]
    return [(path, t)]

def emit(ir):
    validate(ir)
    out = ["// Generated solely from this directory's independent I1 IR.", "#pragma once", "namespace i1 {"]
    for rec in ir["records"]:
        name, kind = rec["name"], rec["kind"]
        fields = " ".join(declaration(n, t) for n, t in rec["fields"])
        if kind == "private_closed":
            out += [f"class {name} {{ {fields} public: explicit {name}(int) : value(7) {{}} {name}(const {name}&)=delete; ~{name}() {{}} std::uint32_t get() const {{return value;}} }};"]
        elif kind == "allocator":
            out += [f"struct {name} {{ {fields} {name}()=delete; explicit {name}(AdapterAllocator a):value(a.value) {{}} }};"]
        elif kind == "custom_dtor":
            out += [f"struct {name} {{ {fields} ~{name}() {{ ++custom_destructions; }} }};"]
        else:
            out += [f"struct {name} {{ {fields} }};"]
    out += ["#ifndef I1_ORACLE", "template<class T> struct Ops;"]
    for rec in ir["records"]:
        name, kind = rec["name"], rec["kind"]
        if kind == "private_closed":
            continue
        leaves = [(path, t) for f, t in rec["fields"] for path, t in leaf_paths(t, f)]
        out += [f"template<> struct Ops<{name}> {{ using T={name};", "static T* restore(void* p,const Input& input,std::size_t offset) {"]
        if kind == "allocator":
            out += ["return ::new(p) T(AdapterAllocator{input.scalar<std::uint32_t>(offset)});"]
        else:
            expr = ",".join(initializer(t, f) for f, t in rec["fields"])
            out += ["return ::new(p) T{" + expr + "};"]
        out += ["}"]
        if kind in {"aggregate", "custom_dtor"}:
            expr = ",".join(initializer(t, f, True) for f, t in rec["fields"])
            out += ["static T* borrow(void* p,const Input& input,std::size_t offset,Arena& owner) {return ::new(p) T{" + expr + "};}"]
        out += ["static std::vector<std::size_t> head_offsets() { return {" + ",".join("offsetof(T," + p + ")" for p, t in leaves if t == "head") + "}; }",
                "static std::vector<Head*> heads(T& value) { return {" + ",".join("&value." + p for p, t in leaves if t == "head") + "}; }",
                "static std::vector<Field> fields() { return {" + ",".join("Field{\"" + f + "\",offsetof(T," + f + "),sizeof((static_cast<T*>(nullptr))->" + f + ")}" for f, _ in rec["fields"]) + "}; }",
                "static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));"]
        for i, (f, t) in enumerate(rec["fields"]):
            out += ["s += std::string(\"" + ("," if i else "") + "@\")+std::to_string(offsetof(T," + f + "))+\":\"+wire_type<decltype(T::" + f + ")>();"]
        out += ["return s+\"}\"; }", "};"]
    out += ["#endif", "}"]
    header = ("\n".join(out) + "\n").encode()
    listing = {r["name"]: {"kind": r["kind"], "fields": r["fields"], "leaves": [[p, t] for f, t in r["fields"] for p, t in leaf_paths(t, f)]} for r in ir["records"]}
    manifest = {"profile": ir["profile"], "ir_sha256": digest(canonical(ir)), "emitter_sha256": digest(pathlib.Path(__file__).read_bytes()), "outputs": {"types.hpp": digest(header)}, "declarations": listing}
    return {"types.hpp": header, "metadata.json": canonical(manifest) + b"\n"}

def check(ir, files):
    expected = emit(ir)
    if set(expected) != set(files) or any(expected[k] != files[k] for k in expected):
        raise ValueError("stale/incomplete/tampered artifact or provenance")

def control(ir):
    baseline = emit(ir)
    check(ir, baseline)
    if emit(ir) != baseline:
        raise AssertionError("nondeterministic")
    variants = []
    # Each negative is preceded by acceptance of the unchanged positive input.
    stale = copy.deepcopy(ir); stale["records"][0]["fields"][0][0] = "revised_stamp"
    variants.append(("stale", stale, baseline))
    pad = copy.deepcopy(ir); pad["records"][0]["fields"].insert(2, ["padding_flag", "bool"])
    variants.append(("padding_bool", pad, baseline))
    nested = dict(baseline); meta = json.loads(nested["metadata.json"]); meta["declarations"]["Nested"]["leaves"].pop(); nested["metadata.json"] = canonical(meta)
    variants.append(("nested_owning_missing", ir, nested))
    tamper = dict(baseline); tamper["types.hpp"] = tamper["types.hpp"].replace(b"stamp", b"stamp_tampered", 1)
    variants.append(("member_tamper", ir, tamper))
    order = copy.deepcopy(ir); order["records"][0]["fields"].reverse()
    variants.append(("declaration_order", order, baseline))
    missing = dict(baseline); del missing["metadata.json"]
    variants.append(("missing_output", ir, missing))
    for label, edit in [
        ("profile", lambda x: x.update(profile="other")),
        ("unknown_type", lambda x: x["records"][0]["fields"].append(["bad", "opaque"])),
        ("duplicate_field", lambda x: x["records"][0]["fields"].append(["stamp", "u32"])),
        ("zero_array", lambda x: x["records"][0]["fields"].append(["bad", {"array":[0],"of":"u32"}])),
        ("recursive", lambda x: x["records"][0]["fields"].append(["bad", "Mixed"]))]:
        edited = copy.deepcopy(ir); edit(edited); variants.append((label, edited, baseline))
    identity = dict(baseline); meta = json.loads(identity["metadata.json"]); meta["emitter_sha256"] = "0"*64; identity["metadata.json"] = canonical(meta)
    variants.append(("source_identity", ir, identity))
    for label, source, outputs in variants:
        check(ir, baseline)
        try:
            check(source, outputs)
        except ValueError:
            print(json.dumps({"case":"GEN-"+label,"status":"pass"}))
        else:
            raise AssertionError("negative accepted: " + label)
    assert len(variants) == 12

if __name__ == "__main__":
    mode, schema = sys.argv[1:3]
    ir = json.loads(pathlib.Path(schema).read_text())
    if mode == "control":
        control(ir)
    elif mode == "emit":
        dest = pathlib.Path(sys.argv[3]); dest.mkdir(parents=True, exist_ok=False)
        for name, data in emit(ir).items():
            (dest/name).write_bytes(data)
    else:
        raise SystemExit("unknown mode")
