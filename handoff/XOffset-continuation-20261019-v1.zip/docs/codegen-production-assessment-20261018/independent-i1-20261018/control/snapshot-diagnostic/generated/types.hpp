// Generated solely from this directory's independent I1 IR.
#pragma once
namespace i1 {
struct Mixed { std::uint32_t stamp; bool enabled; std::uint16_t grid[2][3]; };
struct Pair { std::uint32_t stamp; Head left; Head right; };
struct Direct { Head items[2]; };
struct Nested { Head items[2][2]; };
struct Sequence { SequenceHeader<Head[2]> values; };
struct AllocatorOnly { std::uint32_t value; AllocatorOnly()=delete; explicit AllocatorOnly(AdapterAllocator a):value(a.value) {} };
struct ConstScalar { const std::uint32_t value; };
class PrivateClosed { std::uint32_t value; public: explicit PrivateClosed(int) : value(7) {} PrivateClosed(const PrivateClosed&)=delete; ~PrivateClosed() {} std::uint32_t get() const {return value;} };
struct CustomDtor { std::uint32_t value; ~CustomDtor() { ++custom_destructions; } };
struct Tagged { std::uint32_t tag; Head items[2]; };
#ifndef I1_ORACLE
template<class T> struct Ops;
template<> struct Ops<Mixed> { using T=Mixed;
static T* restore(void* p,const Input& input,std::size_t offset) {
return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,stamp)),input.scalar<bool>(offset+offsetof(T,enabled)),{{input.scalar<std::uint16_t>(offset+offsetof(T,grid[0][0])),input.scalar<std::uint16_t>(offset+offsetof(T,grid[0][1])),input.scalar<std::uint16_t>(offset+offsetof(T,grid[0][2]))},{input.scalar<std::uint16_t>(offset+offsetof(T,grid[1][0])),input.scalar<std::uint16_t>(offset+offsetof(T,grid[1][1])),input.scalar<std::uint16_t>(offset+offsetof(T,grid[1][2]))}}};
}
static T* borrow(void* p,const Input& input,std::size_t offset,Arena& owner) {return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,stamp)),input.scalar<bool>(offset+offsetof(T,enabled)),{{input.scalar<std::uint16_t>(offset+offsetof(T,grid[0][0])),input.scalar<std::uint16_t>(offset+offsetof(T,grid[0][1])),input.scalar<std::uint16_t>(offset+offsetof(T,grid[0][2]))},{input.scalar<std::uint16_t>(offset+offsetof(T,grid[1][0])),input.scalar<std::uint16_t>(offset+offsetof(T,grid[1][1])),input.scalar<std::uint16_t>(offset+offsetof(T,grid[1][2]))}}};}
static std::vector<std::size_t> head_offsets() { return {}; }
static std::vector<Head*> heads(T& value) { return {}; }
static std::vector<Field> fields() { return {Field{"stamp",offsetof(T,stamp),sizeof((static_cast<T*>(nullptr))->stamp)},Field{"enabled",offsetof(T,enabled),sizeof((static_cast<T*>(nullptr))->enabled)},Field{"grid",offsetof(T,grid),sizeof((static_cast<T*>(nullptr))->grid)}}; }
static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));
s += std::string("@")+std::to_string(offsetof(T,stamp))+":"+wire_type<decltype(T::stamp)>();
s += std::string(",@")+std::to_string(offsetof(T,enabled))+":"+wire_type<decltype(T::enabled)>();
s += std::string(",@")+std::to_string(offsetof(T,grid))+":"+wire_type<decltype(T::grid)>();
return s+"}"; }
};
template<> struct Ops<Pair> { using T=Pair;
static T* restore(void* p,const Input& input,std::size_t offset) {
return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,stamp)),Head(HeadInput{input,offset+offsetof(T,left)}),Head(HeadInput{input,offset+offsetof(T,right)})};
}
static T* borrow(void* p,const Input& input,std::size_t offset,Arena& owner) {return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,stamp)),Head(borrow_input(owner,input,offset+offsetof(T,left))),Head(borrow_input(owner,input,offset+offsetof(T,right)))};}
static std::vector<std::size_t> head_offsets() { return {offsetof(T,left),offsetof(T,right)}; }
static std::vector<Head*> heads(T& value) { return {&value.left,&value.right}; }
static std::vector<Field> fields() { return {Field{"stamp",offsetof(T,stamp),sizeof((static_cast<T*>(nullptr))->stamp)},Field{"left",offsetof(T,left),sizeof((static_cast<T*>(nullptr))->left)},Field{"right",offsetof(T,right),sizeof((static_cast<T*>(nullptr))->right)}}; }
static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));
s += std::string("@")+std::to_string(offsetof(T,stamp))+":"+wire_type<decltype(T::stamp)>();
s += std::string(",@")+std::to_string(offsetof(T,left))+":"+wire_type<decltype(T::left)>();
s += std::string(",@")+std::to_string(offsetof(T,right))+":"+wire_type<decltype(T::right)>();
return s+"}"; }
};
template<> struct Ops<Direct> { using T=Direct;
static T* restore(void* p,const Input& input,std::size_t offset) {
return ::new(p) T{{Head(HeadInput{input,offset+offsetof(T,items[0])}),Head(HeadInput{input,offset+offsetof(T,items[1])})}};
}
static T* borrow(void* p,const Input& input,std::size_t offset,Arena& owner) {return ::new(p) T{{Head(borrow_input(owner,input,offset+offsetof(T,items[0]))),Head(borrow_input(owner,input,offset+offsetof(T,items[1])))}};}
static std::vector<std::size_t> head_offsets() { return {offsetof(T,items[0]),offsetof(T,items[1])}; }
static std::vector<Head*> heads(T& value) { return {&value.items[0],&value.items[1]}; }
static std::vector<Field> fields() { return {Field{"items",offsetof(T,items),sizeof((static_cast<T*>(nullptr))->items)}}; }
static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));
s += std::string("@")+std::to_string(offsetof(T,items))+":"+wire_type<decltype(T::items)>();
return s+"}"; }
};
template<> struct Ops<Nested> { using T=Nested;
static T* restore(void* p,const Input& input,std::size_t offset) {
return ::new(p) T{{{Head(HeadInput{input,offset+offsetof(T,items[0][0])}),Head(HeadInput{input,offset+offsetof(T,items[0][1])})},{Head(HeadInput{input,offset+offsetof(T,items[1][0])}),Head(HeadInput{input,offset+offsetof(T,items[1][1])})}}};
}
static T* borrow(void* p,const Input& input,std::size_t offset,Arena& owner) {return ::new(p) T{{{Head(borrow_input(owner,input,offset+offsetof(T,items[0][0]))),Head(borrow_input(owner,input,offset+offsetof(T,items[0][1])))},{Head(borrow_input(owner,input,offset+offsetof(T,items[1][0]))),Head(borrow_input(owner,input,offset+offsetof(T,items[1][1])))}}};}
static std::vector<std::size_t> head_offsets() { return {offsetof(T,items[0][0]),offsetof(T,items[0][1]),offsetof(T,items[1][0]),offsetof(T,items[1][1])}; }
static std::vector<Head*> heads(T& value) { return {&value.items[0][0],&value.items[0][1],&value.items[1][0],&value.items[1][1]}; }
static std::vector<Field> fields() { return {Field{"items",offsetof(T,items),sizeof((static_cast<T*>(nullptr))->items)}}; }
static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));
s += std::string("@")+std::to_string(offsetof(T,items))+":"+wire_type<decltype(T::items)>();
return s+"}"; }
};
template<> struct Ops<Sequence> { using T=Sequence;
static T* restore(void* p,const Input& input,std::size_t offset) {
return ::new(p) T{{}};
}
static T* borrow(void* p,const Input& input,std::size_t offset,Arena& owner) {return ::new(p) T{{}};}
static std::vector<std::size_t> head_offsets() { return {}; }
static std::vector<Head*> heads(T& value) { return {}; }
static std::vector<Field> fields() { return {Field{"values",offsetof(T,values),sizeof((static_cast<T*>(nullptr))->values)}}; }
static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));
s += std::string("@")+std::to_string(offsetof(T,values))+":"+wire_type<decltype(T::values)>();
return s+"}"; }
};
template<> struct Ops<AllocatorOnly> { using T=AllocatorOnly;
static T* restore(void* p,const Input& input,std::size_t offset) {
return ::new(p) T(AdapterAllocator{input.scalar<std::uint32_t>(offset)});
}
static std::vector<std::size_t> head_offsets() { return {}; }
static std::vector<Head*> heads(T& value) { return {}; }
static std::vector<Field> fields() { return {Field{"value",offsetof(T,value),sizeof((static_cast<T*>(nullptr))->value)}}; }
static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));
s += std::string("@")+std::to_string(offsetof(T,value))+":"+wire_type<decltype(T::value)>();
return s+"}"; }
};
template<> struct Ops<ConstScalar> { using T=ConstScalar;
static T* restore(void* p,const Input& input,std::size_t offset) {
return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,value))};
}
static T* borrow(void* p,const Input& input,std::size_t offset,Arena& owner) {return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,value))};}
static std::vector<std::size_t> head_offsets() { return {}; }
static std::vector<Head*> heads(T& value) { return {}; }
static std::vector<Field> fields() { return {Field{"value",offsetof(T,value),sizeof((static_cast<T*>(nullptr))->value)}}; }
static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));
s += std::string("@")+std::to_string(offsetof(T,value))+":"+wire_type<decltype(T::value)>();
return s+"}"; }
};
template<> struct Ops<CustomDtor> { using T=CustomDtor;
static T* restore(void* p,const Input& input,std::size_t offset) {
return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,value))};
}
static T* borrow(void* p,const Input& input,std::size_t offset,Arena& owner) {return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,value))};}
static std::vector<std::size_t> head_offsets() { return {}; }
static std::vector<Head*> heads(T& value) { return {}; }
static std::vector<Field> fields() { return {Field{"value",offsetof(T,value),sizeof((static_cast<T*>(nullptr))->value)}}; }
static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));
s += std::string("@")+std::to_string(offsetof(T,value))+":"+wire_type<decltype(T::value)>();
return s+"}"; }
};
template<> struct Ops<Tagged> { using T=Tagged;
static T* restore(void* p,const Input& input,std::size_t offset) {
return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,tag)),{Head(HeadInput{input,offset+offsetof(T,items[0])}),Head(HeadInput{input,offset+offsetof(T,items[1])})}};
}
static T* borrow(void* p,const Input& input,std::size_t offset,Arena& owner) {return ::new(p) T{input.scalar<std::uint32_t>(offset+offsetof(T,tag)),{Head(borrow_input(owner,input,offset+offsetof(T,items[0]))),Head(borrow_input(owner,input,offset+offsetof(T,items[1])))}};}
static std::vector<std::size_t> head_offsets() { return {offsetof(T,items[0]),offsetof(T,items[1])}; }
static std::vector<Head*> heads(T& value) { return {&value.items[0],&value.items[1]}; }
static std::vector<Field> fields() { return {Field{"tag",offsetof(T,tag),sizeof((static_cast<T*>(nullptr))->tag)},Field{"items",offsetof(T,items),sizeof((static_cast<T*>(nullptr))->items)}}; }
static std::string signature() { std::string s=record_prefix(sizeof(T),alignof(T));
s += std::string("@")+std::to_string(offsetof(T,tag))+":"+wire_type<decltype(T::tag)>();
s += std::string(",@")+std::to_string(offsetof(T,items))+":"+wire_type<decltype(T::items)>();
return s+"}"; }
};
#endif
}
