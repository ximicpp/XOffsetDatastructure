#include "runtime.hpp"
#include "types.hpp"
#include <algorithm>
#include <cstdlib>
#include <sys/mman.h>
#include <unistd.h>

using namespace i1;
namespace {
using Image=std::array<std::byte,Arena::extent>;
constexpr std::size_t root=256;
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
template<class T> void put(Image& image,std::size_t off,T value){std::memcpy(image.data()+off,&value,sizeof(T));}
template<class T> Image fixture(int state) {
    Image image{};
    put<std::uint64_t>(image,0,0x0000315646464f58ull);
    put<std::uint32_t>(image,root,0x1234);
    unsigned index=0;
    for(auto off:Ops<T>::head_offsets()) {
        const std::uint32_t n=state ? 3:0,cap=state==2 ? 7:n;
        const auto data=8192+128*index;
        put<std::int32_t>(image,root+off,64-static_cast<std::int32_t>(root+off));
        put<std::int32_t>(image,root+off+4,cap ? static_cast<std::int32_t>(data-(root+off+4)):0);
        put(image,root+off+8,n);put(image,root+off+12,cap);
        for(unsigned j=0;j<cap;++j)image[data+j]=std::byte(0x30+index+j);
        ++index;
    }
    return image;
}
template<class T> void verify(T& object,const Image& image,int state) {
    const Input input{image.data(),image.size()};
    auto heads=Ops<T>::heads(object);auto offsets=Ops<T>::head_offsets();
    require(heads.size()==offsets.size(),"head closure");
    for(std::size_t i=0;i<heads.size();++i){
        auto* h=heads[i];const auto source=root+offsets[i];
        auto& owner=Arena::containing(h);
        require(h->size==(state?3u:0u) && h->capacity==(state==2?7u:(state?3u:0u)),"length");
        require(static_cast<std::int64_t>(owner.index(h))+h->arena_delta==64*owner.allocator_id,"arena binding");
        if(h->capacity){
            const auto data=source+4+input.scalar<std::int32_t>(source+4);
            require(std::memcmp(owner.bytes+h->data_offset(),image.data()+data,h->capacity)==0,"payload bytes");
        }
    }
}
struct Result { const char* status; const char* reason; };
Result pass(){return {"pass","runtime-and-local-rule"};}
Result unproven(const char* why){return {"unproven",why};}
Result not_run(const char* why){return {"not-executed",why};}

template<class T> Result metadata(int check) {
    if(check==0) {
        auto fields=Ops<T>::fields();require(!fields.empty(),"empty field list");
        std::size_t end=0;
        for(const auto& field:fields){require(field.offset>=end && field.offset+field.size<=sizeof(T),"field bounds/order");end=field.offset+field.size;}
        if constexpr(std::is_same_v<T,Mixed>){require(fields.size()==3 && fields[1].offset==4 && fields[2].offset==6,"padding bool/multidim offset");}
    } else if(check==1) {
        if constexpr(std::is_same_v<T,Mixed>)require(sizeof(T)==20 && alignof(T)==4,"mixed ABI");
        if constexpr(std::is_same_v<T,Pair>)require(sizeof(T)==40 && alignof(T)==8,"pair ABI");
        if constexpr(std::is_same_v<T,Direct>)require(sizeof(T)==32 && alignof(T)==8,"array ABI");
        if constexpr(std::is_same_v<T,Sequence>)require(sizeof(T)==16 && alignof(T)==8,"sequence ABI");
        if constexpr(std::is_same_v<T,AllocatorOnly> || std::is_same_v<T,ConstScalar>)require(sizeof(T)==4 && alignof(T)==4,"scalar ABI");
    } else if(check==2) {
        require(std::is_aggregate_v<T> != std::is_same_v<T,AllocatorOnly>,"aggregate changed");
        auto input=fixture<T>(0);Input view{input.data(),input.size()};Arena arena;destination=&arena;
        auto* value=Ops<T>::restore(arena.bytes+root,view,root);std::destroy_at(value);
        require(arena.live_blocks()==0,"construction cleanup");
    } else {
        auto signature=Ops<T>::signature();require(signature.starts_with("record[s:") && signature.back()=='}',"full signature");
        std::cout<<"LAYOUT\t";
        if constexpr(std::is_same_v<T,Mixed>)std::cout<<"Mixed";
        if constexpr(std::is_same_v<T,Pair>)std::cout<<"Pair";
        if constexpr(std::is_same_v<T,Direct>)std::cout<<"Direct";
        if constexpr(std::is_same_v<T,Sequence>)std::cout<<"Sequence";
        if constexpr(std::is_same_v<T,AllocatorOnly>)std::cout<<"AllocatorOnly";
        if constexpr(std::is_same_v<T,ConstScalar>)std::cout<<"ConstScalar";
        std::cout<<"\t"<<sizeof(T)<<"\t"<<alignof(T)<<"\t"<<signature<<"\n";
        return unproven("classification-awaits-separate-readonly-oracle");
    }
    return pass();
}

template<class T> Result restoring(int state,int overwrite) {
    auto input=fixture<T>(state);const auto before=input;Arena staging;destination=&staging;
    std::memset(staging.bytes+root,overwrite?0xa5:0x5a,sizeof(T));
    auto* object=Ops<T>::restore(staging.bytes+root,{input.data(),input.size()},root);
    verify(*object,input,state);require(input==before,"source was changed");
    require(trace.constructed==static_cast<int>(Ops<T>::head_offsets().size()),"whole construction count");
    std::destroy_at(object);require(staging.live_blocks()==0,"restore leak");return pass();
}

template<class T> T* element(void* address,const Input& input,std::size_t off) {
    if constexpr(std::is_same_v<T,std::uint32_t>)return ::new(address) T(input.scalar<T>(off));
    else if constexpr(std::is_same_v<T,Head>)return ::new(address) Head(HeadInput{input,off});
    else return Ops<T>::restore(address,input,off);
}
template<class T> Image element_fixture() {
    if constexpr(std::is_same_v<T,std::uint32_t>){Image v{};put(v,root,std::uint32_t(37));return v;}
    else if constexpr(std::is_same_v<T,Head>){auto v=fixture<Direct>(1);return v;}
    else return fixture<T>(1);
}
template<class T> Result array_path(int path) {
    if(path==4) return not_run("L4-tail-expand-larger-enclosing-array-not-proven;no-UB-execution");
    auto input=element_fixture<T>();Input view{input.data(),input.size()};Arena arena;destination=&arena;
    constexpr std::size_t cap=4;constexpr std::size_t bytes=cap*sizeof(T);
    alignas(64) std::byte zero[bytes]{};
    auto start=[&](std::size_t off){std::memcpy(arena.bytes+off,zero,bytes);};
    auto construct=[&](std::size_t off,int count){
        T* first=nullptr;
        for(int i=0;i<count;++i){auto* p=element<T>(arena.bytes+off+i*sizeof(T),view,root);if(!i)first=p;}
        if(count>1)require(reinterpret_cast<std::byte*>(first+1)==arena.bytes+off+sizeof(T),"enclosing array stride");
        return first;
    };
    auto destroy=[](T* first,int count){for(int i=count;i>0;--i)std::destroy_at(first+i-1);};
    if(path==1){start(512);require(trace.constructed==0,"empty capacity built leaves");return pass();}
    if(path==3){auto* old=::new(arena.bytes+512) double(3.5);std::destroy_at(old);}
    start(512);auto* first=construct(512,2);
    if(path==2 || path==3 || path==5 || path==7){
        destroy(first,2);start(512);first=construct(512,path==5?1:2);destroy(first,path==5?1:2);
    } else if(path==6){
        start(1024);auto* next=construct(1024,2);destroy(first,2);destroy(next,2);
    } else destroy(first,2);
    require(arena.live_blocks()==0 && trace.constructed==trace.destroyed,"array prefix cleanup");
    if(path==6)return unproven("L4-relocation-used-deep-reconstruction;no-allocation-free-relocation-proof");
    if(path==5)return unproven("L4-erase-fixture-rebuilt-prefix;generic-erase-guarantee-not-proven");
    return pass();
}

template<class T> Result ownership(int relation) {
    if(relation==3 || relation==4)return not_run("R2-actual-ancestor-descendant-transaction-not-proven");
    auto input=fixture<T>(1);Input raw{input.data(),input.size()};Arena source,target;
    destination=&source;auto* a=Ops<T>::restore(source.bytes+root,raw,root);
    if(relation==5){
        // Explicit self identity guard, before touching a single header.
        auto move_assign=[](T* dst,T* src){if(dst==src)return;throw std::logic_error("not self");};
        move_assign(a,a);verify(*a,input,1);std::destroy_at(a);require(source.live_blocks()==0,"self cleanup");return pass();
    }
    T* b=nullptr;
    if(relation==0){
        b=Ops<T>::borrow(source.bytes+1024,source.input(),root,source);
        auto ah=Ops<T>::heads(*a),bh=Ops<T>::heads(*b);
        for(std::size_t i=0;i<ah.size();++i){require(ah[i]->data_offset()==bh[i]->data_offset(),"steal did not retain payload");ah[i]->relinquish();}
        verify(*b,input,1);std::destroy_at(a);std::destroy_at(b);
    }else{
        Arena& destination_owner=relation==1?target:source;
        destination_owner.allocator_id=relation==2?2:1;destination=&destination_owner;
        b=Ops<T>::restore(destination_owner.bytes+1024,source.input(),root);
        auto ah=Ops<T>::heads(*a),bh=Ops<T>::heads(*b);
        for(std::size_t i=0;i<ah.size();++i)require(ah[i]->content()==bh[i]->content(),"deep copy content");
        verify(*b,input,1);std::destroy_at(b);std::destroy_at(a);
    }
    require(source.live_blocks()==0 && target.live_blocks()==0,"ownership leak");
    return unproven("R2-source-reuse-and-full-allocator-transaction-not-yet-proven");
}

template<class T> Result exceptional(int point) {
    auto input=fixture<T>(1);const auto before=input;Input raw{input.data(),input.size()};Arena arena;destination=&arena;
    const char* names[]={"payload","leaf","leaf","payload","scratch","publish"};
    const int ordinals[]={1,1,2,2,1,1};
    failure={names[point],ordinals[point],0,false};T* complete=nullptr;
    try {
        failure.hit("scratch");std::vector<std::byte> scratch(16);
        complete=Ops<T>::restore(arena.bytes+root,raw,root);
        failure.hit("publish");std::vector<std::byte> publication(16);
        std::destroy_at(complete);complete=nullptr;
    }catch(const std::bad_alloc&){if(complete)std::destroy_at(complete);}
    require(failure.reached,"registered failure was not reached");require(input==before,"exception changed source");
    require(trace.constructed==trace.destroyed && arena.live_blocks()==0,"exception prefix leak");
    auto reverse=trace.finished;std::reverse(reverse.begin(),reverse.end());require(reverse==trace.retired,"wrong cleanup order");
    failure={};trace.reset();auto* retry=Ops<T>::restore(arena.bytes+root,raw,root);verify(*retry,input,1);std::destroy_at(retry);
    require(arena.live_blocks()==0,"retry leak");return pass();
}

template<class F,class U> Result floating(U bits) {
    struct Payload {F value;};Arena arena;
    auto* value=::new(arena.bytes+root) Payload{F(0)};
    std::memcpy(&value->value,&bits,sizeof(bits));U observed{};
    std::memcpy(&observed,&value->value,sizeof(observed));require(observed==bits,"float representation changed");
    std::destroy_at(value);return pass();
}
Result representation(int index) {
    static constexpr std::uint32_t floats[]={0,0x80000000u,1,0x7f7fffffu,0x7f800000u,0xff800000u,0x7fc01234u,0x7f801234u};
    static constexpr std::uint64_t doubles[]={0,0x8000000000000000ull,1,0x7fefffffffffffffull,0x7ff0000000000000ull,0xfff0000000000000ull,0x7ff8000000001234ull,0x7ff0000000001234ull};
    if(index<8)return floating<float>(floats[index]);
    if(index<16)return floating<double>(doubles[index-8]);
    Arena arena;
    if(index<24){
        switch(index-16){
        case 0:{auto* p=::new(arena.bytes+root) ConstScalar{29};require(p->value==29,"const int");std::destroy_at(p);break;}
        case 1:return not_run("L6-const-float-arbitrary-representation-initialization-not-proven");
        case 2:{struct V{volatile std::uint32_t value;};auto* p=::new(arena.bytes+root) V{31};require(p->value==31,"volatile value");std::destroy_at(p);return unproven("L6-volatile-value-path-does-not-prove-byte-restoration");}
        case 3:{class PrivateFactory{std::uint32_t value;public:explicit PrivateFactory(std::uint32_t n):value(n){} std::uint32_t get()const{return value;}};auto* p=::new(arena.bytes+root) PrivateFactory(19);require(p->get()==19,"private factory");std::destroy_at(p);break;}
        case 4:return not_run("A1-PrivateClosed-has-no-value-preserving-construction-entry");
        case 5:{int before=custom_destructions;auto* p=::new(arena.bytes+root) CustomDtor{41};require(p->value==41,"custom dtor value");std::destroy_at(p);require(custom_destructions==before+1,"custom dtor event");break;}
        case 6:{auto* p=::new(arena.bytes+root) AllocatorOnly(AdapterAllocator{43});require(p->value==43,"allocator priority");std::destroy_at(p);break;}
        case 7:{require(std::is_aggregate_v<Pair> && !std::is_copy_constructible_v<Pair>,"aggregate/elision eligibility");break;}
        }
        return pass();
    }
    if(index<32){
        const auto k=index-24;const unsigned char values[]={0,1,2,255};auto representation=values[k%4];
        Image image{};const auto off=k<4?root:root+offsetof(Mixed,enabled);
        image[off]=std::byte(representation);
        const bool valid=std::to_integer<unsigned char>(image[off])<=1;
        require(valid==(k%4<2),"raw bool classification");
        if(valid){auto* value=::new(arena.bytes+root) Mixed{};value->enabled=representation==1;require(value->enabled==(representation==1),"valid bool");std::destroy_at(value);}
        return pass();
    }
    switch(index-32){
    case 0:return not_run("L6-potentially-overlapping-nontrivial-member-elision-not-proven");
    case 1:{struct Empty{};struct P{[[no_unique_address]]Empty e;std::uint32_t n;};auto* p=::new(arena.bytes+root) P{{},47};require(p->n==47,"empty overlap");std::destroy_at(p);return unproven("L6-empty-positive-does-not-cover-owning-overlap");}
    case 2:{struct alignas(16) Aligned{std::uint32_t n;};require(alignof(Aligned)>8,"alignment negative");break;}
    case 3:{enum class E:std::uint32_t{One=1};auto* p=::new(arena.bytes+root) E(static_cast<E>(0xdeadbeefu));require(static_cast<std::uint32_t>(*p)==0xdeadbeefu,"unnamed enum rejected");std::destroy_at(p);break;}
    case 4:{enum class E:std::int32_t{Zero=0};auto* p=::new(arena.bytes+root) E(static_cast<E>(INT32_MIN));require(static_cast<std::int32_t>(*p)==INT32_MIN,"enum minimum");std::destroy_at(p);break;}
    case 5:{enum class E:std::int32_t{Zero=0};auto* p=::new(arena.bytes+root) E(static_cast<E>(INT32_MAX));require(static_cast<std::int32_t>(*p)==INT32_MAX,"enum maximum");std::destroy_at(p);break;}
    case 6:{require(sizeof(std::uint16_t[2][3])==12 && sizeof(Direct)==2*sizeof(Head),"dimension stride");break;}
    case 7:{auto* first=::new(arena.bytes+root) ConstScalar{51};std::destroy_at(first);auto* second=::new(arena.bytes+root) ConstScalar{53};require(second->value==53,"fresh pointer const member");std::destroy_at(second);break;}
    }
    return pass();
}

struct Vm {
    static constexpr std::size_t extent=16384;
    std::byte* base;
    Vm():base(static_cast<std::byte*>(::mmap(nullptr,extent,PROT_NONE,MAP_PRIVATE|MAP_ANONYMOUS,-1,0))){if(base==MAP_FAILED)throw std::bad_alloc();}
    ~Vm(){::munmap(base,extent);}
    void commit(std::size_t end){failure.hit("commit");if(end>extent || ::mprotect(base,end,PROT_READ|PROT_WRITE))throw std::bad_alloc();}
    void decommit(){require(::mprotect(base,4096,PROT_NONE)==0,"decommit protect");require(::madvise(base,4096,MADV_DONTNEED)==0,"decommit discard");}
};
Result provenance(int index){
    if(index<24){
        const std::size_t origins[]={0,260,65532};auto origin=origins[index/8];auto kind=index%8;
        const std::int64_t deltas[]={0,1,-1,INT32_MIN,INT32_MAX,65535-static_cast<std::int64_t>(origin),65536-static_cast<std::int64_t>(origin),0};
        std::size_t out=0;const auto n=kind==7?std::numeric_limits<std::size_t>::max():1;
        auto valid=checked_relative(65536,origin,deltas[kind],n,kind==7?2:1,1,out);
        const auto mathematical=static_cast<std::int64_t>(origin)+deltas[kind];
        const bool expected=kind!=7 && mathematical>=0 && mathematical<65536;
        require(valid==expected,"checked arithmetic boundary");
        if(valid){Arena a;auto* p=::new(a.bytes+out) std::byte{0x5a};require(*p==std::byte{0x5a},"byte-base derivation");std::destroy_at(p);}
        return pass();
    }
    const int path=index-24;Vm vm;
    if(path==0)return unproven("L5-VM-reservation-needs-implementation-storage-contract");
    if(path==6){bool rejected=false;try{vm.commit(Vm::extent+4096);}catch(const std::bad_alloc&){rejected=true;}require(rejected,"VM maximum");return pass();}
    if(path==7){failure={"commit",1,0,false};try{vm.commit(4096);}catch(const std::bad_alloc&){}require(failure.reached,"VM failure unreachable");failure={};}
    vm.commit(4096);
    auto* storage=::new(static_cast<void*>(vm.base)) std::byte[Vm::extent];
    auto* value=::new(static_cast<void*>(storage)) std::uint32_t(7);
    if(path==2){auto* old=vm.base;vm.commit(8192);require(vm.base==old && *value==7,"VM base moved");}
    if(path==3 || path==4){std::destroy_at(value);vm.decommit();value=nullptr;if(path==4){vm.commit(4096);value=::new(static_cast<void*>(storage)) std::uint32_t(9);require(*value==9,"recommit object");}}
    if(path==5){std::destroy_at(value);value=nullptr;auto* other=::new(static_cast<void*>(storage)) double(3.5);require(*other==3.5,"VM reuse");std::destroy_at(other);}
    if(value)std::destroy_at(value);
    return unproven("L5-runtime-VM-path-consistent;GCC-POSIX-storage-assumption-not-formally-closed");
}

struct Published {
    std::unique_ptr<Arena> owner;
    Pair* typed=nullptr;
    ~Published(){if(typed)std::destroy_at(typed);}
    Pair& root_value(){if(!typed)throw std::logic_error("not typed");return *typed;}
    void modify(){root_value().stamp=99;}
    std::vector<std::byte> save(){root_value();return {owner->bytes,owner->bytes+512};}
};
void load(Published& state,const Image& image,int failure_stage){
    Input input{image.data(),image.size()};
    if(input.scalar<std::uint64_t>(0)!=0x0000315646464f58ull)throw std::invalid_argument("header rejection");
    for(auto off:Ops<Pair>::head_offsets()){
        const auto size=input.scalar<std::uint32_t>(root+off+8),cap=input.scalar<std::uint32_t>(root+off+12);
        if(size>cap || cap>64)throw std::invalid_argument("graph rejection");
        std::size_t payload=0;
        if(cap && !checked_relative(input.length,root+off+4,input.scalar<std::int32_t>(root+off+4),cap,1,1,payload))throw std::invalid_argument("graph payload rejection");
    }
    auto staging=std::make_unique<Arena>();destination=staging.get();Pair* local=nullptr;
    failure={failure_stage==2?"leaf":"publish",failure_stage==2?2:1,0,false};
    try{local=Ops<Pair>::restore(staging->bytes+root,input,root);failure.hit("publish");std::vector<std::byte> publication(16);}
    catch(...){if(local)std::destroy_at(local);throw;}
    state.typed=local;state.owner=std::move(staging);
}
Result publishing(int stage,int observation){
    auto image=fixture<Pair>(1);Published state;bool rejected=false;
    if(stage==0)image[0]=std::byte{0};
    if(stage==1)put<std::uint32_t>(image,root+offsetof(Pair,left)+8,65);
    try{load(state,image,stage);}catch(const std::exception&){rejected=true;}
    require(rejected,"publication failure accepted");
    if(stage>=2)require(failure.reached,"publication failure unreachable");
    if(stage<2)require(trace.attempts==0,"raw rejection constructed typed object");
    bool unavailable=false;
    if(observation==0){try{state.root_value();}catch(const std::logic_error&){unavailable=true;}}
    if(observation==1){try{state.modify();}catch(const std::logic_error&){unavailable=true;}}
    if(observation==2){try{state.save();}catch(const std::logic_error&){unavailable=true;}}
    if(observation==3)unavailable=!state.owner && trace.constructed==trace.destroyed;
    require(unavailable,"failed staging leaked capability");
    return unproven("L1-H-control-state-machine-only;not-a-V1-header-or-graph-validator");
}

template<class F> Result layout_dispatch(int layout,F&& f){
    switch(layout){case 0:return f.template operator()<Pair>();case 1:return f.template operator()<Direct>();case 2:return f.template operator()<Nested>();default:return f.template operator()<Tagged>();}
}
Result run(char group,int index){
    if(group=='A'){
        switch(index/4){case 0:return metadata<Mixed>(index%4);case 1:return metadata<Pair>(index%4);case 2:return metadata<Direct>(index%4);case 3:return metadata<Sequence>(index%4);case 4:return metadata<AllocatorOnly>(index%4);default:return metadata<ConstScalar>(index%4);}
    }
    if(group=='B')return layout_dispatch(index/6,[&]<class T>(){return restoring<T>((index%6)/2,index%2);});
    if(group=='C'){
        switch(index%4){case 0:return array_path<std::uint32_t>(index/4);case 1:return array_path<Head>(index/4);case 2:return array_path<Pair>(index/4);default:return array_path<Nested>(index/4);}
    }
    if(group=='D')return layout_dispatch(index%4,[&]<class T>(){return ownership<T>(index/4);});
    if(group=='E')return layout_dispatch(index%4,[&]<class T>(){return exceptional<T>(index/4);});
    if(group=='F')return representation(index);
    if(group=='G')return provenance(index);
    return publishing(index/4,index%4);
}
}
int main(int argc,char** argv){
    trace.finished.reserve(128);trace.retired.reserve(128);Arena::registry.reserve(16);
    static_assert(std::endian::native==std::endian::little && sizeof(void*)==8);
    static_assert(sizeof(float)==4 && sizeof(double)==8 && std::numeric_limits<float>::is_iec559 && std::numeric_limits<double>::is_iec559);
    const std::string chosen=argc>1?argv[1]:"all";int errors=0;
    const int counts[]={24,24,32,24,24,40,32,16};
    for(int group=0;group<8;++group){const char letter=char('A'+group);if(chosen!="all" && chosen!=std::string(1,letter))continue;
        for(int index=0;index<counts[group];++index){trace.reset();failure={};Result result;
            try{result=run(letter,index);}
            catch(const std::exception& e){result={"fail","runtime-assertion"};std::cerr<<letter<<index<<": "<<e.what()<<"\n";++errors;}
            std::cout<<"{\"case\":\""<<letter<<"-"<<(index<10?"0":"")<<index<<"\",\"status\":\""<<result.status<<"\",\"reason\":\""<<result.reason<<"\"}\n";
            require(Arena::registry.empty(),"owner escaped trial");
        }
    }
    return errors?1:0;
}
