#pragma once
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <limits>
#include <memory>
#include <new>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

namespace i1 {
inline int custom_destructions=0;
struct AdapterAllocator { std::uint32_t value; };
struct Field { const char* name; std::size_t offset,size; };
template<class T> struct Ops;
inline std::string record_prefix(std::size_t size,std::size_t align) {
    return "record[s:"+std::to_string(size)+",a:"+std::to_string(align)+"]{";
}
struct Input {
    const std::byte* bytes;
    std::size_t length;
    template<class T> T scalar(std::size_t off) const {
        static_assert(std::is_trivially_copyable_v<T>);
        if(off>length || sizeof(T)>length-off) throw std::out_of_range("scalar");
        T value{}; std::memcpy(&value,bytes+off,sizeof(T)); return value;
    }
    const std::byte* range(std::size_t off,std::size_t n) const {
        if(off>length || n>length-off) throw std::out_of_range("range");
        return bytes+off;
    }
};
inline bool checked_relative(std::size_t extent,std::size_t origin,std::int64_t delta,
                             std::size_t count,std::size_t stride,std::size_t alignment,
                             std::size_t& result) {
    if(origin>=extent || delta<std::numeric_limits<std::int32_t>::min() ||
       delta>std::numeric_limits<std::int32_t>::max() || alignment==0) return false;
    if(stride && count>std::numeric_limits<std::size_t>::max()/stride) return false;
    const auto distance=delta<0 ? std::uint64_t(-(delta+1))+1 : std::uint64_t(delta);
    if(delta<0 && distance>origin) return false;
    if(delta>=0 && distance>extent-origin) return false;
    const auto off=delta<0 ? origin-static_cast<std::size_t>(distance) : origin+static_cast<std::size_t>(distance);
    const auto bytes=count*stride;
    if(off>=extent || bytes>extent-off || off%alignment) return false;
    result=off; return true;
}

struct Trace {
    int constructed=0,destroyed=0,attempts=0;
    std::vector<int> finished,retired;
    void reset(){constructed=destroyed=attempts=0;finished.clear();retired.clear();}
};
inline Trace trace;
struct Failure {
    std::string point;
    int ordinal=0,seen=0;
    bool reached=false;
    void hit(const char* name) {
        if(point==name && ++seen==ordinal) { reached=true; throw std::bad_alloc(); }
    }
};
inline Failure failure;
struct Block { std::size_t offset,size; bool live; };
struct Arena {
    static constexpr std::size_t extent=65536;
    alignas(64) std::byte bytes[extent]{};
    std::vector<Block> blocks;
    std::size_t next=4096;
    int allocator_id=1;
    static inline std::vector<Arena*> registry;
    Arena(){ blocks.reserve(128); registry.push_back(this); }
    Arena(const Arena&)=delete;
    ~Arena(){ for(auto it=registry.begin();it!=registry.end();++it) if(*it==this){registry.erase(it);break;} }
    std::size_t index(const void* address) const {
        const auto a=reinterpret_cast<std::uintptr_t>(address),b=reinterpret_cast<std::uintptr_t>(bytes);
        if(a<b || a-b>=extent) throw std::out_of_range("address is not in owner");
        return a-b;
    }
    static Arena& containing(const void* address) {
        const auto a=reinterpret_cast<std::uintptr_t>(address);
        for(auto* owner:registry) {
            const auto b=reinterpret_cast<std::uintptr_t>(owner->bytes);
            if(a>=b && a-b<extent) return *owner;
        }
        throw std::out_of_range("unregistered owner");
    }
    std::size_t allocate(std::size_t n) {
        failure.hit("payload");
        auto off=(next+7)&~std::size_t(7);
        if(n>extent-off) throw std::bad_alloc();
        blocks.push_back({off,n,true}); next=off+n; return off;
    }
    void retire(std::size_t off) {
        for(auto& block:blocks) if(block.offset==off && block.live){block.live=false;return;}
        throw std::logic_error("duplicate or foreign retirement");
    }
    std::size_t live_blocks() const {std::size_t n=0;for(const auto& b:blocks)n+=b.live;return n;}
    Input input() const {return {bytes,extent};}
};
inline Arena* destination=nullptr;
struct HeadInput { const Input& input; std::size_t offset; };
struct BorrowInput { Arena& arena; std::size_t payload; std::uint32_t size,capacity; };
struct alignas(8) Head {
    std::int32_t arena_delta,data_delta;
    std::uint32_t size,capacity;
    Head()=delete;
    Head(const Head&)=delete;
    Head& operator=(const Head&)=delete;
    explicit Head(HeadInput source) : arena_delta(0),data_delta(0),size(0),capacity(0) {
        ++trace.attempts; failure.hit("leaf");
        if(!destination) throw std::logic_error("no destination");
        const auto n=source.input.scalar<std::uint32_t>(source.offset+8);
        const auto cap=source.input.scalar<std::uint32_t>(source.offset+12);
        const auto delta=source.input.scalar<std::int32_t>(source.offset+4);
        if(n>cap || cap>64) throw std::out_of_range("head length");
        std::size_t src=0;
        if(cap && (!delta || !checked_relative(source.input.length,source.offset+4,delta,cap,1,1,src)))
            throw std::out_of_range("head payload");
        if(!cap && (n||delta)) throw std::out_of_range("empty head");
        const auto off=destination->index(this);
        const auto data=cap ? destination->allocate(cap):0;
        if(cap) std::memcpy(destination->bytes+data,source.input.range(src,cap),cap);
        arena_delta=static_cast<std::int32_t>(64*destination->allocator_id)-static_cast<std::int32_t>(off);
        data_delta=cap ? static_cast<std::int32_t>(data)-static_cast<std::int32_t>(off+4):0;
        size=n;capacity=cap;
        ++trace.constructed; trace.finished.push_back(static_cast<int>(off));
    }
    explicit Head(BorrowInput input) noexcept :arena_delta(0),data_delta(0),size(input.size),capacity(input.capacity) {
        const auto off=input.arena.index(this);
        arena_delta=static_cast<std::int32_t>(64*input.arena.allocator_id)-static_cast<std::int32_t>(off);
        data_delta=capacity ? static_cast<std::int32_t>(input.payload)-static_cast<std::int32_t>(off+4):0;
        ++trace.constructed; trace.finished.push_back(static_cast<int>(off));
    }
    std::size_t data_offset() const {
        auto& owner=Arena::containing(this);std::size_t result=0;
        if(!capacity)return 0;
        if(!checked_relative(Arena::extent,owner.index(this)+4,data_delta,capacity,1,1,result))
            throw std::logic_error("bad live binding");
        return result;
    }
    std::vector<std::byte> content() const {
        auto& owner=Arena::containing(this);auto off=data_offset();
        return {owner.bytes+off,owner.bytes+off+size};
    }
    void relinquish() noexcept {data_delta=0;size=capacity=0;}
    ~Head() noexcept {
        auto& owner=Arena::containing(this);
        if(capacity) owner.retire(data_offset());
        ++trace.destroyed;trace.retired.push_back(static_cast<int>(owner.index(this)));
    }
};
static_assert(sizeof(Head)==16 && alignof(Head)==8);
static_assert(!std::is_trivially_copyable_v<Head> && !std::is_trivially_default_constructible_v<Head>);
inline BorrowInput borrow_input(Arena& owner,const Input& input,std::size_t offset) {
    const auto size=input.scalar<std::uint32_t>(offset+8),cap=input.scalar<std::uint32_t>(offset+12);
    const auto delta=input.scalar<std::int32_t>(offset+4);
    std::size_t data=0;
    if(cap && !checked_relative(input.length,offset+4,delta,cap,1,1,data)) throw std::logic_error("borrow range");
    return {owner,data,size,cap};
}
template<class T> struct alignas(8) SequenceHeader {
    std::int32_t arena_delta=0,data_delta=0;
    std::uint32_t size=0,capacity=0;
};
template<class T> struct is_sequence:std::false_type{};
template<class T> struct is_sequence<SequenceHeader<T>>:std::true_type {using element=T;};
template<class T> std::string wire_type() {
    using U=std::remove_cv_t<T>;
    if constexpr(std::is_same_v<U,Head>) return "xstring[s:16,a:8]{arena:rel32,data:rel32,size:u32,capacity:u32}";
    else if constexpr(is_sequence<U>::value) return "xvector[s:16,a:8]{arena:rel32,data:rel32,size:u32,capacity:u32}<"+wire_type<typename is_sequence<U>::element>()+">";
    else if constexpr(std::is_array_v<U>) return "array["+std::to_string(std::extent_v<U>)+"]<"+wire_type<std::remove_extent_t<U>>()+">";
    else if constexpr(std::is_same_v<U,std::uint32_t>)return "u32";
    else if constexpr(std::is_same_v<U,std::uint16_t>)return "u16";
    else if constexpr(std::is_same_v<U,bool>)return "bool";
    else return Ops<U>::signature();
}
}
