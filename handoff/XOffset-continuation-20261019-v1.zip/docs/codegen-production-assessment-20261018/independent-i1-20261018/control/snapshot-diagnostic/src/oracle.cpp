#include "xoffsetdatastructure.hpp"
#include <iostream>
namespace i1 {
using Head=XOffsetDatastructure::XString;
template<class T> using SequenceHeader=XOffsetDatastructure::XVector<T>;
struct AdapterAllocator { std::uint32_t value; };
inline int custom_destructions=0;
}
#define I1_ORACLE
#include "types.hpp"
template<class T> void observe(const char* name) {
    constexpr bool bytes=boost::typelayout::is_byte_copy_safe_v<T>;
    constexpr bool wire=XOffsetDatastructure::is_v1_wire_admitted_v<T>;
    std::cout<<name<<"\t"<<bytes<<"\t"<<wire<<"\t"<<sizeof(T)<<"\t"<<alignof(T)<<"\t";
    if constexpr(wire) {
        constexpr auto signature=XOffsetDatastructure::wire_abi_signature<T>();
        std::cout<<std::string_view(signature);
    } else std::cout<<"not-admitted";
    std::cout<<"\n";
}
int main(){
    observe<i1::Mixed>("Mixed");observe<i1::Pair>("Pair");
    observe<i1::Direct>("Direct");observe<i1::Sequence>("Sequence");
    observe<i1::AllocatorOnly>("AllocatorOnly");observe<i1::ConstScalar>("ConstScalar");
    observe<i1::PrivateClosed>("PrivateClosed");observe<i1::CustomDtor>("CustomDtor");
}
