// New minimal reduction of I1 E-08..E-15; no allocator/runtime/generator dependency.
#include <cstddef>
#include <iostream>
#include <new>
#include <stdexcept>
namespace {
volatile int made=0,retired=0;
struct Leaf {
    Leaf(int ordinal){if(ordinal==2)throw std::runtime_error("second leaf");made=made+1;}
    Leaf(const Leaf&)=delete;
    ~Leaf(){retired=retired+1;}
};
struct Pair{Leaf left,right;};
struct Array{Leaf values[2];};
struct Matrix{Leaf values[1][2];};
Pair make_pair(){return Pair{Leaf(1),Leaf(2)};}
Array make_array(){return Array{{Leaf(1),Leaf(2)}};}
Matrix make_matrix(){return Matrix{{{Leaf(1),Leaf(2)}}};}
void construct(int shape,int form,void* memory){
    if(shape==0){
        if(form==0)::new(memory) Pair{Leaf(1),Leaf(2)};
        if(form==1)::new(memory) Pair(Pair{Leaf(1),Leaf(2)});
        if(form==2)::new(memory) Pair{{1},{2}};
        if(form==3)::new(memory) Pair(make_pair());
    }
    if(shape==1){
        if(form==0)::new(memory) Array{{Leaf(1),Leaf(2)}};
        if(form==1)::new(memory) Array(Array{{Leaf(1),Leaf(2)}});
        if(form==2)::new(memory) Array{{{1},{2}}};
        if(form==3)::new(memory) Array(make_array());
    }
    if(shape==2){
        if(form==0)::new(memory) Matrix{{{Leaf(1),Leaf(2)}}};
        if(form==1)::new(memory) Matrix(Matrix{{{Leaf(1),Leaf(2)}}});
        if(form==2)::new(memory) Matrix{{{{1},{2}}}};
        if(form==3)::new(memory) Matrix(make_matrix());
    }
}
}
int main(){
    for(int shape=0;shape<3;++shape)for(int form=0;form<4;++form){
        alignas(64) std::byte memory[64]{};made=retired=0;bool threw=false;
        try{construct(shape,form,memory);}catch(const std::runtime_error&){threw=true;}
        std::cout<<"{\"shape\":"<<shape<<",\"form\":"<<form<<",\"threw\":"<<threw<<",\"constructed\":"<<made<<",\"destroyed\":"<<retired<<"}\n";
    }
}
