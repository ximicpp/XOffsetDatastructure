"""Budgeted I1 executor: must be a foreground child of the existing shared runner."""
import hashlib
import importlib.util
import json
import os
import pathlib
import resource
import signal
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
REPO = ROOT.parents[2]
V5 = pathlib.Path('/mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发')
CLANG = REPO/'build/toolchains/linux-current-complete-v2-20261016/bin/clang++'
HIST = {'compiles':8,'processes':23,'cases':508,'active_seconds':79.00694717400279}
LIMIT = {'compiles':6,'processes':24,'cases':1024,'active_seconds':600,'disk':128*1024*1024,'rss':3*1024**3}
STATE = ROOT/'control/actual-budget.json'

def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

def manifest():
    files={'control/execute.py':sha(pathlib.Path(__file__).read_bytes())}
    for folder in ('src','generator','generated'):
        directory=ROOT/folder
        if directory.exists():
            for p in sorted(directory.rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts:
                    files[str(p.relative_to(ROOT))]=sha(p.read_bytes())
    return files

def disk_bytes():
    return sum(p.stat().st_size for p in ROOT.rglob('*') if p.is_file())

def rss_tree():
    """Observe this executor and descendants without changing their POSIX session."""
    entries={}
    for path in pathlib.Path('/proc').iterdir():
        if not path.name.isdigit():continue
        try:
            stat=(path/'stat').read_text();tail=stat[stat.rfind(')')+2:].split()
            entries[int(path.name)]=(int(tail[1]),int(tail[21])*os.sysconf('SC_PAGE_SIZE'))
        except (FileNotFoundError,PermissionError,ProcessLookupError,ValueError,IndexError):continue
    owned={os.getpid()}
    changed=True
    while changed:
        before=len(owned)
        owned.update(pid for pid,(ppid,_) in entries.items() if ppid in owned)
        changed=len(owned)!=before
    return max((entries[p][1] for p in owned if p in entries),default=0)

def case_manifest():
    shapes=['Pair','Direct','Nested','Tagged']
    groups={}
    groups['A']=[{'shape':s,'check':c} for s in ['Mixed','Pair','Direct','Sequence','AllocatorOnly','ConstScalar'] for c in ['field-closure','layout','construct','signature-classification']]
    groups['B']=[{'shape':s,'payload':p,'overwrite':v} for s in shapes for p in ['empty','nonempty','spare'] for v in ['5a','a5']]
    groups['C']=[{'path':p,'element':s} for p in ['fresh','empty-capacity','same-reuse','different-reuse','tail-expand','erase-rebuild','relocate','clear-regrow'] for s in ['u32','Head','Pair','Nested']]
    groups['D']=[{'relation':r,'shape':s} for r in ['same-allocator','cross-owner','different-allocator','ancestor','descendant','self'] for s in shapes]
    groups['E']=[{'failure':p,'shape':s} for p in ['payload-1','leaf-1','leaf-2','payload-2-after-prefix','scratch','publish'] for s in shapes]
    floats=['positive-zero','negative-zero','min-subnormal','max-finite','positive-infinity','negative-infinity','qnan-payload','snan-payload']
    groups['F']=[{'type':t,'bits':p} for t in ['float','double'] for p in floats]+[
        {'policy':p} for p in ['const-int','const-float','volatile','private-factory','private-closed','custom-dtor','allocator-only','aggregate-prvalue']]+[
        {'bool':v,'nesting':s} for s in ['scalar','nested'] for v in [0,1,2,255]]+[
        {'boundary':p} for p in ['overlapping-owner','overlapping-empty','overaligned','enum-unnamed','enum-min','enum-max','array-stride','const-member-replacement']]
    groups['G']=[{'origin':o,'offset':d} for o in ['base','head','near-end'] for d in ['zero','plus-one','minus-one','int32-min','int32-max','last-valid','one-past','multiply-overflow']]+[
        {'vm':p} for p in ['reserve','commit','grow','decommit','recommit','reuse','maximum','failure']]
    groups['H']=[{'stage':s,'observation':o} for s in ['header','graph','restore','publish'] for o in ['root','modify','save','cleanup']]
    result=[{'id':f'{g}-{i:02d}','group':g,'parameters':p,'known_ub_execution':False} for g,items in groups.items() for i,p in enumerate(items)]
    assert len(result)==216 and len({r['id'] for r in result})==216
    return result

class Executor:
    def __init__(self):
        self.ledger=json.loads(STATE.read_text()) if STATE.exists() else {'stage':{'compiles':0,'processes':0,'cases':0,'active_seconds':10},'prelease_active_allowance_seconds':10,'jobs':[],'peak_rss_bytes':0,'approved':True,'historical':HIST,'limits':LIMIT}
        self.started=time.monotonic();self.previous=self.ledger['stage']['active_seconds'];self.peak=0
    def record(self):
        self.ledger['stage']['active_seconds']=self.previous+time.monotonic()-self.started
        self.ledger['peak_rss_bytes']=max(self.ledger['peak_rss_bytes'],self.peak,resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss*1024)
        self.ledger['disk_bytes']=disk_bytes()
        save(STATE,self.ledger)
    def check(self):
        self.record()
        for name in ['compiles','processes','cases','active_seconds']:
            if self.ledger['stage'][name]>LIMIT[name]:raise RuntimeError('budget exceeded: '+name)
        if self.ledger['disk_bytes']>LIMIT['disk']:raise RuntimeError('disk budget exceeded')
    def job(self,label,argv,kind='tooling',cases=0,timeout=30):
        self.check();stage=self.ledger['stage']
        increments={'compiles':int(kind=='compile'),'processes':int(kind=='test'),'cases':cases}
        for name,increment in increments.items():
            if stage[name]+increment>LIMIT[name]:raise RuntimeError('budget cannot admit '+label+': '+name)
        if stage['active_seconds']>=LIMIT['active_seconds']:raise RuntimeError('no active-time budget')
        for name,increment in increments.items():stage[name]+=increment
        run_dir=ROOT/'runs'/f'{len(self.ledger["jobs"])+1:02d}-{label}';run_dir.mkdir(parents=True,exist_ok=False)
        job={'label':label,'argv':[str(x) for x in argv],'kind':kind,'case_charge':cases,'directory':str(run_dir.relative_to(ROOT)),'status':'admitted'}
        self.ledger['jobs'].append(job);self.record()
        begin=time.monotonic()
        env=dict(os.environ);env.update(PYTHONDONTWRITEBYTECODE='1',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:abort_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
        with (run_dir/'stdout.txt').open('wb') as stdout,(run_dir/'stderr.txt').open('wb') as stderr:
            process=subprocess.Popen(job['argv'],cwd=ROOT,stdout=stdout,stderr=stderr,env=env)
            try:
                while process.poll() is None:
                    self.peak=max(self.peak,rss_tree())
                    elapsed=time.monotonic()-begin
                    if elapsed>timeout or self.previous+time.monotonic()-self.started>LIMIT['active_seconds'] or self.peak>LIMIT['rss']:
                        process.terminate();job['status']='resource-stop';raise RuntimeError('resource stop: '+label)
                    time.sleep(.04)
                job['returncode']=process.returncode;job['status']='complete' if not process.returncode else 'failed'
            finally:
                job['wall_seconds']=time.monotonic()-begin;self.record();save(run_dir/'job.json',job)
        print(json.dumps({'job':label,'status':job['status'],'budget':dict(stage)}),flush=True)
        return process.returncode

def prepare(executor):
    # This file is only launched under the real global runner; enforce a distinct session ancestor.
    parent_command=pathlib.Path(f'/proc/{os.getppid()}/cmdline').read_bytes()
    if os.getsid(0)!=os.getpid() or b'run_job.py' not in parent_command or b'_worker' not in parent_command:
        raise RuntimeError('expected runner-owned command session and supervisor parent')
    identities={
        V5/'xoffsetdatastructure.hpp':'c4acc7f2005711452e12f0cd7c5d7bc57efe2d4ca0fabc207b6f711b1dbb9964',
        V5/'xoffset_virtual_memory.hpp':'22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad'}
    for p,expected in identities.items():
        actual=sha(p.read_bytes())
        if actual!=expected:raise RuntimeError('oracle identity conflict: '+str(p))
    if not pathlib.Path('/usr/bin/g++').is_file() or not CLANG.is_file():raise RuntimeError('fixed compiler missing')
    save(ROOT/'control/input-identities.json',{str(p):value for p,value in identities.items()} | {str(CLANG):sha(CLANG.read_bytes()),'/usr/bin/g++':sha(pathlib.Path('/usr/bin/g++').read_bytes())})
    save(ROOT/'control/cases-frozen.json',case_manifest())
    for label,argv in [('gcc-version',['/usr/bin/g++','--version']),('oracle-version',[CLANG,'--version'])]:
        if executor.job(label,argv):raise RuntimeError('compiler profile unavailable')
    if executor.job('generator-control',[sys.executable,ROOT/'generator/generate.py','control',ROOT/'src/schema.json'],'test',12):
        raise RuntimeError('generator negative control failed')
    spec=importlib.util.spec_from_file_location('i1_independent_generator',ROOT/'generator/generate.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    output=ROOT/'generated';output.mkdir(exist_ok=False)
    for name,data in module.emit(json.loads((ROOT/'src/schema.json').read_text())).items():(output/name).write_bytes(data)
    save(ROOT/'control/source-manifest.json',manifest())

def snapshot(label):
    dest=ROOT/'control'/label;dest.mkdir(exist_ok=False)
    for relative,expected in manifest().items():
        source=ROOT/relative;target=dest/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
        if sha(target.read_bytes())!=expected:raise RuntimeError('snapshot differs')
    save(dest/'manifest.json',manifest());return dest

def build(executor,snap,profiles):
    output=ROOT/'build';output.mkdir(exist_ok=True)
    for profile in profiles:
        if profile=='oracle':
            argv=[CLANG,'-std=c++26','-freflection','-fexpansion-statements','-stdlib=libc++','-O1','-pthread','-iquote',V5,'-I',V5/'external/typelayout/include','-I',snap/'generated',snap/'src/oracle.cpp','-o',output/'oracle']
        else:
            argv=['/usr/bin/g++','-std=c++20','-fno-elide-constructors','-fno-fast-math','-g','-I',snap/'generated',snap/'src/trials.cpp','-o',output/profile]
            argv+=['-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer','-fno-pie','-no-pie'] if profile=='san' else ['-O2']
        argv+=['-MMD','-MF',output/(profile+'.d')]
        if executor.job('compile-'+profile,argv,'compile',timeout=240):return False
        save(output/(profile+'-identity.json'),{'binary_sha256':sha((output/profile).read_bytes()),'snapshot':str(snap.relative_to(ROOT)),'snapshot_manifest':sha((snap/'manifest.json').read_bytes()),'argv':[str(x) for x in argv]})
    return True

def run(executor,profiles,full=False):
    for profile in profiles:
        if profile=='oracle':
            executor.job('oracle-observations',[ROOT/'build/oracle'],'test',24)
        elif full:
            executor.job(profile+'-all',[ROOT/'build'/profile,'all'],'test',216)
        else:
            for group,count in zip('ABCDEFGH',[24,24,32,24,24,40,32,16]):
                if executor.job(profile+'-'+group,[ROOT/'build'/profile,group],'test',count):
                    # Preserve the first failure and stop dependent testing until it is diagnosed.
                    return False
    return True

def main():
    executor=Executor()
    try:
        mode=sys.argv[1]
        if mode=='initial':
            prepare(executor);snap=snapshot('snapshot-initial')
            if not build(executor,snap,['ordinary','san','oracle']):return 1
            return 0 if run(executor,['ordinary','san','oracle']) else 1
        if mode=='repair':
            profiles=sys.argv[2:];snap=snapshot('snapshot-repair-'+str(executor.ledger['stage']['compiles']))
            if not build(executor,snap,profiles):return 1
            return 0 if run(executor,profiles,True) else 1
        if mode=='resume':return 0 if run(executor,sys.argv[2:]) else 1
        if mode=='audit':
            executor.check();save(ROOT/'control/final-source-manifest.json',manifest());return 0
        raise RuntimeError('unknown mode')
    except Exception as error:
        executor.ledger['stop_reason']=str(error);print(str(error),file=sys.stderr);return 1
    finally:executor.record()

if __name__=='__main__':raise SystemExit(main())
