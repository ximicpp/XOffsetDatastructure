# I1 结果：首选构造路线未通过，停止进入 I2

日期：2026-10-18。开发分支 `codex/offline-codegen-cpp20-20261018`。授权见 [APPROVAL.md](APPROVAL.md)；事前范围见 [SCOPE_AND_BUDGET.md](SCOPE_AND_BUDGET.md)。

**结论：在事前选定的 WSL x86_64 GCC 11.4 profile 上，当前“外部完整 aggregate 构造 + 可抛 owning 元素初始化”路线被否决。I1 未通过，I2 不准入。不是普通 C++20 所有独立实现都不可行的结论。**

没有换编译器、升级标准、添加业务 record 构造函数、改成 trivial-only/proxy 或改动旧合法域。没有为了消除失败手动析构未完成 record 的成员。新增源代码、生成器、测试、构建和证据均位于本独立目录；生产库、demo、V6、固定依赖和既有共享协调器未修改。未提交或推送。

## 实际阻断点

普通版 `E-08..E-15` 共 8 个用例失败，分别是 4 种 owning 布局在第二叶构造抛出、第二次 payload 分配抛出时的前缀清理。错误是 `exception prefix leak`；首叶已构造/申请 payload，第二叶失败后成功前缀没有被析构清理。

在独立的 `diagnostic_forms.cpp` 中移除 arena、rel32、生成器、输入读取与 owning 分配，只留下两个不可复制的 Leaf 和析构计数。三种布局（record、array、matrix）× 四种表达式（直接 prvalue、外层同型 prvalue、成员直接列表、工厂 prvalue），共 12 个固定诊断，全部实际观察到：

```text
第二叶抛出 = true
成功构造 Leaf = 1
析构 Leaf = 0
```

最小构造使用对齐 byte-array 和 placement new，不依赖可选 NRVO。诊断编译命令固定为 GCC 11.4、`-std=c++20 -O2 -fno-elide-constructors`。这把原因收敛到选定编译器/profile 对这组初始化表达式的异常清理行为，未证明具体对应哪个 GCC 缺陷号。

[C++20 except.ctor/3](https://timsong-cpp.github.io/cppwp/n4861/except.ctor#3) 要求初始化异常时清理已经完成初始化的直接子对象。GCC 的 [PR66139 相关状态记录](https://gcc.gnu.org/pipermail/gcc-bugs/2022-January/771956.html) 和 [GCC 12 aggregate 初始化清理修正](https://gcc.gnu.org/pipermail/gcc-cvs/2022-January/358832.html) 是同类问题的外部佐证，不是本机精确缺陷归属或其他版本通过证据。没有下载、更换或运行其他普通编译器。

已有 SAN 二进制仅对 E 组作一次必要确认：同样的 8 个用例失败；ASan/UBSan 没有额外诊断。arena 内部 live-block 和析构计数断言能发现这次问题，不能以 sanitizer 沉默覆盖失败。

## 实际执行范围及剩余责任

| 内容 | 实际结果 |
|---|---|
| 新 JSON IR 与生成器 | 12 个负控通过；包含陈旧输出、padding bool、嵌套 owning 漏项、篡改、顺序、缺文件、profile、未知类型、重复字段、零数组、递归、来源身份 |
| 普通候选 | A–E 共登记处理 128 个 ID：82 个局部断言通过、26 个未证明、12 个在静态门停止而未执行、8 个失败 |
| SAN 候选 | 只确认 E 组 24 个 ID：16 个局部断言通过、8 个失败；其余 192 个没有执行 |
| F/G/H | 普通版 88 个 ID 因先到达否决门未启动；不能从源码存在推断运行通过 |
| 最小诊断 | 12/12 复现已构造前缀未析构 |
| V5 oracle | 8 个新声明形态、24 项扣数；只观察分类/实际布局/签名，不运行旧未证明的恢复路径 |

全部 216 个候选 ID 仍保留在 `control/cases-frozen.json`，普通/SAN 每格的结果与未执行原因汇总在 `control/case-results.json`。`pass` 是固定夹具的局部规则与运行一致，不表示整体类型、容器或完整图已获得资格。原始 A 组的分类检查仍标未证明；后置 oracle 的签名相等不能替代新公开 trait 实现。

在 A–D 已实际运行的局部切片中，受控完整 aggregate 构造、独立输入恢复、部分 fresh/reuse 路径和部分所有权操作得到有限运行证据；这不闭合原地尾扩、真正的 ancestor/descendant 嵌套事务、无分配 relocation、旧源可复用语义或全部旧类型。

`PrivateClosed` 的旧公开 byte-copy 和 V1 准入均为真，但新生成器没有合法完整构造适配；这仍是开放项，不能把它列为旧类型非法。const float、volatile 表示和潜在重叠非平凡成员同样没有被静默删除。旧 trait/签名通过不证明旧全部 API 已可实例化或符合对象模型。

## 只读兼容观察

V5 主头在租约内重新核对，SHA-256 为 `c4acc7f2005711452e12f0cd7c5d7bc57efe2d4ca0fabc207b6f711b1dbb9964`。候选与 oracle 分离 TU、分离进程，不链接或 include 旧实现。

- Mixed、Pair、Sequence、AllocatorOnly、ConstScalar 的实际 sizeof/alignof 和完整签名文字相等，共 5 个已准入形态；不是只比较 hash。
- Direct 的布局为 32/8，但旧公开 byte-copy 与 V1 准入均为 false，保留为负对照，不能算 V1 正例。
- PrivateClosed、CustomDtor 的旧准入均为 true；本次未取得对应的新消费端完整资格，不能宣称覆盖。
- Sequence 的新消费端在 I1 只是头布局夹具，未证明完整 sequence 元素生命周期。

没有执行完整 V1 writer/reader、双向修改回传、完整恶意图校验或原生 Windows。普通/SAN 的 compiler 非系统依赖闭包只有本目录内的 trials.cpp、runtime.hpp、generated/types.hpp，普通消费端无 TypeLayout/P2996/V5 依赖。

## 预算、租约和保存状态

| 资源 | 本次 I1 消耗 | 历史加本次 | 已批准上限 |
|---|---:|---:|---:|
| TU 编译调用 | 4：普通、SAN、oracle、最小诊断 | 12 | 14 |
| 被测进程 | 9 | 32 | 累计 64；I1 上限 24 |
| 固定用例扣数 | 200 | 708 | 累计 1536；I1 上限 1024 |

200 次扣数包括生成器 12 + 普通 A–E 128 + 最小诊断 12 + SAN E 24 + oracle 24。失败请求仍扣整个登记组；没有退回失败或静态停止 ID 的扣数。第三个修复预留编译调用用于上述必要最小诊断，未增加 6 次 I1 硬上限，也未发生修复复编。编译器子进程按 TU 调用归类，版本查询及 receipt checksum 审计作为 tooling 逐 job 记录，不伪装成被测进程。

主动执行、RSS 和文件实际值见 `control/actual-budget.json`；计入准备及收尾各 10 秒的保守额度，租约等待/人工分析分开。没有耗尽预算；停止原因是已登记的生命周期否决，而非资源不足。剩余 2 次累计编译额度保留，未盲目尝试第四种替换实现。

所有生成、编译、测试、集合哈希/扫描与审计均先取得同一个共享 `queue.lock`，每个窗口使用新 receipt：`lease-initial`、`lease-diagnostic`、`lease-confirm`、`lease-audit`。前三个完成的 receipt 还在最后的租约内通过官方 runner 离线校验。执行成功/receipt 校验成功只说明对应命令结束和证据一致，不代表 I1 通过。

原始失败输出、首次生成文件与输入快照、四份二进制及其身份均保存；没有覆盖失败构建。新控制器增加审计/诊断调度，候选实际消费源与首次编译快照一致，逐依赖核对见 `result.json`。最终输出的全量结果和证据清单分别为 `result.json` 与 `control/evidence-inventory.json`。

后续若重新设计，应首先证明在保持 aggregate、最终地址构造和原异常契约下，如何避免此 profile 的缺陷；可评估在完整对象构造前准备全部可抛资源，但不能只把抛出点挪走或宣布自定义构造不抛。数组尾扩、CV/private 与地址来源仍各自需要闭合。当前不自动进入 I2，也不把更换 profile 或删减类型域当作修复。
