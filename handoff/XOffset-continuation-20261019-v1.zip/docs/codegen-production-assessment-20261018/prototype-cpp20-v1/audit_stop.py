from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
V5=Path('/mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发')
def fid(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
expected={V5/'xoffsetdatastructure.hpp':'c4acc7f2005711452e12f0cd7c5d7bc57efe2d4ca0fabc207b6f711b1dbb9964',V5/'xoffset_virtual_memory.hpp':'22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad',ROOT/'xoffsetdatastructure.hpp':'9bc8f1f533bee83a9e111e05d67319383775dbca1844ef33b1aa717047640bb2',ROOT/'xoffset_virtual_memory.hpp':'22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad'}
protected=[fid(p) for p in expected]
for row in protected:assert row['sha256']==expected[Path(row['path'])],row['path']
deps=(HERE/'bin/new-v2.d').read_text().replace('\\\n',' ').split(':',1)[1].split()
closure=sorted({Path(p).resolve() for p in deps})
assert len(closure)==6
assert not any('external/typelayout' in str(p) or 'experimental/meta' in str(p) for p in closure)
# Source identity for the executed binary is its saved compile-input snapshot.
snapshot=HERE/'runs/gcc20-v2/inputs'
compiled=[fid(snapshot/p.relative_to(HERE)) for p in closure]
record={'status':'stopped_without_acceptance','selected_protected_headers_match':True,'protected_headers':protected,'ordinary_actual_non_system_include_closure':[str(p) for p in closure],'executed_binary':fid(HERE/'bin/new-v2'),'executed_compile_input_files':compiled,'current_driver_matches_executed_snapshot':(HERE/'driver.cpp').read_bytes()==(snapshot/'driver.cpp').read_bytes(),'successful_old_oracle':False,'bidirectional_wire_executed':False,'sanitizer_executed':False,'native_windows_executed':False,'preservation_scope':'selected headers and this prototype only; no full-workspace audit; no claim that concurrent V6 remained static'}
(HERE/'stop-audit.json').write_text(json.dumps(record,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'selected_header_identities':'match','ordinary_include_files':len(closure),'driver_snapshot_differs':not record['current_driver_matches_executed_snapshot'],'prototype_accepted':False}))
