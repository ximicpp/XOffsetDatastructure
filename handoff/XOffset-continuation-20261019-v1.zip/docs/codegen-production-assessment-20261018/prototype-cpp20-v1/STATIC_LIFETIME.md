# C++20 静态门与审查清单

这是原型候选的设计论证和待验收边界，不是运行或生产支持证明。生成器只读schema；普通backend不依赖旧反射导出。旧P2996只用于真实V5 oracle。

## 完整元数据

schema中每个record的fields是唯一声明来源。同一循环生成字段声明、按原序排列的member-pointer/decltype/offsetof元数据以及make/transfer/restore/relocate初始化列表。递归byte-safety、admission、signature、alias、validation、compaction均从该tuple取字段；不得另写一份易漏清单。新定义不含继承、隐藏字段、vptr或基类，固定库容器仍为精确识别的旧族。生成物检查以完整重生成字节比较拒绝旧输出和人工篡改；注入落在padding的bool也必须被检出。

byte-safety从全部字段及明确冻结的容器header标量/元素边递归求解。LocalNode的环只在访问过完整节点后作为图固定点终止，其他所有边仍被检查；没有手写safe=true覆盖。LocalNode只用于局部alias试验，不注册其无限递归V1 signature，也不声称V1支持递归schema。旧测试曾用手工safe特化的LocalNode，本原型不沿用那个特化。

## 构造与恢复路径

| 路径 | 当前候选处理 | 核查点 |
| --- | --- | --- |
| Fresh arena header | VM逻辑范围上的memmove创建触发后访问trivial header | 不仅凭OS返回地址或launder假定对象已存在 |
| 普通record创建 | make-tag placement构造完整T；初始化列表按字段顺序构造子对象 | 原有allocator ctor优先；原反射零填/字段默认初始化顺序保留；不运行outer默认构造绕过原分派 |
| Copy/transfer | transfer-tag完整构造；allocator-aware字段按原allocator策略深复制 | 语言保证前缀逆序析构，字段失败不发布T；绑定arena的对象不在栈临时持有 |
| Loaded header/allocator | memcpy触发trivial对象创建；容器/record在此时仍只作为bytes | header、allocator、完整graph均先验证，不形成T引用或调用container方法 |
| Loaded record | 保存sizeof(T)有界inline表示，restore-tag完整构造T | 不把逐成员placement等同完整对象；root offset/sizeof/align与wrapper不变 |
| Loaded container head | 原16字节头的四个标量经restore构造初始化，payload不分配 | 不调用普通bind覆写头；最终对象地址就是rel32原点 |
| Loaded dynamic elements | 用头字段作char地址计算，逐活元素restore完整对象，再递归payload | 在第一个非平凡元素出现前不调用data()中的launder；capacity未用区不析构 |
| Fresh/reused vector storage | dynamic分配返回前使用memmove创建触发；数组对象与非平凡元素分别处理 | array是implicit-lifetime，元素仍由完整make/transfer/relocate placement创建 |
| 原地扩容 | 范围memmove触发新capacity数组；非平凡活元素同地址restore其inline表示 | 不执行用户普通ctor或析构副作用，不重新复制其out-of-line payload；旧元素借用按容器变更失效契约处理 |
| 同arena relocate | owning头新构造、rel32重算、源payload状态清空；record用完整relocate-tag构造 | 先通过原nothrow及alias/provenance门；不分配；源析构不重复退休 |
| free-list node再利用 | 退休时placement构造FreeBlockHeader；新payload分配时再次触发存储类型创建 | 不能launder已被非平凡payload覆盖的旧header |
| owner销毁/失败 | owner整体释放仍沿用旧契约；单元素/数组失败只析构已建前缀 | 不声称会统一执行所有用户root析构副作用；不让析构跟随未验证输入 |

依据：[C++20草案 basic.life](https://timsong-cpp.github.io/cppwp/n4861/basic.life)、[expr.add](https://timsong-cpp.github.io/cppwp/n4861/expr.add)和[ptr.launder](https://timsong-cpp.github.io/cppwp/n4861/ptr.launder)。数组对象的创建不等于非平凡元素的创建；`launder`有现存对象前提。隐式创建触发与恢复表示的设计依据见[WG21 P0593R6](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2020/p0593r6.html)。以上为本候选的具体推导，不把提案当现有库自动正确的证明。

## 必须保持的验证与失败契约

旧V5的header错误顺序、allocator先于容器、owned全局优先、精确byte membership、dense预算、bool/排序/空绑定及allocator accounting保留。raw validator用原引擎注册范围，不以额外预扫描或新拒绝条件代替。签名的field offset由各目标编译器计算，保留全部旧文字和FNV顺序。snapshot仍为owning全量复制，普通save不压缩活图。

原型必须运行旧↔新、初始/修改后/再修改、compact后回存、完整malformed差分、OOM与构造抛出清理。sanitizer只是动态检查，不是生命周期证明；出现静态反例同样否决，即使程序跑通。

## 明确尚未完成的覆盖

本次有限schema的metadata完整性不等于已导入任意旧合法C++定义。私有访问、opaque定制、额外属性、特殊比较器及全部CV操作域尚未证明；旧合法性不因此被改写。当前raw comparator只实现本次string及scalar/enum key切片，其他旧合法比较器有明确编译拒绝，不作生产替代支持声明。

CV样例参与定义/布局元数据，不据此承诺所有const/volatile操作及浮点特殊位表示已证明。value初始化恢复float的精确表示与异常环境、长寿pool复用、原生ARM64也需后续独立验证。任何结果报告须保留这些未覆盖项，不以小型测试通过宣称完整合法域生产化完成。

Windows原生MSVC可发现，但既有POSIX租约runner无法证明Windows子树取消清理；当前worker明确拒绝.exe子进程。不能在WSL持锁后把未受监督Windows编译藏进shell。本次先推进能在现有runner内得到真实绑定与资源监督的C++20检查，Windows门若无已验收适配则维持阻塞，整体原型不虚报全门通过。
