# C++20 原型 v1：部分机制通过，兼容准入门失败，按预算停止

日期：2026-10-18。**本次原型未验收通过；尚未执行V5↔新backend双向wire或sanitizer。** 没有以同机新↔新roundtrip替代V1证明，没有改生产库/demo/V6，没有通过扩大预算或缩减输入域取得通过。

## 已完成与实际结果

| 项 | 结果 | 证据 |
| --- | --- | --- |
| 固定V5身份 | 主头c4acc7f2…b9964及VM头与事前身份一致，根目录F另列 | [source-inputs](source-inputs.json)、[stop-audit](stop-audit.json) |
| 普通生成器 | Python运行，无P2996生成输入；同schema生成定义/完整字段tuple/四种构造入口 | [generate.py](generate.py)、[schema.json](schema.json)、[generated_schema.hpp](generated_schema.hpp) |
| 生成检查 | 7项检查通过，含5个负控：padding字段变更、篡改metadata、缺失输出、未知隐藏字段属性、原生pointer语法；前3项记录实际拒绝错误 | [generator-check](generator-check.json)、[运行日志](runs/generator-controls-v1/stdout.log) |
| 普通C++20编译 | GCC 11.4.0、-std=c++20 -O1成功；非system include闭包为本原型6文件，无TypeLayout include | [成功请求](runs/gcc20-v2/request.json)、[依赖文件](bin/new-v2.d)、[编译器版本](runs/gcc-version/stdout.log) |
| 新backend机制自测 | 同owner转移和binding复用、跨owner深复制、OOM逻辑强保证及显式grow重试、构造前缀/数组异常清理、owned全局优先、祖先/后代copy-before-retire均返回self-ok | [历史输入snapshot](runs/gcc20-v2/inputs/driver.cpp)、[自测日志](runs/gcc20-self-v1/stdout.log)、[回执](runs/gcc20-self-v1/result.json) |
| V5 oracle | 两次均编译失败，无可执行oracle | [第一次错误](runs/v5-oracle-v1/stderr.log)、[第二次错误](runs/v5-oracle-v2/stderr.log) |
| V1准入等价 | **失败**：新算法接受Moves中的非平凡inline数组，旧V5实际拒绝 | [第四次诊断](diagnosis-compile-4.json) |
| V1签名全文/双向/修改后回传/恶意输入差分 | 驱动已写，**未执行**，不能填写兼容通过 | [driver.cpp](driver.cpp) |
| 生命周期证明 | 完整对象restore/relocate及异常机制有初步动态结果；数组与旧准入的组合、特殊表示和全域仍未闭合 | [静态清单及限制](STATIC_LIFETIME.md) |
| Sanitizer | 未编译、未运行，不作通过声明 | 编译预算不足，不转移为普通运行替代 |
| Native Windows | 未执行；当前POSIX租约无原生子树清理适配 | [静态清单](STATIC_LIFETIME.md) |

成功的`new-v2`绑定的是`runs/gcc20-v2/inputs/`中的实际输入。其后driver已加强load与mutation失败的分离处理，该最新版**尚未重新编译**，不能引用self-ok声称当前所有源码通过。

## 三次失败如何解释

1. GCC20 v1：测试驱动两个依赖成员模板调用遗漏`template`关键字。修复后GCC20 v2编译通过，失败输入/日志不覆盖。[诊断](diagnosis-compile-1.json)。
2. V5 oracle v1：`-I`指向大小写不敏感的/mnt/c工作区，`VERSION`遮蔽标准`<version>`。后续改`-iquote`解决搜索范围；未重命名任何旧文件。[诊断](diagnosis-compile-3.json)。
3. V5 oracle v2：共同fixture的CtorProbe默认构造声明不一致，旧侧数组DMI无效；同时Moves被真实旧byte-copy/V1静态准入拒绝。后者是新的实质反例，不是继续重复同一失败命令可以解决。[诊断](diagnosis-compile-4.json)。

TypeLayout实装细节：`all_members_byte_copy_safe`调用内部`is_byte_copy_safe_impl<FieldType>()`；对于非平凡array，trivial快路不成立，array又不是class/union，因此落入false。公开的`is_byte_copy_safe<T[N]>`元素特化是另一条路径。当前新metadata把二者统一递归，产生更宽准入。这说明“生成了全部字段”仍不等于“保留了现有V1准入语义”。固定依赖保持原样，不能加unsafe trait让旧oracle放行，也不能删掉owning-array生命周期覆盖。

对应源码：[TypeLayout admission.hpp](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/admission.hpp:32)；内部决策树在71行，公开array特化在124行。当前候选的[统一递归](metadata.hpp)必须修正，而不是先宣称兼容。

## 实际资源与隔离

- 编译：**4/6**，1次成功、3次失败；被测进程：**2/64**（生成器检查与普通C++20机制自测）；固定case保守记账19/512。
- 编译+被测运行约11.891秒；连同准备、工具版本和收尾审计，active wall **13.079秒**。这些只用于资源预算，不是性能测量。
- 累计子进程最大RSS **336,158,720 bytes（约320.6MiB）**，低于3GiB；收尾审计时新增文件约2MiB，远低于512MiB。没有工具下载、fuzz/profile、正式计时或后台重任务。
- 全部复制、生成检查、编译、原型运行与收尾hash均在一个全局validation租约内执行。run_id `6ea4d72d566c429e885fb6b03f713e2c`，UTC **08:04:38–08:17:46**（北京时间16:04:38–16:17:46），租约内command wall 788.390秒，小于1200秒。
- [租约最终回执](lease-v1/result.json)记录live/process_groups/zombies均为空；租约已释放。回执status=complete表示监督任务正常结束及无遗留进程，**不表示原型功能/兼容验收通过**。
- [收尾审计](stop-audit.json)确认两个选定V5头及根目录两头仍为事前身份；没有全仓扫描，不声称并行V6文件保持静止。所有原型文件只在本目录，未提交、推送、发布或触发远端CI。

## 为什么剩2次就停止

修正后至少要编译旧oracle、新backend、sanitizer各一次，共3次；当前6次总上限只剩2次。继续执行不能在原预算内完成全部必需门禁。依照用户“预算不足先说明，不自行降级”，没有消耗剩余次数后再要求追认，也没有跳过sanitizer或删除数组/异常case。

具体修正、仍未知项及预算提案见[REPAIR_PLAN.md](REPAIR_PLAN.md)：最小总上限需7次；建议总8次（增加2次，保留1次根因明确的修复余量），其他资源上限不变。未来重新获取全局共享租约，不复用已结束租约。没有该预算调整前，不继续编译/测试。

当前结论：普通C++20生成/backend的若干机制已有可运行证据；**“按既有V1语义可无差异替换”尚不成立，整体原型仍未通过**。该失败不证明离线代码生成路线不可行，但要求下一候选精确建模TypeLayout实际行为，再进行双向wire验证。
