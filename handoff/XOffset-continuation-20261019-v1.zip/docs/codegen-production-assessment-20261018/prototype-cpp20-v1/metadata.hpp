#pragma once
// Ordinary C++20 metadata. No P2996 include, parsing, or runtime dependency.
#include <tuple>
#include <array>
#include <type_traits>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <string_view>
#include <limits>
#include <utility>
namespace prototype {
struct make_tag {};
struct transfer_tag {};
struct restore_tag {};
struct relocate_tag {};
template<class T> struct record; // Deliberately incomplete for ungenerated types.
template<class T> concept described = requires { record<std::remove_cv_t<T>>::fields; };
template<class T, class M, M T::* Pointer, std::size_t Offset> struct field {
    using type = M;
    static constexpr auto offset = Offset;
    template<class U> static decltype(auto) get(U&& value) { return std::forward<U>(value).*Pointer; }
};
template<class T, std::size_t I> using field_at = std::tuple_element_t<I, decltype(record<std::remove_cv_t<T>>::fields)>;
template<class T> constexpr std::size_t field_count = std::tuple_size_v<decltype(record<std::remove_cv_t<T>>::fields)>;
template<class T> struct byte_safe;
template<class T> struct edges;
template<class T> inline constexpr bool kv=false;
template<class T> inline constexpr bool byte_safe_v = byte_safe<T>::value;
template<class T, class... Seen> consteval bool check_safe() {
    using U = std::remove_cv_t<T>;
    if constexpr (std::is_pointer_v<U> || std::is_reference_v<U> || std::is_member_pointer_v<U> || std::is_union_v<U> || std::is_polymorphic_v<U>) return false;
    else if constexpr ((std::is_same_v<U, Seen> || ...)) return true; // Finite generated type-graph fixed point; all other edges are still checked.
    else if constexpr (std::is_arithmetic_v<U> || std::is_enum_v<U> || std::is_same_v<U, std::byte>) return true;
    else if constexpr (std::is_array_v<U>) return check_safe<std::remove_extent_t<U>, Seen..., U>();
    else if constexpr (requires { typename edges<U>::types; }) return []<class... E>(std::tuple<E...>*) {
        return (check_safe<E, Seen..., U>() && ...);
    }(static_cast<typename edges<U>::types*>(nullptr));
    else if constexpr (described<U>) return []<std::size_t... I>(std::index_sequence<I...>) {
        return (check_safe<typename field_at<U,I>::type, Seen..., U>() && ...);
    }(std::make_index_sequence<field_count<U>>{});
    else return false;
}
template<class T> struct byte_safe : std::bool_constant<check_safe<T>()> {};

template<class T> T read_scalar(const void* p) noexcept {
    static_assert(std::is_trivially_copyable_v<T> && !std::is_volatile_v<T>);
    T value; std::memcpy(&value, p, sizeof(T)); return value;
}
template<std::size_t N> struct FixedString {
    char value[N+1]{};
    constexpr FixedString() = default;
    constexpr FixedString(const char (&s)[N+1]) { for(std::size_t i=0;i<=N;++i)value[i]=s[i]; }
    template<std::size_t M> constexpr auto operator+(const FixedString<M>& b) const {
        FixedString<N+M> out;
        for(std::size_t i=0;i<N;++i)out.value[i]=value[i];
        for(std::size_t i=0;i<=M;++i)out.value[N+i]=b.value[i];
        return out;
    }
    constexpr operator std::string_view() const { return {value,N}; }
    constexpr const char* c_str() const { return value; }
};
template<std::size_t N> FixedString(const char (&)[N])->FixedString<N-1>;
consteval std::size_t digits(std::size_t n) {std::size_t d=1;while(n>=10){n/=10;++d;}return d;}
template<std::size_t V> consteval auto to_fixed_string() {
    FixedString<digits(V)> out; auto v=V;
    for(std::size_t i=digits(V);i>0;--i){out.value[i-1]=char('0'+v%10);v/=10;}
    return out;
}
// Definitions follow the runtime's container declarations.
template<class T,class Alloc> T make_value(const Alloc&);
template<class T,class Alloc> T transfer_value(const T&,const Alloc&);
template<class T> T restore_value(const unsigned char*) noexcept;
template<class T> T relocate_value(T&) noexcept;
template<class T> void restore_at(void*) noexcept;
template<class T> void restore_payloads(T&);
template<class T> void expand_array_lifetimes(T*,std::uint32_t,std::uint32_t) noexcept;
}
namespace boost::typelayout { inline namespace v1 {
using prototype::FixedString;
using prototype::to_fixed_string;
template<class T> struct is_byte_copy_safe : prototype::byte_safe<T> {};
template<class T> inline constexpr bool is_byte_copy_safe_v=is_byte_copy_safe<T>::value;
}}
static_assert(std::numeric_limits<float>::is_iec559 && std::numeric_limits<double>::is_iec559);
