"""Authoritative schema -> ordinary C++ definitions and complete ordered metadata.

No compiler, P2996 output, AST, or target offsets are inputs. Actual offsetof is
evaluated by the target compiler. --check compares bytes and rejects stale/tampered
output. This bounded prototype has explicit unsupported syntax diagnostics.
"""
from pathlib import Path
import argparse, hashlib, json, re

def parse_type(t):
    m=re.fullmatch(r'(.+?)((?:\[\d+\])*)',t)
    if not m: raise ValueError('unknown type syntax: '+t)
    base, suffix=m.groups()
    if not re.fullmatch(r'(?:const )?[\w:,<> ]+',base): raise ValueError('unsupported type token: '+t)
    return base,[int(n) for n in re.findall(r'\[(\d+)\]',suffix)]

def emit(schema):
    if set(schema)!={'version','namespace','enums','records'} or schema['version']!=1: raise ValueError('unknown schema key/version')
    ns=schema['namespace']; names={r['name'] for r in schema['records']}
    if len(names)!=len(schema['records']): raise ValueError('duplicate type')
    out=['// Deterministically generated from schema.json. DO NOT EDIT.','#pragma once',
         '#include "xoffsetdatastructure.hpp"' if False else '// Runtime is included by the consumer first.',
         f'namespace {ns} {{','using namespace XOffsetDatastructure;']
    for e in schema['enums']:
        out.append(f'enum class {e["name"]} : {e["underlying"]} {{'+','.join(f'{n}={v}' for n,v in e['values'])+'};')
    for r in schema['records']:
        if set(r)-{'name','schema','allocator_ctor','probe_ctor','local_only','fields'}: raise ValueError('unknown record property')
        name=r['name']; fs=r['fields']; seen=set()
        if r.get('local_only'): out.append('#ifndef PROTOTYPE_OLD_V5')
        out.append(f'struct {name} {{')
        for field,t in fs:
            if field in seen: raise ValueError('duplicate field')
            seen.add(field);base,dims=parse_type(t)
            out.append(f'    {base} {field}'+''.join(f'[{n}]' for n in dims)+'{};')
        if r.get('allocator_ctor'):
            inits=[]
            for field,t in fs:
                if t.startswith(('XString','XBlob','XVector<','XMap<','XSet<')): inits.append(f'{field}(alloc)')
            body=' { fixture::on_ctor(); label="probe-owned"; }' if r.get('probe_ctor') else ' {}'
            out.append(f'    template<class Alloc> explicit {name}(const Alloc& alloc)'+(' : '+','.join(inits) if inits else '')+body)
        if r.get('probe_ctor'):out.append(f'    ~{name}() {{ fixture::on_destroy(); }}')
        out.append('#ifndef PROTOTYPE_OLD_V5')
        out.append(f'    {name}() = default;')
        for tag in ['make','transfer','restore','relocate']:
            args={'make':'const Alloc& alloc','transfer':f'const {name}& src, const Alloc& alloc',
                  'restore':'const unsigned char* raw','relocate':f'{name}& src'}[tag]
            prefix='template<class Alloc> ' if tag in ('make','transfer') else ''
            def init_expr(t,field,indices=()):
                base,dims=parse_type(t)
                def leaf(ix):
                    access=field+''.join(f'[{i}]' for i in ix)
                    if tag=='make': return f'prototype::make_value<{base}>(alloc)'
                    if tag=='transfer':return f'prototype::transfer_value<{base}>(src.{access},alloc)'
                    if tag=='relocate':return f'prototype::relocate_value<{base}>(src.{access})'
                    offset=f'offsetof({name},{field})'
                    if ix:
                        stride=0
                        for pos,i in enumerate(ix):
                            rest=1
                            for d in dims[pos+1:]:rest*=d
                            stride+=i*rest
                        offset+=f'+{stride}*sizeof({base})'
                    return f'prototype::restore_value<{base}>(raw+{offset})'
                def arr(level,ix):
                    if level==len(dims):return leaf(ix)
                    return '{'+','.join(arr(level+1,ix+(i,)) for i in range(dims[level]))+'}'
                return arr(0,())
            inits=[f'{f}'+(''+init_expr(t,f) if parse_type(t)[1] else '('+init_expr(t,f)+')') for f,t in fs]
            out.append('    '+prefix+f'{name}(prototype::{tag}_tag, {args})'+(' noexcept' if tag in ('relocate','restore') else '')+(' : '+','.join(inits) if inits else '')+' {}')
        out.extend(['#endif','};'])
        if r.get('local_only'):out.append('#endif')
    out.append('}')
    for r in schema['records']:
        if r.get('schema'):out.append(f'XOFFSET_REGISTER_SCHEMA_NAME({ns}::{r["name"]}, "{r["schema"]}")')
    out.extend(['#ifndef PROTOTYPE_OLD_V5','namespace prototype {'])
    for r in schema['records']:
        name=ns+'::'+r['name']
        fields=[f'field<{name},decltype({name}::{f}),&{name}::{f},offsetof({name},{f})>{{}}' for f,t in r['fields']]
        out.append(f'template<> struct record<{name}> {{ static constexpr auto fields=std::tuple{{'+','.join(fields)+'}; };')
        out.append(f'static_assert(std::is_standard_layout_v<{name}> && alignof({name})<=8);')
    out.extend(['}','#endif',''])
    return '\n'.join(out)

def check_bytes(expected,observed):
    if expected!=observed:raise ValueError('generated output stale, incomplete or tampered')

def main():
    p=argparse.ArgumentParser();p.add_argument('--schema',type=Path,default=Path(__file__).with_name('schema.json'));p.add_argument('--output',type=Path,default=Path(__file__).with_name('generated_schema.hpp'));p.add_argument('--check',action='store_true');a=p.parse_args()
    data=emit(json.loads(a.schema.read_text(encoding='utf-8'))).encode()
    if a.check:
        check_bytes(data,a.output.read_bytes() if a.output.is_file() else None)
    else:a.output.write_bytes(data)
    print(json.dumps({'schema_sha256':hashlib.sha256(a.schema.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}))
if __name__=='__main__':main()
