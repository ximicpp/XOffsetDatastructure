"""Single POSIX lease-owned process; all requests/evidence stay in this directory.

No daemonizing, no remote/native Windows child, no shell interpolation. Requests
are consumed once and preserve failures. The existing run_job owns cancellation
and cleanup for this complete inherited session. Absolute deadline: 1200 seconds.
"""
from pathlib import Path
import hashlib,json,os,resource,signal,subprocess,sys,time,traceback
HERE=Path(__file__).resolve().parent
CONTROL=HERE/'control'
LIMIT=3*1024**3
state={'status':'running','compile_invocations':0,'tested_processes':0,'active_wall_seconds':0.0,'fixed_cases':0,'peak_children_rss_bytes':0,'jobs':[]}

def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def disk_bytes():return sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())
def guard(sanitized):
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    resource.setrlimit(resource.RLIMIT_FSIZE,(128*1024**2,128*1024**2))
    if not sanitized:resource.setrlimit(resource.RLIMIT_AS,(LIMIT,LIMIT))
def own_rss():
    result=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            pid=int(p.name)
            if os.getsid(pid)!=os.getsid(0):continue
            text=(p/'status').read_text()
            rss=next((int(x.split()[1])*1024 for x in text.splitlines() if x.startswith('VmRSS:')),0)
            result.append((pid,rss))
        except (FileNotFoundError,ProcessLookupError,PermissionError):pass
    return result
def execute(req):
    kind=req['kind'];argv=req['argv'];name=req['name'];san=req.get('sanitized',False)
    if kind not in ('prepare','metadata','compile','test'):raise ValueError('unknown job kind')
    if not isinstance(argv,list) or not all(isinstance(x,str) for x in argv):raise ValueError('argv must be a string list')
    if argv[0].endswith('.exe') or any(x.endswith('.exe') for x in argv[:1]):raise ValueError('native Windows child lacks validated lease cleanup adapter')
    if kind=='compile':
        if state['compile_invocations']>=6:raise ValueError('compile budget exhausted')
        state['compile_invocations']+=1
    if kind=='test':
        if state['tested_processes']>=64:raise ValueError('test process budget exhausted')
        state['tested_processes']+=1
        state['fixed_cases']+=int(req.get('fixed_cases',0))
        if state['fixed_cases']>512:raise ValueError('fixed case budget exhausted')
    if disk_bytes()>512*1024**2:raise ValueError('disk budget exceeded')
    out=HERE/'runs'/name;out.mkdir(parents=True,exist_ok=False)
    write(out/'request.json',req)
    if kind=='compile':
        snap=out/'inputs';snap.mkdir()
        for p in sorted(HERE.iterdir()):
            if p.is_file() and p.suffix in ('.py','.hpp','.cpp','.json','.inc','.md'):
                (snap/p.name).write_bytes(p.read_bytes())
        if (HERE/'backend').is_dir():
            (snap/'backend').mkdir()
            for p in (HERE/'backend').iterdir():
                if p.is_file():(snap/'backend'/p.name).write_bytes(p.read_bytes())
    started=time.monotonic();deadline=min(started+float(req.get('timeout_seconds',30 if kind=='test' else 300)),END)
    env=dict(os.environ,LANG='C',LC_ALL='C',PYTHONDONTWRITEBYTECODE='1')
    env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:allocator_may_return_null=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    peak=0;reason=None
    with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
        child=subprocess.Popen(argv,cwd=HERE,stdout=stdout,stderr=stderr,env=env,preexec_fn=lambda:guard(san))
        while child.poll() is None:
            members=own_rss();peak=max(peak,max((rss for pid,rss in members),default=0))
            if peak>LIMIT:reason='resident_memory_limit'
            elif time.monotonic()>deadline:reason='deadline'
            elif disk_bytes()>512*1024**2:reason='disk_limit'
            if reason:
                # Fail the whole lease-owned session; run_job inspects and cleans
                # all remaining descendants before releasing the global lock.
                write(out/'budget-failure.json',{'reason':reason,'peak_sampled_rss':peak})
                raise RuntimeError('resource stop: '+reason)
            time.sleep(.1)
        code=child.wait()
    elapsed=time.monotonic()-started
    state['active_wall_seconds']+=elapsed
    state['peak_children_rss_bytes']=max(state['peak_children_rss_bytes'],resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss*1024,peak)
    if state['peak_children_rss_bytes']>LIMIT:raise RuntimeError('observed peak exceeded budget')
    result={'returncode':code,'wall_seconds':elapsed,'sampled_session_process_peak_rss':peak,'cumulative_child_maxrss':state['peak_children_rss_bytes'],'disk_bytes':disk_bytes()}
    state['jobs'].append({'name':name,'kind':kind,**result})
    write(out/'result.json',result);write(HERE/'budget.json',state)
    print(json.dumps({'name':name,**result}),flush=True)
    return result

START=time.monotonic();END=START+1200
try:
    CONTROL.mkdir(exist_ok=False);(HERE/'runs').mkdir(exist_ok=False)
    write(CONTROL/'ready.json',{'pid':os.getpid(),'session':os.getsid(0),'absolute_lease_deadline_seconds':1200,'start_utc':time.time()})
    write(HERE/'budget.json',state)
    next_id=1
    while time.monotonic()<END:
        request=CONTROL/f'{next_id:03}.request.json'
        if not request.exists():time.sleep(.2);continue
        req=json.loads(request.read_text())
        if req.get('kind')=='finish':
            state['status']='finished';write(HERE/'budget.json',state);write(CONTROL/f'{next_id:03}.result.json',{'status':'finished'});break
        result=execute(req);write(CONTROL/f'{next_id:03}.result.json',result);next_id+=1
    else:raise RuntimeError('absolute lease deadline reached; no budget extension')
except BaseException as e:
    state.update(status='failed',error=f'{type(e).__name__}: {e}')
    write(HERE/'budget.json',state);traceback.print_exc();sys.exit(1)
