#ifdef PROTOTYPE_OLD_V5
#include "xoffsetdatastructure.hpp"
#else
#include "backend/xoffsetdatastructure.hpp"
#endif
#include <stdexcept>
namespace fixture {
inline int calls=0, destroyed=0, fail_on=0;
inline void on_ctor(){++calls;if(fail_on && calls==fail_on)throw std::runtime_error("injected constructor failure");}
inline void on_destroy() noexcept{++destroyed;}
}
#include "generated_schema.hpp"
#include <fstream>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <array>
#include <stdexcept>
#include <vector>
#include <filesystem>
#include <cmath>
using namespace XOffsetDatastructure;
using namespace sample;
void need(bool c,const char* m){if(!c)throw std::runtime_error(m);}
constexpr std::size_t maximum=1024*1024;
auto policy(){return XBuffer::maximum_capacity(maximum);}
std::string read_file(const std::filesystem::path& path) {
    std::ifstream f(path,std::ios::binary);need(bool(f),"input open");
    std::string v((std::istreambuf_iterator<char>(f)),{});need(v.size()<=65536,"wire cap");return v;
}
void write_file(const std::filesystem::path& path,const std::string& value) {
    need(value.size()<=65536,"output cap");std::ofstream f(path,std::ios::binary);f.write(value.data(),value.size());need(bool(f),"output write");
}
template<class T> void fill(T&);
template<> void fill(Scalars& r) {
    r.id=7;r.enabled=true;r.bits[0]=true;r.bits[1]=false;
    for(int i=0;i<2;++i)for(int j=0;j<3;++j)r.matrix[i][j]=i*3+j-4;
    r.state=static_cast<State>(99);r.score=1.25;
}
void fill_part(Part& p,int n) {p.value=n;p.name="part";p.samples.push_back(12);p.samples.push_back(55);}
template<> void fill(UnitState& r) {
    r.id=1001;r.revision=3;r.enabled=true;r.name="unit-name";
    r.blob.push_back(std::byte{0});r.blob.push_back(std::byte{255});
    r.parts.reserve(4);for(int i=0;i<3;++i)fill_part(r.parts.emplace_back(),i+1);
    r.ids.insert(8);r.ids.insert(3);
    fill_part(r.attrs.try_emplace("alpha").first->second,21);
    fill_part(r.attrs.try_emplace("omega").first->second,31);
    r.parts.reserve(9); // non-tail retirement and nontrivial relocation
}
template<> void fill(Moves& r) {
    r.left="left";r.right="right";r.fixed[0].first="a";r.fixed[0].second="b";
    r.fixed[1].first="c";r.fixed[1].second="d";
    for(int i=0;i<3;++i){auto& row=r.rows.emplace_back();row.first="first";row.second="second";}
    r.other.emplace_back().first="other";
}
template<class T> void mutate(T&);
template<> void mutate(Scalars& r){++r.id;r.enabled=!r.enabled;r.matrix[1][2]-=3;r.score+=0.5;}
template<> void mutate(UnitState& r) {
    ++r.revision;r.name="modified-name-with-more-characters";
    r.parts[0].name="modified-part";r.parts[0].samples.push_back(61);
    r.parts.erase(r.parts.begin()+1);fill_part(r.parts.emplace_back(),71);
    r.ids.erase(3);r.ids.insert(17);r.attrs.erase("alpha");fill_part(r.attrs.try_emplace("delta").first->second,81);
    r.blob.push_back(std::byte{77});
}
template<> void mutate(Moves& r) {
    r.left=std::move(r.right);r.rows.reserve(r.rows.capacity()+5);
    r.rows.erase(r.rows.begin());r.rows.emplace_back().first="appended";
    r.fixed[0].second="array-modified";
}
void text(std::ostream& o,std::string_view s){o<<s.size()<<':';for(unsigned char c:s)o<<std::hex<<std::setw(2)<<std::setfill('0')<<unsigned(c);o<<std::dec<<';';}
void dump_part(std::ostream& o,const Part& p){o<<p.value<<';';text(o,p.name.view());for(auto v:p.samples)o<<v<<',';o<<';';}
std::string dump(const Scalars& r){std::ostringstream o;o<<r.id<<';'<<r.enabled<<r.bits[0]<<r.bits[1]<<';';for(auto& row:r.matrix)for(auto v:row)o<<v<<',';o<<';'<<std::uint32_t(r.state)<<';'<<r.score;return o.str();}
std::string dump(const UnitState& r){std::ostringstream o;o<<r.id<<';'<<r.revision<<';'<<r.enabled<<';';text(o,r.name.view());for(auto v:r.blob)o<<unsigned(std::to_integer<unsigned char>(v))<<',';o<<';';for(auto& p:r.parts)dump_part(o,p);for(auto v:r.ids)o<<v<<',';o<<';';for(auto& v:r.attrs){text(o,v.first.view());dump_part(o,v.second);}return o.str();}
std::string dump(const Moves& r){std::ostringstream o;text(o,r.left.view());text(o,r.right.view());for(auto& x:r.fixed){text(o,x.first.view());text(o,x.second.view());}for(auto& x:r.rows){text(o,x.first.view());text(o,x.second.view());}o<<'|';for(auto& x:r.other){text(o,x.first.view());text(o,x.second.view());}return o.str();}
template<class T> void expected(const T& actual,int generation) {
    auto reference=TypedXBuffer<T>::create(16384,policy());fill(reference.root());
    for(int i=0;i<generation;++i)mutate(reference.root());
    need(dump(actual)==dump(reference.root()),"logical state differs from independent fixture construction");
}
template<class T> void signature(const char* label) {
    std::cout<<label<<'\t'<<sizeof(T)<<'\t'<<alignof(T)<<'\t'<<wire_root_type_id_v<T>()<<'\t'<<wire_schema_hash_v<T>()<<'\t'<<std::string_view(wire_abi_signature<T>())<<'\n';
}
template<class T> void emit(const std::filesystem::path& dir,const char* label) {
    auto b=TypedXBuffer<T>::create(16384,policy());fill(b.root());
    write_file(dir/(std::string(label)+"-0.wire"),b.save_verified());
    mutate(b.root());write_file(dir/(std::string(label)+"-1.wire"),b.save_verified());
}
template<class T> void accept(const std::filesystem::path& source,const std::filesystem::path& dest,const char* label,int generation) {
    const auto bytes=read_file(source/(std::string(label)+"-"+std::to_string(generation)+".wire"));
    auto b=TypedXBuffer<T>::load(bytes,policy());expected(b.root(),generation);
    need(b.grow(4096),"grow failed");mutate(b.root());expected(b.root(),generation+1);
    auto out=b.save_verified();auto again=TypedXBuffer<T>::load(out,policy());expected(again.root(),generation+1);
    write_file(dest/(std::string(label)+"-"+std::to_string(generation+1)+".wire"),out);
    auto compacted=XCompactor::compact<T>(b);expected(compacted.template root<T>(),generation+1);expected(b.root(),generation+1);
    auto compact_wire=compacted.template save_verified<T>();auto compact_loaded=TypedXBuffer<T>::load(compact_wire,policy());expected(compact_loaded.root(),generation+1);
}
template<class V> void poke(std::string& bytes,std::size_t at,V value){need(at+sizeof(V)<=bytes.size(),"poke bounds");std::memcpy(bytes.data()+at,&value,sizeof(V));}
template<class T> T peek(const std::string& bytes,std::size_t at){T v{};need(at+sizeof(T)<=bytes.size(),"peek bounds");std::memcpy(&v,bytes.data()+at,sizeof(T));return v;}
void corpus(const std::filesystem::path& dir) {
    auto b=TypedXBuffer<UnitState>::create(16384,policy());fill(b.root());mutate(b.root());const auto good=b.save_verified();
    const auto h=peek<XWireHeaderV1>(good,0);const auto payload=sizeof(h),root=payload+h.root_offset,alloc=payload+h.allocator_offset;
    std::vector<std::pair<std::string,std::string>> cases;
    auto add=[&](const char* id,auto fn){auto bytes=good;fn(bytes);cases.emplace_back(id,std::move(bytes));};
    cases.emplace_back("valid",good);
    add("header-short",[](auto& x){x.resize(8);});
    add("magic",[](auto& x){x[0]='Q';});
    add("magic-and-version",[](auto& x){x[0]='Q';poke(x,offsetof(XWireHeaderV1,format_major),std::uint16_t(2));});
    add("version",[](auto& x){poke(x,offsetof(XWireHeaderV1,format_major),std::uint16_t(2));});
    add("header-size",[](auto& x){poke(x,offsetof(XWireHeaderV1,header_size),std::uint32_t(1));});
    add("endian",[](auto& x){poke(x,offsetof(XWireHeaderV1,endian_tag),std::uint32_t(7));});
    add("flags",[](auto& x){poke(x,offsetof(XWireHeaderV1,flags),std::uint32_t(1));});
    add("root-id",[](auto& x){poke(x,offsetof(XWireHeaderV1,root_type_id),std::uint64_t(1));});
    add("schema",[](auto& x){poke(x,offsetof(XWireHeaderV1,schema_hash_lo),std::uint64_t(1));});
    add("size",[](auto& x){poke(x,offsetof(XWireHeaderV1,used_bytes),std::uint64_t(1));});
    add("reserved",[](auto& x){poke(x,offsetof(XWireHeaderV1,reserved_bytes),UINT64_MAX);});
    add("crc",[](auto& x){poke(x,offsetof(XWireHeaderV1,crc32c),std::uint32_t(1));});
    add("root-oob",[](auto& x){poke(x,offsetof(XWireHeaderV1,root_offset),UINT64_MAX);});
    add("allocator-oob",[](auto& x){poke(x,offsetof(XWireHeaderV1,allocator_offset),UINT64_MAX);});
    add("bool",[&](auto& x){poke(x,root+offsetof(UnitState,enabled),std::uint8_t(2));});
    add("bool-and-string",[&](auto& x){poke(x,root+offsetof(UnitState,enabled),std::uint8_t(2));poke(x,root+offsetof(UnitState,name),INT32_MAX);});
    add("binding",[&](auto& x){poke(x,root+offsetof(UnitState,name),INT32_MAX);});
    add("string-size",[&](auto& x){poke(x,root+offsetof(UnitState,name)+8,UINT32_MAX);});
    add("string-delta",[&](auto& x){poke(x,root+offsetof(UnitState,name)+4,INT32_MIN);});
    add("allocation",[&](auto& x){poke(x,root-sizeof(XBufferCore::AllocationHeader),std::uint32_t(1));});
    add("free-accounting",[&](auto& x){poke(x,alloc+offsetof(XAllocatorStateV1,free_bytes),UINT32_MAX);});
    add("arena-flags",[&](auto& x){poke(x,payload+offsetof(XBufferCore::arena_header,flags),std::uint32_t(1));});
    add("payload-extent",[&](auto& x){poke(x,payload+offsetof(XBufferCore::arena_header,used_end),std::uint64_t(48));});
    add("vector-size",[&](auto& x){poke(x,root+offsetof(UnitState,parts)+8,UINT32_MAX);});
    add("vector-live-overlap",[&](auto& x){
        const auto head=root+offsetof(UnitState,parts);poke(x,head+4,static_cast<std::int32_t>(root-(head+4)));
        poke(x,head+8,std::uint32_t(0));poke(x,head+12,std::uint32_t(1));
    });
    const auto state=peek<XAllocatorStateV1>(good,alloc);
    std::uint32_t free_head=0;for(auto offset:state.freelist_head)if(offset){free_head=offset;break;}
    need(free_head!=0,"fixture must contain retired free blocks");
    add("free-cycle",[&](auto& x){poke(x,alloc+free_head,free_head);});
    add("live-free-overlap",[&](auto& x){
        const auto head=root+offsetof(UnitState,blob);poke(x,head+4,static_cast<std::int32_t>((alloc+free_head)-(head+4)));
        poke(x,head+8,std::uint32_t(1));poke(x,head+12,std::uint32_t(1));
    });
    add("map-duplicate",[&](auto& x){
        const auto head=root+offsetof(UnitState,attrs);const auto entries=head+4+peek<std::int32_t>(x,head+4);
        using Entry=XKeyValue<XString,Part>;
        const auto first=entries+offsetof(Entry,first);
        const auto text_at=first+4+peek<std::int32_t>(x,first+4);
        std::memcpy(x.data()+text_at,"omega",5);
    });
    // Deterministic fixed perturbations include accepted scalar/padding cases.
    for(std::size_t i=0;i<96;++i){auto bytes=good;auto at=payload+(i*31)%(good.size()-payload);bytes[at]^=char(128);cases.emplace_back("bit-"+std::to_string(i),std::move(bytes));}
    need(cases.size()<=128,"fixed corpus cap");
    std::ofstream index(dir/"index.tsv");
    for(std::size_t i=0;i<cases.size();++i){auto file=std::to_string(i)+".wire";write_file(dir/file,cases[i].second);index<<cases[i].first<<'\t'<<file<<'\n';}
}
void inspect_corpus(const std::filesystem::path& dir) {
    std::ifstream index(dir/"index.tsv");need(bool(index),"corpus index");std::string line;
    while(std::getline(index,line)){
        auto at=line.find('\t');auto id=line.substr(0,at);auto bytes=read_file(dir/line.substr(at+1));
        std::optional<TypedXBuffer<UnitState>> holder;
        try {holder.emplace(TypedXBuffer<UnitState>::load(bytes,policy()));}
        catch(const XException& e){std::cout<<id<<"\trejected\t"<<e.what()<<'\n';continue;}
        // Mutation/reload errors are process failures, never misclassified as
        // load rejection. This also exercises owner move into the optional.
        auto& b=*holder;auto before=dump(b.root());need(b.grow(4096),"accepted grow");
        b.root().name="accepted-and-modified";b.root().parts.emplace_back().value=77;
        auto out=b.save_verified();auto after=TypedXBuffer<UnitState>::load(out,policy());
        need(dump(after.root())==dump(b.root()),"accepted mutation reload");
        std::cout<<id<<"\taccepted\t"<<before<<'\n';
    }
}
void self_test() {
    static_assert(is_v1_wire_admitted_v<Scalars> && is_v1_wire_admitted_v<UnitState> && is_v1_wire_admitted_v<Moves>);
    struct HasPointer{int* p;};struct Derived:XString{int extra;};
    static_assert(!is_v1_wire_admitted_v<HasPointer> && !is_v1_wire_admitted_v<Derived>);
    {
        auto b=TypedXBuffer<Moves>::create(16384,policy());fill(b.root());auto& r=b.root();
        auto* ptr=r.right.data();r.left=std::move(r.right);need(r.left.data()==ptr && r.right.empty() && r.right.is_bound(),"same-owner steal/binding");
        r.right="reusable";auto bytes=b.save_verified();auto loaded=TypedXBuffer<Moves>::load(bytes,policy());need(loaded.root().right.view()=="reusable","move roundtrip");
    }
    {
        auto source=TypedXBuffer<Moves>::create(16384,policy());fill(source.root());
        auto dest=TypedXBuffer<Moves>::create(16384,policy());fill(dest.root());
        dest.root().left=std::move(source.root().right);need(dest.root().left.view()=="right" && source.root().right.view()=="right","cross-owner deep copy");
    }
    {
        auto b=TypedXBuffer<Moves>::create(4096,policy());fill(b.root());const auto original=dump(b.root());
        bool failed=false;try{b.root().left=std::string(8192,'x');}catch(const XBadAlloc&){failed=true;}
        need(failed && dump(b.root())==original,"OOM logical strong guarantee");
        auto loaded=TypedXBuffer<Moves>::load(b.save_verified(),policy());need(dump(loaded.root())==original,"OOM save/reload");
        need(loaded.grow(16384),"OOM explicit grow");loaded.root().left=std::string(8192,'x');need(loaded.root().left.size()==8192,"OOM retry");
    }
    {
        auto b=XBuffer::create<ProbeRoot>(8192,policy());fixture::calls=fixture::destroyed=0;fixture::fail_on=2;
        bool failed=false;try{b.root<ProbeRoot>().rows.resize(3);}catch(const std::runtime_error& e){failed=std::string_view(e.what())=="injected constructor failure";}
        fixture::fail_on=0;need(failed && b.root<ProbeRoot>().rows.empty() && fixture::destroyed==1,"constructor prefix rollback");
        b.root<ProbeRoot>().rows.resize(2);need(b.root<ProbeRoot>().rows.size()==2,"constructor recovery");
        b.root<ProbeRoot>().rows.clear();need(fixture::destroyed==3,"constructed element destruction count");
    }
    {
        XBuffer b(8192,policy());fixture::calls=fixture::destroyed=0;fixture::fail_on=2;
        bool failed=false;try{b.make<ProbeArray>();}catch(const std::runtime_error& e){failed=std::string_view(e.what())=="injected constructor failure";}
        fixture::fail_on=0;need(failed && fixture::destroyed==1,"array constructor rollback");
        auto* r=b.make<ProbeArray>();need(r->slots[0].label.view()=="probe-owned","array constructor retry");
    }
    {
        alignas(8) char region[128]{};
        detail::WireValidationContext ctx{.base=region,.end=region+sizeof(region)};
        detail::register_free_range(region+16,8,ctx,"free");detail::register_owned_range(region+64,8,ctx,"owned");
        bool priority=false;try{detail::register_owned_range(region+16,64,ctx,"probe");}
        catch(const XException& e){priority=std::string_view(e.what())=="wire validation detected overlapping dynamic ranges";}
        need(priority,"owned global priority");
    }
#ifndef PROTOTYPE_OLD_V5
    static_assert(prototype::byte_safe_v<LocalNode>); // generated recursive edges, no manual safe override
    {
        auto b=XBuffer::create<LocalTree>(32768,policy());auto& r=b.root<LocalTree>();r.nodes.resize(2);
        r.nodes[0].id=7;r.nodes[0].children.resize(1);r.nodes[0].children[0].id=91;r.nodes[1].id=8;
        auto* inner=r.nodes[0].children.data();r.nodes=std::move(r.nodes[0].children);
        need(r.nodes.size()==1 && r.nodes[0].id==91 && r.nodes.data()!=inner,"ancestor copy-before-retire");
    }
    {
        auto b=XBuffer::create<LocalTree>(32768,policy());auto& r=b.root<LocalTree>();r.nodes.resize(2);
        r.nodes[0].id=7;r.nodes[0].children.resize(1);r.nodes[0].children[0].id=91;r.nodes[1].id=8;
        auto* outer=r.nodes.data();auto& child=r.nodes[0].children;child=std::move(r.nodes);
        need(r.nodes.data()==outer && r.nodes.size()==2 && child.data()!=outer && child.size()==2,"descendant copy-before-retire");
    }
#endif
    std::cout<<"self-ok\n";
}
int main(int argc,char** argv) {
    try {
        need(argc>=2,"mode");std::string mode=argv[1];
        if(mode=="signatures"){signature<Scalars>("scalars");signature<UnitState>("unit");signature<Moves>("moves");}
        else if(mode=="self")self_test();
        else if(mode=="emit"){need(argc==3,"emit args");auto p=std::filesystem::path(argv[2]);emit<Scalars>(p,"scalars");emit<UnitState>(p,"unit");emit<Moves>(p,"moves");}
        else if(mode=="accept"){need(argc==5,"accept args");auto a=std::filesystem::path(argv[2]),b=std::filesystem::path(argv[3]);int g=std::stoi(argv[4]);accept<Scalars>(a,b,"scalars",g);accept<UnitState>(a,b,"unit",g);accept<Moves>(a,b,"moves",g);std::cout<<"accept-ok\n";}
        else if(mode=="corpus"){need(argc==3,"corpus args");corpus(argv[2]);}
        else if(mode=="inspect"){need(argc==3,"inspect args");inspect_corpus(argv[2]);}
        else throw std::runtime_error("unknown mode");
    }catch(const std::exception& e){std::cerr<<"FAIL: "<<e.what()<<'\n';return 1;}
}
