"""Mechanical V5 fork in this directory only. Execute only under global lease.

Exact source identity, exact named-region replacements, and residual P2996 scan
are mandatory. No change to the source tree or its dependency lock.
"""
from pathlib import Path
import hashlib, json, re, sys

HERE=Path(__file__).resolve().parent
BASE=Path('/mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发')
IDENTITIES={'xoffsetdatastructure.hpp':'c4acc7f2005711452e12f0cd7c5d7bc57efe2d4ca0fabc207b6f711b1dbb9964','xoffset_virtual_memory.hpp':'22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad'}

def main():
    global s
    inputs={}
    for name,want in IDENTITIES.items():
        raw=(BASE/name).read_bytes(); got=hashlib.sha256(raw).hexdigest()
        if got!=want:raise RuntimeError('baseline mismatch '+name)
        inputs[name]={'path':str(BASE/name),'bytes':len(raw),'sha256':got}
    (HERE/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
    s=(BASE/'xoffsetdatastructure.hpp').read_text(encoding='utf-8')
    def once(old,new):
        global s
        if s.count(old)!=1:raise ValueError('replacement is not unique: '+old[:100])
        s=s.replace(old,new)
    def region(start,end,new):
        global s
        a=s.index(start);b=s.index(end,a)
        s=s[:a]+new+'\n'+s[b:]
    once('#include <experimental/meta>','#include "../metadata.hpp"')
    once('#include <boost/typelayout.hpp>','// TypeLayout replaced by complete generated ordinary-C++ metadata.')
    region('        template <typename T>\n        consteval std::size_t reflected_base_count()',
           '        template <typename T, typename BaseFn, typename MemberFn>',r'''
        template<class T> consteval std::size_t reflected_base_count() { return 0; }
        template<class T> consteval std::size_t reflected_member_count() { return prototype::field_count<T>; }
''')
    region('        template <typename T, std::size_t N>\n        consteval bool reflected_member_wire_admitted()',
           '        template <typename T, std::size_t N = 0>',r'''
        template<class T,std::size_t N> consteval bool reflected_member_wire_admitted() {
            return is_v1_wire_admitted_impl<std::remove_cv_t<typename prototype::field_at<T,N>::type>>::value;
        }
''')
    region('        template <typename T, std::size_t N = 0>\n        consteval bool reflected_member_needs_validation()',
           '        template <typename T>\n        struct wire_value_needs_validation',r'''
        template<class T,std::size_t N=0> consteval bool reflected_member_needs_validation() {
            if constexpr(N>=prototype::field_count<T>) return false;
            else return wire_value_needs_validation<typename prototype::field_at<T,N>::type>::value || reflected_member_needs_validation<T,N+1>();
        }
''')
    # Replace all typed object-graph access before object lifetimes are established.
    region('        inline void validate_wire_value(const XFixedString& value,',
           '        inline void validate_allocator_state(WireValidationContext& ctx)',
           (HERE/'raw_validator.inc').read_text())
    once('void verify_structural_wire_graph(const T& root, XBufferCore& xbuf)',
         'void verify_structural_wire_graph(const void* root, XBufferCore& xbuf)')
    once('register_allocation(&root, sizeof(T), alignof(T), ctx);','register_allocation(root, sizeof(T), alignof(T), ctx);')
    once('            validate_wire_value(root, ctx);','            validate_raw_value<T>(static_cast<const char*>(root), ctx);')
    region('        template <typename T, std::size_t I>\n        consteval bool member_can_relocate()',
           '        template <typename T>\n        consteval bool can_relocate_without_allocation()',r'''
        template<class T,std::size_t I> consteval bool member_can_relocate() {
            return can_relocate_without_allocation<typename prototype::field_at<T,I>::type>();
        }
        template<class T,std::size_t I> consteval bool base_can_relocate() { return true; }
''')
    once('constexpr auto bases = std::meta::bases_of(^^T, std::meta::access_context::unchecked()).size();','constexpr auto bases = 0;')
    once('constexpr auto members = std::meta::nonstatic_data_members_of(^^T, std::meta::access_context::unchecked()).size();','constexpr auto members = prototype::field_count<T>;')
    region('                detail::for_each_reflected_subobject<CleanT>([&](auto index) {',
           '                return found;',r'''
                detail::static_for<prototype::field_count<CleanT>>([&](auto index) {
                    if(!found) found=move_assignment_owns_address(prototype::field_at<CleanT,decltype(index)::value>::get(value),address);
                });
''')
    region('                detail::for_each_reflected_subobject<T>([&](auto index) {',
           '            }\n        }\n    } // namespace fixed_detail',r'''
                if constexpr (prototype::kv<T>) {
                    ::new(static_cast<void*>(dst)) T{prototype::relocate_value(src.first),prototype::relocate_value(src.second)};
                } else ::new(static_cast<void*>(dst)) T(prototype::relocate_tag{},src);
''')
    region('        template <typename T, std::size_t Index>\n        consteval auto wire_record_field_signature()',
           '        template <typename T, std::size_t Index>\n        consteval auto wire_record_field_signature_with_sep()',r'''
        template<class T,std::size_t Index> consteval auto wire_record_field_signature() {
            using F=prototype::field_at<std::remove_cv_t<T>,Index>;
            return tl::FixedString{"@"}+tl::to_fixed_string<F::offset>()+tl::FixedString{":"}+wire_abi_signature<typename F::type>();
        }
''')
    region('        template <typename T, typename Alloc>\n        void reflect_init_all_impl(void* raw, Alloc alloc);',
           '        // Internal wrapper: constructs T via reflection on raw storage.',r'''
        template<class T,class Alloc> void reflect_init_all(void* raw,Alloc alloc) {
            std::memset(raw,0,sizeof(T));
            if constexpr (detail::is_xkeyvalue_v<T>) {
                ::new(raw) T{prototype::make_value<typename T::first_type>(alloc),prototype::make_value<typename T::second_type>(alloc)};
            } else ::new(raw) T(prototype::make_tag{},alloc);
        }
        template<class T,class Src,class Alloc> void reflect_transfer_init_all(void* dst,Src&& src,Alloc alloc) {
            std::memset(dst,0,sizeof(T));
            if constexpr (detail::is_xkeyvalue_v<T>) {
                ::new(dst) T{prototype::transfer_value(src.first,alloc),prototype::transfer_value(src.second,alloc)};
            } else ::new(dst) T(prototype::transfer_tag{},static_cast<const T&>(src),alloc);
        }
''')
    region('        template<typename T, std::size_t N>\n        static void migrate_base_at(',
           '        template<typename T>\n        static void migrate_members(',r'''
        template<class T,std::size_t N> static void migrate_base_at(const T&,T&,XBufferCore&,XBufferCore&) {}
        template<class T,std::size_t N> static void migrate_member_at(const T& old_obj,T& new_obj,XBufferCore& old_xbuf,XBufferCore& new_xbuf) {
            using F=prototype::field_at<T,N>;
            migrate_member<typename F::type>(F::get(old_obj),F::get(new_obj),old_xbuf,new_xbuf);
        }
''')
    # Raw root lookup must not launder or form a T reference before restoration.
    needle='            auto* root_ptr = detail::find_root<T>(xbuf);'
    once(needle,r'''
            const auto root_raw_offset=xbuf.arena()->root_offset;
            char* root_ptr=nullptr;
            if(root_raw_offset && root_raw_offset<=xbuf.get_size() && sizeof(T)<=xbuf.get_size()-root_raw_offset) {
                auto* candidate=xbuf.data()+root_raw_offset;
                if(reinterpret_cast<std::uintptr_t>(candidate)%alignof(T)==0)root_ptr=candidate;
            }
''')
    once('            detail::verify_structural_wire_graph(*root_ptr, xbuf);',r'''
            detail::verify_structural_wire_graph<T>(root_ptr, xbuf);
            prototype::restore_at<T>(root_ptr);
            prototype::restore_payloads(*std::launder(reinterpret_cast<T*>(root_ptr)));
''')
    # Restore/relocate constructors preserve the exact four-field frozen header.
    for name in ('XFixedString','XFixedVector'):
        needle=f'        {name}() = default;'
        once(needle,needle+f'''
        {name}(prototype::restore_tag,const unsigned char* raw) noexcept
            : arena_delta(prototype::read_scalar<std::int32_t>(raw)),
              data_delta(prototype::read_scalar<std::int32_t>(raw+4)),
              size_(prototype::read_scalar<std::uint32_t>(raw+8)),
              capacity_(prototype::read_scalar<std::uint32_t>(raw+12)) {{}}
        {name}(prototype::relocate_tag,{name}& src) noexcept : {name}(src.binding()) {{
            fixed_detail::set_rel32(data_delta,&data_delta,src.data());
            size_=src.size_;capacity_=src.capacity_;src.data_delta=0;src.size_=0;src.capacity_=0;
        }}
''')
    for name in ('XString','XVector','XSet','XMap'):
        needle=f'        {name}() = default;'
        once(needle,needle+f'''
        {name}(prototype::restore_tag tag,const unsigned char* raw) noexcept : Base(tag,raw) {{}}
        {name}(prototype::relocate_tag tag,{name}& src) noexcept : Base(tag,static_cast<Base&>(src)) {{}}
''')
    # Establish raw storage object/array creation triggers before typed access.
    once('            auto* sm = arena();\n            std::memcpy(sm->magic, payload_magic_, sizeof(payload_magic_));',
         '            std::memmove(buffer_.data(),buffer_.data(),buffer_.size());\n            auto* sm = arena();\n            std::memcpy(sm->magic, payload_magic_, sizeof(payload_magic_));')
    # All fresh/reused dynamic payloads get an implicit object/array creation trigger.
    once('                                return block;', '                                return std::memmove(block,block,aligned_bytes);')
    once('            note_allocator_block(alloc_ref.state, raw, aligned_bytes);\n            return raw;',
         '            note_allocator_block(alloc_ref.state, raw, aligned_bytes);\n            return std::memmove(raw,raw,aligned_bytes);')
    once('                capacity_ = new_cap;\n                return;\n            }\n            if constexpr (fixed_detail::can_relocate_without_allocation<T>())',
         '                prototype::expand_array_lifetimes(data(),size_,new_cap);\n                capacity_ = new_cap;\n                return;\n            }\n            if constexpr (fixed_detail::can_relocate_without_allocation<T>())')
    once('                // VM preparation completed before publishing the enlarged',
         '                prototype::expand_array_lifetimes(old,old_size,count);\n                // VM preparation completed before publishing the enlarged')
    once('            auto* header = std::launder(reinterpret_cast<FreeBlockHeader*>(ptr));',
         '            auto* header = ::new(ptr) FreeBlockHeader;')
    once('            auto* header = std::launder(\n                reinterpret_cast<AllocationHeader*>(buffer_.data() + block_begin));',
         '            auto* header = ::new(static_cast<void*>(buffer_.data()+block_begin)) AllocationHeader;')
    once('            return fixed_detail::resolve_rel32<T>(&data_delta, data_delta);',
         '            if(!data_delta)return nullptr;\n            auto* raw=reinterpret_cast<char*>(&data_delta)+data_delta;\n            auto* p=reinterpret_cast<T*>(raw);\n            return size_?std::launder(p):p;')
    once('            return fixed_detail::resolve_rel32_const<T>(&data_delta, data_delta);',
         '            if(!data_delta)return nullptr;\n            auto* raw=reinterpret_cast<const char*>(&data_delta)+data_delta;\n            auto* p=reinterpret_cast<const T*>(raw);\n            return size_?std::launder(p):p;')
    # Partial-specialized record/edge metadata is instantiated only by consumers.
    pos=s.rfind('#endif')
    s=s[:pos]+'#include "../backend_helpers.hpp"\n'+s[pos:]
    (HERE/'backend').mkdir(exist_ok=False)
    if re.search(r'std::meta|\^\^|\[:|experimental/meta',s): raise ValueError('P2996 residual')
    (HERE/'backend/xoffsetdatastructure.hpp').write_text(s,encoding='utf-8',newline='\n')
    (HERE/'backend/xoffset_virtual_memory.hpp').write_bytes((BASE/'xoffset_virtual_memory.hpp').read_bytes())
    print(json.dumps({'status':'mechanical_port_prepared_not_accepted','main_bytes':len(s.encode()),'note':'Array lifecycle gate must pass before compilation.'}))

if __name__=='__main__':main()
