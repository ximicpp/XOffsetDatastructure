// Deterministically generated from schema.json. DO NOT EDIT.
#pragma once
// Runtime is included by the consumer first.
namespace sample {
using namespace XOffsetDatastructure;
enum class State : std::uint32_t {idle=0,active=1};
struct Empty {
#ifndef PROTOTYPE_OLD_V5
    Empty() = default;
    template<class Alloc> Empty(prototype::make_tag, const Alloc& alloc) {}
    template<class Alloc> Empty(prototype::transfer_tag, const Empty& src, const Alloc& alloc) {}
    Empty(prototype::restore_tag, const unsigned char* raw) noexcept {}
    Empty(prototype::relocate_tag, Empty& src) noexcept {}
#endif
};
struct CvSample {
    const std::uint32_t value{};
#ifndef PROTOTYPE_OLD_V5
    CvSample() = default;
    template<class Alloc> CvSample(prototype::make_tag, const Alloc& alloc) : value(prototype::make_value<const std::uint32_t>(alloc)) {}
    template<class Alloc> CvSample(prototype::transfer_tag, const CvSample& src, const Alloc& alloc) : value(prototype::transfer_value<const std::uint32_t>(src.value,alloc)) {}
    CvSample(prototype::restore_tag, const unsigned char* raw) noexcept : value(prototype::restore_value<const std::uint32_t>(raw+offsetof(CvSample,value))) {}
    CvSample(prototype::relocate_tag, CvSample& src) noexcept : value(prototype::relocate_value<const std::uint32_t>(src.value)) {}
#endif
};
struct Scalars {
    std::uint32_t id{};
    bool enabled{};
    bool bits[2]{};
    std::int32_t matrix[2][3]{};
    State state{};
    double score{};
    Empty empty{};
#ifndef PROTOTYPE_OLD_V5
    Scalars() = default;
    template<class Alloc> Scalars(prototype::make_tag, const Alloc& alloc) : id(prototype::make_value<std::uint32_t>(alloc)),enabled(prototype::make_value<bool>(alloc)),bits{prototype::make_value<bool>(alloc),prototype::make_value<bool>(alloc)},matrix{{prototype::make_value<std::int32_t>(alloc),prototype::make_value<std::int32_t>(alloc),prototype::make_value<std::int32_t>(alloc)},{prototype::make_value<std::int32_t>(alloc),prototype::make_value<std::int32_t>(alloc),prototype::make_value<std::int32_t>(alloc)}},state(prototype::make_value<State>(alloc)),score(prototype::make_value<double>(alloc)),empty(prototype::make_value<Empty>(alloc)) {}
    template<class Alloc> Scalars(prototype::transfer_tag, const Scalars& src, const Alloc& alloc) : id(prototype::transfer_value<std::uint32_t>(src.id,alloc)),enabled(prototype::transfer_value<bool>(src.enabled,alloc)),bits{prototype::transfer_value<bool>(src.bits[0],alloc),prototype::transfer_value<bool>(src.bits[1],alloc)},matrix{{prototype::transfer_value<std::int32_t>(src.matrix[0][0],alloc),prototype::transfer_value<std::int32_t>(src.matrix[0][1],alloc),prototype::transfer_value<std::int32_t>(src.matrix[0][2],alloc)},{prototype::transfer_value<std::int32_t>(src.matrix[1][0],alloc),prototype::transfer_value<std::int32_t>(src.matrix[1][1],alloc),prototype::transfer_value<std::int32_t>(src.matrix[1][2],alloc)}},state(prototype::transfer_value<State>(src.state,alloc)),score(prototype::transfer_value<double>(src.score,alloc)),empty(prototype::transfer_value<Empty>(src.empty,alloc)) {}
    Scalars(prototype::restore_tag, const unsigned char* raw) noexcept : id(prototype::restore_value<std::uint32_t>(raw+offsetof(Scalars,id))),enabled(prototype::restore_value<bool>(raw+offsetof(Scalars,enabled))),bits{prototype::restore_value<bool>(raw+offsetof(Scalars,bits)+0*sizeof(bool)),prototype::restore_value<bool>(raw+offsetof(Scalars,bits)+1*sizeof(bool))},matrix{{prototype::restore_value<std::int32_t>(raw+offsetof(Scalars,matrix)+0*sizeof(std::int32_t)),prototype::restore_value<std::int32_t>(raw+offsetof(Scalars,matrix)+1*sizeof(std::int32_t)),prototype::restore_value<std::int32_t>(raw+offsetof(Scalars,matrix)+2*sizeof(std::int32_t))},{prototype::restore_value<std::int32_t>(raw+offsetof(Scalars,matrix)+3*sizeof(std::int32_t)),prototype::restore_value<std::int32_t>(raw+offsetof(Scalars,matrix)+4*sizeof(std::int32_t)),prototype::restore_value<std::int32_t>(raw+offsetof(Scalars,matrix)+5*sizeof(std::int32_t))}},state(prototype::restore_value<State>(raw+offsetof(Scalars,state))),score(prototype::restore_value<double>(raw+offsetof(Scalars,score))),empty(prototype::restore_value<Empty>(raw+offsetof(Scalars,empty))) {}
    Scalars(prototype::relocate_tag, Scalars& src) noexcept : id(prototype::relocate_value<std::uint32_t>(src.id)),enabled(prototype::relocate_value<bool>(src.enabled)),bits{prototype::relocate_value<bool>(src.bits[0]),prototype::relocate_value<bool>(src.bits[1])},matrix{{prototype::relocate_value<std::int32_t>(src.matrix[0][0]),prototype::relocate_value<std::int32_t>(src.matrix[0][1]),prototype::relocate_value<std::int32_t>(src.matrix[0][2])},{prototype::relocate_value<std::int32_t>(src.matrix[1][0]),prototype::relocate_value<std::int32_t>(src.matrix[1][1]),prototype::relocate_value<std::int32_t>(src.matrix[1][2])}},state(prototype::relocate_value<State>(src.state)),score(prototype::relocate_value<double>(src.score)),empty(prototype::relocate_value<Empty>(src.empty)) {}
#endif
};
struct Part {
    std::int32_t value{};
    XString name{};
    XVector<std::uint16_t> samples{};
#ifndef PROTOTYPE_OLD_V5
    Part() = default;
    template<class Alloc> Part(prototype::make_tag, const Alloc& alloc) : value(prototype::make_value<std::int32_t>(alloc)),name(prototype::make_value<XString>(alloc)),samples(prototype::make_value<XVector<std::uint16_t>>(alloc)) {}
    template<class Alloc> Part(prototype::transfer_tag, const Part& src, const Alloc& alloc) : value(prototype::transfer_value<std::int32_t>(src.value,alloc)),name(prototype::transfer_value<XString>(src.name,alloc)),samples(prototype::transfer_value<XVector<std::uint16_t>>(src.samples,alloc)) {}
    Part(prototype::restore_tag, const unsigned char* raw) noexcept : value(prototype::restore_value<std::int32_t>(raw+offsetof(Part,value))),name(prototype::restore_value<XString>(raw+offsetof(Part,name))),samples(prototype::restore_value<XVector<std::uint16_t>>(raw+offsetof(Part,samples))) {}
    Part(prototype::relocate_tag, Part& src) noexcept : value(prototype::relocate_value<std::int32_t>(src.value)),name(prototype::relocate_value<XString>(src.name)),samples(prototype::relocate_value<XVector<std::uint16_t>>(src.samples)) {}
#endif
};
struct UnitState {
    std::uint64_t id{};
    std::uint32_t revision{};
    bool enabled{};
    XString name{};
    XBlob blob{};
    XVector<Part> parts{};
    XSet<std::int32_t> ids{};
    XMap<XString,Part> attrs{};
    template<class Alloc> explicit UnitState(const Alloc& alloc) : name(alloc),blob(alloc),parts(alloc),ids(alloc),attrs(alloc) {}
#ifndef PROTOTYPE_OLD_V5
    UnitState() = default;
    template<class Alloc> UnitState(prototype::make_tag, const Alloc& alloc) : id(prototype::make_value<std::uint64_t>(alloc)),revision(prototype::make_value<std::uint32_t>(alloc)),enabled(prototype::make_value<bool>(alloc)),name(prototype::make_value<XString>(alloc)),blob(prototype::make_value<XBlob>(alloc)),parts(prototype::make_value<XVector<Part>>(alloc)),ids(prototype::make_value<XSet<std::int32_t>>(alloc)),attrs(prototype::make_value<XMap<XString,Part>>(alloc)) {}
    template<class Alloc> UnitState(prototype::transfer_tag, const UnitState& src, const Alloc& alloc) : id(prototype::transfer_value<std::uint64_t>(src.id,alloc)),revision(prototype::transfer_value<std::uint32_t>(src.revision,alloc)),enabled(prototype::transfer_value<bool>(src.enabled,alloc)),name(prototype::transfer_value<XString>(src.name,alloc)),blob(prototype::transfer_value<XBlob>(src.blob,alloc)),parts(prototype::transfer_value<XVector<Part>>(src.parts,alloc)),ids(prototype::transfer_value<XSet<std::int32_t>>(src.ids,alloc)),attrs(prototype::transfer_value<XMap<XString,Part>>(src.attrs,alloc)) {}
    UnitState(prototype::restore_tag, const unsigned char* raw) noexcept : id(prototype::restore_value<std::uint64_t>(raw+offsetof(UnitState,id))),revision(prototype::restore_value<std::uint32_t>(raw+offsetof(UnitState,revision))),enabled(prototype::restore_value<bool>(raw+offsetof(UnitState,enabled))),name(prototype::restore_value<XString>(raw+offsetof(UnitState,name))),blob(prototype::restore_value<XBlob>(raw+offsetof(UnitState,blob))),parts(prototype::restore_value<XVector<Part>>(raw+offsetof(UnitState,parts))),ids(prototype::restore_value<XSet<std::int32_t>>(raw+offsetof(UnitState,ids))),attrs(prototype::restore_value<XMap<XString,Part>>(raw+offsetof(UnitState,attrs))) {}
    UnitState(prototype::relocate_tag, UnitState& src) noexcept : id(prototype::relocate_value<std::uint64_t>(src.id)),revision(prototype::relocate_value<std::uint32_t>(src.revision)),enabled(prototype::relocate_value<bool>(src.enabled)),name(prototype::relocate_value<XString>(src.name)),blob(prototype::relocate_value<XBlob>(src.blob)),parts(prototype::relocate_value<XVector<Part>>(src.parts)),ids(prototype::relocate_value<XSet<std::int32_t>>(src.ids)),attrs(prototype::relocate_value<XMap<XString,Part>>(src.attrs)) {}
#endif
};
struct Owning {
    XString first{};
    XString second{};
#ifndef PROTOTYPE_OLD_V5
    Owning() = default;
    template<class Alloc> Owning(prototype::make_tag, const Alloc& alloc) : first(prototype::make_value<XString>(alloc)),second(prototype::make_value<XString>(alloc)) {}
    template<class Alloc> Owning(prototype::transfer_tag, const Owning& src, const Alloc& alloc) : first(prototype::transfer_value<XString>(src.first,alloc)),second(prototype::transfer_value<XString>(src.second,alloc)) {}
    Owning(prototype::restore_tag, const unsigned char* raw) noexcept : first(prototype::restore_value<XString>(raw+offsetof(Owning,first))),second(prototype::restore_value<XString>(raw+offsetof(Owning,second))) {}
    Owning(prototype::relocate_tag, Owning& src) noexcept : first(prototype::relocate_value<XString>(src.first)),second(prototype::relocate_value<XString>(src.second)) {}
#endif
};
struct CtorProbe {
    XString label{};
    template<class Alloc> explicit CtorProbe(const Alloc& alloc) : label(alloc) { fixture::on_ctor(); label="probe-owned"; }
    ~CtorProbe() { fixture::on_destroy(); }
#ifndef PROTOTYPE_OLD_V5
    CtorProbe() = default;
    template<class Alloc> CtorProbe(prototype::make_tag, const Alloc& alloc) : label(prototype::make_value<XString>(alloc)) {}
    template<class Alloc> CtorProbe(prototype::transfer_tag, const CtorProbe& src, const Alloc& alloc) : label(prototype::transfer_value<XString>(src.label,alloc)) {}
    CtorProbe(prototype::restore_tag, const unsigned char* raw) noexcept : label(prototype::restore_value<XString>(raw+offsetof(CtorProbe,label))) {}
    CtorProbe(prototype::relocate_tag, CtorProbe& src) noexcept : label(prototype::relocate_value<XString>(src.label)) {}
#endif
};
struct ProbeArray {
    CtorProbe slots[2]{};
#ifndef PROTOTYPE_OLD_V5
    ProbeArray() = default;
    template<class Alloc> ProbeArray(prototype::make_tag, const Alloc& alloc) : slots{prototype::make_value<CtorProbe>(alloc),prototype::make_value<CtorProbe>(alloc)} {}
    template<class Alloc> ProbeArray(prototype::transfer_tag, const ProbeArray& src, const Alloc& alloc) : slots{prototype::transfer_value<CtorProbe>(src.slots[0],alloc),prototype::transfer_value<CtorProbe>(src.slots[1],alloc)} {}
    ProbeArray(prototype::restore_tag, const unsigned char* raw) noexcept : slots{prototype::restore_value<CtorProbe>(raw+offsetof(ProbeArray,slots)+0*sizeof(CtorProbe)),prototype::restore_value<CtorProbe>(raw+offsetof(ProbeArray,slots)+1*sizeof(CtorProbe))} {}
    ProbeArray(prototype::relocate_tag, ProbeArray& src) noexcept : slots{prototype::relocate_value<CtorProbe>(src.slots[0]),prototype::relocate_value<CtorProbe>(src.slots[1])} {}
#endif
};
struct ProbeRoot {
    XVector<CtorProbe> rows{};
#ifndef PROTOTYPE_OLD_V5
    ProbeRoot() = default;
    template<class Alloc> ProbeRoot(prototype::make_tag, const Alloc& alloc) : rows(prototype::make_value<XVector<CtorProbe>>(alloc)) {}
    template<class Alloc> ProbeRoot(prototype::transfer_tag, const ProbeRoot& src, const Alloc& alloc) : rows(prototype::transfer_value<XVector<CtorProbe>>(src.rows,alloc)) {}
    ProbeRoot(prototype::restore_tag, const unsigned char* raw) noexcept : rows(prototype::restore_value<XVector<CtorProbe>>(raw+offsetof(ProbeRoot,rows))) {}
    ProbeRoot(prototype::relocate_tag, ProbeRoot& src) noexcept : rows(prototype::relocate_value<XVector<CtorProbe>>(src.rows)) {}
#endif
};
struct Moves {
    XString left{};
    XString right{};
    Owning fixed[2]{};
    XVector<Owning> rows{};
    XVector<Owning> other{};
#ifndef PROTOTYPE_OLD_V5
    Moves() = default;
    template<class Alloc> Moves(prototype::make_tag, const Alloc& alloc) : left(prototype::make_value<XString>(alloc)),right(prototype::make_value<XString>(alloc)),fixed{prototype::make_value<Owning>(alloc),prototype::make_value<Owning>(alloc)},rows(prototype::make_value<XVector<Owning>>(alloc)),other(prototype::make_value<XVector<Owning>>(alloc)) {}
    template<class Alloc> Moves(prototype::transfer_tag, const Moves& src, const Alloc& alloc) : left(prototype::transfer_value<XString>(src.left,alloc)),right(prototype::transfer_value<XString>(src.right,alloc)),fixed{prototype::transfer_value<Owning>(src.fixed[0],alloc),prototype::transfer_value<Owning>(src.fixed[1],alloc)},rows(prototype::transfer_value<XVector<Owning>>(src.rows,alloc)),other(prototype::transfer_value<XVector<Owning>>(src.other,alloc)) {}
    Moves(prototype::restore_tag, const unsigned char* raw) noexcept : left(prototype::restore_value<XString>(raw+offsetof(Moves,left))),right(prototype::restore_value<XString>(raw+offsetof(Moves,right))),fixed{prototype::restore_value<Owning>(raw+offsetof(Moves,fixed)+0*sizeof(Owning)),prototype::restore_value<Owning>(raw+offsetof(Moves,fixed)+1*sizeof(Owning))},rows(prototype::restore_value<XVector<Owning>>(raw+offsetof(Moves,rows))),other(prototype::restore_value<XVector<Owning>>(raw+offsetof(Moves,other))) {}
    Moves(prototype::relocate_tag, Moves& src) noexcept : left(prototype::relocate_value<XString>(src.left)),right(prototype::relocate_value<XString>(src.right)),fixed{prototype::relocate_value<Owning>(src.fixed[0]),prototype::relocate_value<Owning>(src.fixed[1])},rows(prototype::relocate_value<XVector<Owning>>(src.rows)),other(prototype::relocate_value<XVector<Owning>>(src.other)) {}
#endif
};
#ifndef PROTOTYPE_OLD_V5
struct LocalNode {
    std::uint32_t id{};
    XVector<LocalNode> children{};
#ifndef PROTOTYPE_OLD_V5
    LocalNode() = default;
    template<class Alloc> LocalNode(prototype::make_tag, const Alloc& alloc) : id(prototype::make_value<std::uint32_t>(alloc)),children(prototype::make_value<XVector<LocalNode>>(alloc)) {}
    template<class Alloc> LocalNode(prototype::transfer_tag, const LocalNode& src, const Alloc& alloc) : id(prototype::transfer_value<std::uint32_t>(src.id,alloc)),children(prototype::transfer_value<XVector<LocalNode>>(src.children,alloc)) {}
    LocalNode(prototype::restore_tag, const unsigned char* raw) noexcept : id(prototype::restore_value<std::uint32_t>(raw+offsetof(LocalNode,id))),children(prototype::restore_value<XVector<LocalNode>>(raw+offsetof(LocalNode,children))) {}
    LocalNode(prototype::relocate_tag, LocalNode& src) noexcept : id(prototype::relocate_value<std::uint32_t>(src.id)),children(prototype::relocate_value<XVector<LocalNode>>(src.children)) {}
#endif
};
#endif
#ifndef PROTOTYPE_OLD_V5
struct LocalTree {
    XVector<LocalNode> nodes{};
#ifndef PROTOTYPE_OLD_V5
    LocalTree() = default;
    template<class Alloc> LocalTree(prototype::make_tag, const Alloc& alloc) : nodes(prototype::make_value<XVector<LocalNode>>(alloc)) {}
    template<class Alloc> LocalTree(prototype::transfer_tag, const LocalTree& src, const Alloc& alloc) : nodes(prototype::transfer_value<XVector<LocalNode>>(src.nodes,alloc)) {}
    LocalTree(prototype::restore_tag, const unsigned char* raw) noexcept : nodes(prototype::restore_value<XVector<LocalNode>>(raw+offsetof(LocalTree,nodes))) {}
    LocalTree(prototype::relocate_tag, LocalTree& src) noexcept : nodes(prototype::relocate_value<XVector<LocalNode>>(src.nodes)) {}
#endif
};
#endif
}
XOFFSET_REGISTER_SCHEMA_NAME(sample::Scalars, "prototype.Scalars.v1")
XOFFSET_REGISTER_SCHEMA_NAME(sample::UnitState, "prototype.UnitState.v1")
XOFFSET_REGISTER_SCHEMA_NAME(sample::Moves, "prototype.Moves.v1")
#ifndef PROTOTYPE_OLD_V5
namespace prototype {
template<> struct record<sample::Empty> { static constexpr auto fields=std::tuple{}; };
static_assert(std::is_standard_layout_v<sample::Empty> && alignof(sample::Empty)<=8);
template<> struct record<sample::CvSample> { static constexpr auto fields=std::tuple{field<sample::CvSample,decltype(sample::CvSample::value),&sample::CvSample::value,offsetof(sample::CvSample,value)>{}}; };
static_assert(std::is_standard_layout_v<sample::CvSample> && alignof(sample::CvSample)<=8);
template<> struct record<sample::Scalars> { static constexpr auto fields=std::tuple{field<sample::Scalars,decltype(sample::Scalars::id),&sample::Scalars::id,offsetof(sample::Scalars,id)>{},field<sample::Scalars,decltype(sample::Scalars::enabled),&sample::Scalars::enabled,offsetof(sample::Scalars,enabled)>{},field<sample::Scalars,decltype(sample::Scalars::bits),&sample::Scalars::bits,offsetof(sample::Scalars,bits)>{},field<sample::Scalars,decltype(sample::Scalars::matrix),&sample::Scalars::matrix,offsetof(sample::Scalars,matrix)>{},field<sample::Scalars,decltype(sample::Scalars::state),&sample::Scalars::state,offsetof(sample::Scalars,state)>{},field<sample::Scalars,decltype(sample::Scalars::score),&sample::Scalars::score,offsetof(sample::Scalars,score)>{},field<sample::Scalars,decltype(sample::Scalars::empty),&sample::Scalars::empty,offsetof(sample::Scalars,empty)>{}}; };
static_assert(std::is_standard_layout_v<sample::Scalars> && alignof(sample::Scalars)<=8);
template<> struct record<sample::Part> { static constexpr auto fields=std::tuple{field<sample::Part,decltype(sample::Part::value),&sample::Part::value,offsetof(sample::Part,value)>{},field<sample::Part,decltype(sample::Part::name),&sample::Part::name,offsetof(sample::Part,name)>{},field<sample::Part,decltype(sample::Part::samples),&sample::Part::samples,offsetof(sample::Part,samples)>{}}; };
static_assert(std::is_standard_layout_v<sample::Part> && alignof(sample::Part)<=8);
template<> struct record<sample::UnitState> { static constexpr auto fields=std::tuple{field<sample::UnitState,decltype(sample::UnitState::id),&sample::UnitState::id,offsetof(sample::UnitState,id)>{},field<sample::UnitState,decltype(sample::UnitState::revision),&sample::UnitState::revision,offsetof(sample::UnitState,revision)>{},field<sample::UnitState,decltype(sample::UnitState::enabled),&sample::UnitState::enabled,offsetof(sample::UnitState,enabled)>{},field<sample::UnitState,decltype(sample::UnitState::name),&sample::UnitState::name,offsetof(sample::UnitState,name)>{},field<sample::UnitState,decltype(sample::UnitState::blob),&sample::UnitState::blob,offsetof(sample::UnitState,blob)>{},field<sample::UnitState,decltype(sample::UnitState::parts),&sample::UnitState::parts,offsetof(sample::UnitState,parts)>{},field<sample::UnitState,decltype(sample::UnitState::ids),&sample::UnitState::ids,offsetof(sample::UnitState,ids)>{},field<sample::UnitState,decltype(sample::UnitState::attrs),&sample::UnitState::attrs,offsetof(sample::UnitState,attrs)>{}}; };
static_assert(std::is_standard_layout_v<sample::UnitState> && alignof(sample::UnitState)<=8);
template<> struct record<sample::Owning> { static constexpr auto fields=std::tuple{field<sample::Owning,decltype(sample::Owning::first),&sample::Owning::first,offsetof(sample::Owning,first)>{},field<sample::Owning,decltype(sample::Owning::second),&sample::Owning::second,offsetof(sample::Owning,second)>{}}; };
static_assert(std::is_standard_layout_v<sample::Owning> && alignof(sample::Owning)<=8);
template<> struct record<sample::CtorProbe> { static constexpr auto fields=std::tuple{field<sample::CtorProbe,decltype(sample::CtorProbe::label),&sample::CtorProbe::label,offsetof(sample::CtorProbe,label)>{}}; };
static_assert(std::is_standard_layout_v<sample::CtorProbe> && alignof(sample::CtorProbe)<=8);
template<> struct record<sample::ProbeArray> { static constexpr auto fields=std::tuple{field<sample::ProbeArray,decltype(sample::ProbeArray::slots),&sample::ProbeArray::slots,offsetof(sample::ProbeArray,slots)>{}}; };
static_assert(std::is_standard_layout_v<sample::ProbeArray> && alignof(sample::ProbeArray)<=8);
template<> struct record<sample::ProbeRoot> { static constexpr auto fields=std::tuple{field<sample::ProbeRoot,decltype(sample::ProbeRoot::rows),&sample::ProbeRoot::rows,offsetof(sample::ProbeRoot,rows)>{}}; };
static_assert(std::is_standard_layout_v<sample::ProbeRoot> && alignof(sample::ProbeRoot)<=8);
template<> struct record<sample::Moves> { static constexpr auto fields=std::tuple{field<sample::Moves,decltype(sample::Moves::left),&sample::Moves::left,offsetof(sample::Moves,left)>{},field<sample::Moves,decltype(sample::Moves::right),&sample::Moves::right,offsetof(sample::Moves,right)>{},field<sample::Moves,decltype(sample::Moves::fixed),&sample::Moves::fixed,offsetof(sample::Moves,fixed)>{},field<sample::Moves,decltype(sample::Moves::rows),&sample::Moves::rows,offsetof(sample::Moves,rows)>{},field<sample::Moves,decltype(sample::Moves::other),&sample::Moves::other,offsetof(sample::Moves,other)>{}}; };
static_assert(std::is_standard_layout_v<sample::Moves> && alignof(sample::Moves)<=8);
template<> struct record<sample::LocalNode> { static constexpr auto fields=std::tuple{field<sample::LocalNode,decltype(sample::LocalNode::id),&sample::LocalNode::id,offsetof(sample::LocalNode,id)>{},field<sample::LocalNode,decltype(sample::LocalNode::children),&sample::LocalNode::children,offsetof(sample::LocalNode,children)>{}}; };
static_assert(std::is_standard_layout_v<sample::LocalNode> && alignof(sample::LocalNode)<=8);
template<> struct record<sample::LocalTree> { static constexpr auto fields=std::tuple{field<sample::LocalTree,decltype(sample::LocalTree::nodes),&sample::LocalTree::nodes,offsetof(sample::LocalTree,nodes)>{}}; };
static_assert(std::is_standard_layout_v<sample::LocalTree> && alignof(sample::LocalTree)<=8);
}
#endif
