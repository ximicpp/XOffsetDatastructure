# 阻塞后的具体修正与预算提案

当前v1候选保留，不补写通过；4次编译中只有普通GCC20 v2成功，V5 oracle尚未得到可执行文件。下面是待执行修正，不是已验证实现。

1. 修复生成器的共同fixture定义：allocator-only CtorProbe在两侧都应有足以使数组DMI合法的相同默认构造声明；allocator构造仍优先，保留第二元素抛出与逆序清理测试，不能删除ProbeArray。
2. 区分TypeLayout的public byte-copy trait与internal成员递归语义。当前统一递归数组算法错误地扩大了V1准入。按实际源决策树从完整metadata计算，不手写safe特化、不改固定TypeLayout。增加旧新相同的正/负admission断言。
3. 保留`record { Owning items[2]; }`作为旧V5实际拒绝、新候选也应拒绝的case。其普通对象生命周期可在local-only路径单列；不冒充V1兼容fixture。正向wire数组候选是容器元素为array的形态，先经原oracle确认trait/signature/具体API都合法。这个候选仅调整新测试schema，生产库/V1完全不动；失败也不强制改成合法。
4. 为新backend的restore_at补齐动态元素本身是数组时的路径：数组对象由既定C++20触发建立，递归显式构造非平凡叶元素；不能将整个非平凡数组memcpy进活对象。array/record/container各层职责分别记录。
5. 使用加强后的driver：load失败才归类rejected；已接受图的修改/再次load失败必须使进程失败。该改进已写入当前driver，但尚未重新编译。当前成功的new-v2绑定的是其历史snapshot，不把最新driver视为已运行。
6. 分别编译修正后的旧oracle、普通新backend及ASan/UBSan新backend，然后执行原登记的双向初始/修改后/回传、完整恶意输入差分、OOM/构造/alias/compaction。新增正负断言尽量进入同一TU，不额外启动未计入的编译。

最少还需3次编译，目前只剩2次：总编译上限至少由6调整为7才有可能完成。建议允许总8次（额外2次），留1次有明确根因的修复余量。其余硬预算不变：64个被测进程、512固定case、每图64KiB、owner1MiB、进程3GiB、新文件512MiB、编译+测试累计1200秒、单test30秒；不新增测量、工具下载、工作区或生产修改。

本次单租约窗口在阻塞后结束；未来恢复必须重新获取同一个全局租约，不能把旧租约记录当授权，也不能延长仍被其他项目持有的锁。Windows原生子进程的取消/清理适配仍未建立，此项另列，不能通过WSL互操作隐藏启动，不因Linux通过而填绿。

新增编译预算与修正后oracle能否证明候选正例合法均待定；这个提案不承诺下一次一定通过，也不授权超过上限后继续尝试。
