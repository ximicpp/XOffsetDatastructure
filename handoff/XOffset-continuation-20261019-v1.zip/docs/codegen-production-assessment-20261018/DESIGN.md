# 方案比较与替换设计

## 1. 判断与不可越过的边界

**建议：条件立项；先证明 V1、完整职责和对象生命周期，再决定生产改造。** 从源码可以确定反射查询结果有可离线表达的有限结构，但不能据此推导普通 C++ 实现已可行。最难的部分是完整性、对象构造与加载后生命周期，而非生成字段名称。

评估基于 V5 主头 `c4acc7f2…b9964`。行号均对应该文件，具体证据见 [EVIDENCE.md](EVIDENCE.md)。不采用变化中的 V6 为基线；未来接入 V6 必须在其冻结后另作差异移植和回归，不能将本文评估写成 V6 的实施授权。

目标保持：

- 普通 C++ 定义直接存于 arena；动态字段仍为 XOffset 冻结容器，读取不经通用运行时字段表或虚拟分派。
- rel32 从偏移字段自身寻址；整个 arena 平移与内部对象迁移区分处理。
- 可变长增删改、独立拥有的完整 save/load、显式压缩和默认 Explicit 增长契约。
- V1 精确匹配，完整加载校验、错误优先级、每个受支持容器操作的异常保证。
- 合法 wire 域不能缩成“只有 POD/只有整数/没有嵌套”。有限原型仅是验证切片，不能扩大为全域支持声明。

## 2. 路线比较

| 路线 | 完整枚举及漏字段防护 | 生产/生成端依赖 | V1 风险及判断 |
| --- | --- | --- | --- |
| A. 权威 schema → 普通 C++ 定义 + 全套操作 + 布局断言 | 一个 IR 同时生成定义与所有遍历；定义不允许另处手改；重生成差异门禁 | 最终生成器可为普通 Python 或普通 C++ 程序，生成结果用 C++20/17 | 首选候选。必须逐项证明旧类型布局、签名和行为；生成自定义构造函数也会改变分派，不能只比 sizeof |
| B. 受约束 C++ 定义 → 普通 Clang AST → 同类产物 | 必须遍历所有 FieldDecl/Base、数组/CV、属性、条件分支和模板实例闭包；未知 AST 节点硬失败 | 普通 Clang 开发工具依赖，无 P2996；消费者不必安装 Clang 生成器 | 既有定义导入候选。目标宏/编译参数闭包与私有访问是实质成本；不能用正则或不完整 AST 列表替代 |
| C. 显式字段注册表 | 双写类型与注册时，sizeof/offset 不能发现落在 padding 的漏字段 | 普通 C++ 即可 | 单独使用不满足硬要求。仅当注册 DSL 同时生成类型定义，或由 B 独立校验完整 AST 时可用；前者本质为 A |
| D. P2996 仅开发端导出 C++ | 可利用当前反射建立过渡 oracle | 生产无 P2996，但重生成仍依赖 P2996 | 可作为对照/一次迁移输入，不是彻底去依赖，不作为最终路线 |
| E. 改成纯 trivial wire struct + proxy/外部所有权 | 可生成，但类型、析构/所有权语义显著变化 | 可用普通 C++ | 当前不能接受为默认替代：可能改容器/API/V1 或缩合法域。只可提出另项目，不静默升级 V2 |

A/B 不是承诺支持任意原生 C++。对“既有合法类型”的覆盖，先建立从旧定义到受控定义/适配层的完整映射：字段、CV、访问、构造/析构、比较和迁移定制都入账。遇到无法等价生成的既有合法形态，登记为阻塞，不删除测试、不把它偷偷列为非法。尤其是私有成员、用户构造/析构或 opaque 定制：普通 AST 能看见不等于普通 C++ 可以合法绕过访问或构造规则。若必须保留任意旧类源码完全不变且无任何协作入口，本轮没有证明可行的通用替代，应停止该承诺。

## 3. 权威输入与生成闭包

建议 IR 保存：schema 稳定名称及独立语义修订号、原声明顺序、完整类型和 CV、定长数组维度、枚举底层类型、record 及容器实例闭包、对齐/属性、成员访问策略、默认值及其适用路径、构造/迁移定制、允许的目标 profile。递归容器类型用图 IR 表示；检测非法按值递归，不能把所有递归 schema 一概拒绝。签名递归是否可终止以 V5 实际实例能力为准。

输出至少包括：

1. 普通 C++ 类型定义，或经审计的旧类型适配层；直接字段访问保持可内联。
2. `generated_record_ops<T>` 类似的封闭元数据：按声明顺序的字段类型/访问、初始化、transfer、部分析构、relocate、owns-address、validate、compact/migrate 操作。此名称是设计示意，尚无代码。
3. 两层安全结论：递归 byte-copy 安全和 V1 admission 分离；不是手写 `safe=true`。未知类型默认拒绝并要求补齐可验证定义，不能 opaque 一句 pointer_free 即放行未知字段。
4. 使用目标编译器实际 `sizeof/alignof/offsetof` 的断言和表达式；完整 signature 文本、root ID、schema hash，以及目标布局报告。生成机不计算假定目标 offset 后伪装为原生结果。
5. schema/IR/生成器/模板/配置/输出摘要、输入闭包列表和诊断映射。相同输入确定性生成；不以时间戳制造差异。
6. 负向生成检查：漏字段、篡改输出、陈旧 IR、条件宏漂移、未知属性、未登记类型/目标必须可检测。消费者检查产物身份；发布流程重新生成并比较，而非运行任意消费者生成步骤。

布局断言不是完整枚举证明。新增一个 bool 恰好落在旧 padding 中时，record sizeof 可能完全不变，遗漏仍会破坏校验/迁移。A 通过唯一声明来源防遗漏；B 通过完整 AST 清单与生成清单逐项双射、目标编译上下文绑定防遗漏。两条路线都要做“注入一个嵌套 owning 成员但不更新元数据”的故障试验。

生产包应携带生成结果及身份，不要求游戏/服务消费者运行生成器。生成器可在开发构建独立运行；最终离线重新生成与包验证必须在没有 P2996 头、库、编译器的环境成功。旧 P2996 oracle 只服务迁移对照，不属于最终生成依赖。

## 4. 反射和 TypeLayout 替换点清单

下表是工作项而非已完成实现。布局、容器算法、owner、VM、精确范围索引原则上复用 V5 机制；替换它们访问类型结构的入口，避免顺带进行性能重写。

| 职责 / V5 位置 | 普通 C++ 替代要求 | 不允许的捷径 / 验收证据 |
| --- | --- | --- |
| 枚举 bases/members：1045–1065；各处 meta splice | 生成完整有序清单及直接字段访问；V1 无基类判定继续存在，非 wire/detail 支持域单独登记 | 不能默默跳私有、数组、CV 或 derived 容器字段；清单双射与故障注入 |
| TypeLayout recursive byte safety：外部 admission/layout_traits/signature | 从完整 IR 递归判原生地址、函数/member pointer、引用、vptr、opaque 定制及所有子对象；库冻结容器精确特化继续递归元素 | `trivially_copyable` 单独不够；指针成员也可能 trivial；不能用人工 unsafe trait 接管 |
| V1 admission：3038–3113 | 精确复现白名单、record standard-layout/无基类/非多态/align≤8、容器精确类型及元素递归 | derived XString/XMap 不能误当冻结头；byte-safe 与 V1-admitted 分别测试 |
| 容器绑定/初始化：1510–1600、4218–4399 | 生成分支选择、allocator 注入、数组递归、原构造顺序；空容器绑定也必须正确 | 不能零填 rel32 当作合法空绑定；不能构造绑定 arena 的栈临时容器 |
| 默认/transfer 构造、析构/异常回滚：1535–1600、4247–4364 | 在合法生命周期内构造完整对象；按已成功前缀逆序清理，计数在成功后递增；allocator-aware 拷贝/回退分支保留 | 成员构造抛异常、嵌套数组、host/VM OOM 后逻辑值/绑定/可继续操作不变；业务多步和外部副作用不变成事务 |
| 可无分配 relocation：3861–3889、3945–3972 | 递归算可迁移性；同 arena 迁移重算每个 owning head 的 arena/data rel32，清空源 payload 状态且保留可复用绑定；nothrow 条件必须可证 | 不能 memcpy 含 rel32 的内联头到新地址；迁移中不得新增申请或隐藏失败 |
| 祖先/后代别名与 move：3895–3941、容器 move assignment | 生成嵌套 owning 子树 contains/owns-address 检测；allocator provenance 比较 arena+state；双向检查祖先/后代 | rel32 数值相同不证明同 owner；必须保留 copy-before-retire 回退及 OOM 强保证 |
| 显式压缩：4990–5173 | 新 owner 中按原策略递归重建活图；数组、key/value、vector/set/map、定制策略保留；失败不发布 | 不能把 shrink_to_fit/save 当图压缩；不能把 compact 当 schema 升级；原 owner 仍有效 |
| 完整加载校验：3115–3851、4763–4861 | 元数据驱动相同遍历及判断顺序；合法生命周期建立前用字节安全的读取方式验证；保留 allocator/range 引擎及预算 | 不能只验证 header，不能为性能跳过 bool/空绑定/排序/owned-free 精确冲突 |
| 校验无操作分支裁剪：3621–3660 | 只对 V5 原本没有任何可观察检查的递归类型裁剪；bool、容器始终保留 | enum 当前无枚举值范围检查，不擅自新增拒绝；裁剪不是降低校验 |
| root/type/schema/layout 身份：3994–4215、4880 起 | 保留 schema_name 注册语义、V1 文本语法及 FNV 顺序；target 实际 offset/sizeof/alignof；host root token/epoch 仍进程内 | 不用 `typeid`/pretty_function 或生成器版本替换 wire ID；host 指针绝不写 wire |
| TypeLayout 常量字符串及其他依赖 | 独立普通 C++ 常量字符串实现或生成表达式；保留文本/数字格式；包和工具单独适配 | 不能只去掉主头 `<experimental/meta>` 而仍经 TypeLayout umbrella 间接包含；不改当前固定依赖来掩盖问题 |

现有 TypeLayout 主入口递归包含 P2996 头，`FixedString` 也含 `<compare>`/spaceship/consteval，故不能假定只生成 record 特化就能直接保留整个依赖。未来独立候选应隔离新的 metadata/backend 边界；既有固定依赖及其许可证/内容锁在本次完全不动。是否保留普通工具层接口、公共 trait 名称及兼容 wrapper 属 API 交付工作，需列清来源与许可。

## 5. C++20 与 C++17 的改造范围

| 项 | 普通 C++20 候选 | 普通 C++17 额外工作 |
| --- | --- | --- |
| P2996 查询、splice | 全部生成替换；不能解析主头时残留非法语法 | 相同 |
| concepts/requires：SetLike、MapLike、allocator、view、各容器 overload | 可保留标准 concepts 及约束语义 | `void_t` detection、enable_if/tag dispatch、is_constructible 等；保持重载优先级和二阶段实例化，不将所有约束改 body static_assert |
| `std::span` | 可保留 | 项目自有非拥有视图兼容层：data/size/size_bytes、const 转换、extent 和重载消歧；不能向 std 注入替身。C++17 源 API 与 C++20 span 签名差异要显式公布 |
| construct_at | 可保留，仍需先证明 raw slot 的使用合法 | placement new 包装，完美转发、对齐、返回指针和异常清理；数组单独实现，不能用 scalar helper 冒充数组构造 |
| destroy_at/destroy_n、launder | 有标准设施，但不自动建立生命周期 | C++17 已有这些设施；数组销毁规则及 helper 分支仍须逐项核对，不泛称“C++17 全无这些 API” |
| consteval、常量字符串 | 改 constexpr 或生成文字；结果强制存入 constexpr/static_assert | 同时消除类 NTTP/`<compare>`/spaceship，常量拼接用 C++17 可表达模板；哈希强制常量求值，不能退回运行时字符串反射 |
| 模板 lambda `[&]<...>`、remove_cvref | C++20 可保留 | 用命名函数模板展开 index_sequence；组合 remove_reference/remove_cv，不能改成 decay 丢数组维度 |
| string resize_and_overwrite | 当前有 feature-test 的可用分支及 append 回退 | 保留现有语义等价回退；不能据此预测 C++17 一定慢或快 |
| 指针宽度、大小端、浮点 | 保持 64-bit LE、实际标量布局/浮点断言 | 相同；不能因为弃用 TypeLayout 而漏掉其 config 浮点保证 |
| 对象/数组生命周期 | 按下节单独证明，并覆盖非 implicit-lifetime 成员 | 还需明确选择 C++17 标准规则、实现 DR 支持范围、placement 数组/new cookie 与数组对象语义；不依赖未声明扩展 |

PMR、optional、string_view、structured binding、fold expression、if constexpr、inline/thread_local 等已有 C++17 支持，不能全算成降级障碍。当前 storage-only C++17 成功只证明 VM 存储层，不证明完整库 C++17 已完成。

目标属性也需单列：例如既有合法定义若使用 `[[no_unique_address]]` 一类影响空成员布局的特性，17模式下忽略属性可能改变offset/size；不能用“仍可编译”当兼容。必须证明可用普通定义保持同一V1布局，或明确相应组合尚无解。本次未确认业务schema是否使用这类特性，不能先删这些输入来简化17路线。

## 6. 对象生命周期是首个设计否决门

直接源码事实：TypeLayout admission.hpp 明言 byte-copy safe 不保证 C++ 对象生命周期；V5 的 XFixedString/XFixedVector 有非平凡析构，copy/move 构造被删除；load 将 bytes 复制入 VM，再按类型查 root/容器。新实现不能把这个 trait 当作生命周期证明，也不能用 sanitizer 未报告来替代标准论证。

标准依据：隐式对象创建限于 implicit-lifetime 类型，且不自动启动其中非此类子对象；`launder` 不创建对象。见 [WG21 P0593R6](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2020/p0593r6.html)。C++17 的初始化/存储重用要求另见 [N4659 basic.life](https://timsong-cpp.github.io/cppwp/n4659/basic.life)。

**保持 V1 的候选：** wire bytes 和 typed 对象分两段发布。先在受限拥有的输入/arena bytes 上，用 `memcpy` 到已存在的标量临时值进行范围/绑定/元数据/图检查，保持旧错误顺序；完全验证前不访问尚不存在的非平凡 typed 对象。再由生成的内部 restore-tag 构造/placement 路径，在相同地址建立完整 root、子 record、容器头及活元素的生命周期，恢复已经验证的标量/头字段，不重新分配 payload、不执行普通绑定默认值覆盖输入。owner/schema 的 typed 发布在全部成功之后。

该候选只是待证明设计，至少还有这些难点：

- 完整 enclosing object 与成员生命周期，动态 `T[n]` 数组对象及 capacity 未使用区域的存储规则，不能仅逐成员 placement 后假定有合法 T；C++17 尤其不能靠 `reinterpret_cast<T*>` 后指针算术糊过去。
- 验证后建立生命周期需保存即将被构造覆盖的字节；仅 bounded 临时标量/头或受限计划，不引入整图深复制和额外 payload 分配。float/NaN 等允许表示要保留，不能值转换导致位模式漂移。
- generated record 构造支持数组、const 成员、私有访问、原有 allocator ctor/默认值语义及用户定制。原 reflect 路径零填/逐字段初始化与已有 allocator ctor 路径不相同，不能无条件调用默认构造函数或默认成员初始化。
- 引入生成构造函数不能意外改变 `has_wire_allocator_ctor`、triviality、聚合初始化、重载匹配或 compactor 策略。需显式 backend 分派；维护既有 wrapper 占用大小、对齐和 root slot 布局，差异逐项验收。
- 构造/恢复失败时清理只能处理已合法建立的对象，不能让析构遍历未验证字节或重复退休 payload。整块 owner 销毁与单元素 erase/rebuild 的析构契约区分；V5 Core 析构只释放 owner 元数据/存储，不承诺逐个执行任意用户析构副作用。
- 恢复额外 host/scratch OOM、发布顺序和错误优先级需与旧契约对齐。若需要新增可抛分配点而无法保持保证，这是阻塞；不能靠禁用异常或缩输入域通过。
- 构造合法化可能增加加载工作，需在未来独立计账；保留低成本完整快照原理不等于承诺加载完全不触碰字段。

另一候选是 ABI 保持的、受控表示层配合生成访问代码；它若要求改 `root<T>()` 类型/容器析构行为，属于显式 API 变更，当前不能直接采纳。C++23/26 的 lifetime 库函数也不能作为 C++20/17 最终依赖，且不能泛化处理所有非平凡类型。

本评估没有判定现有每个执行路径均有 UB；结论是**普通工具链版本尚缺系统生命周期证明**。如果完整合法域和既有 API 在所选语言中无法同时满足，保持原实现与 V1 数据读取能力，报告 no-go；不得通过仅准入 trivial 类型、改容器 wire 或关闭校验伪装成功。
