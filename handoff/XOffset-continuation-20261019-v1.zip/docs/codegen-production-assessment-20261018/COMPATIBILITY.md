# V1 兼容证明策略

状态：以下全部是待执行门禁设计。本文没有运行 writer/reader，没有产生新的跨平台兼容结果。

## 1. 固定什么

基准是 [V5 验收](../PERFORMANCE_V5_ACCEPTANCE.md)指定、此次重新哈希确认的实际主头 `c4acc7f2…b9964` 和 VM 头 `22f181b5…9ad`。V5 旧控制双向 60 例和补充 8 schema 为**已有验收的引用**，不能替代新生成版本的证明。根目录 F、历史冻结包、V4、V6 不可混作此旧 writer。

以实际源码优先于早期设计草案。`V1_FIXED_SCHEMA_DESIGN.md` 中建议 allocator 形状、零复制措辞、growth 搬迁说明等不全对应当前实现；本方案以 ALPHA 合约及 V5 为准。

| 不变量 | V5 事实及新候选要求 |
| --- | --- |
| 外层 header | XWireHeaderV1：align 8，按源码声明计算大小 88；magic 为 `XOFFV1\0\0`，major/minor=1/0，header_size 为其 sizeof。新版本用原生断言核验这个计算结果 |
| 外层字段顺序 | magic, format_major, format_minor, header_size, used_bytes, reserved_bytes, root_offset, allocator_offset, root_type_id, schema_hash_lo, schema_hash_hi, flags, endian_tag, crc32c, reserved0 |
| 保留位 | flags=0，endian_tag=0x01020304，schema_hash_hi/crc32c/reserved0=0；不可借保留位塞生成器版本、CRC、业务 revision |
| Payload | arena_header 原字段顺序，按声明计算大小48/align8；magic `XBUFV1\0\0`；offset 从 payload 起算，不从外层 header 起算 |
| Allocator | XAllocatorStateV1 原字段顺序，源码断言 size88/align8：arena_begin/end, free_bytes, epoch, segment_delta, reserved0, freelist_head[16]；free header 和 size-class/accounting 规则不变 |
| Allocation header | 原 total_bytes/user_bytes/user_offset/alignment 四个 u32，源码断言 size16/align8；保留实际分配时 alignment≥alignof(max_align_t) 等目标相关行为，不能只比容器大小 |
| 容器头 | 冻结头 size16/align8：arena_delta:i32、data_delta:i32、size:u32、capacity:u32；string 的终止符和分配圆整规则不变，map/set 沿用实际 XKeyValue/排序表示 |
| rel32 | 字段自身地址 + 有符号 delta；0 为 null，绑定/tag 分支沿用实际实现；不能改为 arena base offset 或统一 u32 |
| Record | 原声明顺序、每字段 offset、实际 sizeof/alignof、数组 stride/dim、枚举底层类型；不加隐藏版本字段/vptr/指针，不改 packing |
| Owner | 一个 buffer 一个 root/allocator，owned 动态块互斥，不能把多个对象共享同一动态 payload 变成默认 DAG；host owner/TLS/cache/epoch 不进 wire |
| Snapshot | owning copy，used_end 规范化，save 将 reserved_bytes 写成 used_bytes；内部空洞、container spare capacity、free-list 仍可能存在，普通 save 不做活图重打包 |
| 上限/策略 | payload≤0x7ffffff8，固定硬 maximum，64-bit LE；Explicit 默认，Automatic/pool opt-in；OS/owner 策略不序列化 |

跨 ABI 的分配起点、对齐填充、max_align_t/page 影响要实测。相同 wire 签名不包含所有 allocator 工作量细节，不能把头布局相同推导成大小、性能或任意数据逐字节一致。

## 2. 签名与身份算法必须逐字符保持

V5 由 XOffset 自己拥有 verified-wire 签名，不直接使用 TypeLayout 的通用 layout signature 作为 schema hash：

- `root_type_id = FNV1a64(schema_name)`，offset basis=14695981039346656037、prime=1099511628211。
- `schema_hash_lo = FNV1a64(schema_name || wire_abi_signature<T>())`，通过同一个 hash 状态先名称后 signature 追加，hi=0；无新分隔符。
- record 为 `record[s:<sizeof>,a:<alignof>]{@<offset>:<field-signature>,...}`，字段顺序按声明，**没有字段名**。
- sequence 头文字形如 `xstring[s:16,a:8]{arena:rel32,data:rel32,size:u32,capacity:u32}`；map/set/vector 追加原元素模板文字；`XVector<std::byte>` 用 `xblob`，不可用普通 `xvector<byte>` 代替。
- array 使用 `array[N]<...>`，enum 使用 `enum<underlying-signature>`，XKeyValue 使用源码的 `xkv[s:...,a:...]<K,V>`，不可擅自改成 record 或为其追加 offset 文本。
- scalar 必须保留 V5 `if constexpr` 分支次序。int8_t 与 signed char 等可能同型，先命中 char 分支会影响 token；不可按 schema 拼写强行改成 i8/u8。int64_t 与 long/long long 的平台 typedef 身份同样须按实际 C++ 类型判定。
- `root_type_identity_` 的进程内 token 与 epoch 是 host 类型防护；不能拿它替代 wire root ID，也不能把它序列化。

生成器应输出目标编译器可计算的表达式和断言，而非把在开发机观察到的数值硬编码为全平台通用。先比较完整签名文字，再比哈希，再进行运行矩阵。单个64位 hash 匹配既不证明布局无碰撞，也不证明语义一致。

字段改名、同类型字段的语义交换、枚举值含义变化可能保持当前签名不变。生产 schema catalog 需在 wire 外独立记录语义修订/字段身份、完整 IR 摘要和允许的 reader/writer 集；不修改 V1 hash 公式来“修复”此问题。名称和 signature 相等仅是加载的必要条件。

## 3. 合法域不能偷换

以“旧 API 在给定 schema/profile 可实例化，且旧 reader 接受的有效 image”建立基准域，区分 byte-safe、admission trait 为真、signature 可生成和具体操作可编译四个层次。

必须覆盖 scalar、bool、枚举、嵌套 record、多维数组、空/非空容器、XString/XBlob、fixed/public vector/set/map、XKeyValue、字符串 key/非平凡 value、CV、allocator-aware 和反射默认构造路径。byte-safe 的非 wire 类型、基类/多态/union/pointer/reference/member pointer、derived 容器、align>8 等保持原拒绝。

两个容易误判的事实：

1. 草案“禁 long/int”不能覆盖实际规则。typedef 可能同型，V5 `test_wire_admission.cpp` 明确按实际 fixed-width alias 接受或拒绝 HasLong。生成器可以给新 schema 风格诊断，但兼容层不能因原拼写为 long 就拒绝过去的合法数据。
2. V5 trait 的 record 分支未单独禁止用户析构，bit-field 还会在签名阶段被明确拒绝。不能用草案“无自定义析构/无 bit-field”推断当前 trait 与全部操作域完全一致。保留差异台账；遇到构造/访问不可等价的旧合法类型是阻塞，不能以更窄新 schema 子集宣告完成。

现有 reader 不检查 enum 值是否列于枚举，也不提供通用 UTF-8、数值范围或业务属性合法性验证。新 reader 不新增这些拒绝来扩大安全成绩；业务语义校验在 typed load 成功之后、业务发布之前独立完成。允许的标量/float 位表示、嵌入 NUL、padding/无害未引用字节也不应被误判成格式错误。

## 4. writer/reader 与修改矩阵

每份 fixture 绑定 schema/完整签名、源码 hash、生成输入/输出 hash、compiler/stdlib/SDK/flags/target ABI、可执行文件 hash、数据生成种子和修改 trace。旧程序用真实固定 V5；新的20/17程序不得共享从旧反射查询中偷偷产生的运行依赖。oracle 对照不属于新生成器的必要步骤。

| Writer / Reader | 状态与必须验证的操作 | 当前证据 |
| --- | --- | --- |
| V5 → 新20 | 初始图、修改后碎片图；完整 load、查询、变长修改、grow、再 save | 未执行 |
| 新20 → V5 | 同一 schema/profile 可兼容布局，旧 load、查询、变长修改、再 save | 未执行 |
| V5 → 新17；新17 → V5 | 与20完全相同的输入域/保证；单独生命周期和 API 验收 | 未执行 |
| 新20 ↔ 新17 | 同/跨目标平台双向读写，不以同机 roundtrip 代替 | 未执行 |
| V5 → 新 → V5 | 初始/旧修改后加载，新版替换 string、append/erase 嵌套 vector、map/set 插删、显式 grow，再保存；旧版复读和继续变更 | 未执行 |
| 新 → V5 → 新 | 反向执行相同 trace，验证 free-list 可用、rel32 和绑定无残留 | 未执行 |
| 旧/新 → 新 compact → 旧 | 显式压缩为新 owner，原 owner 仍完整；输出被旧 reader 接受，活图内容/排序一致，handles 按契约处理 | 未执行 |
| 错 root/name/schema/layout | 明确不兼容时按原入口顺序拒绝；不能“尽力读”或重标 verified | 未执行 |
| raw load → typed/save_verified | 原禁止 relabel 路径继续禁止；unsafe 仍仅为受信任入口 | 未执行 |
| OOM/throw → 再保存/增长/重试 | 逐操作对比逻辑值、顺序、binding、owner 清理；不要求 capacity/bookkeeping 全回滚 | 未执行 |

验证内容用独立逻辑快照/哈希 oracle（字段值、容器顺序和允许的位模式）及后续可变更性共同判断。对明确初始化且确定输出的 golden case 再要求字节完全一致；对规范化允许变化的 capacity/allocator 不要求全部历史 image 重存字节相等。任何字节差异须解释，不能只比同机业务 checksum。

## 5. 完整校验、恶意输入与错误优先级

header 错误顺序以 V5 load_verified 源码为准：小于 header → magic → major/minor → header_size → endian → flags → root ID → schema lo/hi → used 与输入长度 → reserved/payload 上限 → crc/reserved → root offset → allocator offset。然后复制到独立 owner，执行 payload header/used_end、root/allocator 存在性与 offset 一致性检查，最后 graph；typed/schema 仅在成功后发布。

graph 顺序：arena flags/reserved 检查 → arena owned → allocator allocation → root allocation → allocator state/free-list → root 按声明顺序，容器元素按原顺序。每次冲突检测先整体寻找 owned，不能碰到 free 就提前报告从而漏掉后续 owned。V5 精确字节 membership、稀疏大 arena、dense 逻辑预算和 scratch OOM 保证继续保持。

| 注入类 | 要求与差分检查 |
| --- | --- |
| header 截断、长度不等、版本/endian/flags/保留位、root/schema 不符 | 旧/新均拒绝；对双缺陷输入比首个异常类别/信息及可观察顺序 |
| payload header、used_end、root/allocator offset 越界/不齐/不一致 | 分配上限与旧保证不变；先检查再寻址，失败无 typed 发布 |
| rel32 极值、0/错误绑定、指向别 owner/allocator、加法溢出 | 先 host 宽度边界和 origin 校验；不能先构造非法 T 引用再校验 |
| size>capacity、乘法/加法溢出、空头残留 delta、字符串无终止符 | 旧拒绝条件和次序保留，包括空容器绑定；不读取超界 bytes |
| allocation header 尺寸/对齐/user_offset/total 不符 | live/free 全部验证，不能仅用用户 payload 范围代替含 header 的 owned 范围 |
| live-live/shared block、live-free、free-free、head/root/allocator 重叠 | 精确 membership 不得改为粗略页或包围盒；多重错误验证 owned 全局优先 |
| free-list 环、越界、错误 bucket、block size、free_bytes 不符 | 全部拒绝，循环被 overlap/range 机制限制；有界资源下停止并释放 staging |
| bool 非0/1（含数组/嵌套）；map/set 乱序/重复 key | 保留检查；enum 未命名值等旧合法图继续接受，不用新增拒绝替代兼容 |
| 合法/无害 bit perturbation、padding、空值、保留 spare capacity | 接受域差分；接受后 grow/mutate/save/第二次 load 必须继续安全 |
| registry/scratch/VM/输出分配失败、构造抛出、取消前 staging 清理 | 对应资源路径的原保证与生命周期计数；不得让析构跟随未验证 rel32 |

单故障用例不足以证明优先级，至少加入 header 双错、前后字段各错、同区间同时 owned/free、OOM 与部分构造组合。对比异常类型、既有文本或稳定可核验分类、首个观察点和清理行为。若候选增加内部步骤导致错误顺序改变，先报告阻塞，不重写旧 golden 使其通过。

初期以固定小 corpus 作差分，不在本任务启动 fuzz。后续 fuzz/metamorphic 的有效性预先固定：每个接受样本都继续修改/再存，不把“拒绝越多”当正确。

## 6. 目标平台矩阵与证据等级

| Profile 候选 | 最终需实际环境 | 现有证据边界 |
| --- | --- | --- |
| Windows x64 | 普通 MSVC；若发布 clang-cl 也单独冻结其 profile，实际 CRT/编译选项 | 当前根 storage 有原生结果；没有新20/17 full 结果 |
| Windows ARM64 | 若纳入发布，原生普通工具链与设备，单独 CRT/ABI | 未建立 |
| Linux x64 | 普通 GCC/Clang，所选 libstdc++/libc++、内核/运行形态 | V5 WSL P2996 功能验收不是新普通工具链，也不是独立原生机结果 |
| Linux ARM64 | 原生 ARM64 GCC/Clang profile | 未建立；不能用 QEMU 性能替代 |
| Android ARM64 | 实际 NDK/Clang/libc++、API level、设备 page size/OS | 只有合成目标签名引用，非 native wire 结果 |
| iOS ARM64 | 实际 Apple Clang/SDK/libc++、deployment target、真机 | 历史 macOS ARM64 不是 iOS，更不是该 V5 新 backend 结果 |

先定发布 profile 集合 P，再对每一有序 `(writer-profile, reader-profile)` 执行运行矩阵，包含对角线。同一 OS/架构不同 compiler/stdlib 是不同 profile。若采用表中全部六个，则为36条有向平台边；Windows ARM64 是否发布是后续产品支持决策，不能在未验证时默认为支持。C++20/17、旧/新实现方向再独立展开；没有可运行旧 V5 profile 的格子标记缺证，不能拿合成 signature 填绿。

每目标导出真实 sizeof/alignof/offsetof、序列头、标量/enum/数组、max_align_t、签名及一组实际 wire，再由其他目标读取、修改、保存回传。宿主交叉编译/模拟器可做早期诊断，正式支持结论保留原生/仿真身份；iOS simulator/Android emulator 不代替 ARM64 真机。现有 tools/sigs 的四目标是 explicit catalog + ABI metadata 基线，不是四个 native exporter，也不是任意用户 schema 的证明。

任何原生布局不同：先拒绝该 schema/profile 组合，调查是否可通过受控普通定义、合法对齐和固定宽类型保持同一 V1 表示。不能 `#pragma pack(1)`、修改 hash、放松 reader 或默默升级 V2。若当前 V1 不能在目标组合实现，保留已证明的 V1 reader 和离线转换候选，明确该目标 no-go；扩大合法域或新格式需另立版本决策。

## 7. Schema 演进与旧数据保留

V1 固定 schema。生产 schema revision 不可只用名称或64位 hash 表示，应有外部 catalog：完整定义/语义摘要、目标布局、writer/reader profile、部署批次、迁移链和回滚 reader。

演进候选保持 V1：旧 schema 原样保存为独立类型/namespace/已冻结生成产物；由对应完整校验 reader 读取旧 image，在独立新 owner 中显式映射到新 schema，使用新 schema 的 V1 header/hash 保存。变更字段默认值、删除字段保留、未知字段和数值转换逐项指定；不原地改旧 header 使其冒充新数据，不把 `XCompactor` 当升级器。

滚动部署可以先部署兼容集合 reader，再启用新 writer；每个数据 envelope 路由到正确 reader。持久化不可重建的旧数据，保留原 bytes、工具链/运行环境或已证明的新独立 reader、转换工具及回滚映射。降级会丢字段时，保留旧副本/sidecar 或禁止降级写回，不静默舍弃。业务未给版本窗口/保留期限/恢复点时，此项仍是生产前提，不能填“已支持演进”。
