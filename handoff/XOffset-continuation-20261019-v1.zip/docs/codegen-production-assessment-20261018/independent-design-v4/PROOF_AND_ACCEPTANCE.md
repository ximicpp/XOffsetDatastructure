# 证明责任与验收台账

本表是独立实现的待执行门，不是已通过清单。v2 的成功/失败只属于其保存快照；当前阶段只完成调研设计。

| ID | 要证明的事实 | 必要证据 | 当前状态 |
| --- | --- | --- | --- |
| M1 | 每个声明字段都进入全部操作 | 唯一 IR、定义与清单对应、padding bool/嵌套 owning 漏项/篡改负控 | 设计已给出，未实现 |
| M2 | 实际目标布局保持 V1 | compiler 计算 sizeof/alignof/offsetof、完整签名全文、再比 hash | 新独立实现未执行 |
| M3 | 公开 byte-copy、内部递归、V1、具体 API 分离 | 数组/容器物理头与元素正负 oracle；union 等公开 trait 单列 | 旧原型有部分证据，不能继承 |
| C1 | 生成业务 record 不无意改变构造分派 | aggregate traits/重载/默认值/allocator-priority 对照 | 外部 aggregate 构造为首选候选 |
| L1 | raw 图验证前没有非平凡 typed 访问 | ByteView/offset 数据流审查、坏 bool/rel32/截断输入 | 未实现 |
| L2 | 恢复来源不被目标构造覆盖 | load 原始输入 view 与 staging 非重叠、有效期和读地址审计 | 输入驱动恢复候选，未证明全路径 |
| L3 | enclosing object 与成员都真正建立 | 完整 aggregate/合法 ctor 初始化及数组展开；不得只有成员 placement | 待试验 |
| L4 | capacity 数组与 live 元素分别合法 | fresh/reuse/tail-expand/clear/erase/rebuild/compact 的开始结束及指针依据 | 否决级开放项 |
| L5 | rel32 具有合法寻址来源 | backing byte-array/VM/profile 规则、signed offset 算术、范围/对齐与 launder 可达性 | 否决级开放项 |
| L6 | 标量表示和 CV 不缩旧域 | byte oracle 覆盖正负零/NaN 等；const/volatile/潜在重叠单列 | 非 const 平凡成员有候选，其他开放 |
| L7 | 恢复及迁移的异常清理正确 | 第二字段/第二数组元素抛出、精确析构、OOM、无半发布、重试 | 未实现 |
| L8 | 整体 owner 释放与元素析构契约匹配 | owner 不擅自增加任意业务析构副作用；erase/回滚按活对象处理 | 待规格映射与试验 |
| R1 | VM/allocator 不破坏地址、上限及 image | reserve/commit/decommit、pool/move/swap/epoch、V1 block 元数据 | 独立实现未开始 |
| R2 | 同 allocator steal 与跨 owner/祖先后代回退正确 | owner/provenance 双向检查、copy-before-retire、失败后源目标逻辑不变 | 独立实现未开始 |
| W1 | 新旧 V1 互操作且继续可修改 | 双向初始/修改/回传、grow、compact、原 owner 保留 | 新独立实现未执行 |
| W2 | 接受域和首个错误保持 | 固定合法/恶意/双故障 corpus，逐行比结果；接受后继续改存读 | 新独立实现未执行 |
| W3 | 不把自洽当兼容 | 固定旧 reader/writer + 独立逻辑模型 + 新实现；最终产物身份绑定 | 方案已给出 |
| A1 | 旧合法类型没有被悄悄排除 | 字段/API/私有/析构/比较/opaque/CV 逐类型映射表 | 需真实业务 schema 输入，尚未闭合 |
| P1 | Windows 取消后无原生子孙遗留 | suspended 入 Job、超时/kill/失联/nested-job 故障，drained 后释放原锁 | 基础设施前提未完成 |
| P2 | 各 profile 的 ABI/wire 真实成立 | 原生导出与所有已声明有向 reader/writer 边；修改回传 | 未执行 |
| D1 | 重新生成与消费无实验依赖 | 普通环境离线生成、实际 include/运行依赖、包/multi-TU/ODR/混版本诊断 | 未执行 |

每一份报告至少列出：规范来源、输入/schema/profile、生成器与输出身份、实际构建输入快照、编译器/stdlib/SDK/flags、逐 job charge、运行结果、失败清理、当前源码是否与执行快照一致。哈希审计不等于平台运行通过。

资源分级：文档、少量指定源码阅读和静态推导可在当前设计阶段完成；复制、生成运行、构建、被测运行、文件集合哈希/扫描须进入既有共享租约，并在新的独立输出目录执行。不得借“自测”“诊断”或脚本包装绕过编译次数、真实子进程和 case 记账。

旧派生原型的收尾与新独立实现是不同交付。前者即便补齐最终 driver，也不能使本表自动完成。新方案先做 I1 的可否决试验，再决定是否承担 I2–I5；所有最终目标保持，阶段划分不构成降低验收范围。
