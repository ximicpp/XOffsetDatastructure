# 独立 C++20 实现：综合评估与设计决策

日期：2026-10-18。分支：`codex/offline-codegen-cpp20-20261018`。状态：设计完成，关键可行性仍待证明；本轮没有新增实现、构建或测试。

**建议：独立编写 schema 编译器、完整元数据与类型操作、运行时和 V1 校验器；以普通 C++20 为首目标，以 V5 为只读兼容规范和 oracle。先通过生命周期与布局否决门，再投入完整运行时。**不把“已有普通 C++20 分支”当成满足当前约束的证明，也不把“独立开发”当成无须兼容审查的理由。

本决策取代此前“复用 practical 生成器前端”的建议。历史调查和原型证据保持原样，不回写成新方案结果。

## 1. 独立实现与任务边界

本设计按独立实现评估：不复制、移植、cherry-pick main/practical/next 的生成器或运行时；不以现有原型的机械派生 backend 作为新实现底座。现有源码、文档、wire 和失败样本只作为接口要求、反例和只读对照。V5 的协议常量、布局和可观察契约是兼容目标，不属于可任意重设计的部分。

新生成器使用 Python 标准库及结构化 JSON 输入；新消费者使用普通 C++20 标准库和必要 OS VM API，不依赖 PFR、TypeLayout、Boost.Container 或 P2996。旧 P2996 oracle 只在开发验证侧存在，重新生成和用户消费不得要求它。既有共享协调器作为执行基础设施继续使用，不改锁、不绕过租约，也不改生产库、demo、V6 或固定依赖。

目标仍是：普通原生字段访问、可修改变长 owning 容器、独立完整快照、稳定 arena 基址、V1 双向兼容、完整图校验、异常及别名契约。C++17、schema 版本迁移、业务网络和性能资格分别立项，不能从 C++20 小切片的通过中继承。

## 2. 调研结论及证据层次

| 观察 | 已有依据 | 对新设计的约束 |
| --- | --- | --- |
| 仓库已有普通 C++20 路线及 schema 生成 | [分支调查](../branch-survey-20261018/REPORT.md) | 证明路线有先例；本次不采用其代码和生成模板 |
| practical 的表示、地址策略、压缩与当前 V5 不同 | 同一调查中的固定 commit 源码对照 | 保持当前契约必须独立实现，不能靠改编译标准完成 |
| 本地 v2 三个 schema 有双向、差分和 sanitizer 证据 | [v2 结果](../prototype-cpp20-v2/RESULT.md) | 支持有限切片可研究，不证明新独立实现通过；最终 emit 修改仍未复编 |
| 公开 trait、内部成员递归、V1、具体 API 不是同一集合 | v2 数组正负 oracle 与原固定源码 | 分开表达和测试，不凭一个 safe 标记推导全部能力 |
| 生命周期、浮点表示、指针来源与 native 清理仍有缺口 | [上一轮研究](../research-design-v3/RESEARCH_AND_DESIGN.md) | 在扩大功能前设置可否决的设计门 |

外部机制比较只用于判断设计空间：FlatBuffers 有实验性反射修改/resize 路径，resize 可能使既有 view 失效，不能简单说它“不能修改”；Cap’n Proto 使用自己的分段/指针编码与校验策略。两者提供思路，但采用其表示都不是保持当前 V1 的直接办法，本方案不采用它们的实现或协议。[FlatBuffers reflection API](https://github.com/google/flatbuffers/blob/master/include/flatbuffers/reflection.h)、[Cap’n Proto encoding](https://capnproto.org/encoding.html)

## 3. 方案比较

| 路线 | 完整性 | 生命周期/API 代价 | 结论 |
| --- | --- | --- | --- |
| 结构化 schema 同时生成定义与操作 | 唯一声明来源，可逐字段生成与校验 | 构造及旧类适配仍须证明 | 主路线 |
| C++ 字段 DSL 同时生成定义与清单 | 同样可以单一来源 | 宏诊断、复杂类型表达和演进工具更难 | 不作为首选输入；保留后续研究 |
| 普通 Clang AST 导入 | 可枚举已解析配置的声明 | 无法自动解决 private 访问、原构造/析构及条件配置 | 仅后续独立导入工具，不进入首个生成链 |
| 类型定义与手工字段注册分离 | 可能遗漏落在 padding 内的字段 | 维护者双写，缺独立完整性保证 | 不接受为最终依据 |
| 全部使用 raw bytes + proxy/view | 可以避免部分原生对象恢复问题 | 改变 root<T>()、字段和容器对象 API | 不在当前约束下自动采用 |
| P2996 导出后消费普通 C++ | 过渡 oracle 方便 | 重新生成仍有 P2996 依赖 | 只作对照，不作产品生成器 |

LibTooling 能支持独立 AST 工具，但工具需要真实编译上下文；AST 可见不等于普通代码有合法访问/构造权限。它不构成“任意旧 C++ 类原样导入”的解法。[Clang LibTooling](https://clang.llvm.org/docs/LibTooling.html)

选择依据依次为：保持 V1/可观察行为的可能性、完整元数据来源、生命周期可证明性、工具链交付、实现与验证成本。当前没有可用于这几条路线的统一性能实测，因此不打综合分或预估提速百分比。

## 4. 总体架构

```mermaid
flowchart LR
    A[结构化 schema] --> B[规范化 IR 与语义检查]
    B --> C[普通 C++20 类型定义]
    B --> D[完整字段描述与类型操作]
    B --> E[目标布局表达式与来源清单]
    C --> F[新运行时与 V1 接口]
    D --> F
    E --> F
    F --> G[固定 V5 oracle 差分]
    G --> H[原生 profile 与发布资格]
```

| 模块 | 独立实现内容 | 关键不变量 |
| --- | --- | --- |
| Schema compiler | JSON 解析、类型图、声明顺序、语义/未知节点诊断、确定性输出 | 不接收未检查的 C++ 片段，不按字符串猜类型尺寸 |
| Generated types/ops | 完整声明、字段描述、构造/转移/恢复/迁移、校验访问、owns-address、压缩遍历 | 每项操作来自同一 IR；实际目标计算布局 |
| Storage owner | OS reserve/commit/decommit、硬上限、显式 grow、move/swap/epoch 与池化边界 | arena 基址稳定；host 信息不进入 wire |
| Allocator | 按 V1 头/size-class/free-list 协议独立实现申请、复用、退休与回收 | 每个动态块唯一 owning，元数据可由旧 reader 解释 |
| Containers | V1 冻结头的 string/blob/vector/set/map；allocator provenance、移动/回退和异常保证 | 不含 host 指针或隐藏 wire 状态；容器元素移动规则单列 |
| V1 reader/writer | 头/图校验、对象恢复、typed 发布、规范化 save | 失败不发布；reserved 字段和 hash 规则不变 |
| Verification | 独立逻辑模型、旧 reader/writer、负控、故障与平台矩阵 | 不把同一套新代码同时当实现和唯一正确性 oracle |

建议目录为新的独立 `independent-cpp20/`，包含 `generator/`、`include/`、`generated/`、`tests/`、`coordination/`、`evidence/`；本轮不创建该实现目录。CMake 只在该目录设置普通 C++20 目标，不触碰根 CMake、生产头或 demo。

## 5. IR 与完整元数据契约

IR 使用明确节点：scalar、enum、record、array、string/blob、vector/set/map、cv-qualified type、显式适配入口。数组保存完整维度，record 保存全部非静态字段的顺序与稳定业务身份。类型按图管理，区分容器递归与非法按值递归；能否生成有限 V1 signature 另作检查。

生成产物包含五组数据：

1. 真实 C++ 定义及可验证的字段/属性清单。
2. 字段精确类型、成员访问、目标 `offsetof`、声明序号与数组 stride 表达式。
3. make、copy/transfer、restore、relocate、destroy-prefix、owns-address、validate、compact 操作及前提。
4. 完整 V1 signature 文本、root ID、schema hash 和目标 profile 的布局报告。
5. schema/IR/生成器版本、配置、输入闭包与输出身份；外部语义版本不塞进 V1 保留位。

五个结论分开生成：`metadata_complete`、旧公开 byte-copy 语义、旧内部递归语义、V1 admission、具体操作资格。未知类型/属性不能用默认 8-byte 尺寸或 safe=true 放行。对原来合法但尚无恢复路径的类型，记录“实现未覆盖”，不能修改旧合法域后宣称完成替换。

每个合法输入字段必须同时进入定义、布局、校验、构造、迁移和压缩清单。重生成逐字比较、padding 内加 bool、嵌套 owning 漏项、输出篡改、未知类型、条件 profile 漂移必须实际失败。sizeof/alignof 相等只能验证部分布局，不单独证明清单完整。

新内部命名空间与第三方库分开；不向 boost::typelayout 注入替代主模板。兼容 XOffset 既有公开别名/API 需单独核对，未支持的第三方 namespace 接口不伪装为完整兼容。

## 6. 类型构造策略：优先保持 aggregate

业务 record 首选只生成字段与需要的原声明属性，由外部 `record_ops<T>` 生成完整 aggregate 初始化表达式。make/transfer/restore/relocate 不默认通过向每个 record 注入 tag 构造函数实现，避免无意改变 `is_aggregate`、构造可行性和重载选择。内部容器头可以拥有窄用途构造入口，其行为另证。

对普通、非重叠的成员，研究以同类型 class prvalue 直接初始化目标子对象，使绑定在最终 arena 地址建立；不能依赖命名局部变量的可选 NRVO，更不能先在栈上构造带 rel32 的对象再搬入 arena。数组由生成器展开合法的嵌套初始化表达式，不假定可以从函数按值返回数组。[C++20 初始化规则](https://timsong-cpp.github.io/cppwp/n4861/dcl.init)

这里有严格边界：旧类含用户构造、private 字段、定制析构/比较器等时，保留实际构造优先级，要求合法的显式适配入口；不能强制改成 aggregate。任何旧合法类无法等价映射，都是完整替换的阻塞。当前设计不承诺普通 C++20 能无协作地完整反射任意旧类。

可能抛出的 transfer 先完成不改变源的构造，成功后才提交所有权；部分成员失败由完整对象初始化的语言规则清理。relocate 必须证明各叶操作无分配且 nothrow，才能清空源头和退休源存储，不能仅统一打印 noexcept。

## 7. 加载状态机与生命周期依据

```mermaid
stateDiagram-v2
    [*] --> InputBound
    InputBound --> HeaderChecked
    HeaderChecked --> RawGraphChecked
    RawGraphChecked --> Restoring
    Restoring --> TypedPublished
    InputBound --> Failed
    HeaderChecked --> Failed
    RawGraphChecked --> Failed
    Restoring --> Failed
    Failed --> Released
```

只有 TypedPublished 可以返回 root、绑定 schema、修改或保存 verified image。原始验证阶段只使用合法输入 byte 范围、offset 和标量临时对象；不形成尚不存在的非平凡 T 引用。格式检查、大小/对齐、owned/free、bool 和排序等仍按旧优先级执行。

### 7.1 从稳定输入恢复，避免全 record 临时快照

load 始终创建独立 staging owner；同步调用期间持有调用者的只读输入 view，直至恢复结束，不允许它与新 staging 重叠或被并发修改。新 arena 可以先复制 payload，但所有初始化读取仍来自未被覆盖的原始输入及对应 payload offset。构造目标对象不会破坏下一字段的恢复来源，也无须为每个大 record 额外分配 sizeof(T) 快照。

这只解决 load 的来源保存；不自动解决原地数组扩容、存储复用或输入并发。若调用契约无法保证输入在同步 load 期间有效，必须有明确 owning 输入入口及其复制计账，不能保留悬空 view。

### 7.2 分开建立数组对象与活元素

C++20 的隐式创建只覆盖相应 implicit-lifetime 对象，不自动开始其中所有非此类子对象的生命周期；memcpy/memmove 有创建规则，launder 要求目标已经存在并满足可达性条件。数组对象、完整 enclosing record、非平凡元素、capacity 空槽分别列出开始/结束时点。[对象模型](https://timsong-cpp.github.io/cppwp/n4861/intro.object#10)、[cstring](https://timsong-cpp.github.io/cppwp/n4861/cstring.syn#3)、[launder](https://timsong-cpp.github.io/cppwp/n4861/ptr.launder)

fresh allocation、free-list reuse、tail-expand、erase/insert、rebuild、compact 都需要独立规则。尤其不能把“memmove 一下再逐元素 restore”当作已经证明；大数组原地扩容还涉及旧元素生命周期、引用失效、源表示保存、析构副作用与 scratch OOM。

“一律新分配再搬迁”只能作为被评估的策略，不能自动代替旧 tail-expand：它可能使旧来得及原地扩容的请求因额外空间而 OOM。若无法保持约定成功/失败与异常语义，应停止该分支的支持声明，而不是默默采用更简单算法。透明替换和旧指针自动指向新对象也有明确前提。[生命周期与透明替换](https://timsong-cpp.github.io/cppwp/n4861/basic.life)

C++23 的 start_lifetime_as 系列不是本 C++20 方案的可用依赖，也不通用于所有非平凡类；不能靠升级标准掩盖当前证明缺口。[P2590R2](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2022/p2590r2.pdf)

### 7.3 标量表示与 CV

非 const、非 volatile、非潜在重叠的平凡标量成员，研究先合法初始化完整对象，再通过 memcpy 恢复对应活成员的表示，避免 float 经值返回/计算而丢失表示细节。bool 必须在任何 typed 读之前验证。const float、volatile、重叠子对象是单独待证分支，不能用 const_cast 后写入解决。

NaN payload、正负零、subnormal 等以 byte/整数观察，不先作浮点算术；padding 不当作业务值，也不强求所有重存 image 字节相同。已存在 trivially-copyable 对象的表示复制有标准条件，不能推广到整个非平凡 record。[basic.types](https://timsong-cpp.github.io/cppwp/n4861/basic.types#3)

### 7.4 地址来源与 VM 边界

新 `StorageView` 持有真实 backing storage、extent、owner/epoch 和检查后的 offset。相对寻址先在整数 offset 域完成有符号增量、范围和对齐检查，再从合法存储基址取得地址；wire 仍以字段自身地址起算 rel32。

必须分别说明 byte-array backing、typed array 和 OS reserve/commit 的语言/实现契约，不能仅凭数值地址在 arena 内就宣称指针来源成立。typed 读路径若因此需要 owner 查找或额外上下文，需单独分析 API 与成本。当前这是设计候选，尚无全域证明或性能结论。

## 8. 独立运行时与 V1 行为

VM 层按 maximum 预留地址空间，再显式 commit/decommit；grow 不迁移 arena。容器自身 reserve/erase/rebuild 仍可能移动元素，不能把 arena 稳定推广成全部借用永远有效。pool/Automatic、owner move/swap、epoch、handle 和取消语义列入同一兼容台账，首个子阶段没有实现不代表可以从最终目标删除。

allocator 保留当前 V1 allocation/free header、size-class 和 accounting 表示；具体实现独立编写。allocator 决策不必对所有 image 产生完全相同的分配顺序，但旧 reader 必须能解释结果，且记录容量、失败保证和目标相关 alignment 的差异。

新 validator 可研究使用按地址有序的精确区间索引，owned/free 分开管理；区间包含头与 payload，不以粗页或包围盒替代真实字节范围。每次冲突先查询整个已登记 owned 集，再查询 free，维护原始错误次序。复杂度和 scratch 上界须分析，新增 host OOM 点需验证，不能把新索引设计直接当成与 V5 等价。

冻结项以 [V1 规范台账](../COMPATIBILITY.md) 为来源：88-byte 外层头、48-byte arena 头、allocator/allocation header、16-byte 容器头、声明顺序及实际 offset、标量/enum/数组 token、schema 名称及 FNV 追加规则、reserved 规范化。该台账中早期“未执行”状态是历史快照，当前有限切片结果以 v2 为准。新实现的每项结论重新验证，不继承通过。

完整校验保留 header/allocator/root/free-list、live/live-free/free-free、bool 表示、字符串终止、空绑定、size/capacity、排序与重复 key 等检查。旧 reader 不检查的 enum 值域或 UTF-8 不新增拒绝；业务校验在 typed load 成功后单列。

## 9. 资格与风险评估

| 能力 | 当前可行性判断 | 独立开发成本判断 | 首要验证 |
| --- | --- | --- | --- |
| 结构化 schema 与确定性生成 | 路线清楚 | 中 | 类型图闭包、未知项/篡改负控 |
| 全字段 metadata 与 V1 signature | 受控定义可行性较高 | 中至高 | 真实 offsetof、CV/数组与 typedef 分支 |
| 稳定 VM owner/allocator | 机制清楚，跨 OS 资格未建立 | 高 | OOM、回收、move/swap/epoch、对齐 |
| 完整可变 owning 容器 | 可实施，边界多 | 高 | 强异常、allocator 身份、祖先/后代 alias |
| 通用同地址恢复与数组复用 | 仍有否决级未知 | 极高 | 第 7 节全部对象/存储路径 |
| 任意既有 C++ 类无修改支持 | 无通用保证 | 不给可完成承诺 | private/custom/CV 逐类型适配 |
| 全 V1 接受域与错误兼容 | 需逐项验证 | 高 | 双向 writer/reader + 恶意图差分 |
| 普通工具链与原生平台交付 | 技术路径存在，尚未完成 | 高 | compiler/stdlib/SDK/profile 与 native 清理 |
| 性能及长期碎片 | 未知 | 后续独立测量 | 预登记指标、稳定源码、真实 trace |

成本等级为基于职责规模的工程判断，不是工期或性能数据。独立重写的主要成本在运行时、生命周期和兼容验证，不在 JSON 解析；不能沿用旧机械移植原型的收尾预算来承诺整套完成。

## 10. 实施顺序与退出门槛

| 阶段 | 交付 | 继续条件 |
| --- | --- | --- |
| I0 当前设计 | 本方案、证明台账、范围和旧域映射方法 | 尚无代码通过声明 |
| I1 类型/生命周期否决试验 | 新 IR、aggregate 外部构造、输入驱动恢复、数组复用/地址来源最小反例 | 关键路径能给明确依据；const/private 等未解项原样保留 |
| I2 独立核心纵向切片 | 新 VM/allocator、完整元数据、三个代表 schema、实际 V1 reader/writer 与图校验 | 签名、双向修改、压缩、恶意输入及失败清理全部通过；不能只做 POD roundtrip |
| I3 完整行为与旧类覆盖 | 容器/API/定制映射、公开 traits、OOM/alias、包与 multi-TU | 目标旧合法域逐项闭合，缺项不标完成 |
| I4 原生 profile | Windows MSVC 与所选 Linux/ARM64/移动端的真实导出、读写回传 | 每格有原生证据；不以 WSL 或交叉编译填绿 |
| I5 性能与消费者 | V6 冻结后另行差异决策、同工作量门槛、长期内存/业务同步迁移 | 不从去反射推导提速；上线与生产改造另行授权 |

Windows native executor 需 Job Object 的进程树控制与共享租约释放联动。先 suspended 入 Job，再运行；取消/超时后确认整个 Job drained 才释放共享锁。既有 POSIX runner 不自动证明 native 子孙清理，不能通过隐藏互操作启动绕过。Job 的 committed-memory 限制与既有 RSS 指标也不能混算。[Microsoft Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects)

I1 的预算必须先形成具体 TU/job/case 账本，I2–I5 各自预登记；本轮不要求实施批准，也不启动任何阶段。已批准预算仍为编译 8/8、被测进程 23/64、固定 case 508/512、累计主动执行约 79.01 秒。早前提出的 12 次编译/1024 case 只是旧派生原型收尾提案，未获准，不能视为独立重写预算。

新的预算统计继续继承历史消耗，限定新目录、同一共享租约、单重任务、3 GiB/进程、512 MiB 新文件、单 test 30 秒、64 KiB/wire、1 MiB 测试 owner；执行预算不足先说明，不通过换平台、跳测试或缩合法域求通过。需要新增时间/次数/案例时，在具体实施包中明确提出；本设计不清零或扩大上限。

**否决线：**若完整对象/数组生命周期、const/private 等旧合法形态、目标 ABI 或 native 清理只能靠未登记扩展、unsafe trait、改 V1、关闭校验或缩输入域成立，就不宣布完整替换可行。保留旧 V1 reader 与失败反例，按具体冲突重新评估；独立实现不豁免这些要求。
