"""Strict evidence comparison; no compilation, child execution, or baseline write."""
from pathlib import Path
import difflib, hashlib, json
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
V5=Path('/mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发')

def fid(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def output(job):return (HERE/'runs'/job/'stdout.log').read_bytes()
def passed(job):
    result=json.loads((HERE/'runs'/job/'result.json').read_text())
    assert result['returncode']==0,(job,result)
    return result

required=['port-v2','generate-v2-fixed','generator-controls-v2','generator-controls-final-report','v5-oracle-v4','gcc20-v3',
          'gcc20-sanitized-v1','old-signatures','new-signatures','old-corpus-create',
          'old-corpus-inspect','new-corpus-inspect','san-corpus-inspect','san-self',
          'new-accept-old0','old-accept-new0','old-accept-return1','new-accept-return1',
          'old-accept-return2','new-accept-return2','san-accept-old0','san-accept-old1']
for job in required:passed(job)
assert output('old-signatures')==output('new-signatures')
assert len(output('old-signatures').splitlines())==3
assert output('old-corpus-inspect')==output('new-corpus-inspect')==output('san-corpus-inspect')
lines=output('old-corpus-inspect').decode().splitlines()
assert len(lines)==125 and len((HERE/'corpus/index.tsv').read_text().splitlines())==125
accepted=sum('\taccepted\t' in x for x in lines)
assert accepted>0 and accepted<125
assert output('san-self')==b'self-ok\n'

expected={V5/'xoffsetdatastructure.hpp':'c4acc7f2005711452e12f0cd7c5d7bc57efe2d4ca0fabc207b6f711b1dbb9964',
          V5/'xoffset_virtual_memory.hpp':'22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad',
          ROOT/'xoffsetdatastructure.hpp':'9bc8f1f533bee83a9e111e05d67319383775dbca1844ef33b1aa717047640bb2',
          ROOT/'xoffset_virtual_memory.hpp':'22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad'}
protected=[fid(p) for p in expected]
for row in protected:assert row['sha256']==expected[Path(row['path'])]
for row in json.loads((HERE/'source-lineage.json').read_text()):
    assert fid(Path(row['path']))['sha256']==row['sha256'],'v1 source altered'

closures={}
for binary,job in [('new','gcc20-v3'),('san','gcc20-sanitized-v1')]:
    deps=(HERE/(binary+'.d')).read_text().replace('\\\n',' ').split(':',1)[1].split()
    closure=sorted({Path(p).resolve() for p in deps})
    assert len(closure)==6,(binary,closure)
    assert all(p.is_relative_to(HERE) for p in closure)
    assert not any('external/typelayout' in str(p) or 'experimental/meta' in str(p) for p in closure)
    snapshot=HERE/'runs'/job/'inputs'
    inputs=[]
    for p in closure:
        saved=snapshot/p.relative_to(HERE)
        inputs.append({**fid(saved),'matches_current':p.read_bytes()==saved.read_bytes()})
        if p.name!='driver.cpp':assert p.read_bytes()==saved.read_bytes(),'unverified backend/metadata change'
    closures[binary]={'binary':fid(HERE/binary),'non_system_include_files':[str(p) for p in closure],'compile_inputs':inputs}

failures=[]
for p in sorted((HERE/'runs').glob('*/result.json')):
    r=json.loads(p.read_text())
    if r['returncode']:
        failures.append({'job':p.parent.name,**r,'stderr':(p.parent/'stderr.log').read_text()})
wire=[fid(p) for p in sorted(HERE.glob('*/*.wire'))]
assert all(p['bytes']<=65536 for p in wire)
old_new_initial={}
for schema in ('scalars','unit','moves'):
    old_new_initial[schema]=(HERE/'old-emit'/f'{schema}-0.wire').read_bytes()==(HERE/'new-emit'/f'{schema}-0.wire').read_bytes()
driver_diff=''.join(difflib.unified_diff((HERE/'runs/gcc20-sanitized-v1/inputs/driver.cpp').read_text().splitlines(True),(HERE/'driver.cpp').read_text().splitlines(True),fromfile='compiled-san-driver',tofile='current-driver'))
(HERE/'postcompile-driver.diff').write_text(driver_diff)
budget=json.loads((HERE/'budget.json').read_text())
assert budget['compile_invocations']==8 and budget['tested_processes']<=64 and budget['fixed_cases']<=512
assert budget['active_wall_seconds']<1200 and budget['peak_children_rss_bytes']<=3*1024**3
result={'status':'bounded_evidence_passed_with_known_fixture_failures_and_pending_final_driver_rebuild',
        'required_jobs':required,'schemas':3,'full_signature_equal':True,'corpus_cases':125,
        'corpus_accepted':accepted,'corpus_rejected':125-accepted,'full_corpus_output_equal_old_new_sanitized':True,
        'initial_wire_byte_equality':old_new_initial,'bidirectional_generations_checked':[0,1,2,3],
        'sanitized_self_passed':True,'sanitized_old_input_generations_checked':[0,1],
        'selected_protected_headers_match':True,'protected_headers':protected,'include_closures':closures,
        'preserved_failures':failures,'wire_files':wire,'budget_at_review':budget,
        'final_driver_matches_sanitized_snapshot':not driver_diff,
        'prototype_fully_accepted':False,'native_windows_executed':False,
        'scope':'Generated public standard-layout schema slice only; selected header audit; no claim that concurrent workspaces remained static.'}
(HERE/'evidence-review.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:result[k] for k in ['status','schemas','full_signature_equal','corpus_cases','corpus_accepted','corpus_rejected','full_corpus_output_equal_old_new_sanitized','final_driver_matches_sanitized_snapshot','prototype_fully_accepted']}))
