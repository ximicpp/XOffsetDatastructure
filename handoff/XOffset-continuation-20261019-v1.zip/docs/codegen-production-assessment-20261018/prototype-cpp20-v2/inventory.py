from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
def fid(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
deps=(HERE/'old.d').read_text().replace('\\\n',' ').split(':',1)[1].split()
closure=sorted({Path(p).resolve() for p in deps})
assert any('/performance-v5/' in str(p) and p.name=='xoffsetdatastructure.hpp' for p in closure)
assert any('/external/typelayout/' in str(p) for p in closure)
assert (HERE/'driver.cpp').resolve() in closure and (HERE/'generated_schema.hpp').resolve() in closure
names=['bootstrap.py','revise.py','generate.py','check_generator.py','port_backend.py','review_evidence.py',
       'inventory.py','control_worker.py','schema.json','metadata.hpp','backend_helpers.hpp',
       'raw_validator.inc','driver.cpp','generated_schema.hpp','backend/xoffsetdatastructure.hpp',
       'backend/xoffset_virtual_memory.hpp']
value={'old_binary':fid(HERE/'old'),'actual_old_non_system_dependencies':[fid(p) for p in closure],
       'final_source_files':[fid(HERE/name) for name in names],
       'note':'Content hashes bind current local input bytes. The final driver has an uncompiled emit grow fix; snapshots bind executed binaries.'}
(HERE/'source-manifest.json').write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'old_include_files':len(closure),'final_source_files':len(names),'status':'content_identities_recorded'}))
