# 第二轮结果：受控切片已验证，原型仍未完整验收

分支为 `codex/offline-codegen-cpp20-20261018`，成果保留在本独立目录，未提交、推送或修改生产库、demo、V6。原工作区已有的 11 项 tracked 修改仍保留；对生产/V5 的四个选定头文件做了身份核对，未作整个并行工作区静态不变的声明。

已实现：共同 schema 生成两侧声明与新侧有序完整 metadata；区分公开 byte-copy trait 与内部成员准入；保留直接非平凡数组成员的负断言；使用 XVector<Owning[2]> 正例；按叶元素恢复动态数组生命周期；修复共同 probe 默认构造及 arena 内的本地生命周期夹具。

| 验证 | 实际结果 |
| --- | --- |
| 旧 V5/P2996 oracle、普通 GCC C++20、GCC C++20 ASan/UBSan | 均已构建成功；包含正负准入断言 |
| Scalars / UnitState / Moves 完整 ABI 签名、sizeof/alignof、类型 ID、schema hash | 逐字一致 |
| 旧→新、新→旧，修改保存、重载、grow、压缩与继续回传 | 三个 schema 全部通过，generation 0→1→2→3 |
| 125 个固定 wire 输入 | 47 接受、78 拒绝；旧、新、sanitizer 完整输出一致，包括多错优先级 |
| 接受后的修改/再次 load | 在 inspect 内强制验证；后续操作异常使整个进程失败 |
| sanitizer self | self-ok；同 owner steal、跨 owner copy、OOM/grow、构造与数组前缀回滚/重试/析构、owned 优先级、祖先/后代别名回退通过 |
| 普通新侧实际非系统 include 闭包 | 6 个本地文件；无 TypeLayout/P2996 依赖 |
| 生成器负控 | 陈旧、padding 字段漂移、metadata 篡改、缺输出、未知字段属性、指针及非法嵌套类型拒绝 |

失败记录全部保留，未重写通过：第一次生成不支持模板内数组语法；累计第 5 次编译因负准入类型的 typed allocator 夹具失败；旧/普通 self 的栈对象不满足 rel32 距离前提；旧/普通 emit 在保存收缩后未显式 grow，均在 Moves 修改时报 OOM。前两项已修复并后续编译/测试；栈夹具修正已在最后一份 sanitizer self 中通过。具体错误与修复见 diagnosis 文件。

当前 driver 相比最后成功的 sanitizer snapshot **只有 emit 中新增 grow 与注释**，见 postcompile-driver.diff。该最后改动尚未复编；backend、metadata、生成的 schema 与成功构建的输入逐字一致。成功的双向/回传流程使用已包含 grow 的 accept 模式，保留完整数组类型和压缩验证。不能把历史失败的 emit/self，或最终 driver，统称全部通过。

预算：用户将总编译上限明确调为 8，已用 8/8（继承 v1 的 4 次，失败也计数）；测试进程累计 23/64，固定 case 累计扣数 508/512（包括重复验证）。最终累计主动执行约 79.01 秒，峰值 643,268,608 bytes（约 613.5 MiB）；两个原型目录合计约 14.46 MB，均低于其余上限。最终数量以 budget.json、逐任务结果和全局租约记录为准；资源统计不作性能结论。

全局共享租约 `71962c4f9ba64004918d5782ea958ee9` 已于北京时间 2026-10-18 16:41:53 结束并释放；受控会话的 live/process_groups/zombies 均为空。租约 complete 仅表示执行器正常退出及清理完成，不表示原型完整验收通过。

尚未完成：最终 driver 复编及完整 emit 回归；原生 Windows 测试及其受控取消/清理适配；任意旧 C++ 类型的导入、private/基类/opaque 定制、完整 CV 和浮点表示等覆盖。当前 metadata 的完整性限于本 IR 生成的 record，sanitizer 也不是全部对象模型合法性的证明。因此 prototype_fully_accepted=false。

下一次构建前需要明确追加编译预算，并重新取得同一个全局共享租约。继续时先读 CONTINUATION.md、DESIGN.md、evidence-review.json 和 postcompile-driver.diff；不要复用已封存租约或修改失败档案。本轮按已批准上限停止，不自行降低平台或验证范围。
