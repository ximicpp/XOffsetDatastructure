# 第二轮设计：可生成的受控 C++20 切片

## 完整元数据的边界

`schema.json` 同时生成两侧的字段声明、稳定名称与新侧 metadata。每个生成 record 的全部非静态字段按声明顺序列出：精确 `decltype`、成员指针、目标编译器计算的 `offsetof`，以及完整数组维度。生成结果必须逐字等于重新生成的结果；增加 padding/bool 字段但沿用旧输出、修改成员指针、丢失输出均必须失败。生成器现在递归解析模板参数，故 `XVector<Owning[2]>` 与直接字段 `Owning[2]` 不再混淆。

这是本 IR 中 record 的完整元数据，不是对任意现存 C++ 类型的完整导入承诺。生成器没有 private、基类、union、opaque 定制、匿名字段、位域或任意用户比较器的导入能力；这些旧类型不能通过人工 safe=true 变成支持。未知类型默认拒绝。CvSample 仅检查声明/metadata，未完成所有 const/volatile 操作域。

## 两种 byte-copy 判断

固定 TypeLayout 的公开 `is_byte_copy_safe<T[N]>` 检查元素的内部谓词；反射 record 的成员递归直接调用内部谓词。内部谓词只对 trivially-copyable 且 pointer-free 的数组走快路径，非平凡数组并不进入 class/union 递归。因此本轮保留如下两侧相同的断言：

| 类型 | 公开 byte-copy | 用途 |
| --- | --- | --- |
| Owning[2] | true | 容器元素可继续进入 V1/API 检查 |
| XVector<Owning[2]> | true | 由公开容器特化检查元素 |
| InlineOwningArray（直接含 Owning[2]） | false | 负准入，不调用 make/wire |
| ProbeArray（直接含 CtorProbe[2]） | false | 负准入；普通本地生命周期单列 |
| Owning[2][2] | false | 公开 trait 只向内部递归一层 |
| int32[2][3] | true | 平凡多维数组 |
| XVector<int*> | false | 公开容器特化不允许指针元素 |

新 metadata 的 `edges` 只列物理字段：容器头的四个整数。`public_edges` 列公开 trait 要检查的模板参数。record 成员递归使用 `internal_safe`，不把公开容器元素递归误当成物理反射；V1 准入另行按原 backend 的逻辑检查元素。这两个 gate 与签名、实际 API 实例化分别保留。旧 oracle 已编译这些断言，未改 TypeLayout 或 V5。

## 对象生命周期

1. 验证原始图时仅访问 bytes、offset 与已有标量临时对象；保留旧 owned/free 索引与报错顺序。尚未验证的非平凡对象不形成引用，不 `launder`。
2. 验证完成后，以局部 inline 表示快照输入 placement 构造完整 record；生成构造函数真正开始 enclosing object 和各成员的生命周期。恢复容器头不分配、不覆盖保存的绑定。
3. 动态数组对象依赖分配/加载时既定的 C++20 memcpy/memmove 隐式创建触发。非平凡元素仍必须显式构造；`restore_at<E[N]>` 按字节偏移递归恢复叶元素，不对整个非平凡数组 placement-default 后 memcpy。全部叶元素完成后才形成数组引用并递归处理外部 payload。
4. fresh/reused/tail-expanded storage 的数组边界与元素生命周期分别处理。非平凡 relocate 通过生成构造建立完整 record；重新计算 rel32，清空源头，再销毁源对象，payload 地址保留。
5. make/transfer 的部分构造清理交给语言的成员/数组逆序析构。第二个 probe 抛异常时必须只销毁成功的前缀；重试成功后要精确销毁两个元素。
6. 带 rel32 绑定的普通本地对象也必须在可表示的 arena 范围内。栈夹具并不保证与 arena 距离小于 2 GiB；本轮最后一份 sanitizer driver 改为 arena 内对齐分配，并明确区分注入异常和其他异常。

静态论证是必要条件。ASan/UBSan 通过只能说明此次运行未报告相应错误，不能自动证明 C++ 对象模型中所有情形合法。

## 显式增长策略

原 `save_verified()` 会 `shrink_to_fit()`。旧 emit 夹具保存 generation 0 后立即修改，Moves 的扩容因此在旧新两侧均 OOM。`accept` 模式在修改前调用 `grow(4096)`，三个 schema 的双向及回传流程已能执行。该差异属于夹具未遵循既有显式增长策略；不能修改生产增长语义来让测试通过。

本轮保留失败请求，最后源码会补齐 emit 的 grow，但累计 8 次编译已耗尽，补丁是否进入运行证据必须通过 snapshot 对比单独说明。不会把历史二进制当成修正后源码。

## 资源与平台

继承 v1 消耗，累计 8 次 TU 调用。其他上限为 64 被测进程、512 固定 case（重复检查也扣数）、64 KiB/wire、1 MiB/owner、3 GiB/进程、512 MiB/新增文件、1200 秒累计主动执行；单 test 30 秒。共用原 POSIX 全局租约，串行启动，不改 V6 的协调文件或工作区。

普通 C++20 为 WSL GCC 11.4；旧 oracle 为既有 P2996 Clang/固定 V5；sanitizer 为普通 GCC C++20。Windows 原生取消/清理适配未验证，不能由 WSL 成功推导 Windows 通过。
