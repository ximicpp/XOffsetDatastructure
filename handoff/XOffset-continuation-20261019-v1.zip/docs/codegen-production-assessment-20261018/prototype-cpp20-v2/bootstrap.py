"""Copy only prototype source inputs under the existing global shared lease."""
from pathlib import Path
import hashlib, json, runpy

HERE=Path(__file__).resolve().parent
OLD=HERE.with_name('prototype-cpp20-v1')
names=['metadata.hpp','backend_helpers.hpp','raw_validator.inc','schema.json',
       'generate.py','port_backend.py','check_generator.py','driver.cpp','control_worker.py']
inputs=[]
for name in names:
    raw=(OLD/name).read_bytes()
    with (HERE/name).open('xb') as f:f.write(raw)
    inputs.append({'path':str(OLD/name),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
prior=json.loads((OLD/'budget.json').read_text())
assert prior['status']=='finished' and prior['compile_invocations']==4
(HERE/'inherited-budget.json').write_text(json.dumps(prior,indent=2)+'\n')
(HERE/'source-lineage.json').write_text(json.dumps(inputs,indent=2)+'\n')
runpy.run_path(str(HERE/'revise.py'),run_name='__main__')
runpy.run_path(str(HERE/'control_worker.py'),run_name='__main__')
