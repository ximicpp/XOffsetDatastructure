#pragma once
namespace prototype {
using namespace XOffsetDatastructure;
using HeadEdges=std::tuple<std::int32_t,std::int32_t,std::uint32_t,std::uint32_t>;
template<> struct edges<XFixedString> { using types=HeadEdges; };
template<> struct edges<XString> : edges<XFixedString> {};
template<class T> struct edges<XFixedVector<T>> { using types=HeadEdges; };
template<class T> struct edges<XVector<T>> : edges<XFixedVector<T>> {};
template<class T> struct edges<XFixedFlatSet<T>> : edges<XFixedVector<T>> {};
template<class T> struct edges<XSet<T>> : edges<XFixedVector<T>> {};
template<class K,class V> struct edges<XFixedFlatMap<K,V>> : edges<XFixedVector<XKeyValue<K,V>>> {};
template<class K,class V> struct edges<XMap<K,V>> : edges<XFixedVector<XKeyValue<K,V>>> {};
template<class T> struct public_edges<XFixedVector<T>> { using types=std::tuple<T>; };
template<class T> struct public_edges<XVector<T>> : public_edges<XFixedVector<T>> {};
template<class T> struct public_edges<XFixedFlatSet<T>> : public_edges<XFixedVector<T>> {};
template<class T> struct public_edges<XSet<T>> : public_edges<XFixedVector<T>> {};
template<class K,class V> struct public_edges<XFixedFlatMap<K,V>> { using types=std::tuple<K,V>; };
template<class K,class V> struct public_edges<XMap<K,V>> : public_edges<XFixedFlatMap<K,V>> {};
template<class K,class V> inline constexpr bool kv<XKeyValue<K,V>> = true;
template<class K,class V> struct record<XKeyValue<K,V>> {
    using T=XKeyValue<K,V>;
    static constexpr auto fields=std::tuple{field<T,K,&T::first,offsetof(T,first)>{},field<T,V,&T::second,offsetof(T,second)>{}};
};
static_assert(sizeof(XString)==16 && alignof(XString)==8);
static_assert(offsetof(XFixedString,arena_delta)==0 && offsetof(XFixedString,data_delta)==4 && offsetof(XFixedString,size_)==8 && offsetof(XFixedString,capacity_)==12);
static_assert(std::is_same_v<decltype(XFixedString::arena_delta),std::int32_t> && std::is_same_v<decltype(XFixedString::data_delta),std::int32_t>);
static_assert(std::is_same_v<decltype(XFixedString::size_),std::uint32_t> && std::is_same_v<decltype(XFixedString::capacity_),std::uint32_t>);
template<class T,class Alloc> T make_value(const Alloc& alloc) {
    if constexpr(requires { T(alloc); }) return T(alloc);
    else if constexpr(!std::is_trivially_copyable_v<T> && described<T>) {
        if constexpr(kv<T>)return T{make_value<typename T::first_type>(alloc),make_value<typename T::second_type>(alloc)};
        else return T(make_tag{},alloc);
    } else return T{};
}
template<class T,class Alloc> T transfer_value(const T& src,const Alloc& alloc) {
    if constexpr(std::is_trivially_copyable_v<T>)return src;
    else if constexpr(requires{T(src,alloc);})return T(src,alloc);
    else if constexpr(kv<T>)return T{transfer_value(src.first,alloc),transfer_value(src.second,alloc)};
    else return T(transfer_tag{},src,alloc);
}
template<class T> T restore_value(const unsigned char* p) noexcept {
    using U=std::remove_cv_t<T>;
    if constexpr(kv<U>)return U{restore_value<typename U::first_type>(p+offsetof(U,first)),restore_value<typename U::second_type>(p+offsetof(U,second))};
    else if constexpr(std::is_class_v<U>)return U(restore_tag{},p);
    else return read_scalar<U>(p);
}
template<class T> T relocate_value(T& src) noexcept {
    if constexpr(std::is_trivially_copyable_v<T>)return src;
    else if constexpr(kv<T>)return T{relocate_value(src.first),relocate_value(src.second)};
    else return T(relocate_tag{},src);
}
template<class T> void restore_at(void* dst) noexcept {
    using U=std::remove_cv_t<T>;
    if constexpr(std::is_array_v<U>) {
        // Precondition: the enclosing payload's memcpy/memmove created the
        // implicit-lifetime array object. Each nontrivial leaf still needs an
        // explicit construction; no array reference/launder before this loop.
        using E=std::remove_extent_t<U>;
        for(std::size_t i=0;i<std::extent_v<U>;++i)
            restore_at<E>(static_cast<unsigned char*>(dst)+i*sizeof(E));
    } else {
        std::array<unsigned char,sizeof(U)> repr;
        std::memcpy(repr.data(),dst,sizeof(U));
        if constexpr(kv<U>) ::new(dst) U{restore_value<typename U::first_type>(repr.data()+offsetof(U,first)),restore_value<typename U::second_type>(repr.data()+offsetof(U,second))};
        else if constexpr(std::is_class_v<U>)::new(dst) U(restore_tag{},repr.data());
        else {::new(dst) U;std::memcpy(dst,repr.data(),sizeof(U));}
    }
}
template<class T> void restore_payloads(T& value) {
    using U=std::remove_cv_t<T>;
    namespace d=XOffsetDatastructure::detail;
    if constexpr(std::is_array_v<U>)for(auto& e:value)restore_payloads(e);
    else if constexpr(d::is_fixed_string_v<U>) {}
    else if constexpr(d::is_fixed_vector_v<U> || d::is_fixed_flat_set_v<U> || d::is_fixed_flat_map_v<U>) {
        using E=typename U::value_type;
        auto* payload=reinterpret_cast<char*>(&value.data_delta)+value.data_delta;
        for(std::uint32_t i=0;i<value.size();++i) {
            auto* slot=payload+std::size_t(i)*sizeof(E);
            restore_at<E>(slot);
            restore_payloads(*std::launder(reinterpret_cast<E*>(slot)));
        }
    } else if constexpr(described<U>) {
        d::static_for<field_count<U>>([&](auto i){restore_payloads(field_at<U,decltype(i)::value>::get(value));});
    }
}
template<class T> void expand_array_lifetimes(T* data,std::uint32_t live,std::uint32_t capacity) noexcept {
    if(!data)return;
    std::memmove(data,data,std::size_t(capacity)*sizeof(T));
    if constexpr(!std::is_trivially_copyable_v<T>)
        for(std::uint32_t i=0;i<live;++i)restore_at<T>(reinterpret_cast<char*>(data)+std::size_t(i)*sizeof(T));
}
}
