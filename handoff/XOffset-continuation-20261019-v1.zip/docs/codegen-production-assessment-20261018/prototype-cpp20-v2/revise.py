"""Reviewable anchored edits, applied once to a new local prototype copy."""
from pathlib import Path
import json
HERE=Path(__file__).resolve().parent

def edit(name,old,new):
    p=HERE/name;s=p.read_text()
    assert s.count(old)==1,(name,old[:100],s.count(old))
    p.write_text(s.replace(old,new),newline='\n')

# Public array admission is NOT the rule used inside reflected records.
p=HERE/'metadata.hpp';s=p.read_text()
a=s.index('template<class T, class... Seen> consteval bool check_safe()')
b=s.index('template<class T> T read_scalar',a)
s=s[:a]+'''// Only generated records and exact runtime container families are described.
// Physical layout traversal deliberately excludes container template elements.
template<class T> struct public_edges;
template<class T> consteval bool pointer_free() {
    using U=std::remove_cv_t<T>;
    if constexpr(std::is_pointer_v<U> || std::is_reference_v<U> ||
                 std::is_member_pointer_v<U> || std::is_union_v<U> || std::is_polymorphic_v<U>) return false;
    else if constexpr(std::is_arithmetic_v<U> || std::is_enum_v<U>) return true;
    else if constexpr(std::is_array_v<U>) return pointer_free<std::remove_extent_t<U>>();
    else if constexpr(requires { typename edges<U>::types; }) return []<class... E>(std::tuple<E...>*) {
        return (pointer_free<E>() && ...);
    }(static_cast<typename edges<U>::types*>(nullptr));
    else if constexpr(described<U>) return []<std::size_t... I>(std::index_sequence<I...>) {
        return (pointer_free<typename field_at<U,I>::type>() && ...);
    }(std::make_index_sequence<field_count<U>>{});
    else return false;
}
template<class T> consteval bool internal_safe() {
    using U=std::remove_cv_t<T>;
    if constexpr(!pointer_free<U>()) return false;
    else if constexpr(std::is_trivially_copyable_v<U>) return true;
    else if constexpr(std::is_class_v<U> && requires { typename edges<U>::types; }) return []<class... E>(std::tuple<E...>*) {
        return (internal_safe<E>() && ...);
    }(static_cast<typename edges<U>::types*>(nullptr));
    else if constexpr(std::is_class_v<U> && described<U>) return []<std::size_t... I>(std::index_sequence<I...>) {
        return (internal_safe<typename field_at<U,I>::type>() && ...);
    }(std::make_index_sequence<field_count<U>>{});
    else return false; // In particular: a nontrivial array in a record member.
}
template<class T> consteval bool public_safe() {
    if constexpr(std::is_array_v<T>) return internal_safe<std::remove_extent_t<T>>();
    else if constexpr(requires { typename public_edges<T>::types; }) return []<class... E>(std::tuple<E...>*) {
        return (byte_safe_v<E> && ...);
    }(static_cast<typename public_edges<T>::types*>(nullptr));
    else return internal_safe<T>();
}
template<class T> struct byte_safe : std::bool_constant<public_safe<T>()> {};

'''+s[b:];p.write_text(s,newline='\n')
edit('backend_helpers.hpp','std::tuple<std::int32_t,std::int32_t,std::uint32_t,std::uint32_t,T>','HeadEdges')
edit('backend_helpers.hpp','template<class K,class V> inline constexpr bool kv<XKeyValue<K,V>> = true;','''template<class T> struct public_edges<XFixedVector<T>> { using types=std::tuple<T>; };
template<class T> struct public_edges<XVector<T>> : public_edges<XFixedVector<T>> {};
template<class T> struct public_edges<XFixedFlatSet<T>> : public_edges<XFixedVector<T>> {};
template<class T> struct public_edges<XSet<T>> : public_edges<XFixedVector<T>> {};
template<class K,class V> struct public_edges<XFixedFlatMap<K,V>> { using types=std::tuple<K,V>; };
template<class K,class V> struct public_edges<XMap<K,V>> : public_edges<XFixedFlatMap<K,V>> {};
template<class K,class V> inline constexpr bool kv<XKeyValue<K,V>> = true;''')
edit('backend_helpers.hpp','''    std::array<unsigned char,sizeof(U)> repr;
    std::memcpy(repr.data(),dst,sizeof(U));
    if constexpr(kv<U>) ::new(dst) U{restore_value<typename U::first_type>(repr.data()+offsetof(U,first)),restore_value<typename U::second_type>(repr.data()+offsetof(U,second))};
    else if constexpr(std::is_class_v<U>)::new(dst) U(restore_tag{},repr.data());
    else {::new(dst) U;std::memcpy(dst,repr.data(),sizeof(U));}''','''    if constexpr(std::is_array_v<U>) {
        // Precondition: the enclosing payload's memcpy/memmove created the
        // implicit-lifetime array object. Each nontrivial leaf still needs an
        // explicit construction; no array reference/launder before this loop.
        using E=std::remove_extent_t<U>;
        for(std::size_t i=0;i<std::extent_v<U>;++i)
            restore_at<E>(static_cast<unsigned char*>(dst)+i*sizeof(E));
    } else {
        std::array<unsigned char,sizeof(U)> repr;
        std::memcpy(repr.data(),dst,sizeof(U));
        if constexpr(kv<U>) ::new(dst) U{restore_value<typename U::first_type>(repr.data()+offsetof(U,first)),restore_value<typename U::second_type>(repr.data()+offsetof(U,second))};
        else if constexpr(std::is_class_v<U>)::new(dst) U(restore_tag{},repr.data());
        else {::new(dst) U;std::memcpy(dst,repr.data(),sizeof(U));}
    }''')
# The old fixture must also declare its allocator-constructible probe's default
# constructor, because its enclosing record contains a default member array.
edit('generate.py',"        if r.get('allocator_ctor'):\n            inits=[]", "        if r.get('allocator_ctor'):out.append(f'    {name}() = default;')\n        if r.get('allocator_ctor'):\n            inits=[]")
edit('generate.py',"        out.append(f'    {name}() = default;')", "        if not r.get('allocator_ctor'):out.append(f'    {name}() = default;')")
p=HERE/'schema.json';schema=json.loads(p.read_text())
moves=next(r for r in schema['records'] if r['name']=='Moves')
moves['fields']=[(f,'XVector<Owning[2]>' if f=='fixed' else t) for f,t in moves['fields']]
schema['records'].insert(next(i for i,r in enumerate(schema['records']) if r['name']=='Moves'),{'name':'InlineOwningArray','fields':[['items','Owning[2]']]})
p.write_text(json.dumps(schema,indent=2)+'\n')
edit('driver.cpp','r.left="left";r.right="right";r.fixed[0].first="a";r.fixed[0].second="b";\n    r.fixed[1].first="c";r.fixed[1].second="d";', 'r.left="left";r.right="right";r.fixed.resize(1);r.fixed[0][0].first="a";r.fixed[0][0].second="b";\n    r.fixed[0][1].first="c";r.fixed[0][1].second="d";')
edit('driver.cpp','r.fixed[0].second="array-modified";', 'r.fixed[0][0].second="array-modified";r.fixed.reserve(r.fixed.capacity()+3);')
edit('driver.cpp','for(auto& x:r.fixed){text(o,x.first.view());text(o,x.second.view());}', 'for(auto& row:r.fixed)for(auto& x:row){text(o,x.first.view());text(o,x.second.view());}')
edit('driver.cpp','    struct HasPointer{int* p;};struct Derived:XString{int extra;};','''    // Same assertions compile against the unchanged TypeLayout oracle and new metadata.
    static_assert(is_byte_copy_safe_v<Owning[2]>);
    static_assert(is_byte_copy_safe_v<XVector<Owning[2]>>);
    static_assert(!is_byte_copy_safe_v<InlineOwningArray>);
    static_assert(!is_v1_wire_admitted_v<InlineOwningArray>);
    static_assert(!is_byte_copy_safe_v<ProbeArray>);
    static_assert(!is_v1_wire_admitted_v<ProbeArray>);
    static_assert(!is_byte_copy_safe_v<Owning[2][2]>);
    static_assert(is_byte_copy_safe_v<std::int32_t[2][3]>);
    static_assert(!is_byte_copy_safe_v<XVector<int*>>);
    struct HasPointer{int* p;};struct Derived:XString{int extra;};''')
edit('driver.cpp','''        bool failed=false;try{b.make<ProbeArray>();}catch(const std::runtime_error& e){failed=std::string_view(e.what())=="injected constructor failure";}
        fixture::fail_on=0;need(failed && fixture::destroyed==1,"array constructor rollback");
        auto* r=b.make<ProbeArray>();need(r->slots[0].label.view()=="probe-owned","array constructor retry");''','''        // Ordinary local construction only: this type is intentionally rejected
        // by the original public wire/make API, as asserted above.
        alignas(ProbeArray) unsigned char storage[sizeof(ProbeArray)];
        auto construct=[&]{fixed_detail::default_construct(reinterpret_cast<ProbeArray*>(storage),b.allocator<ProbeArray>());};
        bool failed=false;try{construct();}catch(const std::runtime_error& e){failed=std::string_view(e.what())=="injected constructor failure";}
        fixture::fail_on=0;need(failed && fixture::destroyed==1,"array constructor rollback");
        construct();auto* r=std::launder(reinterpret_cast<ProbeArray*>(storage));
        need(r->slots[0].label.view()=="probe-owned","array constructor retry");
        std::destroy_at(r);need(fixture::destroyed==3,"local array exact cleanup");''')
# Carry all v1 consumption forward; include both prototype directories in disk accounting.
edit('control_worker.py',"state={'status':'running','compile_invocations':0,'tested_processes':0,'active_wall_seconds':0.0,'fixed_cases':0,'peak_children_rss_bytes':0,'jobs':[]}","""prior=json.loads((HERE/'inherited-budget.json').read_text())
state={**prior,'status':'running','jobs':[],'inherited_jobs':len(prior['jobs']),'compile_limit':8}
""")
edit('control_worker.py',"def disk_bytes():return sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())", "def disk_bytes():return sum(p.stat().st_size for root in (HERE,HERE.with_name('prototype-cpp20-v1')) for p in root.rglob('*') if p.is_file())")
edit('control_worker.py',"state['compile_invocations']>=6", "state['compile_invocations']>=8")
edit('control_worker.py',"    if disk_bytes()>512*1024**2:raise ValueError('disk budget exceeded')", "    if state['active_wall_seconds']>=1200:raise ValueError('cumulative active time exhausted')\n    if disk_bytes()>512*1024**2:raise ValueError('disk budget exceeded')")
edit('control_worker.py',"deadline=min(started+float(req.get('timeout_seconds',30 if kind=='test' else 300)),END)", "deadline=min(started+float(req.get('timeout_seconds',30 if kind=='test' else 300)),started+1200-state['active_wall_seconds'],END)")
print('v2 source revisions applied; no compilation or acceptance claimed',flush=True)
