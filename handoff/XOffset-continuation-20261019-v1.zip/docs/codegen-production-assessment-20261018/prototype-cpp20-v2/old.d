/mnt/c/Users/gzsufanchen/Documents/ChatGPT/xoffsetdatastructure开发/docs/codegen-production-assessment-20261018/prototype-cpp20-v2/old: \
  /mnt/c/Users/gzsufanchen/Documents/ChatGPT/xoffsetdatastructure开发/docs/codegen-production-assessment-20261018/prototype-cpp20-v2/driver.cpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/typelayout.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/config.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/fwd.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/fixed_string.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/signature.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/detail/type_map.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/detail/signature_impl.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/detail/reflect.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/opaque.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/admission.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/layout_traits.hpp \
  /mnt/c/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/detail/sig_parser.hpp \
  /mnt/c/Users/gzsufanchen/Documents/ChatGPT/xoffsetdatastructure开发/docs/codegen-production-assessment-20261018/prototype-cpp20-v2/generated_schema.hpp
