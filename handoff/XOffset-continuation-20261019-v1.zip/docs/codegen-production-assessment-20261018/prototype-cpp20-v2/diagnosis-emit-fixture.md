# 保存后显式增长

旧 oracle 与普通 GCC20 的 emit 请求均保存了 scalars-0/1、unit-0/1、moves-0，随后返回 XOffset arena allocation failed。失败请求和所有前缀文件保持原样。

原 save_verified 会 shrink_to_fit，emit 随后未 grow 就调用 mutate；Moves 的数组容器扩容需要新增空间。相同的旧→新与新→旧 accept 流程在 load 后先 grow(4096)，三个 schema 都完成修改、保存、重载和压缩，未修改增长策略。这支持夹具前提错误的定位。

累计 8 次编译后，当前源码只为 emit 补入显式 grow 与说明。此改动未编译，不能把历史 emit 失败或历史 sanitizer 结果改写为此最终 driver 的通过。最后的 core backend/metadata 与成功普通及 sanitizer 构建的输入保持一致，审查脚本逐文件核实并输出 postcompile-driver.diff。

现有回传证据采用实际成功的 accept 请求，从两侧保存的初始图分别向对方修改，并再次回传直到 generation 3；这些测试保留完整 Moves 数组容器、grow、压缩和重新验证，没有删去失败类型或静默降低原目标。原生 Windows 和最终 driver 复编仍待完成。
