from pathlib import Path
import copy,hashlib,importlib.util,json
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('schema_generator',HERE/'generate.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
schema=json.loads((HERE/'schema.json').read_text());a=module.emit(schema).encode();b=module.emit(schema).encode()
assert a==b and a==(HERE/'generated_schema.hpp').read_bytes()
changed=copy.deepcopy(schema)
scalar=next(x for x in changed['records'] if x['name']=='Scalars')
scalar['fields'].insert(2,['padding_marker','bool'])
errors=[]
def rejected(name,expected,observed):
    try:module.check_bytes(expected,observed)
    except ValueError as e:errors.append({'case':name,'error':str(e)})
    else:raise AssertionError(name+' escaped the actual generator check')
rejected('stale_output_after_padding_member_added',module.emit(changed).encode(),a)
tampered=a.replace(b'&sample::Scalars::enabled',b'&sample::Scalars::bits',1)
rejected('tampered_member_metadata',a,tampered)
rejected('missing_output',a,None)
unknown=copy.deepcopy(schema);unknown['records'][0]['hidden_fields']=[]
try:module.emit(unknown)
except ValueError:pass
else:raise AssertionError('unknown property accepted')
pointer=copy.deepcopy(schema);pointer['records'][0]['fields']=[['ptr','std::uint32_t*']]
try:module.emit(pointer)
except ValueError:pass
else:raise AssertionError('native pointer syntax accepted')
assert module.parse_type('XVector<Owning[2]>')==('XVector<Owning[2]>',[])
assert module.parse_type('std::int32_t[2][3]')==('std::int32_t',[2,3])
for bad in ('XVector<int*>','XMap<int, XVector<int*> >','Owning[0]','XVector<Owning','XVector<>'):
    try:module.parse_type(bad)
    except ValueError:pass
    else:raise AssertionError('invalid nested type accepted: '+bad)
# The common definition, before the new-side guard, declares the probe default
# constructor on both sides. This used to break the unchanged old oracle.
probe=a.decode().split('struct CtorProbe {',1)[1].split('#ifndef PROTOTYPE_OLD_V5',1)[0]
assert 'CtorProbe() = default;' in probe
# Compare the entire output, never just sizeof/count or a caller-provided trait.
out={'status':'passed','checks':['deterministic','current_output','padding_field_schema_drift','tampered_member_metadata','missing_output','unknown_hidden_field_property','native_pointer_syntax'],'output_sha256':hashlib.sha256(a).hexdigest(),'negative_controls_exercised':5,'actual_rejection_errors':errors}
(HERE/'generator-check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
