# 本地数组夹具修正

旧 oracle 与普通 GCC20 二进制都在相同的 array constructor rollback 断言失败。此前的同 owner 移动、cross-owner copy、OOM/reload/grow、vector 构造异常断言先执行，未报告失败。

夹具使用栈上的 ProbeArray，里面的 XString 需要从头位置到 arena 的 signed rel32。任意栈地址与 mmap arena 没有 2 GiB 距离保证。原测试 catch 把所有 runtime_error 混成 failed=false，掩盖了非注入异常。固定 backend 的 set_rel32 明确拒绝超出距离，因此该夹具本身不满足相对指针前提。

当前源码在同一个 arena 中按真实 alignment 分配原始空间，并以已有 allocator state 构造完整的普通本地对象；ProbeArray 的 byte-copy/V1 负断言保持不变，也不调用被拒绝的 make<ProbeArray>。对其他异常原样传播。

普通旧/新二进制绑定的是各自 runs/*/inputs 快照，尚未包含此修正，不能把其失败改写为通过。最后一次编译将检验包含修正的 ASan/UBSan C++20 版本。系统没有 gdb，未安装调试器；根因目前由源码与共同失败位置定位，待修正版运行确认。
