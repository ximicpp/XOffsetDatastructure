# 证据索引与评估范围

本次只做指定文档、相关源码及小型元数据的定向读取、少量文件哈希和文档检查。没有扫描/复制全仓、验证完整依赖内容树、读取大型测量原始数据、执行handoff检查器、构建、测试、采样或性能测量。HANDOFF中的其他开发流程未执行。既有验收结果均注明为引用。

## 1. 实际核对的源码身份

| 对象 | 本次直接观察 |
| --- | --- |
| performance-v5/xoffsetdatastructure.hpp | SHA-256 `c4acc7f2005711452e12f0cd7c5d7bc57efe2d4ca0fabc207b6f711b1dbb9964`，与V5验收中未提交候选一致 |
| performance-v5/xoffset_virtual_memory.hpp | SHA-256 `22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad` |
| 根目录xoffsetdatastructure.hpp | SHA-256 `9bc8f1f533bee83a9e111e05d67319383775dbca1844ef33b1aa717047640bb2`；与V5不同 |
| 依赖锁元数据 | Boost `da041154c6bac1a4aa98254a7d6819059e8ac0b0`；TypeLayout `9a6de1d73617631a9612ba9f572d6c0844a90b19`。本次只读相关TypeLayout头及锁文件，不宣称重新验完锁树 |

[input-identities.json](input-identities.json)记录本次指定文件收尾时的实际身份；不是全库manifest或新构建闭包。V6设计文档只恢复约束，可能由并行会话维护，不成为固定候选。未读取或哈希其构建、补丁、工具、计划目录，也未加入调度队列。

## 2. 源码定位

以下链接全部指向实际V5工作区，不是根目录F。行号为评估时源码位置，主头身份如上。

| 事实 | 定位 |
| --- | --- |
| 直接P2996、concepts/span及TypeLayout入口 | [主头18行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:18) |
| 64-bit、LE断言 | [主头53行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:53) |
| arena_header、Core析构及owner寿命 | [主头266行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:266) |
| grow/shrink只改逻辑extent，借用span | [主头403行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:403) |
| AllocationHeader实际字段与size/alignment断言 | [主头517行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:517) |
| host OwnerRecord、TLS/registry和类型token | [主头548行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:548) |
| bytes加载和payload验证 | [主头683行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:683) |
| object_at_offset/launder、slot placement、分配对齐 | [主头806行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:806) |
| 反射基础遍历、概念、fixed scalar | [主头1010行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:1010) |
| allocator state冻结size88/align8、provenance/contains | [主头1099行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:1099) |
| rel32解析及设置/绑定tag | [主头1160行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:1160) |
| default/transfer/construct_bound与异常清理 | [主头1533行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:1533) |
| XFixedString非平凡析构/删除copy-move构造/同owner移动条件 | [主头1704行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:1704) |
| XFixedVector相应构造与析构 | [主头1970行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:1970) |
| V1 admission，包括exact容器、record、元素递归 | [主头3038行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:3038) |
| 精确索引dense预算与owned全局优先 | [主头3298行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:3298) |
| owned/free注册、相对寻址、allocator binding | [主头3521行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:3521) |
| Allocation metadata、无需检查裁剪、bool/排序校验 | [主头3590行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:3590) |
| allocator先验证、graph注册次序 | [主头3781行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:3781) |
| 可无分配relocate、祖先后代owns-address、头部重算 | [主头3861行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:3861) |
| XWireHeaderV1及常量 | [主头3985行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:3985) |
| root ID、signature全语法、schema hash | [主头4027行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:4027) |
| 前缀逆序析构、初始化/transfer、ReflectRoot与allocator ctor分派 | [主头4247行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:4247) |
| owning save与verified header输出 | [主头4652行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:4652) |
| verified header检查顺序、graph后typed发布 | [主头4763行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:4763) |
| 单root显式压缩与迁移策略 | [主头4990行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:4990) |
| 库容器TypeLayout byte-safe递归特化 | [主头5177行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffsetdatastructure.hpp:5177) |
| VM OS分支和from_bytes memcpy | [VM头191行](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/xoffset_virtual_memory.hpp:191) |
| TypeLayout实际byte-safe决策与生命周期警示 | [admission.hpp](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/admission.hpp) |
| TypeLayout隐式反射include闭包 | [detail/reflect.hpp](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/detail/reflect.hpp)、[layout_traits.hpp](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/layout_traits.hpp) |
| TypeLayout常量字符串compare/consteval | [fixed_string.hpp](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/fixed_string.hpp) |
| TypeLayout浮点保证及平台检测 | [config.hpp](C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发/external/typelayout/include/boost/typelayout/config.hpp) |

## 3. 小型测试/工具源码观察

这些文件只读，**本次未运行**：

- `tests/test_wire_admission.cpp`：trait与签名、long/fixed-width alias、derived容器拒绝、load后修改及raw typed访问隔离。
- `tests/test_wire_validation.cpp`：偏移、bool、allocation/free-list、排序、单字节扰动中合法接受继续修改。
- `tests/test_same_arena_move.cpp`：同owner、祖先/后代fallback、重载后移动、retire OOM及跨arena失败保证。
- `tests/test_mutation_failures.cpp`：逐操作分配失败及可重试路径的源码入口。
- `tests/test_schema_envelope.cpp`、`test_compaction.cpp`：schema和normalized保存、显式新owner压缩。
- `tests/test_reflection_core.cpp`、`test_reflection_advanced.cpp`：既有反射/构造输入示例；不是新backend验证。
- `tools/export_signatures.cpp`、`signature_catalog.hpp`、`signature_target_matrix.hpp`：catalog实际wire签名配上手写目标ABI metadata；没有由这段代码在四个目标执行原生导出。
- `examples/demo.cpp`仅定向查看类型注册/相关位置，未更改；没有用新样例替换正式trace。

## 4. 文档与历史验收的使用方式

先读：[AGENTS](../../AGENTS.md)、[HANDOFF](../../HANDOFF.md)、[README](../../README.md)、[alpha边界](../ALPHA_COMPATIBILITY.md)、[V5验收](../PERFORMANCE_V5_ACCEPTANCE.md)、[V6设计](../PERFORMANCE_V6_DESIGN.md)、[分项目标](../PERFORMANCE_PHASE_FOLLOWUP.md)。另定向读取V1设计/状态、correctness repair、包与依赖锁相关内容。

V5 [final-acceptance.json](../coordination/performance-v5-20261018/final-acceptance.json)给出固定候选身份、功能/完整校验与V1保留、性能目标未达成/旧新收益未确立、未晋升及开放项。本次没有复核其9,264子进程输出、17,748保护文件或全部原始archive，不能把引用验收写成本次独立重验。

根README/HANDOFF/alpha反映storage原生Windows、WSL完整P2996及历史macOS等不同版本/环境。它们用于判断现有生产化边界，不能全部归为V5，也不能外推iOS/Android。N7生产入口尚不具备的记录沿用为开放前提，不执行旧协调请求、不向其他会话发消息。

## 5. 标准依据和限制

针对生命周期这一容易误判的细节，检索原始WG21文件及标准草案：

- [WG21 P0593R6](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2020/p0593r6.html)：隐式创建及launder区别，作为设计风险依据；不是对当前所有执行路径的运行诊断。
- [C++17草案N4659 basic.life](https://timsong-cpp.github.io/cppwp/n4659/basic.life)：初始化、存储重用及生命周期边界。
- [C++20草案N4861 basic.memobj](https://timsong-cpp.github.io/cppwp/n4861/basic.memobj)：核对隐式创建/子对象限制；C++17实现是否采用相应DR仍需profile明确。

没有据第三方博客推断平台支持，也没有安装/探测最新编译器或SDK。路线所列MSVC/GCC/Clang/NDK/Apple Clang是待验证的普通工具链类别，不是已可用版本清单或原生通过声明。

## 6. 本次保全与验证声明

写入范围为新目录 `docs/codegen-production-assessment-20261018/`。本次收尾仅检查本目录文档链接、JSON可解析、需求覆盖、输出文件列表与几个指定头的前后hash，属于文档交付检查。没有全仓preservation扫描，不声称整个工作区在并行V6期间静止，也不触碰原保全清单。

未创建额外workspace、未启动lease或heavy queue，因为本次没有任何需租约的重负载。未来原型预算仅提案；需要先按当前共享租约安排资源。未更改根头/CMake/demo、V6工作区/补丁/构建/工具/计划、固定依赖、冻结证据与历史档案；未提交/推送/合并/发布/触发远端CI。
