# 远端普通 C++ 分支调查

调查日期：2026-10-18。结论：**有，而且当前远端 main 本身就是 C++20 路线，另有 next_practical 和 release/v2.0-practical。它们包含数据结构与 schema 生成，不只是独立 storage。**

此前调研只围绕当前交接分支及本地原型，遗漏了远端 practical 路线；这是需要纠正的调研缺口。本文新增补充，不修改之前的历史报告或运行证据。

## 1. 分支清单与证据范围

`git ls-remote --heads origin` 实时列出以下 9 个分支；本机 `git branch -a` 当时只记录两个本地分支和一个 origin 交接分支，不能用它代表远端全集。本轮没有 fetch、checkout、创建工作区或下载依赖。

| 远端分支 | 当前提交缩写 | 本轮确认的标准/定位 |
| --- | --- | --- |
| main | d6cce5b5 | CMake 要求 C++20，Boost/PFR、Python schema 生成 |
| next_practical | c2a4797e | C++20 practical 开发路线，已有 YAML 生成器 |
| release/v2.0-practical | 08fd8894 | C++20 practical 发布路线，Boost.PFR 与生成器 |
| next | 119d1aa9 | 较早 C++20 路线；自动压缩另有 C++26 条件入口，普通路径有 manual 入口 |
| deprecated/next | 3fb0561c | CMake 设为 C++20；历史实现，不作现代完整资格声明 |
| deprecated/experiment | 70611de2 | 2024 历史树，benchmark17 的工程设为 C++17，主 demo 工程设为 C++20；不能称整分支 C++17 已验证 |
| next_cpp26 | 07d64990 | 当前 V5 所继承的 C++26/P2996 开发基线之一 |
| release/v2.0-cpp26 | ccf94e43 | CMake 要求 C++26 与 reflection/expansion flags |
| codex/vm-handoff-20261016 | 7539433a | 当前交接线：full 为 P2996，storage 独立 C++17 |

普通路线的一手入口：[main CMake](https://github.com/ximicpp/XOffsetDatastructure/blob/d6cce5b50eee0818493bdae7da5d73cb5ba8276c/CMakeLists.txt#L3)、[next_practical CMake](https://github.com/ximicpp/XOffsetDatastructure/blob/c2a4797ebd177aa91ca4f0fd5c8e71866aefc0b1/CMakeLists.txt#L3)、[release practical CMake](https://github.com/ximicpp/XOffsetDatastructure/blob/08fd889465656ddeb9f24ebfbc8d9603d0b508b8/CMakeLists.txt#L3)、[next CMake](https://github.com/ximicpp/XOffsetDatastructure/blob/119d1aa933dbf2a78a255a4fc3ffb4334a8a1e2e/CMakeLists.txt#L3)。实验性路线对照：[release cpp26 CMake](https://github.com/ximicpp/XOffsetDatastructure/blob/ccf94e4330449ba3a0994f7d2db1f628bca2c632/CMakeLists.txt#L3)。

远端 main 提交时间为 2026-03-16，release practical 为 2025-11-09，next_practical 为 2025-11-08（UTC 提交时间，非测试运行时间）。main README 推荐 practical 并声称生产可用；这是仓库作者的描述，本轮未独立运行验证。[main README](https://github.com/ximicpp/XOffsetDatastructure/blob/d6cce5b50eee0818493bdae7da5d73cb5ba8276c/README.md#L3)

GitHub compare API 对此次 next_practical/release practical 两个 tip 返回 No common ancestor；所以没有据分支名认定二者为线性的开发/发布关系，也没有伪造 ahead/behind 数值。逐分支结论绑定各自提交。

本地 `codex/offline-codegen-cpp20-20261018` 的 HEAD 仍是交接提交 7539433a，C++20 原型位于未提交的独立目录。它不是远端已发布的新实现；V3/V4/V5/V6 等 worktree 当时均 detached 在该 Git 基点，实际未提交源码分别演化，不能据 HEAD 判断内容相同。

## 2. practical 已经实现了什么

practical 的核心头是 `xoffsetdatastructure2.hpp`，不是交接线的同名无 2 主头。其 CMake 还列出 11 份 YAML schema，调用 `tools/xds_generator.py`，允许消费预生成头。配置为 C++20，没有要求实验性 P2996 flags。[构建与生成入口](https://github.com/ximicpp/XOffsetDatastructure/blob/08fd889465656ddeb9f24ebfbc8d9603d0b508b8/CMakeLists.txt#L81)

生成器从同一字段清单输出带 allocator 构造的运行时类型和 aggregate ReflectionHint，再生成安全、大小/对齐及签名断言；这已经是可复用的 schema→普通 C++ 工作。它的布局计算包含固定类型尺寸及对齐推导，未知尺寸还存在默认值，因此不能直接作为当前目标的完整元数据证明。[生成器](https://github.com/ximicpp/XOffsetDatastructure/blob/08fd889465656ddeb9f24ebfbc8d9603d0b508b8/tools/xds_generator.py#L120)

next_practical 的头通过 PFR 获得字段类型，并按前一字段尺寸/当前对齐推算 offset；容器安全识别中存在 sizeof/alignof 与成员 typedef 形状判定。它不同于目标编译器逐字段 offsetof 和精确容器族准入。[next_practical 核心头](https://github.com/ximicpp/XOffsetDatastructure/blob/c2a4797ebd177aa91ca4f0fd5c8e71866aefc0b1/xoffsetdatastructure2.hpp#L180)

PFR 的可移植承诺本来就有 SimpleAggregate 限制，涵盖基类、const、引用和 C 数组等边界，不能把“能枚举 Hint”推广为“完整反射任意旧类型”。应以分支固定的 Boost 配置逐项验证。[Boost.PFR 1.81 限制](https://www.boost.org/doc/libs/1_81_0/doc/html/boost_pfr/limitations_and_configuration.html)

## 3. 为什么不能直接替换当前 V5

release practical 基于 Boost.Interprocess 托管内存和 Boost.Container，签名按 32B 容器头描述；save/load 是内存镜像复制及 open；grow 使用 vector resize。其 compact 模板仍用失败 static_assert 占位。这些源码事实与当前 V5 的 16B 冻结头、稳定 VM 基址、verified V1 和实际压缩算法不同。[release practical 核心头](https://github.com/ximicpp/XOffsetDatastructure/blob/08fd889465656ddeb9f24ebfbc8d9603d0b508b8/xoffsetdatastructure2.hpp#L308)

| 约束 | 对当前方案的影响 |
| --- | --- |
| 当前 V1 header、allocator、rel32 与容器布局须保持 | 原始 Boost segment image 无法当成当前 verified V1 的直接替代；不是只换反射后端 |
| arena grow 不搬移基址 | vector 扩容不能提供相同指针稳定保证，需要保留当前 VM owner |
| 完整恶意输入校验与原错误优先级 | 类型签名/编译期 safe trait 不等于当前完整 wire graph 校验 |
| 自动压缩、异常与 alias 保证 | 发布 practical 的占位压缩入口不满足此要求，不能靠改叫 shrink 解决 |
| 加载后的合法对象生命周期 | 复制镜像/open 的存在仍需单独证明非平凡对象恢复，不能从 Boost 名称推导已解决 |
| 完整 metadata | Hint 的 sizeof/alignof 相等不独立证明运行时类型全部字段/offset；需要单一来源约束和防篡改/漂移负控 |

main 也仍以 vector 保存托管区域、以原始镜像保存，并保留未实现的 compact 占位；所以切换到更新的 main 不能自动消除这些差异。[main 核心头](https://github.com/ximicpp/XOffsetDatastructure/blob/d6cce5b50eee0818493bdae7da5d73cb5ba8276c/xoffsetdatastructure2.hpp#L407)

以上兼容结论是源码结构对比，不是本轮新做的 wire 拒绝实验。没有把 practical 中签名常量标为本机实测 sizeof，也没有宣称其所有使用场景不安全。

## 4. 测试声明要如何解读

release practical 定义了 14 个 CTest 名称，包括容器、序列化、MSVC、生成类型和 const；其中 `test_compaction` 注册名为 MemoryStats。存在测试目标不代表本轮跑过或现有缺口已覆盖。[测试清单](https://github.com/ximicpp/XOffsetDatastructure/blob/08fd889465656ddeb9f24ebfbc8d9603d0b508b8/tests/CMakeLists.txt#L126)

其 test_compaction 实际检查统计、增长、shrink，没有调用上述 compact 模板；因此不能用这个文件名证明图压缩可用。[统计测试源码](https://github.com/ximicpp/XOffsetDatastructure/blob/08fd889465656ddeb9f24ebfbc8d9603d0b508b8/tests/test_compaction.cpp)

序列化测试覆盖命名对象、复杂容器、空 buffer 和多次 raw roundtrip；并不是当前 V5 verified V1 的双向兼容与恶意图验证。[序列化测试](https://github.com/ximicpp/XOffsetDatastructure/blob/08fd889465656ddeb9f24ebfbc8d9603d0b508b8/tests/test_serialization.cpp)

main 的 CI 配置包含 Windows MSVC 等任务，其中额外类型签名实验步骤允许失败；工作流定义和提交说明中的“测试通过”都不能代替特定 commit 的实际运行结果。本轮未查询并验收 CI run，也未触发远端 CI。[main 工作流](https://github.com/ximicpp/XOffsetDatastructure/blob/d6cce5b50eee0818493bdae7da5d73cb5ba8276c/.github/workflows/ci.yml#L155)

## 5. 修正后的复用建议

如果目标只是已有普通 C++20 offset 容器及镜像保存，应该首先评估 main/practical，而不是重新创造这条路线。如果目标继续是当前已授权的“V5 完整语义、V1 双向兼容、完整校验、稳定地址与生命周期”，则采用“复用前端、保留当前后端”的候选更符合边界。

| 现有资产 | 建议处理 |
| --- | --- |
| YAML schema、字段/默认值/嵌套类型输入 | 作为旧 schema 导入候选，映射到规范化 IR，不自动转换类型语义 |
| allocator-aware 类型生成框架 | 评估复用；将类型定义、完整字段清单及所有操作从同一 IR 生成 |
| ReflectionHint/PFR | 可作受限独立交叉检查，不能成为任意类型完整性的唯一依据 |
| 生成签名/布局逻辑 | 保留测试资产；改由目标实际 offsetof/sizeof/alignof 表达式并遵守当前 V1 文法 |
| Boost 存储、容器及 raw image reader | 不直接替换当前 V5，避免改变 V1、地址和校验契约 |
| practical 的 schema/MSVC/容器测试输入 | 翻译为后端中立逻辑 trace，补到兼容/异常/生命周期矩阵；不继承未核验通过结论 |

下一步先对实际业务 schema 做三方映射：practical 生成产物、当前 V5 定义、本地生成原型。比较字段、目标布局、构造分派和操作域；能等价的生成器代码再复用，不能等价的记录具体反例。没有证据支持现在直接合并 practical 或重置当前工作区。

这次调查改变了“应从哪些资产起步”的建议：**先审计并复用已有生成器，避免重复实现前端；当前 V5 后端的兼容/生命周期工作仍然必要。** 未编译、运行测试、消耗新增 TU 预算、创建工作区或修改生产/demo/V6；只新增本独立调查目录。
