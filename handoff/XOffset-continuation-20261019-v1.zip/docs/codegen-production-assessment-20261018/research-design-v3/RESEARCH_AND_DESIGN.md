# C++20 离线生成：原型后的调研与设计

日期：2026-10-18。分支：`codex/offline-codegen-cpp20-20261018`。

建议继续采用“权威 schema → 普通 C++20 定义与操作”的主路线，先完成原型收尾和生命周期证明，再推进旧类型导入及原生平台资格。当前证据支持三个 schema 的受控切片，尚不足以承诺全量替换 TypeLayout/P2996，更没有运行时提速结论。本轮仅调研、设计和预算核算，未编译、运行原型、获取执行租约或修改旧证据。

## 1. 已知事实与本轮判断

历史事实来自 [第二轮结果](../prototype-cpp20-v2/RESULT.md)、[机器结果](../prototype-cpp20-v2/result.json) 和各次构建输入快照：

| 已有证据 | 可以支持的结论 | 仍不能推出的结论 |
| --- | --- | --- |
| 三个 schema 的完整签名、类型 ID、schema hash 相同；双向修改回传至 generation 3 | 这三个 schema 在已执行 WSL profile 的互操作性成立 | 任意旧类型、全部 CV/float 表示、其他 ABI 均兼容 |
| 125 个固定输入：47 接受、78 拒绝；旧、新、SAN 完整输出一致 | 已覆盖输入的接受域、首个错误和接受后可修改性一致 | 完整合法域相等、所有恶意输入均安全 |
| 最后一次 ASan/UBSan self 通过 | 对应快照中的构造/回滚、数组、OOM、move 和 alias 路径有运行证据 | 对象模型、pointer provenance 或任意自定义类型已获标准证明 |
| 新普通编译的非系统 include 闭包只有 6 个本地文件 | 已执行的消费端切片无 TypeLayout/P2996 include 依赖 | 生成器/包/所有消费者已彻底去依赖 |
| 最终 driver 新增 emit 的显式 grow | 已有具体源码修正，可供复编 | 最终源码已经全部测试通过 |

两项新的设计重点是本轮的源码审查推论，不是新测试发现：①现有 rel32 从成员地址进行跨对象字节寻址，仍缺完整语言/实现契约；②将 float 读为值再返回并初始化，不能仅凭输出文本相等证明所有允许的浮点表示保真。下面给出解决路径与否决条件。

## 2. 路线选择与架构

| 路线 | 定位 | 决策 |
| --- | --- | --- |
| 权威 schema 同时生成类型与全部操作 | 新受控定义的主路径；声明与 metadata 单一来源 | 继续，最先补强 IR 和生命周期 |
| 普通 Clang AST 导入旧定义 | 帮助枚举完整字段、访问、属性、模板实例与目标上下文 | 后续导入入口；不能自动解决 private 访问或合法构造 |
| 手工字段注册 | 双写难发现 padding 内漏字段 | 不能单独承担完整性保证 |
| P2996 导出 | 固定旧实现的对照 oracle | 只服务迁移证据，不能成为最终重新生成依赖 |
| 改 wire、改容器所有权、仅支持 trivial 类型 | 会改变本任务边界或旧合法域 | 本方案不采用；若必要只能报告现路线不满足目标 |

Clang LibTooling 可通过 CompilationDatabase 驱动 AST 工具；编译数据库绑定命令、工作目录及文件，一个文件也可能有多条配置。导入时应逐 profile 保存参数、宏、include/response-file 闭包；不能把一次宿主解析结果当成所有目标定义。[LibTooling](https://clang.llvm.org/docs/LibTooling.html)、[Compilation Database](https://clang.llvm.org/docs/JSONCompilationDatabase.html)

```mermaid
flowchart LR
    S[权威 schema 或受约束 AST 导入] --> I[规范化类型图 IR]
    I --> D[普通 C++20 定义]
    I --> O[字段与构造/校验/迁移操作]
    I --> M[输入身份与目标 profile 清单]
    D --> C[目标编译器核验布局与签名]
    O --> C
    M --> C
    C --> V[旧新差分与原生运行]
    V --> P[满足全部门槛后才发布支持声明]
```

后续独立目录可拆为 `ir/`、`generator/`、`generated/`、`runtime/`、`fixtures/`、`coordination/`、`evidence/`。这是设计，不是本轮新增实现。IR 至少记录声明顺序、完整 CV/数组/枚举类型图、访问、属性、默认值、构造/析构/比较/迁移定制、wire 名称与外部语义版本；字段类型不长期停留在未解析字符串。

目标编译器决定实际 sizeof/alignof/offsetof；Clang ASTRecordLayout 的布局信息可以用于导入诊断，但不能代替 MSVC/Apple Clang 等目标的真实断言和运行。[ASTRecordLayout](https://clang.llvm.org/doxygen/classclang_1_1ASTRecordLayout.html)

## 3. 元数据完整性与旧合法域

建议分开维护五个结论：完整 metadata、旧公开 byte-copy trait、旧内部成员递归、V1 admission、可合法执行的生命周期操作。任何一个为真都不替代其他结论。

v2 已揭示公开数组特化与内部反射递归不同：`Owning[2]` 公开 trait 为真，直接包含该数组的 record 为假；容器物理头与其逻辑元素也必须分别遍历。生产候选保留该行为，不能“统一递归”扩大 V1。另一方面，v2 的 `pointer_free()` 直接排除 union，而旧 TypeLayout 内部可处理 class/union；即便 V1 最终拒绝 union，也不能声称整个公开 trait API 已等价。此项来自 [metadata.hpp](../prototype-cpp20-v2/metadata.hpp:33) 的源码对照，尚未补做新 oracle。

建立逐类型映射表：旧声明/profile → 公开 trait → V1 → signature → 实际 create/load/modify/compact API → 生成/适配方案 → 证据。private、基类、opaque 或用户析构的旧合法类型若未找到等价入口，记为替换阻塞。可以有明确的首批支持范围，但不能据此把全量替换标记完成。

生成侧必须有以下检查：完整有序字段清单与类型图闭包、非法按值递归、未知属性硬诊断、确定性重生、条件宏漂移、漏掉 padding 内 bool/嵌套 owning 字段、输出篡改。未知节点不产生半份 metadata。schema 路线由生成定义保证单一来源；AST 路线需完整声明清单与输出清单逐项对应。

普通 AST 能看见 private 字段，不意味着普通生成代码具有访问权限。若需 friend/内部 restore 入口或修改类定义，必须单列源码适配成本；在“不改任何旧类且无协作入口”的约束下，不承诺通用可行。

运行时内部移至项目自己的 metadata 命名空间。保留 XOffset 既有公共别名需要 API 审核；不能直接把原型中的 `boost::typelayout` 替身头作为生产方案，否则与真实 TypeLayout 同 TU 使用可能产生定义冲突。生成构造函数还会改变 aggregate/constructible 等 traits，须逐项核对初始化、重载及 compactor 分派，布局相同不足以覆盖源码兼容。

## 4. 生命周期：先补证明，再扩支持

C++20 的 memcpy/memmove 在复制前有隐式对象创建规则，但对象创建只覆盖 implicit-lifetime 类型，不能顺带启动其中非该类别子对象的生命周期。数组对象和非平凡元素须分开论证；launder 的前提是相应对象已经活着，且可达字节条件成立。[N4861 cstring.syn](https://timsong-cpp.github.io/cppwp/n4861/cstring.syn#3)、[N4861 intro.object](https://timsong-cpp.github.io/cppwp/n4861/intro.object#10)、[N4861 ptr.launder](https://timsong-cpp.github.io/cppwp/n4861/ptr.launder)

P0593R6 还专门讨论了自定义容器数组、存储复用与非分配 placement-array-new。它支持继续研究当前路线，但不证明任意 memmove 或 VM 映射调用就能合法化所有后续操作；实现提供的映射函数语义、标准版本及缺陷修正需按 compiler/profile 记录。[P0593R6](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2020/p0593r6.html)

### 4.1 地址与存储依据

当前 [restore_payloads](../prototype-cpp20-v2/backend_helpers.hpp:69) 使用从 `data_delta` 成员地址出发的 char 指针加法，[raw_relative](../prototype-cpp20-v2/raw_validator.inc:8) 使用整数地址转换。通过边界检查能证明数值位于 arena 中，但不能单独证明所有 C++ 指针加法、来源及可达性规则满足。

P1839R7 专门讨论对象表示读访问及指针规则的缺陷，且其非目标包含原地写表示。本方案不能把“有这篇缺陷报告”当作 GCC 11.4 的 C++20 模式已实现全部相关语义，更不能把一个 4-byte 成员的对象表示当成整个 arena。[P1839R7](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2025/p1839r7.html)

建议设计 `StorageView`：持有实际存储区域的 byte-array 基址、extent、owner/epoch 与已检查 offset。raw validator 从区域 offset 寻址，先检查 signed delta 加法、长度和对齐，再取得地址；恢复后的 typed resolver 复用同一来源规则。wire 中仍保存“字段自身起算”的 rel32，不能改成 base offset。

这仍是待证明候选：必须说明 backing unsigned-char/std::byte 数组何时建立、何时提供存储，VM commit/decommit、池复用、free-list 和 tail-expand 如何保持/重建它与 T[n]。不要把 char* 数值转换当成该证明。还要评估 typed resolver 是否新增 owner 查询及其成本，不预先承诺读取性能不变。[N4861 存储与生命周期规则](https://timsong-cpp.github.io/cppwp/n4861/basic.life)

### 4.2 分开构造与恢复表示

建议生成三类明确操作：

| 操作 | 契约 | 验收重点 |
| --- | --- | --- |
| make/transfer | allocator-aware 与默认路径分开；构造完整 enclosing object | 原顺序、前缀回滚、绑定、重试、无栈上 rel32 临时对象 |
| restore | 原始图完整验证后，在同地址建立完整对象与活元素；不重新分配 payload | 未验证图不形成非平凡引用；构造前保存被覆盖的 inline 表示；全部成功后发布 typed/schema |
| relocate | 同 owner、无分配、可证明 nothrow；重算头偏移并清空源 | 源/目的生命周期、数组、祖先后代回退、外部 payload 地址与源可复用绑定 |

`noexcept` 不能只由生成器统一打印：以每个叶操作及构造前提形成可审计结论，生成静态约束。恢复过程中若仍有可抛操作，需 staging 状态和有效对象清单，保证失败时不遍历未验证头、不重复释放 payload。恢复新增 scratch/stack 工作也必须入预算；不通过人为缩小旧合法图来回避深度或大 record。

对于非 const、非 volatile、非潜在重叠的平凡标量成员，优先研究“先合法建立完整 enclosing object，再通过 memcpy 恢复该活成员表示”，避免 float 经按值返回/赋值路径。标准对 trivially-copyable 对象的表示复制有明确条件，不能把该保证泛化到整个非平凡 record、const 修改或重叠子对象。[N4861 basic.types](https://timsong-cpp.github.io/cppwp/n4861/basic.types#3)

const float、volatile、no_unique_address、用户定制等仍是单独的待证分支；上述方法不构成它们的解法。需要比较 +0/-0、有限值、subnormal、infinity、多个 NaN payload 等允许表示；使用整数/byte 快照进行观察，避免比较动作本身先计算 float。若旧合法输入不能在原 API/V1 下等价恢复，就报告阻塞，不把该输入从域中删除。

动态数组保留两层：capacity 对应的 T[n] 数组对象，以及 `[0,size)` 的活元素。fresh/reused/tail-expand、clear/erase/rebuild/compact 分别列出开始和结束规则；不能仅在 load 路径证明后就推广到存储复用。对象构造完成前不靠 launder 补救。ASan/UBSan 仅是补充运行证据，其检测范围不是完整对象模型证明。[ASan](https://clang.llvm.org/docs/AddressSanitizer.html)、[UBSan](https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html)

## 5. V1：保持格式，也保持接受域和后续操作

冻结 V5 主头身份 `c4acc7f2…b9964`，根目录 F、V6 及历史包分别标识。保留原 header/allocator/容器/rel32 表示，使用目标实际布局生成完整签名，保持原名称/hash 算法，不占用 V1 保留位。不同目标的原生分配对齐等差异单列，不能只比 schema hash。

继续按以下顺序验收：完整签名文字 → hash → 初始 image → 修改后的碎片 image → 对方加载修改保存 → 回传继续修改 → compact 到新 owner 并双侧复读。原 owner、binding、free-list 和异常后重试同时检查。浮点等有表示意义的值用 bit-preserving oracle；对 capacity/padding 等允许变化不强求所有 image 字节相等。

原始校验器保留旧遍历及 owned/free 全局优先级；旧 reader 不检查的 enum 枚举值、UTF-8 或业务数值范围不擅自新增拒绝。每个接受 corpus case 必须继续 grow/mutate/save/reload；load 之后失败属于测试失败，不能归类为“拒绝”。新增 custom comparator 的 raw 操作要独立证明，不能加载非法对象再调用业务比较函数。

profile 矩阵先闭合 WSL 旧/新/新 SAN，再建立 Windows x64 的实际 reader/writer；Windows 输出回 WSL 旧 reader、WSL 旧输出到 Windows reader均需执行。Linux 原生、ARM64、移动端随后逐 profile 登记；WSL 结果不能填为原生 Windows/Linux 设备结果。C++17 另行证明，不从当前 C++20 结论继承。

## 6. Windows 原生执行与共享租约

Microsoft 的 Job Object 可管理关联进程及默认继承的子进程；最后句柄关闭时的 kill 行为要求设置相应 flag，并禁止工作负载继承 Job 句柄或通过 breakaway 逃逸。嵌套 Job 是否能关联还取决于现有层级和限制。[Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects)、[Nested Jobs](https://learn.microsoft.com/en-us/windows/win32/procthread/nested-jobs)

拟议 native executor：CreateJobObject → 设置 KILL_ON_JOB_CLOSE 和限制、禁用 breakaway → CreateProcessW(CREATE_SUSPENDED | CREATE_NO_WINDOW) → AssignProcessToJobObject 成功 → ResumeThread。关联失败就终止尚未运行的进程并退出，不能带着未受控 child 继续编译。[Process creation flags](https://learn.microsoft.com/en-us/windows/win32/procthread/process-creation-flags)、[AssignProcessToJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-assignprocesstojobobject)

内存口径需分开：Job 的 ProcessMemoryLimit/JobMemoryLimit 是 committed memory，并不等于既有 3 GiB RSS 口径；不能把新 cap 悄悄当成相同约束。分别记录进程 working-set 峰值、job commit 和 VA，并事先登记采用的停止条件。[Extended limit information](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information)

仅有上述 executor **还不足以接入现有 POSIX runner**。原协调器按 POSIX session 清理；原生 Windows 进程不自动落入该清理证明。建议定义 lease/native 交接协议：

| 状态 | 必须满足的条件 |
| --- | --- |
| granted | 原共享锁仍被 coordinator 持有；run-id/nonce、deadline 和精确 argv 绑定 |
| native-bound | 独立 guardian 持有不可继承 Job handle；目标已 suspended 且成功入 Job；此前不能 resume |
| running | guardian 与 lease supervisor 保持受控通道；编译器、linker、测试子孙均受 Job 控制 |
| stopping | 取消、超时、客户端/桥接/guardian 丢失均进入停止；先终止 Job，不先释放锁 |
| drained | 查询 accounting/PID 列表确认无活进程，已掌握进程句柄等待完成；保存 native 清理结果 |
| released | coordinator 核对 drained 的 run-id/nonce 后才释放原锁 |

QueryInformationJobObject 提供 accounting 和 PID-list 查询；完成通知只能作为唤醒，最终需查询确认。本表的 IPC、身份核验和失联处理是本项目提出的协议设计，不是 Windows API 自带保证。[QueryInformationJobObject](https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-queryinformationjobobject)

若 guardian/通道死亡导致无法确认 drained，coordinator 必须保留锁并报告需介入的资源阻塞；不能凭 wsl.exe 退出、metadata 时间戳或 root PID 消失就释放。需要 coordinator 的显式 native cleanup 支持；现有 runner 的通用子进程包装不能代替它。该接入可能涉及共享基础设施，因此先在独立目录做协议实现和故障试验，正式接入另行安排，不能直接修改当前共享 runner 干扰 V6，也不另建一个不互斥的全局锁。

必测故障：正常结束、编译器产生 linker 子进程、根进程先退出、超时、公开客户端被 kill、桥接进程被 kill、guardian 被 kill、嵌套 Job 关联失败、尝试 breakaway、查询权限失败、Job handle 意外继承。任一无法证明清理的路径都阻止 native 构建准入。

## 7. 阶段、交付与预算

| 阶段 | 具体交付 | 出口 |
| --- | --- | --- |
| R0 本轮 | 本调研、源码风险台账、收尾验证账本 | 仅设计完成，不增加“已通过”的项目 |
| R1 原型收尾 | 同一最终 driver 分别构建旧 oracle、普通20、SAN；完整 emit/self/双向回传/corpus 重跑；输入和产物身份绑定 | 历史失败仍保留；新快照全通过才能关闭夹具收尾 |
| R2 生命周期与合法域 | StorageView 证明、数组存储复用、标量表示、CV/定制入口、公开 trait/API 差异台账 | 逐项有解且不改旧域；未解保留 blocker，不称全量替换 |
| R3 原生 Windows | native lease 协议与故障清理先验；再 MSVC profile 和双向 wire | 原生清理和数据互操作分别通过 |
| R4 完整候选 | 旧类型映射、生成器/包/multi-TU、其余产品选定 profile | 支持表中每项有证据；跨版本升级/回滚另有迁移链 |
| R5 后续性能/接入 | V6 冻结后的差异评估及独立授权；真实单位消费者与事前性能门槛 | 不能借去反射直接宣称收益，也不干扰正在进行的 V6 |

R1 的建议是追加**最多 4 次 TU 调用**：旧 oracle、普通20、SAN 各 1 次，加 1 次有明确诊断的修复余量；累计编译上限由 8 调至 12。所有 schema/核心路径保留，不用只重编一个可执行文件冒充三侧同源验证。

固定 case 也需要追加：当前 508/512，仅剩 4 次扣数。按 [验证账本](VALIDATION_LEDGER.md) 的 28 个被测进程、502 次保守扣数计算，累计预计 51 个进程、1,010 次 case。建议固定 case 总上限调为 **1,024**；进程仍为 64，其余原上限保持：3 GiB/进程、512 MiB 新文件、累计主动执行 1200 秒、30 秒/test、64 KiB/wire、1 MiB/owner、单重任务、原共享租约、不下载工具、不 fuzz/测量。

这些是**尚未获准的执行预算提案**，本轮不启动 R1，也不视本调研请求为预算批准。Windows helper、编译器及原生测试不挤入 R1 的余量；R2/R3 根据已完成设计另登记累计资源，不清零 v1/v2/R1 消耗。任何阶段资源不足先报告，不通过删平台、减合法类型或跳验证自行降级。

## 8. 决策与否决线

继续投入的最小条件：受控 schema 路线不依赖 P2996 重新生成；完整 metadata 有唯一来源或可核验导入；生命周期在所选 compiler/profile 下有明确依据；V1 及后续可修改性保持；原生任务能在同一共享租约中可靠清理。

以下任一情况出现，暂停“完整替换”承诺并保留原 reader：必须靠 unsafe trait、隐含编译扩展、缩旧合法域、改 V1、关闭图校验才能通过；private/const/opaque 等旧合法形态无法等价；目标 ABI 无法保持；native 清理结果不能确定。有限切片仍可作为研究产物保留，但不得转写为生产验收。
