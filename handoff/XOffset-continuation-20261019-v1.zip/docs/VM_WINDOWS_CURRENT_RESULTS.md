# Windows 当前交接源码验证（2026-10-16）

Windows 原生 x64 的 storage **2 项**、可重定位安装消费 **3 项**、源码子项目消费
**3 项**已通过。结果为本机新构建的运行证据，不来自历史 Windows 准备包或其旧 fixture。
本项未验证 Windows 完整 P2996 库、sanitizer、动态库/跨 CRT 边界或性能。

实际环境：Windows 11 Enterprise 10.0.26200、原生 AMD64、32 个逻辑 CPU；Visual Studio
Community 2022 17.14.42，MSVC 19.44.35229（工具目录 14.44.35207），Windows SDK/UCRT
10.0.26100.0；Python 3.11.7、CMake/CTest 3.28.1、Ninja 1.11.1。runner 自动调用
`vcvarsall.bat x64`，核对 x64 host/target 与 SDK，不改变调用方或系统环境。

## Windows 完整库能力评估

另外进行了单次最小原生反射 compile/link 能力探测，结果见
[native-full-assessment](validation/2026-10-16-windows-continuation/native-full-assessment/result.json)。
同一 x64 MSVC 环境以 `/std:c++latest /EHsc` 直接编译现有
`cmake/reflection_probe.cpp`，在 `xoffsetdatastructure.hpp:18` 失败：
`C1083: Cannot open include file: 'experimental/meta': No such file or directory`。
未进入链接阶段，未启动完整库 CMake 配置、构建或测试。源码同时产生 C4819 编码警告；
这不改变缺失 reflection header 的实际失败。

开发者环境 PATH、VS 的 `VC/Tools/Llvm/bin` 与 `VC/Tools/Llvm/x64/bin`、
`C:/Program Files/LLVM/bin` 中均未找到 `clang.exe`、`clang++.exe` 或 `clang-cl.exe`。
两处 VS LLVM 目录仅含 clang-format/tidy；不能把它们作为编译器。
这是明确范围的当前机器发现结果，不声称其他位置或其他可获取工具链不存在。
Windows 完整 P2996 支持保持未验证。该次评估的六个证据文件已按 manifest 复核，
原始 stdout/stderr 保留；没有改写已封存的 `current-05`。

## 可审计证据

- [最终结果 current-05](validation/2026-10-16-windows-continuation/current-05/result.json)：
  2026-10-16 14:45:51 至 14:46:28（北京时间）；构建输出保留在
  `build/windows-continuation-20261016/current-05/`。
- [源文件清单](validation/2026-10-16-windows-continuation/current-05/source-manifest.json)：
  当前工程的 135 文件构建闭包，含根目录非隐藏文件及 `cmake/tests/tools/examples/include`。
  不包含历史研究、依赖或整个交接仓库的全部文件。清单 SHA-256：
  `233018a81563dce8901520f16c9c791e7f13e02541c784d968e74855e75cddba`。
- [工具链与可执行文件身份](validation/2026-10-16-windows-continuation/current-05/toolchain.json)、
  [实际构建清单](validation/2026-10-16-windows-continuation/current-05/storage-build.ninja)、
  [package 结果及全部命令](validation/2026-10-16-windows-continuation/current-05/package-result.json)。
- JUnit 分别为 [storage](validation/2026-10-16-windows-continuation/current-05/storage-tests.xml)、
  [installed](validation/2026-10-16-windows-continuation/current-05/consumer-tests.xml)、
  [subproject](validation/2026-10-16-windows-continuation/current-05/subproject-tests.xml)。
  storage 注册清单与生成的 CMake inventory 一致；全部测试名称精确匹配，未跳过。
- [证据 manifest](validation/2026-10-16-windows-continuation/current-05/manifest.json)
  固定 39 个证据文件的长度和 SHA-256，自身 SHA-256 为
  `4c2a93b16dcc0136e91fe52da8b47ba023fe425f12a1ed893967463ee731076a`。
  独立离线 audit 已通过。

生产头未修改；快照身份仍为 F：

| 文件 | SHA-256 |
| --- | --- |
| `xoffsetdatastructure.hpp` | `9bc8f1f533bee83a9e111e05d67319383775dbca1844ef33b1aa717047640bb2` |
| `xoffset_virtual_memory.hpp` | `22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad` |

包验证复用受维护的 `tools/validate_vm_package.py --suite storage`，核对四个安装文件、
安装重定位、原生产路径失效后的独立消费、缺失 full 组件的明确拒绝、子项目默认关闭
开发目标，以及前后源码/安装包不变。native 与 package 的源文件字节清单完全相同。
三个消费者测试分别覆盖跨翻译单元转移、pool handle 先于 owner 析构、跨翻译单元静态析构。

## 复现与工具验证

`tools/validate_vm_windows_current.py` 不下载依赖；storage 不读取 Boost/TypeLayout。
`--work` 与 `--out` 必须分别为新目录，保留源码快照、命令、版本、二进制身份与 JUnit。
默认使用 Ninja；编译为 Release、C++17，测试断言通过 `/UNDEBUG` 保留。

```powershell
python tools/validate_vm_windows_current.py --source-dir . `
  --work build/windows-continuation-20261016/current-NEW `
  --out docs/validation/2026-10-16-windows-continuation/current-NEW --jobs 2

python tools/validate_vm_windows_current.py `
  --audit docs/validation/2026-10-16-windows-continuation/current-05

python -m unittest discover -s tools/tests -p test_validate_vm_windows_current.py -v
```

9 项工具测试通过，覆盖缺失处理器环境变量时的原生架构识别、缺失/重复/错误测试名称、
失败/跳过/disabled 测试、输出路径保护、证据增删改、无效 package 数量和不同源码替换。
离线 audit 不编译、不运行测试，不读取旧构建路径。

## 保留的失败及诊断

每次修正明确根因后均使用新目录，没有覆盖失败结果，也没有反复运行以筛选性能结论。
四轮准备失败与最终成功均保留于同一新日期证据根目录。

| 目录 | 实际结果 | 根因与修正 |
| --- | --- | --- |
| `current-01` | 编译前前提判定失败 | 启动环境缺少 `PROCESSOR_ARCHITECTURE`，`platform.machine()` 为空；改为 `GetNativeSystemInfo` 直接询问 OS |
| `current-02` | CMake 配置失败 | compiler cache 路径反斜杠被生成的 `.cmake` 解析为 `\P`；向 CMake 传递正斜杠路径 |
| `current-03` | CMake compiler probe 链接失败 | CMake 3.28.1 + NMake 把中文 PDB 路径损坏为 `????`，LNK1201；选用本机已有 Ninja，保留相同 MSVC 与测试范围 |
| `current-04` | storage 2 项通过，package wrapper 失败 | Windows Python 默认 GBK 无法解码 CMake UTF-8 路径输出；对 package 子进程设置 `PYTHONUTF8=1` |
| `current-05` | storage 2、installed 3、subproject 3 全通过 | 采用以上修正；源码、包、JUnit 与证据身份审计通过 |

前四轮未修改生产头或根 CMake。先前已封存的失败目录保持原样；其额外诊断材料另存
`validation/2026-10-16-windows-continuation/diagnostics-01/`，未回写失败 manifest。
历史 `docs/VM_PACKAGING.md` 与 `docs/VM_PLATFORM_FOLLOWUP.md` 记载的是旧机器当时状态，
本文件提供新的 Windows 运行证据，不回写旧证据。
