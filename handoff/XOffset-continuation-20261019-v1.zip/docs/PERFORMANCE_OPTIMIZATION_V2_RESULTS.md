# 性能优化 v2 实施与验收

2026-10-17。研究、详细路线图、三子代理分工、首批 P1/P2 实现、完整功能/兼容门禁、固定机制诊断及唯一新五库窗口均已执行。P6/P7 仍是有启动条件的后续工作，不把整体性能路线图写成完成。没有提交、推送、合并、发布或触发远端 CI。

可编辑候选：`C:/Users/gzsufanchen/.codex/worktrees/performance-roadmap-v2/xoffsetdatastructure开发`。Linux 源码与结果：`/root/xoffset-performance-roadmap/20261017/v2`。Git 基点仍为 `7539433ab96d69c4a07b1db5c0a13786da85cdcd`，不代表新候选已提交。生产主头 204,159 字节，SHA256 `e0f905694031c88618b8e2b453f6ac2400872e36a9caf82233c1d9e1dfabaf7a`；OS 头保持 `22f181b52c11ce442a5576ffc0dc35af1828f77deb4424f387d0acfa658239ad`，双头内容身份 `14c3b410fcbf51f930953c3847bd44c6cad1fe1d2080593e8dbcccb26749d080`。VERSION/alpha 档案未改，不是新发行版。

## 实现与功能保证

P1 将验证 owned/free 两棵 map 的逐节点上游分配改为 context 专属标准 PMR 单调资源，显式 new_delete_resource、小规模固定初始量、按需申请。两树比较/登记顺序、hint、在线拒绝、owned/free 互斥、绑定及所有原输入检查保持，资源随单次验证销毁，不形成全局池或 VM owner pool，不根据不可信长度预分配或新增合法节点上限。

P2 在 trait 允许无抛迁移时，先分配新父 buffer、预备 rel32，并完整构造新尾部，成功后才迁移旧 prefix，销毁已清空源对象并提交新描述符；失败清理新尾部，原 prefix 及 descriptor 保持。fill 引用旧元素/子对象及跨 arena fill 分别验证；不满足 trait 保留原 copy fallback。公共 API、容量策略、V1 存储字段和 OS 后端均未改。原 README 的整个 allocator 账本无需事务回滚这一边界不扩大成新承诺。

## 已执行门禁

| 门禁 | 实际结果 |
| --- | --- |
| P1 针对性 normal / SAN | 20 / 20 通过 |
| P1+P2 针对性 normal / SAN | 21 / 21 通过 |
| 最终完整库 normal / SAN | 各 52 项；各 3 项 configure 检查另列 |
| 五库适配器 normal / SAN | 各 16 项，另各 5 组 model golden |
| 维护工具 normal / Python -O | 各 40 项 |
| ASan/UBSan/LSan 实际正控 | UAF、overflow、leak 三种均检测到 |
| 五库 S/M/L normal / SAN | 各 80 子进程、15 格；独立 canonical/query/body/pin 审计通过 |
| V1 previous-candidate / range-index reader-writer | S/M/L 初始与修改后双向共 24 例 |
| alpha S reader 补充 | 2 例 |
| P2 嵌套/fill alias 专门 schema | 2 个双向 reader 例，4 个写/读动作 |
| 全新安装、移位及源码消费 | installed 3 项、subproject 3 项；851 依赖头内容锁通过 |

实际使用 WSL2 Ubuntu22.04 x86-64、固定 P2996 Clang21 `9ffb96e...`、匹配 libc++/私有 glibc 与兼容 sanitizer 资源。正式五库 Release -O3 的真实 Ninja 依赖绑定最终裸生产头，未混入诊断 generated 头或旧 alpha。此处不建立 Windows 原生完整 P2996 或独立原生 Linux 设备结论。

## 机制收益与代价

| 指标 | 本轮基线 2c50 | 当前 e0f9 |
| --- | ---: | ---: |
| 九阶段 arena 申请 | 86,016 | 53,248 |
| 九阶段 owner lookup | 172,032 | 106,496 |
| 九阶段 retire | 112,640 | 63,488 |
| stage6 arena 申请 | 45,056 | 12,288 |
| stage7 arena 申请 | 0 | 0 |
| stage8 新数据 arena 申请 | 24,576 | 24,576 |

P1 单独在同一 wire 上证明初载/重载的 owned/free、逻辑节点、key 与 neighbor 检查逐值不变。真正上游申请各为 11 个 chunk，而非每个节点一次；节点逻辑计数仍为 196,612 / 212,996。每次资源上游申请 16,769,376 字节，逻辑节点请求分别 9,437,376 / 10,223,808 字节；几何增长有闲置余量，不能宣称这些请求字节是 RSS 或节省的内存。固定本机 ≤128 次及 ≤2.25×节点字节+64KiB 的预算通过，退出 logical/upstream live 均为 0。

P2 完整 M trace 达到事前 12,288 目标，避免旧前缀的 32,768 次嵌套申请；stage8 是新增数据构造，不把它全部算浪费。最终 wire 仍为 17,830,872 字节，没有体积收益。重载 key 比较从 8,394,648 变为 8,788,248，owned/free 总数相同但物理布局/登记顺序不同，不能声称每项工作都减少。

计数版与时间版分离，九阶段 canonical 与前后 query 全部检查。诊断 driver 的 emit 包含一次阶段外生成与一次阶段内赋值，旧 save 重载计数覆盖也不完整，因此不能把其零 save 计数解读为无执行/零成本；正式 driver 不受此诊断范围影响。

P1 首次计数执行时，后加的事前 binary/dependency capture 尚未进入已载入的脚本。原 raw/request 未改；独立新目录 `P1-v1/counts-postrun-binding-v1` 保存实际 Ninja 依赖及当前 binary/生成头身份，并恢复了与原 request SHA 完全相同的 4,206 字节工具源码，没有重跑 native。这是后验补证，不补称原事前 pin。P12 则具备完整的事前 actual-dependency/binary/input 绑定。

固定当前版本 phase 采样各 16 次，load/reload/mutate 的实际样本数 678/647/270，丢失 0。区间登记仍是加载叶热点，修改热点分散到业务循环、申请和 ownership 保护。DWARF FORM0x23 等解析告警仍存在；不宣称完整行级符号化，不把叶函数百分比当纯机制因果，不用新旧样本数量推加速。[后续设计](PERFORMANCE_OPTIMIZATION_V2_FOLLOWUP.md) 据此仍优先研究区间边界快路径和 scratch 余量。

## 唯一正式窗口

本轮 launcher 尝试 1 次，实际 native 测量窗口 1 次，性能重试 0。实际成功 55/285 个子进程，未执行 230；窗口状态 `failed`，`measurement_qualified=False`，错误 `ProtocolError: anchor qualification failed: pre`。

窗口未通过既定资格，没有正式速度排名、加速倍率或旧→新因果速度结论。下表只使用全部可用 pre A/A 观察，排除 warmup，不筛点或重跑。

| 库 | n | 初载 ms | 修改 ms | 保存 ms | 重载 ms | 生命周期 ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| XOffset | 8 | 44.29 | 12.40 | 5.38 | 41.36 | 118.73 |
| cista | 8 | 11.04 | 8.03 | 12.31 | 8.82 | 55.37 |
| FlatBuffers | 8 | 7.33 | 7.99 | 13.51 | 3.81 | 57.59 |
| Cap’n Proto | 8 | 9.05 | 25.10 | 11.71 | 17.91 | 105.20 |
| cereal | 8 | 7.60 | 7.50 | 11.99 | 4.84 | 51.94 |

本批描述性均值中，XOffset 与 cista 的生命周期差额为 63.36 ms，两次加载差额为 65.78 ms，修改差额为 4.37 ms。它是当前样本的可加分解，不是纯安全检查成本或 CPU 因果分解。

| anchor | 库 | 合格 | 配对中位比 | AB | BA | scaled log-MAD |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| pre | capnproto | False | 0.958237 | 0.978211 | 0.900106 | 0.060768 |
| pre | cereal | False | 1.024150 | 1.024150 | 1.092106 | 0.069211 |
| pre | cista | False | 1.039715 | 1.039715 | 1.121843 | 0.055968 |
| pre | flatbuffers | False | 1.026335 | 1.101061 | 1.026335 | 0.047059 |
| pre | xoffset | False | 1.003411 | 1.025622 | 0.991988 | 0.016917 |

保持原 CPU2、285 子进程、20秒/child、45分钟、16GiB、15warmup、三组 A/A 和30比较块；比值/顺序中位数0.98–1.02、scaled log-MAD≤ln(1.02)、漂移≤1.02。全部 schedule/statistics/POLICY 的非身份 AST 与前版一致。正式测量没有并行编译/重测试/归档，不能由此宣称物理宿主机隔离；未通过资格不追加样本或换窗口。

冻结后实际复制五个 binary 并运行 describe，核内容、0755 与 runtime；最终审查使用 AST/纯读取，最后 inventory 拒绝 pyc、symlink 和非普通文件。外部 frozen pin、post-run 双清单复合 pin、维护 audit/report 均保留。审计通过证明保留的成功或失败记录可核对，不等于计时资格通过；旧 N3 未因此关闭。

## 体积与资源口径

| 库 | 最终 M wire 字节 | 本批进程峰值 RSS 中位数 MiB |
| --- | ---: | ---: |
| XOffset | 17,830,872 | 91.23 |
| cista | 12,095,936 | 86.44 |
| FlatBuffers | 10,757,704 | 83.44 |
| Cap’n Proto | 33,623,952 | 122.02 |
| cereal | 9,772,151 | 88.01 |

RSS 为审计前整个进程累计高水位，包含输入/trace、runtime、state/wire 重叠及分配器，不是库独占或阶段峰值。XOffset 与 cista 最终 wire 差异仍约47.4%；arena 保留能力、容量/metadata/空洞与重新序列化表示不同，不能仅据 wire 字节推内存差或把差额全部归为必要保证。

## 交付与后续

详细实施与责任边界见 [路线图](PERFORMANCE_OPTIMIZATION_ROADMAP_V2.md)，当前采样后的 P6/P7 工作包见 [后续设计](PERFORMANCE_OPTIMIZATION_V2_FOLLOWUP.md)。P6a 的有序边界 fast path、P6b scratch 余量、P6c 修改保护以及 P7 长驻/compact/同保证对照均未实现，不作为本轮验收完成项。新旧候选的因果速度研究需另行预注册同窗角色与日程，本轮未临时加入第六角色。

新协调记录在 `docs/coordination/performance-roadmap-v2-20261017`；便携选集在 `docs/validation/2026-10-17-performance-roadmap-v2`，包含生产/测试/工具、计数、日志、profile解析与formal metadata，实际文件清单见其manifest。SDK/runtime/binary、大wire/canonical、perf.data/stacks留在原Linux绝对路径，不把选集描述为独立runtime发行包。

最终保护核对通过，P0所记 2086 个根工程/旧worktree/旧源码/旧协调成员字节未变，新可编辑worktree与最终源一致。Git身份与暂存状态另见最终git检查；本轮没有自动提交、推送、发布、合并或远端CI。
