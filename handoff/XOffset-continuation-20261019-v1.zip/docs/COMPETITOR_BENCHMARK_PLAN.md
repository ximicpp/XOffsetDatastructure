# XOffset 竞品验证与后续开发实施计划

日期：2026-10-17。状态：研究、设计与实施计划；下述 P0–P11 尚未实施。

本计划的目标是判断 XOffset 在什么功能合同下值得采用，再判断性能差异来自哪里。
比较对象是 XOffset、cista、FlatBuffers、Cap’n Proto、cereal，共五个库；“四个竞品”不包含 XOffset。
研究见 [功能与证据](COMPETITOR_BENCHMARK_RESEARCH.md)，实现合同见
[系统设计](COMPETITOR_BENCHMARK_DESIGN.md)。机器可读任务、版本候选和本轮验收放在
[协调目录](coordination/competitor-benchmark-20261017/)。

## 1. 产品定位与本轮决定

核心候选场景为**固定 schema 的 C++ 可变状态快照**：输入快照 → 拥有可修改状态 → 查询 →
标量和容器变更/增长 → 生成独立快照 → 恢复 → 相同查询 → 释放。
它适合探索游戏/仿真状态、单进程服务状态和本地缓存恢复；这些只是合成场景的动机，
当前没有真实业务数据、生产延迟目标或流量分布，不能宣称已经满足其中某个产品的需求。

共同主轨使用值语义、固定宽度整数、字符串、序列、嵌套记录和有序键值项；不以压缩位域
减少某一个库承担的信息量。不要求相同内存布局或相同算法，但要求相同操作与最终语义。
只读分发另设成本边界；共享对象身份/循环图、arena 地址稳定、格式演进、跨语言和直接
文件映射列为单独能力轨。缺少硬能力记为 unsupported，不用复制对象或外置索引冒充原生能力。

先实现能核验这些合同的实验系统，不预先扩充生产库。后续功能取舍按 P10 的决策门禁执行，
不能因为某个单点分数低就删除修改、校验或所有权功能。

## 2. 已有状态与不可替代的门禁

| 项目 | 当前证据 | 本计划如何使用 |
| --- | --- | --- |
| alpha.1 | 已在干净目录验证发行包，本地准备完成，尚未发布 | 固定不可变源码包为 XOffset 比较输入；不重新打包覆盖 |
| 生产实现 | 交接 F 双头保持原样 | SHA 固定在候选锁；不以 Git HEAD 单独代表当前完整 alpha 源码 |
| WSL2 | full/storage/消费和兼容 sanitizer 已有功能证据 | 可以准备新基准；旧功能通过不等于噪声合格 |
| 原生 Windows | storage 路径已验，完整 P2996 环境未建立 | Python/协议审计与 storage 辅助验证；不伪造完整库竞品结果 |
| 原 N3 | 唯一 78 进程 F/F 窗口完成，但 2% 噪声资格失败 | 保留失败；本计划不恢复、替换或关闭旧 D/F 归因任务 |
| N7 | 用户确认真实消费者/协议资料暂不具备 | 保留开放项；不反复询问，也不以回环样例代替生产整合 |
| 旧 cista benchmark | 源码可解释布局、适配器和检查范围差异 | 只作研究线索；其排名、年代和机器均不作为本项目基线 |

来源：[alpha 边界](ALPHA_COMPATIBILITY.md)、[发行验收](RELEASE_V0_1_0_ALPHA_1_RESULTS.md)、
[N3 当前结果](VM_N3_CURRENT_RESULTS.md)、[后续路线图](VM_NEXT_STAGE_PLAN.md)。
WSL 和 Docker 可作为 Linux 实验环境；Docker-on-WSL 仍属于同一 VM，换容器名不构成独立复现或降噪证明。

## 3. 固定输入与版本策略

[候选锁](coordination/competitor-benchmark-20261017/candidate-lock.json)已核对上游 refs，
但尚未完成所有依赖内容下载、构建或功能验证。P1 才产生 executable lock。

| 输入 | 选择 | 选择理由及限制 |
| --- | --- | --- |
| XOffset | `0.1.0-alpha.1` 已验 source tar，SHA `5a8647736d1145676c503299d704bc37e2dd035d730ccc2ffca2e5e96a28c658` | 保留本地发布收尾，生产 F 未变；源提交身份仍记交接 `7539433…` |
| cista | v0.16 / `015b94e66c4c0d7c1ef29742383a024c84fbbba1` | 正式版本主轨；已审 master 的后续修复不能默认算进这个版本 |
| FlatBuffers | v25.12.19 / `7e163021e59cca4f8e1e35a7c828b5c6b7915953` | 选明确的常规发布；GitHub 另有后缀快照，不声称所选是 Latest |
| Cap’n Proto | v1.5.0 / `373e61ec89e2359f1c362e9b2eadc552f4779306` | 官方安装页当前版本；仅使用序列化运行库，RPC 不计入主轨 |
| cereal | v1.3.2 / `ebef1e929807629befafbb2918ea1a08c7194554` | 正式版本，BinaryArchive 为同机主轨；portable archive 独立命名 |

cista 补充候选 `bde0f01af0ec8f764baae106bd0a46a80e9e7b92` 仅用于发布后修复的功能敏感性检查，
不静默替换主轨。发现 v0.16 不满足功能合同，先保存最小复现、定位原因，主轨记 unsupported/bug；
修复版必须作为新增版本并重新过完整门禁。任何库都适用同一规则。

主性能轨统一已验 P2996 Clang 21 提交 `9ffb96e3ce362289008e14ad2a79a249f58aa90a`、匹配
libc++/libc++abi、私有 glibc runtime 与优化配置。所有被测运行时代码使用同一个实际 compiler、
stdlib、目标架构和 Release 参数；反射选项仅对需要它的 XOffset 翻译单元开启并逐项记录。
不得将系统 Clang 编译的 Cap’n Proto runtime 混入同编译器主轨。codegen 可使用独立 host 工具链，
但源提交、生成器二进制、参数、schema 与生成字节必须锁定，生成物须由主轨编译器编译。
如果第三方与该实验编译器不兼容，记录阻塞，诊断或增设完整命名的工具链轨，不能悄悄混编。

## 4. 实验系统落地与写入分工

以下路径是待创建的实施路径，本轮没有创建适配器、harness 或伪运行结果。

| 实施单元 | 拟建路径 | 独占写入者 |
| --- | --- | --- |
| 独立 CMake、接口、版本锁、公共配置 | `experiments/serialization_comparison/{CMakeLists.txt,include,locks,protocols}` | 主会话 |
| canonical 数据、trace、oracle、能力门禁测试 | `experiments/serialization_comparison/{model,fixtures,tests/contracts}` | 契约代理 |
| XOffset/cista adapter、各自测试 | `experiments/serialization_comparison/adapters/{xoffset,cista}` | 实施代理 A |
| FlatBuffers schema/codegen/adapter、测试 | `experiments/serialization_comparison/adapters/flatbuffers` | 实施代理 B |
| Cap’n Proto/cereal schema/adapter、测试 | `experiments/serialization_comparison/adapters/{capnproto,cereal}` | 实施代理 C |
| 串行驱动、回执、离线审计、统计与审计测试 | `tools/serialization_comparison/` | 测量代理 |
| 最终协调、独立复核、结果/决策文档 | 新 `docs/coordination/` 与 `docs/perf/` 子目录 | 主会话/只读复核者 |

最多主会话加三个子代理同时工作。先完成公共接口，再并行 A/B/C；契约与测量代理按阶段复用槽位。
公共接口修改由主会话集中处理，代理用消息提交变更理由，不能多人改共享 CMake 或 schema 合同。
适配器禁止运行时虚调用留在逐元素计时热循环；可用独立可执行文件与编译期绑定。

依赖下载与构建放项目独立环境，例如
`build/serialization-comparison/<profile>/<attempt>/`；WSL 原生 ext4 上使用持久目录，
不能以易失 `/tmp` 作为唯一保留位置。成果证据写
`docs/perf/<date>-serialization-comparison/<campaign-id>/`，大 wire 的存放、保留策略与
完整审计所需输入明确列出。只保留小包时不得宣称它能独立重算全部 wire。

## 5. 分阶段工作包、依赖和验收

任务状态与依赖同时记录在 [plan.json](coordination/competitor-benchmark-20261017/plan.json)。
各阶段完成必须同时有产物、检查结果和独立审查，不用“已写代码”替代完成。

| 阶段 | 依赖/负责人 | 具体工作与产物 | 退出门禁 |
| --- | --- | --- | --- |
| P0 合同冻结 | 无；主会话+契约代理 | schema/trace/digest/所有权/就绪点/信任分轨 ADR，功能矩阵，场景清单 | 每个场景列出操作、相同输出、资源与不支持条件；无真实 SLA 时明确合成假设 |
| P1 环境和内容锁 | P0；环境代理 | 下载固定 refs、校验完整 commit/tree/许可证、source archive hash；编译 runtime/codegen 小 probe；toolchain/runtime lock | 五库主轨实际可编译；codegen 与 runtime 身份一致；失败可复现且不隐式改版本 |
| P2 canonical 与 oracle | P0；契约代理 | 固定 PRNG、S/M/L fixture、混合 trace、逐步期望与确定性 digest、超限/错误模型 | 独立参考实现与 golden 一致；重复生成字节相同；边界值/空值/键顺序明确 |
| P3 五库适配 | P1+P2；A/B/C 并行 | 只读与 detached mutable 路径、保存/恢复、manifest；具体转换/复制成本明示 | 同一 trace 每个检查点值相同；不使用不同位宽、别名语义或提前转换规避计时 |
| P4 功能与失败验收 | P3；契约代理+独立复核 | 所有规模的 roundtrip/增长/销毁、独立进程重载、适用 sanitizer、负例矩阵、能力实测清单 | 正常主轨 100% 通过；无已知 UB/越界/泄漏；untrusted 仅对通过合同的子集开放 |
| P5 驱动与审计 | P2，可与 P3 并行；测量代理 | 串行队列/lease、strict JSON、raw→summary、预算/超时清理、离线 audit；小型合成故障测试 | 错误 hash、缺样本、重叠 child、预算超限、进程残留、统计改写均能拒绝；校验不依赖 Python assert |
| P6 事前登记与环境资格准备 | P4+P5；主会话 | 冻结输入/binary/protocol，功能运行估算预算，单一 runner 与全代理静默回执；新 campaign 运行理由 | 未看正式时间前锁定目标、顺序、样本数、统计/停止规则；旧 N3 窗口不复用 |
| P7 唯一正式窗口 | P6；主会话单执行 | 一次有限 A/A anchor 与比较 block 队列；原始回执、环境观测、wire 结果 | 所有功能/身份/预算检查通过且 anchor 资格满足；失败保留、不追加或挑样本 |
| P8 离线复核与结论 | P7；独立复核者 | 原 raw 独立重算、大小/RSS/区间、功能成本图、环境局限与适用场景报告 | 能从证据重算；只对合格 cell 下结论；不能把资格失败写成库性能相等 |
| P9 归因 | P8 且存在值得解释的差异；测量代理 | 独立 profiler/分配/布局账本，预注册一个因素一个对照的消融方案 | 解释有计数/调用栈证据；诊断开销不混入主性能；消融另立有限窗口，不能事后换主轨 |
| P10 产品实施方案 | P4+P8，优化需要 P9；主会话 | 采纳/保留/拒绝/前提不足的决策与需求，若需要则新建生产变更方案 | 新功能有硬场景、正确性与预算合同；优化有收益/回退约束；无结果时保留 F |
| P11 条件性 N7 | P10 + 真实消费者资料；专属实施代理 | 异步所有权/完成取消、真实协议适配、背压/资源上限、故障注入与业务验收 | 源码/协议/schema/尺寸/并发/完成取消语义齐备；当前 prerequisite_unmet，不计完成 |

并行关系：P1/P2 可并行；P5 的基础驱动在 P2 后可与适配并行；P4 的各库功能检查可并行。
P6 冻结之后停止编译与重负载；P7 完全串行；P8 为离线只读。P9 是独立后续诊断，
不能要求所有竞品都有完全相同内部数据结构，不能从相关性直接写成某个机制导致某个百分比。

队列优先复用既有 `experiments/vm_coordination/run_job.py` 的 POSIX 全局 lease，
显式指向共享稳定锁目录，不能因新 build/worktree 而另建一把互不相斥的锁。当前 runner 按
session/process group 回收自有 child，明确不支持 Docker daemon 后代；首轨使用 WSL 原生进程。
如要改用 Docker，须先完成独立的容器所有权/取消/清理/lease 适配和故障验证，不能把
`docker run` 藏进现有 runner 后声称进程树已受控。该限制是执行工具的前提，不撤销用户允许 Docker 的范围。

实施规模估计为约 18–28 个独立工作包：合同/锁/探针 3–4，oracle/trace 2–3，五库适配 5–8，
功能/负例 3–4，驱动与审计 3–4，冻结/测量/报告 2–5；数量用于拆分排程，不是工期或性能承诺。
最早可交付点是 P4 的功能竞争矩阵，即使平台测量资格仍不足，也能回答“功能上能否替代”。

## 6. 首个测量 campaign 的完整规格草案

以下是待由 P0/P4/P6 冻结为正式 JSON 的具体设计，不是已执行的授权回执。
正式实施命令须具备 `prepare → functional → freeze → run → audit → report` 的独立入口，
参数指向显式绝对路径；dry-run/functional 不产生 `performance_accepted=true`。

### 输入和范围

- cell：`V1-M-mixed-growth-trusted-detached`，五库各一个正式版本/adapter。
- 数据规模：S=128、M=16,384、L=131,072 条 Record；按相同逻辑数量固定，不按各库 wire 大小补齐。
- 数据字段与生成算法以系统设计为准；主轨统一整数位宽，不采用旧图测试的 slim 位域。
- 首窗只正式测 M+混合 trace+trusted detached。其他规模、只读与 U 轨先完成功能，性能后续分别登记。
- 主终点：同进程 `load_detached + query_before + mutate + save_owning + retire_modified_state + reload_query + cleanup`；
  原始输入 wire 已在 RAM，复制/解包/Builder 重建、必要规范化和库拥有资源的析构均计入。
  load 完成后、query-before 前立即由 harness 释放原 input owner，释放计入 load/总耗时；
  save 产生 final owning wire 后先释放旧 modified state 及其 blob/heap/builder，计入
  cleanup-before-reload。随后对 final wire 的只读 span 做 detached reload，不转移 final owner。
  query-after 后计时释放 reload state；final wire 移交 harness 保留供证据审计，其最终析构不计。
  所有库使用这些相同释放时点，post_audit 只能依赖 final wire。
- independent-process reload 是功能门禁，每库/规模/trace 单独验证；不拿另一进程时钟相加冒充单次 native timer。
- fixture 构造、初始编码、文件读写、fsync、进程启动、输出落盘和摘要计算均有独立记录。
  它们不混入上述 RAM 主终点；若报告“构造到恢复”或“持久化端到端”，必须另计完整边界。
- 主结果需要 consumed query digest 防止删减工作；昂贵逐值审计在计时外进行，但验收要求不变。

### 环境改变与准入

旧 N3 的 2% 目标不变。本 campaign 研究新的功能合同和工作负载，暂以 **5% 的工程差异**
作为最小关注量级；它是事前选择的实验目标，不是业务 SLA，也不是把旧 N3 门槛放宽后改判。
P6 记录新工作负载与旧 64 MiB save/vector 指标的差别，以及实际宿主调度、后台负载、电源和
持久 ext4 路径等设置。优先减少可控干扰；不擅自终止用户服务或修改需要权限的全局设置。
若同一新 cell 已资格失败，没有实质条件变化或新的问题假设就不重复。Docker 不能单独作为重试理由。

功能 smoke 用于检查时间/空间可行性，不提供比较结论，不据其速度选择有利的 cell。
超出预算须在冻结前修订规模/范围并说明原因；冻结后只能停止，不能自动缩小数据继续。
P6 必须记录当时覆盖本 campaign 的有效用户授权和外部 pin；本轮研究请求、旧 N3 单次批准
均不充当未来 run 回执。后续若用户已明确授权包含测量的整套实施，沿用该授权推进，不逐阶段重复询问。

### 顺序与硬预算

1. 事前锁定五库顺序表、balanced rotation 和随机种子。A/B 是同一个二进制与同一输入的标签。
2. 校准预热：每库 1 个 A/A pair，共 10 child。比较预热：每库 1 child，共 5 child。
3. pre/mid/post anchor：每库每 anchor 4 个 A/A pair，AB/BA 各 2；共 120 child。
4. 正式比较 30 个完整 block，每 block 五库各 1 child，共 150 child；pre 与 mid 之间 15 block，
   mid 与 post 之间 15 block。轮转顺序五个位置各出现 6 次，顺序表逐行保存。
5. 总上限 **285 child，45 分钟，20 秒/child，新 wire 16 GiB**；队列创建/核验/落盘都算窗口预算。
   P6 用真实功能产物大小和保留数量核算 wire 预算，同时验证磁盘有余量；预计超额即拒绝启动。
6. 任一 crash/语义错误/身份变化/timeout/预算耗尽/lease 冲突即停止，保存已产生记录，不补失败样本。
   pre anchor 未通过也停止；mid/post 失败则已取得时间保留为未合格证据，不能用 pre 结果替代。
   首窗整体资格属于这个五库共同 cell；任一库任一 anchor 不合格，全 cell 不作横向主结论，
   不在看见失败后只筛选剩余 pair 或库。
7. 全队列持有一个 lease。所有代理明确停止构建、重测试、归档、重 hash 与其他测量；只有 runner
   执行。前后快照和低开销观测记录宿主/WSL 状态，不宣称这证明整台机器没有外部噪声。

资格草案针对主终点逐库检查：**每个已完成 anchor 单独**计算其 4 对的 A/B 中位比，
须在 `[0.98,1.02]`；这 4 个 log ratio 的 `1.4826 × MAD` 不超过 `log(1.02)`；
AB/BA 两层各 2 对的比值中位数也须在同一区间。pre 仅凭本 anchor 这些门禁判停；
mid 还须检查 pre↔mid 的漂移；post 须检查三个 anchor 的漂移。漂移对同一二进制
pooled 及 A/B 各侧的 anchor 时间中位数计算，max/min 均不超过 `1.02`。
post 另检查合并 12 对的 log MAD 和 AB/BA 各 6 对中位比，沿用上述门槛。
最终资格要求所有局部、顺序、合并和漂移检查通过；不能用 pooled 合格覆盖某个 anchor 失败。
这些是事前诊断门槛，不保证 5% 效应一定可检出；实际比较仍须看区间。
不能据各阶段自己的 anchor 资格对未预注册的微小阶段收益补充结论。

### 统计与报告

单位是独立 child/完整 block，进程内循环不算额外样本。每 block 计算各竞品对 XOffset 的
主终点 log ratio，以配对 log ratio 中位数的指数作为主要比例估计（`>1` 表示竞品用时更多）。
bootstrap 10,000 次：每次在 pre→mid 的前 15 个完整五库 block 中有放回抽 15 个，
在 mid→post 的后 15 个中有放回抽 15 个，保持时间分段比例与五库配对；这是分层的
独立 block 重采样，不是把进程内循环采样，也不称作时间序列 moving-block bootstrap。
以各次重采样的主要比例估计形成 percentile 区间；四个主要对照采用 Bonferroni 的
每对 98.75% 区间，tails 为 `0.00625/0.99375`，目标是名义 95% family 口径。
该设计不保证小样本实际覆盖；若残留时间自相关使独立 block 假设可疑，降为描述性结果，另设计研究。
普通 95% 区间只作为明确标注的探索性辅助，同时保留原始 block。

重采样索引固定为 SHA-256 counter rejection sampling：对 ASCII 字符串
`xoffset-bb-v1|b|s|j|k` 求 hash，取前 8 字节 little-endian u64；`b=0..9999`、
`s=0/1`、`j=0..14`，`k` 从 0 递增。拒绝 `x >= 2^64-(2^64 mod 15)`，接受后索引为
`15*s + x mod 15`。数字用无前导零十进制替换占位符；每个 draw 独立重置 k。
中位数在偶数项时取中间两值的算术平均；区间分位数使用排序后 `h=(n-1)*q` 的相邻线性插值
（Type 7）。实施时用 golden 重采样索引和独立统计实现检验，不从不同库随机库默认行为推导一致。

事前实用区间为 `[1/1.05,1.05]`：区间整体在上界外/下界外，才报告达到关注量级的方向；
区间整体在实用区间内，才可在此场景报告实用等价的估计；其余记无法区分/不确定。
不删离群点，不只报最快一次，不合成跨场景总冠军。30 block 不足以支持生产 p99，不报告 p99。

同时报告准确 wire 字节、独立 child 的 Linux `ru_maxrss`（KiB）、CPU/wall 时间、页故障和
退出/清理。RSS 包含输入/输出/运行库等进程成本，不能当作 allocator live bytes；VA reservation、
accessible bytes、RSS 分列。分配计数、堆峰值和 profiler 另开诊断 pass，声明 malloc/new/mmap/
自定义 allocator 覆盖范围，漏计字段写 unavailable，不能写成零。

正式 timer 结束后才做的完整 wire/canonical `post_audit` 仍计入 20 秒 child 上限、总窗口和
输出预算。主 endpoint 结束先读一次 high-water（含 setup），再记录退出时含 post_audit 的
whole-child peak；两者分列，不以相减 high-water 当精确增量，不把 audit 峰值冒充纯库操作峰值。

untrusted 轨后续另立协议：统一应用端长度/元素/深度/步数等资源限制；各库结构检查、惰性检查、
schema 检查与业务校验逐项披露。校验和作为共同外层可选轨单独计时，不能用 checksum 替代结构验证，
不能把 cereal 解码、Cap’n Proto getRoot、cista UNCHECKED 和完整 verifier 命名成同一个 SAFE。

## 7. 功能缺口和生产变更决策

| 需求/发现 | 立即动作 | 后续实施条件 |
| --- | --- | --- |
| 主值语义修改/增长快照 | 先完成五库等价 adapter 与功能矩阵 | P4 通过后才比较性能 |
| XOffset 与 cista 显著差异 | 检查拥有权、复制、容器布局、碎片和检查范围 | P8 合格且 P9 有证据后提出具体优化，不预设赢家 |
| 业务必须任意共享身份/循环对象图 | 现有 XOffset admitted wire 不提供通用指针图合同，单列能力缺口 | 独立设计 offset reference/所有权/验证/compact/版本策略；需要业务需求才扩生产格式 |
| 业务必须 mmap 只读启动 | 承认当前 copy-load 的能力/成本差异 | 独立 attach/view 生命周期与校验设计，不能由性能测试暗加生产 API |
| 跨语言/长期 schema 演进 | FlatBuffers/Cap’n Proto 为不同优势候选 | 新业务合同和迁移设计；现有 XOffset schema hash 仅检测不迁移 |
| 原生 Windows full | 保持未验证 | 实际可用 P2996 compiler/stdlib 后新 profile，不能用 storage 冒充 |
| N3 历史 D/F | 保持开放 | 实质新条件下独立原目标协议，不由新竞品结果代替 |
| N7 生产网络 | 保持前提不足 | 用户/工程出现真实入口后再做 P11，不把研究完成写成整合完成 |

P10 交付一份决策表：功能合格但无性能证据、功能合格且场景有优势、功能不满足、前提不足。
要做生产代码改动时，另列问题、预期行为、格式/API 兼容影响、测试与回退条件；
本计划不预先授权删能力、修改 V1 或发布 alpha.2。

## 8. 最终验收和停止后的交接

实施交付至少包含：source/toolchain/codegen lock、canonical/trace/golden、五库 adapter 与
逐项能力结果、功能/sanitizer/负例证据、preregister 与独立 pin、raw/receipt/环境/预算、可重算
summary、独立审查、场景决策。unsupported、unavailable、failed、not_run 与 passed 分开。

验收脚本须能离线拒绝缺失输入、部分 block、改过的 digest、混入不同库/模式/编译器的时间、
重叠窗口或无法重算的统计。发布式摘要须保留失败、置信范围与功能前提，不摘用漂亮单点。

“拒绝部分 block”指拒绝将它标成成功比较。合法早停档案仍应可审计：冻结完整 expected schedule，
回执精确对应已启动的连续前缀，每个 child 有实际状态/原始输出或明确无输出原因/清理结果，
停止原因与未执行后缀明确；可给 `audit-preserved-failure`，但 `performance_accepted=false`。
成功才要求全部 285 child 和 30 完整 block；驱动不能为了凑成功计数补样本。

遇到工具问题先诊断，不反复跑正式样本。确实缺少凭据/权限/生产业务决定时，标明具体阻塞并
推进其他独立阶段；不把工具安装或复制命令交给用户。所有新证据使用新目录；已有修改、历史
档案和 alpha.1 包保持不变。本轮及后续默认不暂存、提交、推送、合并、发布或触发远端 CI。

当前可验收的是研究和设计计划本身：文档互相一致、版本 refs 可核对、阶段依赖无环、
计数与预算闭合、边界明确、未损坏已有成果。P0–P11 的实现和性能结果仍待后续执行。
