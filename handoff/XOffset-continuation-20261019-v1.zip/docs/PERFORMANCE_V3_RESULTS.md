# Performance v3 实施与验收结果

2026-10-18。独立未提交开发候选；不是 alpha 发行包，也未发布。

**本版竞争目标：尚未达到。** 正式窗口未通过全部预注册 A/A 资格检查，不能据此发布正式速度排名或加速结论。

已完成精确在线位图索引和字符串增长替换优化；保留生产校验、公共 API 和 V1 wire。当前主头 SHA256 `39ff8d4f75029f86caaa9bc37b47f9066067611a2cf90c75c9de572bc0c55725`。

## 完整生命周期实测

共同业务为 M mixed-growth trusted-detached：16,384 records、28,673 modifications、55,299 queries。包括私有 owning 初载、查询、变长修改、owning 保存、退休修改状态、重载、再查询和清理。全程保留各库实际路径；XOffset 不使用 unchecked。以下为全部测量行的算术均值，单位 ms，warmup 排除，不剔除样本。

| 角色 | n | 初载 | 查询前 | 修改 | 保存 | 退休 | 重载 | 查询后 | 清理 | 总计 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 旧 XOffset v2 | 96 | 44.343 | 6.703 | 12.487 | 5.659 | 0.620 | 40.630 | 7.308 | 0.433 | 118.183 |
| 新 XOffset v3 | 96 | 8.663 | 6.487 | 12.133 | 5.811 | 0.631 | 14.401 | 6.787 | 0.429 | 55.341 |
| cista v0.16 | 96 | 10.473 | 6.282 | 7.305 | 11.989 | 1.768 | 8.967 | 6.289 | 0.448 | 53.521 |
| FlatBuffers v25.12.19 | 96 | 7.070 | 7.055 | 7.962 | 12.742 | 6.320 | 3.522 | 7.050 | 4.305 | 56.026 |
| Cap’n Proto v1.5.0 | 96 | 9.642 | 19.504 | 24.444 | 11.818 | 0.825 | 18.220 | 19.849 | 0.005 | 104.307 |
| cereal v1.3.2 | 96 | 7.791 | 6.436 | 7.307 | 11.795 | 3.864 | 4.818 | 6.332 | 2.565 | 50.909 |

阶段算术均值用于定位成本；下表推断量为每 block 的 A/B log 配对、再按六 block 聚合的八个 macrocycle，与上表算术均值比不是同一统计量。下表仅作未合格窗口的诊断观察，comparison=null，不能用于正式胜负或因果加速。

| 新 XOffset / 对照 | 几何延迟比 | 单侧同时上界 | 目标上界 |
| --- | ---: | ---: | ---: |
| 旧 XOffset v2 | 0.4674 | 0.4798 | 1.00 |
| cista v0.16 | 1.0326 | 1.0713 | 0.80 |
| FlatBuffers v25.12.19 | 0.9891 | 1.0352 | 0.80 |
| Cap’n Proto v1.5.0 | 0.5304 | 0.5504 | 0.80 |
| cereal v1.3.2 | 1.0888 | 1.1249 | 0.80 |

目标在新候选任何计时之前固定为：对四个竞品点估计及同时区间上界均 ≤0.80（至少少20%延迟），且六角色 A/A 全通过。旧新改善另有独立判据，不把跨窗口均值差当因果。

A/A：

| 角色 | 实际先执行 / 后执行的同时区间 | 等价成立 |
| --- | --- | --- |
| 旧 XOffset v2 | [0.9802, 1.0552] | False |
| 新 XOffset v3 | [0.9802, 1.0535] | False |
| cista v0.16 | [0.9591, 1.0606] | False |
| FlatBuffers v25.12.19 | [0.9225, 1.0340] | False |
| Cap’n Proto v1.5.0 | [1.0107, 1.0733] | False |
| cereal v1.3.2 | [0.9309, 1.0601] | False |

资格/目标未决原因：`["AA_equivalence_not_established:old_xoffset", "AA_equivalence_not_established:new_xoffset", "AA_equivalence_not_established:cista", "AA_equivalence_not_established:flatbuffers", "AA_equivalence_not_established:capnproto", "AA_equivalence_not_established:cereal"]`。

## 测量与功能保证边界

WSL2 Ubuntu22.04 x86-64，i9-13900K，taskset CPU2，固定 P2996 Clang21/libc++，裸 Release -O3。600 fresh-process children（24 warmup + 576 正式行），八个平衡 Williams macrocycle，48 blocks；一个全局租约窗口，无编译/重测试/归档并行，无性能重试、追加样本或挑选窗口。CPU 亲和不证明宿主独占。

六角色 chronological A/A 同时区间须全部落入 [1/1.05,1.05]。五个 contrast 各单侧99%，Bonferroni family nominal95%，df7；A/A 是另一 family95%，不声称两组11个区间联合95%。区间依赖 macrocycle 近似独立正态模型，不是分布无关、给定 A/A 通过后的覆盖保证或未来宿主性能保证。

共同业务功能并不代表所有库安全功能完全相同：cista NONE 仍做结构检查，但不等于 XOffset 的 free-list/owned-free 完整准入；FlatBuffers 为可信 ObjectAPI UnPack/Pack 且未额外 Verifier；Cap’n Proto 为 bounded reader 后 detached builder；cereal 为 BinaryArchive/native DTO。只读 mmap、跨语言和长期驻留并未替换主场景。详见 [预注册设计](PERFORMANCE_V3_DESIGN.md) 和便携证据中的 `implementation-and-review-tools/review/design.md`。

## Wire 与进程资源

| 角色 | 初始 wire 字节 | 修改后 wire 字节 | audit前整进程RSS峰值中位数 MiB |
| --- | ---: | ---: | ---: |
| 旧 XOffset v2 | 13,702,104 | 17,830,872 | 91.234 |
| 新 XOffset v3 | 13,702,104 | 17,830,872 | 90.855 |
| cista v0.16 | 10,315,104 | 12,095,936 | 86.441 |
| FlatBuffers v25.12.19 | 8,990,248 | 10,757,704 | 83.438 |
| Cap’n Proto v1.5.0 | 9,055,872 | 33,623,952 | 122.027 |
| cereal v1.3.2 | 8,063,804 | 9,772,151 | 88.012 |

wire为实际文件长度；RSS为每个fresh process在语义audit之前的整个进程高水位，再取96次中位数，含输入/trace、adapter及runtime等，不是库独占内存、scratch请求字节或峰值活跃allocation。本版没有减少V1保存内容；两个XOffset的wire相同，体积仍大于cista/FlatBuffers/cereal。位图的scratch节约不能被直接解释为相同比例RSS下降。

## 已验证机制

| 指标（固定 M，非计时样本） | v2 | v3 |
| --- | ---: | ---: |
| 初载 scratch 上游请求字节 | 16,769,376 | 1,686,576 |
| 重载 scratch 上游请求字节 | 16,769,376 | 4,423,888 |
| 初载/重载 scratch 上游请求次数 | 11 / 11 | 6 / 7 |
| 实际登记路径区间树查询 | 原有树 | 0 |
| 九阶段 arena 申请次数 | 53,248 | 53,248 |
| 字符串增长全量替换前复制的旧逻辑字节 | 存在 | 少146,601字节 |

各退出点 scratch live 为0；owned/free登记计数保持。请求字节不是 RSS，也不是仅活跃内存。每arena字节对应一个bit、分别维护owned/free，半开区间不取整，首次错误顺序及父对象先登记后访问子对象不变。实际不再维护影子树。整空页可标sentinel；partial页后来填满仍保留真实Page所有权。固定extent U的两个目录/partial位图逻辑上界1040×ceil(U/4096)字节（约U/4+U/256），另有PMR slack；任意detail helper增长须另计历史目录，不能套用固定extent公式。

字符串 fresh-growth 在准备rel32后直接复制rhs及terminator，成功后提交并退休旧块；in-place memmove、tail expand、容量策略及别名/异常保证保留。没有宣称减少arena申请或owner lookup。

固定 CPU 采样仅3进程×16内部迭代，load/reload/mutate 各125/243/261 samples、0lost；缓存可暖、FIFO握手尾及缺页属于该诊断边界，DWARF部分未知栈保留。样本数和叶百分比均不能当耗时、因果成本份额或竞品加速。反汇编独立核查还确认 header.alignment 的模运算已被编译器转为mask；generic validate_storage_range 则仍有div，不能把两者混为一个待优化除法。

## 验收与保留证据

- 完整库 normal/SAN 各54项；adapter normal/SAN各16项、各5goldens；UAF/overflow/leak三正控有效。
- 五库 S/M/L normal/SAN各80个顺序进程、15cells、九阶段canonical及query正确。
- V1三旧控制版本双向36cases；alpha-S补充2、resize schema双向2、string schema双向2。
- 干净relocation安装与子工程各3项通过，绑定851个实际依赖头。
- 维护工具40+40、六角色统计21+21（normal/Python-O）通过。
- 原3799个保护文件逐一核对；原工作区及v2/alpha/失败记录保留，新增候选独立可编辑。
- 首次bitmap构建的nested Page noexcept错误、诊断transform regex及实际copy描述字段漏项均保留原失败，在独立目录修正后过门禁；这些不是性能重试，正式窗口仅一次。

原始大wire/canonical/query、native binary、完整运行时闭包及perf.data保留在 `/root/xoffset-performance-v3/20261017/v1`。便携证据仅复制小型metadata、源码摘录和工具，明确不冒充离线完整重现包。

## 剩余差距与下一版预算

目标未达到有两个独立原因：A/A尚未证等价；而即使暂不考虑资格，新/四竞品的诊断点估计也只有对Cap’n Proto低于0.80，对cista为1.0326、cereal为1.0888。仅改善测量资格不能把当前候选变成目标已达成。

把本窗cereal算术观察值乘0.80，只能得到描述性工程预算 **40.7274 ms**；当前新候选仍差 **14.6136 ms（其总计的26.406%）**。这不是正式最快排名、目标推断阈值重定义或可实现性证明。如果除load/reload以外的32.2771 ms完全不动，两次load合计23.0639 ms需降至8.4503 ms，即还需减少63.361%；几个算术特化无法凭现有证据承诺这么大的收益。

即便把新候选修改阶段假设替换为cista观察成本，距离上述预算仍有9.7853 ms；再假设重载也等于cista，仍差4.3517 ms。两次query相对cereal的观察总差仅0.5058 ms。跨库工作/保证不同，这些只是加减法预算，不能把某库阶段成本直接移植成可达收益。

重载与初载不是相同工作：初载owned登记196,612/free0；修改后重载owned204,804/free8,192，overlap queries393,224→425,992、tested words334,773→695,262、partial pages2,995→6,772。重载先复制修改后的V1存储，逐链校验其已有allocator/free-list的offset、header、size-class和freebytes并登记free区间，另有更大的私有copy；不是另建host free-list。不能把14.40−8.66 ms直接归因于额外校验、free-list或除法，也不能将其全部认定为实现浪费。

A/A未证等价是区间未完全落入预注册[1/1.05,1.05]，不等于已证明每个角色都有非等价偏差，更不能仅凭它断言原因全在宿主负载。缓存顺序、进程首次触页和环境漂移需要独立诊断；本轮未改变阈值、过滤行或再次计时。

## 后续性能路线

以下为新研究项，不写成已实施或已验证收益；本轮不重开计时窗口：

1. **P0：校验算术与调用专化。** 针对已证明power-of-two的固定/模板alignment路径做mask/常量特化，generic任意alignment保留原行为；按真实-O3反汇编验证div和调用是否减少，保留错误优先级、OOM和完整范围准入。重复bounds中有的证明不同对象范围，不能直接删。
2. **P1：修改中owner/allocator成本。** 用固定机制诊断区分真实owner查找、arena申请、容器构造和缺页；只有epoch/move/swap/release/ancestor alias证明完整后才考虑局部复用。禁止全局裸owner缓存或跳过构造/绑定检查。
3. **P2：按剩余总成本分配预算。** 将两次加载的字段遍历/私有copy、query、save、retire/cleanup分别计账；V1保持且不换场景。若wire体积/布局成为瓶颈，另开有显式兼容策略的格式版本，不静默改变本版V1。
4. 新候选先经同等normal/SAN/兼容/消费门禁，再事前登记新的唯一测量窗口；不能用本轮看过的数据选择阈值或重复本候选直到通过。N7仍缺真实业务入口，保持开放；原生Windows full P2996未建立。

## 可定位产物

- [协调验收](coordination/performance-v3-20261017/final-acceptance.json)
- [阶段账本](coordination/performance-v3-20261017/plan.json)
- [原始描述统计](coordination/performance-v3-20261017/descriptive-window-results.json)
- [便携证据](validation/2026-10-18-performance-v3/README.md)

未提交、推送、合并、正式发布或触发远端CI。
