# 四路径固定成本调查

S/M/L各一次完整原始轨迹，M固定16次输出分解；所有九阶段canonical、首尾query与逐库原modified wire身份通过。诊断不是正式性能成绩，插桩的每分配registration时钟、统计分支与PMR事件会扰动耗时，不能据此计算原生产路径的精确时间占比。

| 修改后物理字节类别 | S | M | L |
|---|---:|---:|---:|
|headers_arena_allocator|25784|3276984|26214584|
|live_value_bytes_including_ABI_padding|90533|11562115|92478301|
|capacity_spare_bytes|0|0|0|
|request_rounding_bytes|1667|211349|1693251|
|physical_donor_excess_bytes|5160|593080|4728064|
|free_allocation_bytes|11576|1571648|12587584|
|host_free_bytes|0|0|0|
|proven_fresh_alignment_gaps|256|32768|262144|
|other_holes_including_unrecoverable_input_gaps|4608|582840|4655768|

全部互斥分类守恒到used_end。live包含对象ABI padding；free allocation包含其物理头和payload；request rounding与复用过大donor余量分开。旧输入没有完整历史allocation链，582840B的M继承hole不可反推全为对齐间隙。仅本轨迹fresh core分配事件能证明新增32768B gap，约修改后载荷的0.184%；不能为布局候选重生成有利initial wire或假定其整理旧hole。

| M 修改阶段 | 递归owns调用 | dynamic申请 | 实际freelist节点访问 | cursor维护比较 |
|---|---:|---:|---:|---:|
|1|0|0|0|0|
|2|0|4096|0|151546|
|3|0|4096|0|151530|
|4|0|4096|0|139244|
|5|0|4096|4682|64613|
|6|0|12288|8192|258022|
|7|320465|0|0|49152|
|8|0|24576|62698|240759|
|9|0|0|0|0|

M第7阶段递归owns为320465次；第8阶段cursor仍有62698次节点访问、240759次维护比较。维护比较不是owner扫描，更不是机器比较计数。默认透明locator需先过ancestor/escaping descriptor soundness，不能为性能跳过真实嵌套所有权。

M16 owning emit中位 5.481292ms；独立controlled分配 0.015029ms、touch 4.393732ms、hot-destination完整copy 1.621979ms。后面三个是独立条件实验，不能与旧emit嵌套copy重复相加。touch每次实际minor faults见原JSON（通常4352），hotcopy为0；allocator页面复用/首次fault显著影响预算。首轮owning emit与后续中位也不同，不能择快值宣称正式.20目标。

reload的owning_construct包含VM准备、实际payload memcpy、arena检查和registry；单独vm_payload_copy_ns明确嵌套其中。graph也包含逐allocation注册时钟和bitmap逻辑计数，scratch申请/释放耗时嵌套其中；这些数不直接相加。保留完整validation，下一步只测机制明确的新候选。

旧owning独立输出仍要实际物化所有V1字节。新freeze两段lease只属于独立生产口径，不能代替旧demo来完成5x目标。大页仅研究，未更改通用string分配或全局设置。
