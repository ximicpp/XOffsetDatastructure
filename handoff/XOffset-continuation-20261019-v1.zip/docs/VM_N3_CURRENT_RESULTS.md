# N3 新机器校准结果（2026-10-16）

唯一78进程F/F窗口全部执行成功，但4项指标的12个局部anchor与4项跨anchor漂移资格全部未通过。**2%目标量级的检出资格尚未建立，默认D/F回退复现与归因仍开放。** 本轮没有D/F性能比较、消融、生产优化、采用或重试；生产双头仍保持F。

## 平台与固定输入

实际运行类别为 `wsl2-vm-x86_64`：本机Windows上的Ubuntu 22.04 / WSL2 x86_64，内核 `6.6.87.2-microsoft-standard-WSL2`。它是本地VM证据，不关闭独立原生Linux设备或跨设备复现前提，也不代表Windows完整P2996库性能。

工具链使用固定P2996 Clang 21提交 `9ffb96e3ce362289008e14ad2a79a249f58aa90a`、配套libc++/libc++abi及项目独立glibc2.39 loader/runtime；C/system headers如实来自宿主，并未声称使用完整私有sysroot。D/F共同参数为 `-O3 -DNDEBUG -std=c++26 -freflection -fexpansion-statements -stdlib=libc++ -pthread`，Boost/TypeLayout内容锁通过，两个variant使用相同harness与工作。compiler、wrapper、实际include内容、动态库和链接输入身份均在冻结profile/runtime内记录。

历史D/F来源是随交接带来的8份Stage I源码快照，未使用旧 `next_cpp26` HEAD代替D或F。新平台先独立验证 `max_align_t=16` 与allocator/root/vector布局，才固定新解析契约；完整源码和protocol保存在[冻结小包](perf/2026-10-16-vm-continuation/frozen-source-protocol.tar.gz)，各成员见[身份清单](perf/2026-10-16-vm-continuation/archive-members.json)。

## 执行范围与失败分类

| 阶段 | 实际数量 | 结果与计数边界 |
| --- | --- | --- |
| 首次功能 `functional-v1` | 1个D producer | native退出0、语义checksum正确，Python因沿用旧mac布局常量拒绝；不是性能样本，不能记为本轮功能通过 |
| ABI probe首次准备 `layout-probes-v2` | 1次编译失败，native 0 | 依赖模板调用缺少 `template`；保留原源码、合同、profile、driver与失败回执 |
| 独立小probe `layout-probes-v3` | D/F各1次，共2个native | 无计时、各最多65元素；ABI、bootstrap、11个容量stage和verified roundtrip均符合事前模型 |
| 新功能 `functional-v2` | 6个native | 3个case的D/F等工作量、完整wire与逐值核验通过，功能audit通过；功能时间不参与性能比较 |
| 唯一F/F正式校准 | 78个native | 6个预热、72个计量进程，全部使用同一个F二进制、成功退出且无超时；噪声资格未通过 |

上述N3阶段总计87个native进程；编译过程不混入此数。正式78个进程内已经包含6个预热，不能再把预热额外相加。四个指标与12个anchor cell是统计口径，不是native进程或测试数量。

首次功能错误已定位为平台布局：Core将每次分配对齐提升到 `alignof(std::max_align_t)`；新平台两处8 B padding使64 MiB save的used_end从旧67109072变为67109088。独立事前模型预测vector_tail的used_end4194560、wire4194648；D/F小probe验证后才移植解析器。原raw、旧模块、生产头及旧失败目录均保留；没有将raw投影成旧mac值或放宽为任意确定性长度。详见[根因与ABI契约](coordination/vm-continuation-20261016/N3-layout-analysis.md)及[独立审查](coordination/vm-continuation-20261016/N3-layout-review-v2.json)。

另有两项协调层事件：freeze初次使用相对路径，在输出创建和编译前拒绝；build-v2队列已经成功后，父层写日志时遇到既有路径碰撞。统筹检查了成功构建结果，没有重编译，仅为后续步骤换用新的v2日志前缀。两者均未额外启动benchmark native，不计作库、producer或原生平台失败，也不增加上表native数量。

## 唯一窗口与资格

正式队列于北京时间 **15:36:45.959–15:41:02.330**（UTC 07:36:45.959–07:41:02.330）持有一次完整timing lease，run_id为 `0c32c66ca26543c9a63626b7fb58d54f`；原queue记录耗时约256.36秒，结束无存活子进程。该队列边界包括准备和审计开销，不等于native timer之和。

78个native串行receipt从首个启动至最后结束的跨度为148.939926454秒；它与256.36秒队列总跨度是不同口径，也不等于各操作native timer之和。

事前[preregister](perf/2026-10-16-vm-continuation/calibration/preregister.json)与[外部pin](perf/2026-10-16-vm-continuation/calibration/preregister-pin.json) SHA-256为 `2e1330a763aedd81ed372f0df9df9dba8db375b5dadfae2b23584a2430bba52d`；[统筹批准](perf/2026-10-16-vm-continuation/coordination/N3-calibration-acceptance-v1.json)仅授权这一个校准窗口。每case为1个warmup pair及pre/mid/post各4对，按AB/BA平衡顺序；每child最多30秒，窗口最多900秒，新输出wire预算6 GiB，不因资格失败追加样本或重跑。

目标分辨量级为2%。局部中位数偏差、顺序分层偏差与log离散门槛按事前1%规则检查；pooled及A/B各自跨anchor的median max/min均须不超过1.01。以下漂移为 `(max/min−1)×100%`，是描述性资格检查，不是D/F收益或回退。

| case / metric | 局部anchor合格 | pooled漂移 | A侧漂移 | B侧漂移 | 整体资格 |
| --- | ---: | ---: | ---: | ---: | --- |
| save_first_64m / first_ms | 0/3 | 5.470% | 9.893% | 5.105% | 未通过 |
| save_repeated_64m / first_ms | 0/3 | 4.433% | 4.938% | 3.574% | 未通过 |
| save_repeated_64m / repeated_mean_ms | 0/3 | 2.024% | 1.025% | 2.181% | 未通过 |
| vector_tail_1m / elapsed_ms | 0/3 | 2.127% | 4.527% | 0.213% | 未通过 |

即使某一侧漂移较小，也不能替代该指标其他局部或跨anchor门槛。完整高精度字段、配对值和顺序分层结果保存在[原summary](perf/2026-10-16-vm-continuation/calibration/summary.json)。`performance_evidence=true`表示保存了实际校准数据，不表示噪声合格或采用资格。

## 环境观测及解释边界

正式窗口内各实施代理停止编译、重测试、重hash和归档，由主会话单一执行；这保证了本次代理协作的排他安排，不能据此认证整台硬件安静。宿主事前观测为Balanced电源计划，进程快照可见codemaker-hub-gui、TGitCache、WMI等后台活动；`project_compilers`列表为空。WSL一分钟load average在前后快照约0.529/0.996。它们是瞬时观测，本轮没有将任何进程、电源状态、VM调度、锁或registry认定为噪声或历史回退的原因。

WSL记录中的Darwin power/thermal探针明确不可用，不能冒充Linux或Windows温度/电源采样。主指标仍使用原harness的native timer；原始报文写入、逐值readback等范围按既有计时边界保留，不能把进程wall time、功能样本或小probe当作生产p99。

## 审计、封存及未关闭项

主会话针对原完整功能与校准运行执行维护的全量audit，均退出0；校准audit核对外部pin、raw/normalized映射、完整wire身份、串行receipt、预算与summary重算。审计通过确认取证和协议有效，不改变噪声失败判定。[完整校准audit输出](perf/2026-10-16-vm-continuation/audit/v2-calibrate-audit.log)与[功能audit输出](perf/2026-10-16-vm-continuation/audit/v2-functional-audit.log)已复制保存。

[独立统计审查](perf/2026-10-16-vm-continuation/coordination/N3-calibration-review.json)使用另写的Python统计实现，从全部78份raw重新计算四指标的配对、顺序分层、log离散与跨anchor漂移，逐值与原summary一致；同时核对preregister外部pin、单一F身份、串行receipt、queue清理与预算。审查者只读取每个wire的600 B头/前缀并核对stat；完整SHA/FNV明确引用主会话全量audit，未自称独立重hash全部wire。该审查没有启动新的native、编译或计时。原review为43460字节、SHA-256 `7055364cfef61601bf01062e065f124b4ce737e79032b24efa39fcdc7ecf0d3e`。

[小证据目录](perf/2026-10-16-vm-continuation/README.md)保留78组正式小记录、6组功能小记录、queue、环境、事前授权、失败来源和冻结源码/protocol小包；[run-reference](perf/2026-10-16-vm-continuation/run-reference.json)固定原输出及省略文件身份。本窗口新生成78份完整wire共 **3598738000字节**，没有复制进小证据包；包含嵌入的功能wire后，原校准bundle另记录84份wire共3875564000字节。二者是不同集合，不应相加冒充独立样本。compiler/runtime/SDK/依赖正文及benchmark二进制也仅本机引用，两个小ABI probe二进制是冻结小包的明确例外。因此本目录不能独立重做完整wire audit，不能称作完整离线复现环境。

最终[小证据manifest](perf/2026-10-16-vm-continuation/manifest.json)固定455个payload文件、4041196字节；含manifest自身共456文件、4112060字节。manifest为70864字节，SHA-256 `170b72a37b49e266f19636a744ba888b78c8a75d0db494300ab95940d5cbf621`。其中压缩源码/protocol小包1309294字节、39个成员；全部小文件身份、复制来源和压缩成员字节已核对，未读取大wire正文或改写原运行。

当前只完成新平台输入/ABI/功能适配和一次有限校准。没有新的D/F性能结论，也没有稳定归因、消融或采用；N3的原目标及独立原生Linux性能前提继续开放。未来如运行条件发生实质变化，应另立事前设计和有限预算，不复用这个失败资格窗口，也不通过反复重试取得想要的结论。
