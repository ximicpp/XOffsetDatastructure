# 竞品基准系统设计：共同语义、能力准入与完整流程

日期：2026-10-17。状态：设计，尚未实现适配器或取得竞品测量结果。

本文设计 XOffsetDatastructure、cista、FlatBuffers、Cap’n Proto、cereal 的独立实验系统。
本轮只增加本文，不修改生产头、V1 wire、依赖锁、alpha 源码包或已冻结证据；不编译、
不执行正式性能，也不把文中的接口与 gate 写成已实现或已通过。zpp_bits 不在首轮五库范围。

## 1. 要回答的问题及不回答的问题

首要问题是：在相同的值语义数据、操作和信任假设下，从已有快照完成读取、修改、
产生可独立保存的快照并重载，五种实现分别需要多少时间、空间和应用层工作？

先比较可观察的应用结果，再解释内部表示。支持更多功能本身不构成不公平；把不同
所有权、共享身份、验证工作或生命周期结束点放在同一列，才会使结果失去解释力。
本设计不生成跨场景总冠军，不承诺 ABI/跨语言/长期 schema 演进能力等价，不把文档
中的潜在优化解释为已经实测的因果。

共同主轨是值语义快照；共享图、原生指针身份、稳定地址、映射、schema 演进、压缩、
加密、网络、异步、并发、池复用均是独立能力或后续工作，不偷偷混入主轨。

## 2. 输入、版本和实验隔离

新实现位于 `experiments/serialization_comparison/`，具备独立 CMake project、schema、
adapter、oracle 和工具测试；驱动位于 `tools/serialization_comparison/`，根 CMake 不引用
实验 project。依赖放入该实验的新依赖目录，构建和结果使用新
`build/serialization-comparison/<profile>/<attempt>/`。不得复用旧 benchmark build、
替换根 `external/` 或把实验文件加入 alpha 发行闭包。路径是后续实施约定，本轮未创建。

统筹已只读核对的候选版本如下；**获取、内容锁、许可证闭包、代码生成及构建尚待 P1**。
版本号不代替 commit、源码文件身份或实际构建证据。

| 项目 | 主轨候选 | 需固定的源身份 |
| --- | --- | --- |
| XOffset | 已验 `0.1.0-alpha.1` source tar / F 双头 | 下述不可变 tar 身份及其 manifest，内含 11 include 树与 3 license 内容锁；不以当前工作树或 Git HEAD 替代 |
| cista | `v0.16` | commit `015b94e66c4c0d7c1ef29742383a024c84fbbba1` |
| FlatBuffers | 正式版本 `v25.12.19` | annotated tag `282dcb1c3266b45600510da4810092f6ec4c85f2`；peeled commit `7e163021e59cca4f8e1e35a7c828b5c6b7915953` |
| Cap’n Proto | `v1.5.0` | commit `373e61ec89e2359f1c362e9b2eadc552f4779306` |
| cereal | `v1.3.2` | annotated tag `962c43351b8b244cb9edb2bbb958d009bf4a1892`；peeled commit `ebef1e929807629befafbb2918ea1a08c7194554` |

XOffset 输入确切为
`build/release-v0.1.0-alpha.1-20261017/artifacts/source/xoffsetdatastructure-0.1.0-alpha.1.tar.gz`，
SHA-256 `5a8647736d1145676c503299d704bc37e2dd035d730ccc2ffca2e5e96a28c658`。
P1 在新目录只读审计并解压该 tar，再生成实验实际输入闭包，不把新增研究文档或当前
未提交工作树打进被测库。该源包与 header 的身份检查不能替代本实验 schema 的功能 gate。

cista 当前已读实现 `bde0f01af0ec8f764baae106bd0a46a80e9e7b92` 只能命名为独立
`cista-master-bde0` 补充 profile。其修改/扩容审计不能直接当作 v0.16 的运行证明；
若 release 暴露缺陷，保留失败，修订方案或另列 master，不静默换版本。
FlatBuffers 也不把选定正式版本笼统称为 GitHub 的最新标签。

主比较轨统一实际 P2996 Clang、libc++/ABI、C/C++ headers、linker、runtime、目标架构、
优化级别和 assertion 配置；反射选项仅对需要它的 XOffset 翻译单元开启并逐项记录，
不把此必要选项差异隐藏为完全相同命令。代码生成器、生成命令、生成文件 hash 一并固定。
所有库都需在此工具链通过 gate；编译不支持是该 profile 的缺口，不换编译器后留在同列。
各项目推荐生产工具链的结果可另开 `deployment-profile`，完整标记配置，不与共同工具链
数据合并，也不声称差异仅来自库实现。Sanitizer、分配跟踪和性能各用独立二进制。

## 3. Canonical 值模型 V1

模型先于 `.fbs`、`.capnp` 和 C++ 容器定义。下表是逻辑字段，不是共享 C++ ABI。

| 类型 | 字段及含义 |
| --- | --- |
| Snapshot | `schema_version:u32=1`、`epoch:u64`、按 id 升序的 `records:sequence<Record>` |
| Record | `id:u64`、`revision:u32`、`score:i64`、`name:text`、`samples:sequence<u32>`、`payload:bytes`、`attrs:dictionary<text,bytes>` |
| AttrEntry | 唯一 key 与 value；主轨用按 key 排序的 entry 序列表示字典，统一二分查找语义 |

约束：id 唯一且非零；text 是无内嵌 NUL 的合法 UTF-8，首轮只生成 ASCII；排序按
无符号 UTF-8 字节序，不用 locale。bytes 可含零；空序列和空字典合法。主轨不使用
optional/null、union、多态、原生引用、浮点、bitfield、重复 key、共享可变子对象。
缺失 id/key 返回显式 `not_found`，不能由某个 adapter 偷换成插入或默认值。
整数运算有明确取值范围；业务 score 更新在生成时证明不溢出，查询 accumulator
单独约定为无符号模 `2^64` 运算，不依赖有符号溢出。

物理表示可以有必要的容器元数据和 padding；标量宽度、字段数量和逻辑内容不得变化。
禁止某库把边或标量额外压成位域、预计算查询答案、删除冗余字段或用共享 intern 表
改变主轨语义。字典主轨不比较不同 hash/table 策略：五库均使用 sorted entries。
`native-dictionary` 后续能力轨才允许 XMap/cista hash/STL map/库原生索引等方案，
必须登记构建索引、维护排序、查找和输出时规范化的费用，不混回主轨结论。

首批逻辑规模按记录数固定，不按每个库的 wire 字节重新填充：

| dataset | Record 数 N | 初始每 Record 内容 |
| --- | ---: | --- |
| V1-S | 128 | name 8–64 B；samples 32 项；payload 128 B；attrs 4 项 |
| V1-M | 16384 | 同上 |
| V1-L | 131072 | 同上 |

id 初始为 `1..N`；attrs 初始 key 为 `k0000..k0003`（各 5 B），value 各 16 B。
另设功能 fixture `N=0/1/17/257`、字段空值、短/长字符串边界和接近长度上限的数据，
不拿这些小 fixture 做性能外推。S/M/L 是输入定义，不是本轮运行授权；功能产物大小
确认后才能登记正式进程/输出预算，超预算须修订协议，不能按库偷偷缩小输入。

生成器不使用实现相关的 STL random distribution。确定性字节流使用 SHA-256 counter
expansion：domain、seed、record id、field、counter 均采用固定字段顺序及长度前缀；
seed UTF-8 为 `xoffset-competitor-v1`，counter 从 0 开始、u64 little-endian。
各字段生成规则、范围映射和截断在 fixture spec 中逐字固定，发布至少三个 golden
输入/trace/hash 测试向量。排列 P 将 `1..N` 按独立 domain hash 排序，平手按 id。
这只是可复现输入，不声称密码学随机负载或真实业务分布。

## 4. 确定性查询和修改 trace

输入 fixture 和 trace 在实验前由独立 reference model 生成、求值并封存。
运行时 adapter 只读取已展开操作和新值；随机生成、JSON 解析、预期结果计算不计入
库操作，但不允许预建待测库的图、索引、builder 或最终 wire 后藏在 setup 中。
每条操作带顺序号、目标 id、参数、预期成功/缺失状态；trace 绑定输入 hash 和模型版本。

`query-v1` 固定包含：按 id 的命中/缺失查询、attrs 命中/缺失查询、按顺序扫描记录，
求 score、samples、name/payload 长度及选定字节的结果。具体 id、字段、顺序和次数写入
query trace；所有库返回相同有序结果序列，不用容器迭代的偶然顺序充当输出。
共同 query sink 写入预分配结果区；这笔相同的写出工作计入 query。禁止只对某库
多做一次全图转换。完整 canonical 导出用于功能 gate，查询不能代替全字段正确性验证。

`mixed-growth-v1` 采用下列固定阶段；目标均由 P 的不相交区间选择，生成器在每一步
reference state 上检查前提。S/M/L 的 N 均可被 8 整除。

| 顺序 | 操作 | 数量与效果 |
| --- | --- | --- |
| 1 | update_score | N/4 条；修改 score、revision，值在 i64/u32 范围内 |
| 2 | replace_name | N/4 条；新 name 为 128 B，包含短变长与长变更长 |
| 3 | append_samples | N/4 条；每条追加 32 个已固定 u32，初始 32 变 64 |
| 4 | replace_payload | N/4 条；128 B 变 384 B |
| 5 | replace_attr | N/4 条；已有 `k0001` 的 value 改成 32 B |
| 6 | insert_attr | N/4 条；新增 `k0004`、32 B value，维护 sorted-entry 语义 |
| 7 | erase_record | 删除 P 最后 N/8 个 id，保留剩余记录的 id 顺序 |
| 8 | append_record | 增加 N/8 条，新 id 为 `N+1..N+N/8`，内容由独立 domain 生成 |
| 9 | set_epoch | 1 次，将 epoch 增加 1 |

阶段 1/2/3/4 使用 P 的前四个 N/4 区间；5/6 复用第一个区间；7 的删除发生在其
先前变更之后，reference oracle 对被删除记录的操作也逐步核对。8 不是重用删除 id。
trace 包含预期每阶段 digest 和最终查询结果。长度变化制造实际容量压力，但不强求
每个实现恰好同次数分配/搬迁；容量策略本就是待测行为，应单独观测而非篡改工作量。

主轨允许按已知初始数量预留初始容器容量；不得提前按未来 trace 的最终大小预留。
reuse/pool/预留最终容量属于独立 profile。XOffset 首个动态增长方案建议显式
`Automatic`、初始 arena 4096 B、硬上限由 case manifest 固定，必须标为 opt-in 策略，
不冒充默认 Explicit。若改用 Explicit，业务增长协议必须预先固定且 grow 时间计入。
最终这些选项由功能 gate 和资源预算冻结，不借测量结果调参。

## 5. Canonical 编码、统一输出与独立 oracle

定义 `canonical-v1` 编码，只作模型交换、功能判定和 digest，不要求各库 wire 相同：

- 固定 magic/模型版本；整数按字段宽度 little-endian；i64 用其数学值对应的 64-bit
  二补码编码。text/bytes 先写 u64 字节长度，sequence 先写 u64 项数。
- Snapshot 按上述字段顺序；records 按 id；Record 按表中字段顺序；attrs 按字节 key
  顺序。不存在 native padding、地址、capacity、allocator header 或隐含 null terminator。
- full-state digest 为 SHA-256(canonical-v1 全部字节)。query digest 则绑定 query 版本、
  操作序号、状态和值的规范有序结果。wire SHA-256 独立记录，不能替代语义 digest。

Python reference model 与 C++ oracle 分开实现 canonical encoder；小型 golden 字节
向量先相互核对。adapter 通过只读 visitor 导出所有字段，由共同 encoder 规范化；
不能让各 adapter 自己声明“checksum 正确”。正式 query 也必须消费结果，防止优化
删除工作；SHA-256 的汇总时间是否计入由 phase 合同固定，不能对不同库择优处理。

功能 gate 每一步比较状态码、完整 state digest、查询输出、计数与长度；对小 fixture
还逐值差异定位，避免仅靠 digest 无法诊断。保存后须在新进程从最终 wire 独立重载，
丢弃旧对象、原 builder、原 blob、旧进程地址与应用缓存，再核对完整 digest。

## 6. Adapter 的状态和操作合同

概念接口如下，仅是设计边界；实现不必采用虚函数，避免计时中 type-erasure 分派成为
单一库的额外成本。每库独立可执行文件，使用同一 orchestration/protocol/oracle 代码。

```text
describe() -> capabilities + library/source/schema/build identities
build(CanonicalInput, CapacityPolicy) -> NativeState
emit(NativeState, WirePolicy) -> OwningWire
load(InputLease, LoadContract, TrustPolicy, Limits) -> LoadedState
query(LoadedState, QueryTrace, ResultSink) -> statuses
mutate(LoadedState, MutationTrace) -> statuses
visit_canonical(LoadedState, CanonicalSink) -> full-state evidence
release(State/Lease) -> cleanup evidence
```

`InputLease` 明确 bytes 起止、对齐、可写性、所有者及有效期；不能只返回裸 root。
`LoadedState` 拥有 reader/builder/arena、原 blob lease、后来分配的 heap 等所有必要状态，
并声明其清理方式。`OwningWire` 必须是可独立移交的完整字节序列，不能是悬空 builder
view；多 segment flatten、move/adopt、必要复制全部按真实实现记录。初始 artifact
和最终 artifact 分开保留身份，raw reader 改写过的进程指针不能当作原始持久化字节。

接口实现可以使用库原生能力和官方 object API，不允许以同一通用 DTO 实现全部操作
后只在最后调用 codec、却把它报告为该库的原生加载/修改。若采用 DTO/object API，
转换属于该 profile 的实现，计入相应阶段、报告临时峰值空间和实际容器类型。

## 7. 借用、接管和独立所有权分轨

| load contract | 完成条件 | 生命周期测试 |
| --- | --- | --- |
| borrowed-read | 调用方维持输入 lease；状态可依赖原 wire，仅提供读取 | lease 存活时查询正确；结束时先释放 reader 后释放 lease |
| adopt | 调用方将 wire owner 移入 LoadedState，状态负责其生命周期 | 原调用方 owner 为空；随后状态可查询，内部仍可借用已接管字节 |
| detached | 输入 lease 不转移；完成时状态不再依赖调用方的那块输入 | 功能测试覆盖/释放原输入后仍可查询、变更、输出新快照 |

不得把 borrowed/adopt 标成 detached。若 raw cista 要求改写输入指针，而合同提供只读
wire，其私有可写副本必须在 load 阶段建立并计时；不在 setup 中赠送复制。cista 的
容器变更可能新建 heap，清理须覆盖这些后来分配的对象；不能因根在 blob 中就跳过。
XOffset 的 owning load 复制到新 reservation，并无借用 mmap 入口；不支持的 contract
登记 `unsupported`，不能用名字相同但条件不同的函数充数。

FlatBuffers 的 object API 可用于 detached/mutable profile，其 unpack、普通容器、pack
及输出分配均计入；固定大小原位修改是另一能力轨。Cap’n Proto reader、message
builder、segment 所有者及 clone/rebuild 行为必须明确。cereal materialized 对象的
输入 stream、解码分配和析构也按同一完成条件统计。各方案均由实际版本 gate 确认。

## 8. 信任与验证策略

`T-trusted`：fixture 来自已封存且由外部身份检查确认的本次 producer；可采用已登记
的最小安全读入口，库强制保留的检查仍保留。`U-untrusted`：输入可恶意截断、篡改或
构造资源炸弹；在发布可供业务读取的状态前，必须满足明确的结构、业务和资源合同。
二者分表，不用 FAST 与 SAFE 文字推断安全等价。

U 合同包含：总 wire 限制、schema/version、所有可达字段的界限/长度/深度、唯一 id/key、
排序、引用有效性、文本规则、整数范围、聚合元素/分配预算。必须拒绝非法数据；普通
业务查询仅碰到部分字段，不足以完成全状态检查。外部 SHA 不是发送者认证；认证协议
不在首轮。本实验 envelope 只记录身份和长度，不虚称能约束恶意内部长度。

| 实现 | U 策略设计要求，尚待版本 gate |
| --- | --- |
| XOffset | `load_verified<T>`、明确 maximum 与 wire budget，再做共同业务约束；不得把当前零值 CRC 字段当作 checksum；`save_verified` 不等于完整恶意输入验证 |
| cista | 明确 `DEEP_CHECK`、version/integrity 是否启用及其语义；对所有业务字段再做 bounded scan；默认 mode 或 unchecked 不能直接称 U 合格 |
| FlatBuffers | 生成 verifier，固定 depth/table limits，再做共同业务 scan；普通 Get/accessor 不替代 verifier |
| Cap’n Proto | reader 的 traversal/nesting limits 及异常路径固定，完整 bounded 访问所有业务字段；lazy 检查成本不能留到“已验证完成”之后不计 |
| cereal | 先证明恶意长度在分配前受限；默认 binary archive 的成功 roundtrip 不是该证明。必要 bounded load adapter 必须单列应用层代码与费用；未证明则 U 不准入 |

cista [官方 Security 说明](https://github.com/felixguendling/cista/wiki/Security)另有重要
限制：读取不可信反序列化数据和随后修改该数据，不具有相同安全保证。`DEEP_CHECK`
加一次 bounded 业务 scan 不能自动证明 `verified → mutation → access/save` 安全。
U-read 与 U-mutable 必须分别 gate；所选版本/模型需要独立安全论证及负例测试，或采用
已验证数据复制重建到可信对象的明确转换合同并计入成本；做不到则 U-mutable 为
`unsupported/not-established`。不得只复用通过的 U-read 标记。本限制不改变来源已知
可信的 T 主轨，亦不把 master 或官方文字当作 release 的运行证明。

U 不要求错误编码逐字一致，但要求分类一致、确定失败、不暴露部分成功状态、不越界、
不遗留子进程/文件/拥有资源。若某库只有进程资源上限兜底，不能把 OOM kill 当作
“优雅拒绝通过”；这是隔离成功、库/adapter gate 失败。库未提供的安全条件不偷加成
免费前置工作，也不为追求五库齐表降低 U 要求。拒绝性能另轨，不能与合法输入吞吐混合。

## 9. Phase 边界与首个完整应用 cell

每个 child 运行一个 adapter/case/profile，独立新 state；禁止跨库同进程共用 allocator
或未声明的跨样本 builder。input bytes、trace 与 expected 读取属于 harness setup。
计时使用相同单调时钟；输出每个 phase 的 ns、进程 CPU 与 child wall，不能相互替代。

| phase | 起点 → 完成点 | 应计入的工作 |
| --- | --- | --- |
| build | 空 native state → 原生表示可供 emit | 容器/arena/builder、copy、排序/索引及业务表示构建 |
| emit | 已有状态 → 独立 owning wire | normalization、archive encoding、pointer fixup、flatten、必需复制；不额外赠送已构造 graph |
| load | 合同规定的 input lease → 满足读取/所有权/信任合同；首轨随后释放原 input_owner | copy/adopt、reader/object 构造、解码、必要验证和 limit 检查；首轨 input_owner 的释放计入 load |
| query-before | load 后状态 → 固定查询结果区 | 同一个 query trace 与共同 sink |
| mutate | 初始已加载状态 → 全部 mutation trace 成功 | unpack/clone 若直到此时才发生、索引维护、grow、heap/arena 分配及数据迁移 |
| emit-after | 修改后状态 → 移交 harness 的独立 final owning wire | 包含保存所需的所有转换，不以输入 blob 仍可访问冒充持久化 |
| cleanup-before-reload / retire_modified_state | final wire 独立完成 → 旧 modified state 及其全部 blob/heap/builder 释放 | 在 reload 前显式销毁旧状态及其所有拥有资源，计入总耗时 |
| reload_detached | harness 的只读 final wire span → 不依赖该 span 的新状态 | 不转移 final wire owner，不复用旧对象；实际 copy/parse/validation |
| query-after | 新状态 → 固定最终查询结果区 | 同等工作量的结果消费 |
| cleanup-reloaded-state | 最后查询结束 → 重载 state 与其全部工作 owner 释放 | 含 heap、arena、reader、builder 与内部 blob；harness 保留的 final wire 最终析构不计入 |

首个 campaign 候选仅 `V1-M-mixed-growth-trusted-detached`，不展开完整笛卡尔积。
其主 endpoint 为当前进程连续执行 `load_detached（含释放 input_owner）→ query-before →
mutate → emit-after → retire_modified_state → reload_detached → query-after →
cleanup-reloaded-state` 的总耗时；各 phase 是诊断指标，不能挑最快 phase
替代主 endpoint。主 endpoint 不含初始 fixture 的 build/emit，它们在独立功能与描述性
phase 中保留；若业务从原始记录生成第一份快照，须另立包含 build/emit 的 cell。

首轨的生命周期时点对五库完全一致：首次 adapter load 返回后、query-before 前，
harness 立即释放原 `input_owner`，该释放在 load phase 与 total 内；此后 LoadedState
不得依赖原输入。emit-after 产生独立 `final_wire` 并由 harness 持有后，必须先调用
`retire_modified_state` 释放旧 mutated state 及其所有 blob/heap/builder，再开始 reload。
reload 仅接收 `final_wire` 的只读 span，按 detached 合同加载，不转移它的 owner。
query-after 完成后计时释放全部 reloaded state。最终 owning wire 已作为结果移交
harness，其最终析构不必计入主 endpoint；不能仅为某库延后旧状态清理或提前释放
final wire，从而把不同资源生命周期误报为库的 RSS 差异。

正式 timer 内不做 reference 求值、日志格式化、磁盘写出和额外全字段 oracle 导出。
query 结果在 timer 后统一求 digest；最终 wire 在 timer 后做同一份有界完整重载/
canonical audit；其待验证数据只能来自 harness 保留的 `final_wire`，不能依赖已释放
的 input_owner、modified state 或 reloaded state。结果失败使该次无效并触发停止，
不能只检查返回码。此 `post_audit`
单列耗时和资源，不加入主 endpoint；它仍计入 child wall/执行上限。主 endpoint 末
先读取一次进程 high-water，再做 post_audit；该值是截至主 endpoint 完成的进程峰值，
仍包含 setup，不能称为纯 phase 峰值。另记整个 child（含 post_audit）的峰值，不将
两者相减当作 audit 的精确内存成本。

新进程独立重载是功能准入及保存语义 gate，在正式 campaign 前验证；不把进程启动
塞进主 phase，也不把同进程 reload 冒充重启证明。若以后每个结果必须独立进程重载，
新增进程数量、时间、输出须提前计入预算，不能暗中扩大当前注册窗口。

I/O 独立 cell 明确读写与 durability 等级：内存 owning bytes、写入 OS page cache、
flush/fsync 后完成、重新打开读取是不同 endpoint。首轮内存主轨不使用“保存到磁盘”
措辞，也不从 write 返回推导断电持久性。只读 mmap 能力不能算作 XOffset load 的同名替代。

## 10. 共享图与额外能力轨

`G-id`：全局 node/edge 表，每个实体唯一稳定 id，邻接表只存 edge id。修改某条边后，
所有入/出引用必须看见同一逻辑值。循环由 id 表表示；共同 resolver/index 的构建和
访问成本计入。五库可各自尝试，但先验证复杂度、重复/悬空 id 与共享修改语义。

`G-native`：要求库原生对象别名/循环引用和加载后别名修改传播。必须证明共享对象
只存在一份、循环终止、重载保持身份；裸地址不进入 canonical digest。不能把 id
emulation、值副本、反序列化后应用自行重建指针表静默计为原生支持。XOffset 当前
admitted wire 不接纳普通原生指针；不凭 offset 容器名字承诺任意共享指针图。cista、
cereal 的相关能力也必须在所选版本实测 gate，不凭第三方 benchmark 宣称通过。

`A-stability`、`A-inplace-fixed`、`A-file-growth`、`A-schema-evolution` 各有单独合同。
例如 arena base 稳定不等于 vector 元素地址稳定，字段原位写入不等于可原位扩容，
可修改 heap 对象不等于原 blob 已持久化。未准入显示 `unsupported/not-established`，
不填零毫秒，不进入共同收益比。首轮只完成这些能力的功能分类，不正式测量所有能力。

## 11. 功能 gate、错误矩阵与结果状态

Gate 顺序：输入/golden oracle → schema/admission → build/emit → 三类 load contract →
query/逐步 mutation → 完整 digest → 保存与新进程重载 → cleanup/限额 → malformed。
实现至少覆盖空数据、缺失 id/key、重复 id/key、非法 UTF-8/内嵌 NUL、截断、长度溢出、
超深/超多元素、错误 schema、越界引用（G 轨）和失败后的释放。长度上限与协议字段
由统一 Limits 给出，并翻译成每库可执行的 guard；unsupported 的 guard 不能被遗漏。

合法 trace 在执行前保证业务前提；非法 trace 要在应用层预检查后拒绝，不要求所有库
天然提供多操作事务。资源失败则丢弃本次修改状态、保留初始 owning wire，并检验清理；
不擅自承诺每个 API 的容量/allocator bookkeeping 强回滚。需要事务语义应另设能力 gate。
sanitizer 用小 fixture 和独立构建，不能与 release timing 结果混为同一 profile。

状态使用 `planned / unsupported / blocked / gate-failed / functional-passed /
measurement-qualified / measured / rejected`；每个状态附 case/profile、理由和证据。
只有相同 cell 的功能门槛与测量资格都通过，才允许生成横向估计。构建失败和功能失败
不算性能输家；超时/崩溃/缺失输出不删样本补跑，不用剩余成功样本生成胜负结论。

## 12. 资源、计时证据和报告字段

每次记录 canonical logical bytes、对象/元素数、输入/最终 wire bytes、峰值 live owned
bytes（若可靠可观测）、进程 peak RSS、current RSS、CPU、page faults、child wall、
文件字节与清理结果。RSS 同时报绝对值与启动基线，不能用相减的 high-water 当精确
增量峰值。虚拟地址 reservation、可访问页、已提交页、RSS 是不同字段；XOffset
`reserved_bytes/accessible_bytes` 是库特定诊断，不能拿它们直接对比其他库 RSS。

分配次数/字节采用独立 instrumentation profile，明确覆盖范围：malloc/new、aligned
allocation、VM mapping、库内部 allocator。不能只拦截 new 就声称所有分配；不得把
instrumented timing 填回正式 release 列。缓存/页冷热、CPU affinity、功耗/频率及 VM
类别要固定并如实记录，不用未经测量的背景进程解释某库输赢。

每条 JSON 结果至少绑定：protocol/case/profile、library commit、完整 source manifest、
schema/generated code、compiler/link/runtime、输入/trace/oracle hash、trust/load/wire
策略、capacity/pool/cache policy、phase ns、query/full-state/wire digest、resource、
退出码/stderr、gate 状态、run id/串行 receipt、预算与清理。大 wire 正文与小审计元数据
分开存储，保留未复制文件的 size/hash/reference；省略正文时不能称完整离线复验包。

JSON 使用 UTF-8、显式 schema version、固定字段类型；读取器拒绝重复 key、未知必需
版本、类型漂移、截断/多余文档、NaN、Infinity/-Infinity，所有派生浮点数均须有限。
SHA/digest 用固定长度小写 hex。u64/i64 业务值、大计数、绝对 ns 时间戳及结果中的
`*_ns` 采用规范十进制字符串（零只写 `0`，无多余前导零/正号；i64 允许负号），
避免 JSON 下游经 double 丢失整数精度。小型枚举/schema version 等可用严格受限
JSON integer，不接受 bool 冒充 integer。原始 timer 可为 native/Python 整数，导出到
结果字段时显式规范化；raw、normalized、audit 和报表对同一字段遵守同一整数合同，
不能只在一层转成 float 再转回。拒绝输入时不用 Python `assert` 作为唯一检查。

报告先列 cell 和功能准入矩阵，再列主 endpoint、wire 大小和资源，phase 作为解释。
原始值、预先登记的统计、所有失败和顺序/漂移检查都保留；不以最小值、单次运行、
表格四舍五入的 0 或“fast”名称推导普遍倍率。没有 profiling 时只给可验证机制，
不量化 map、cache、检查器、allocator 分别贡献多少。

## 13. 执行资格与交付检查表

现有 WSL2 N3 唯一 F/F 校准的 12 个局部 anchor、4 个漂移资格全部失败，详见
[当前结果](VM_N3_CURRENT_RESULTS.md)。该结果不能借用为竞品测量资格；当前环境也不能
因换一层 Docker 就宣称改进。后续需记录实质环境变化，或为独立新 workload 预注册
明确工程分辨目标、有限 A/A 校准、顺序/漂移与停止规则。功能通过不自动授权正式测量。

首轮按统筹实施计划仅选择一个 M cell；S/L、只读、U、图与能力轨先做功能验证。
样本数、资格阈值、complete block 顺序、单一 lease、进程/时间/输出上限和禁止补跑
写入单独冻结 protocol，而不是散落在 adapter。新 5% 工程目标不能声称解决历史 N3
2% 检出问题。编译、sanitizer、归档、重 hash 与正式计时窗口不并行。

正式 driver 复用已有 `experiments/vm_coordination/run_job.py` 的全局 WSL timing
lease，而不是新建工作目录私有 lease。`queue.lock` 路径与 inode 要稳定，不删除/替换
锁文件，不因跨 workdir、容器或新实验路径绕过排他。先只读核对 runner 的实际配置和
占用状态，旧完成队列不恢复执行。当前 runner 依赖 POSIX `fcntl`、session/process
group 所有权，首轨按 WSL 原生 child 设计。Docker daemon child 不能假装是普通可回收
进程组：若改选 Docker，P1 必须另证容器身份、全局 lease、超时 kill/清理/退出码和资源
归属适配；前提未通过明确 unsupported，不在正式窗口才降级或发现孤儿容器。

与[实施计划](COMPETITOR_BENCHMARK_PLAN.md)对齐的顺序是：10 个 A/A 预热 child、
5 个比较预热 child，随后 pre anchor、15 个五库完整比较 block、mid anchor、
15 个完整 block、post anchor。三个 anchor 每库各 4 个 A/A pair，共 120 个 child；
比较 150 个，总上限 285 个。anchor 分布在比较前/中/后，不能预先一次跑完再比较。
pre 未通过则停止；mid/post 未通过则已有比较数据保留为未合格证据。45 分钟、
20 秒/child、16 GiB 新 wire 等上限与具体统计规则以 P6 冻结协议为准；当前尚未授权
执行，不因设计计数闭合就自动开始。

进入测量前必须能回答：

1. 五库的相同 cell 是否全部通过功能 gate，库-specific 转换/验证是否计入？
2. 所有模型、trace、oracle、代码生成和依赖身份是否冻结；wire 是否独立可重载？
3. 主 endpoint、post_audit、fresh-process gate、child wall 和资源范围是否无歧义？
4. 首轮输出实际大小是否满足整批预算；未满足时是否先修订协议而非运行中改变 N？
5. 测量环境是否取得本次目标资格；失败是否保留并停止而非反复试到通过？

本设计仍需实施期解决的具体点：五个候选在共同工具链的构建/功能兼容；cista release
与已审 master 的差异；cereal U 的分配前 guard；每库 detached/mutable 的实际官方
API 路径；XOffset 初始/最大容量和增长配置；代码生成与内容锁；canonical golden
字节向量、具体 query trace；统一资源计数器的可观测范围。它们是进入对应 gate 的
工作项，不是可以忽略的前提，也不应在本轮设计完成时被标成已通过。

## 14. 已核查依据与历史 benchmark 的使用边界

- 当前 XOffset [alpha 合同](ALPHA_COMPATIBILITY.md)明确 admitted 类型、owning copy、
  validated load、地址稳定边界、非事务与非零复制入口。本设计不扩大这些承诺。
- cista [固定 master vector 实现](https://github.com/felixguendling/cista/blob/bde0f01af0ec8f764baae106bd0a46a80e9e7b92/include/cista/containers/vector.h#L366-L403)
  显示增长可转 heap；这是所读版本机制依据，release 仍须重新 gate。
- FlatBuffers [官方 C++ 文档](https://flatbuffers.dev/languages/cpp/)区分直接访问、
  object API、验证与修改；schema/codegen 命令和选择的 API 必须进入 profile。
- Cap’n Proto [官方 C++ 文档](https://capnproto.org/cxx.html)与
  [encoding](https://capnproto.org/encoding.html)用于定义 reader/builder/segment 及访问
  限额；不把创建 root reader 当全量业务验证。
- cereal [官方 archives 文档](https://uscilab.github.io/cereal/serialization_archives.html)
  用于选择 archive 和表示；archive 名称不代替本实验的恶意长度分配前 guard。
- 作者历史 [benchmark 固定版本](https://github.com/felixguendling/cpp-serialization-benchmark/tree/f8216ebe69de31a41d390e9b1d7618a4ed641faf)
  已发现 slim 位域/值副本与完整共享图不同、FAST/SAFE 表格混列、不同 adapter 的
  临时结构和检查范围、FBS builder 未 reset。该研究只用于避免重复方法问题，不
  复制旧排名，不把源码机制推断当 profiling 结论，不把历史硬件结果当当前 F 的数据。
