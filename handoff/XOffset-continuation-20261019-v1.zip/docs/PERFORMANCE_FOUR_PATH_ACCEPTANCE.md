# 四路径本轮验收：功能通过，正式性能比较未获准

2026-10-19，本机 WSL2、固定 P2996 工具链。A/B/D/E 的实现和功能验收通过；C 完整可变接收未完成。唯一 Q32 完整运行并通过离线审计，但 30 项阶段 A/A 中仅 29 项建立等价，故按预定规则未启动 F64。**本轮没有建立“明显超过全部竞品”的证据，也没有得出新候选输给竞品的正式结论。**

## 交付与完整性

可直接打开的独立候选源码位于 `build/four-path-implementation-20261018/delivery-v1/source/xoffsetdatastructure-0.1.0-alpha.1/`；同级 `archive/` 有完整源码包、精确 manifest 和 SHA256SUMS。保留继承的 alpha.1 版本字符串，这是新的本地开发候选，没有正式发布。

主头264,452字节，SHA256 `b0608024fc8d7902cd775d2c7e9815be0a1413e8a7515654bc4d2dfcc3b692f1`。九个生产头/运行时源文件的内容集 SHA256 为 `a55d2148d0d7e6c16f5b4eaa16ad75765e0ae02e0348c3afe0a8206e8da97f46`。最终源与 Windows 可见副本逐文件一致，源码包全新解压后构建了两个可选 runtime，并实际通过66项功能测试。不是用当前工作区旧HEAD冒充最终源。

| 门禁 | 结果 |
|---|---|
| 完整 normal / ASan+UBSan | 各66项通过；configure检查各3项另列 |
| 原适配器/资源合同 | normal/SAN各2项通过 |
| 业务原语义流程 | normal/SAN各80子进程、15单元；完整9修改阶段及独立真值/重载检查，维护的完整产物审计通过 |
| V1 | 历史六control72、直接V8另12、特殊schema8通过；A/B另2方向4个CLI动作通过 |
| 默认消费 | installed3、subproject3、851个固定依赖头、4种版本请求拒绝通过 |
| 显式共享runtime消费 | 重定位installed6、subproject6通过；原producer source/prefix隐藏；包含跨TU/隐藏DSO共享预算检查 |
| 固定旧M输入专项 | normal/SAN六角色各inspect/validate/run/inspect，48子进程通过；正式初始字节身份不依赖重新编码 |
| 生产生命周期矩阵 | normal/SAN各12配置、各72次发布/80次本地完成模型通过；C共24格blocked |
| 历史证据 | V8 12,385、继承V7 6,270、继承V6 13,021条元数据未变；原根文件及最终九文件身份通过；未重放历史大body全文 |

以上 full 结果是 WSL2 结果，不声明 Windows 原生完整 P2996 已通过。Windows storage 历史结果与这次完整库结果分列。

## 实现范围与核心筛选

A `save_verified_into` 复用容量并保持完整独立 V1 输出，reserve 回调后重新解析源 owner。B `freeze_verified` 在完整校验与资源准备后提交不可变拥有快照，提供稳定两段和真实完成 lease；取消不等于完成。D 提供 decision-first `stable_erase_if` 与不可变快照 ownership 阴性证据索引；未知仍走原递归，索引不是业务 ID lookup。E 是显式、独占的原始 scratch lease；每次完整重验，不缓存输入结论，不默认改变旧加载接口。

默认核心继续保留已验收 V8 Word-only。布局候选唯一72对的emit比值0.998948、上界1.049759；CheckedRange唯一72对的reload比值0.993209、上界1.016868，均未证明自改善。两者各144子进程、无补样。合并owned/free控制区因配额/OOM回退缺口计时前否决；透明mutable locator的局部descriptor/epoch捷径存在拥有关系反例，保留原predicate。不能把功能门禁通过等同于这些核心优化已提速。

## Q32与正式目标

固定4656实际子进程=2328 primary+2328同角色conditioner；primary中的24次预定warmup保留但不用于推断，余2304行按32个完整平衡macrocycle分析。CPU2为客体affinity，不宣称独占物理核或锁频。墙钟2137.892秒，小于2700秒；清理为空；电源真实恢复；原始产物、实际哈希、精确字节去重、预算与全部回执的完整离线审计通过。

30项A/A只有 `cereal / mutate` 未建立等价。它比较的是**同一cereal二进制的chronological first/second**，点估计1.005199，联合族区间[0.954965,1.058075]；允许范围[0.952381,1.05]。上界超出1.05意味着本次精度不足以证明要求的等价，不能据此断言真实退化或系统性漂移。全部32个单位和预定样本都保留，没有删除离群值、增加样本或放宽界值。此前总量AA与本轮30个阶段AA定义不同，不能简单用失败个数作直接改善比较。

| 原定F64主目标（候选/各竞品上界） | cista | FlatBuffers | Cap’n Proto | cereal |
|---|---|---|---|---|
| read_sum≤1.05 | 未正式验证 | 未正式验证 | 未正式验证 | 未正式验证 |
| mutate≤1.05 | 未正式验证 | 未正式验证 | 未正式验证 | 未正式验证 |
| 旧demo独立拥有输出emit≤0.20 | 未正式验证 | 未正式验证 | 未正式验证 | 未正式验证 |

F64实际子进程为0，未计算跨库对比或新排名。“29/30”不是“12个竞品目标通过29项”，不能拿Q或新API生命周期数据代替F。后续若继续测量，需要新的事前协议/资格与预算；本轮不自动重试。

## 生产效果与C开放项

16K记录的普通repeat16模型中，A空输出均值约1.384799ms，hot含准备约1.400720ms，B完整freeze约2.695511ms。它们串行同源、有global-new计量及独立oracle，不能解释为独立加速对照；完整CPU约45.1357ms/次，其中oracle约11.8538ms。shared3仍有3×wire的网络模型字节；512MiB是VM预留，freeze没有decommit；显式资源释放不等于整个进程retained为0（记录净余40B）。详见[生产结果](PERFORMANCE_PRODUCTION_PATHS_RESULTS.md)。

C的准确状态是whole-array fresh/reuse/extent及内部alias生命周期证明尚未闭合。已有文档只承诺arena/root稳定，并不承诺容器修改后所有旧外部元素引用永久有效；早期把它当作既有保证进而声称C不可能实现，表述过强。物理同址tail增长、scalar无额外申请/退休及内部自别名读取顺序仍须保留。后续可研究完整extent创建/重建与前缀owning-head激活，尚未解决；当前没有用immutable或copy-load替代它。见[契约澄清](coordination/performance-four-paths-20261018/receive-contract-independent-review-v1.md)。

没有提交、推送、合并、正式发布或触发远端CI；未使用Superpowers。历史失败与本轮所有原始证据保留。
