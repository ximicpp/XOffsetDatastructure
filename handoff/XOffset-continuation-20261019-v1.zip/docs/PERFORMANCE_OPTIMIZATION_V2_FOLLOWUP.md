# v2 诊断后的后续优化设计

2026-10-17，P4 固定诊断完成后新增。本文补充 [原实施路线图](PERFORMANCE_OPTIMIZATION_ROADMAP_V2.md) 的条件后续 P6/P7，不改动已通过门禁的 v2 源码、预算、协议或原始计划快照，不把以下设计标为已经实现。

当前候选主头为 `e0f905694031c88618b8e2b453f6ac2400872e36a9caf82233c1d9e1dfabaf7a`。三组 CPU-clock 诊断各执行固定 16 次，初载/重载/修改实际样本数为 678/647/270，均无丢失；每次均验证 canonical 与 query。采样包含 FIFO 启停边界、反复运行及 cache/allocator 状态，不能与旧版本样本数相除当作加速，也不能把叶函数占比当作纯机制因果。

初载叶样本 `register_owned_range` 为 77.88%，重载为 61.21%；内部含字段/区间检查、树查询、hint 插入及内联分配等多种操作，尚不能精分每一项。修改的 allocator 叶样本为 9.26%，一项嵌套 ownership 保护为 9.26%，owner registry 查询为 2.96%；270 个样本不足以精排细小差异。当前证据仍支持继续优先研究验证区间登记，而非直接把 registry mutex 当作下一主因。

机制计数证明 v2 将九阶段 arena 申请从 86,016 降为 53,248，owner lookup 从 172,032 降为 106,496；它们不是 host malloc 或 CPU 指令。P1/P12 上游 chunks 各为 11，申请 16,769,376 字节，退出 live 为 0；节点总数仍为 196,612/212,996。最终 wire 仍是 17,830,872 字节，重载 key 比较由 8,394,648 变为 8,788,248，须保留这个实际代价，不宣称体积或每项工作都下降。

| 次序 | 待实施工作包 | 设计与边界 | 首要验收 |
| --- | --- | --- | --- |
| P6a | 区间索引有序边界快路径 | 在原 interval helper 内，对空树及严格位于最大 end 之后的区间，用 end hint；必要时研究小于最小 begin 的前插。仍先做原指针/长度/溢出检查，仍做另一棵树 overlap 检查；边界不满足立即走原 lower_bound，不假设对象图总按地址顺序遍历 | 同 wire 比较首次拒绝类别、登记集合和 owned/free 次序；adjacent/contained/duplicate/cross-owned-free/random/reverse/oracle 全覆盖；单独计量 branch/fast-hit/fallback/key/neighbor；逐节点与真实 chunk OOM均保留 |
| P6b | 验证 scratch 的内存余量 | 标准 monotonic 当前有明显 chunk slack；先记录不同 S/M/L/profile 的请求字节、实际进程峰值与回收，再比较固定上限的增量 slab 资源。保持资源只活到单次验证结束，不从不可信 node 数预分配，不加合法输入 cap | 相同合法/恶意输入及异常能力；同时比较 upstream calls、请求/实际驻留、load/reload，不仅比较 node 逻辑字节；若标准资源已足够则不因偏好替换 |
| P6c | 修改保护与替换路径 | 优先从当前栈/计数拆出 ancestor guard、rel32 rebase、owner lookup 和缓存维护；只有能证明目的 descriptor 不在源 ownership 中的路径才研究更窄保护。payload/字符串全量替换可研究避免 resize 默认初始化后覆盖 | 不缓存裸 owner 指针跨 epoch/move/swap/release；独立 owner 正确性、多线程外部同步边界、ancestor alias、自移动、跨 arena 与真实 OOM；新增 API 另立契约，不能改变现有默认 |
| P7a | 长驻可变场景 | 新增固定“load 一次，多轮变长修改、定期 save/重载”的 workload，与冷恢复场景分开，不从现有 total 减去 load 假装测得 | 先冻结轮数、size 分布、增长/删除比例、冷热、查询、checkpoint频率、语义摘要和资源上限；维护与归还全部计时 |
| P7b | compact 与布局 | 评估内部空洞、spare capacity 和元数据对 wire/RSS/重载的影响；可研究显式 compact/新存储代际，但不隐式改变地址稳定或默认 save | 同时验收 compact 成本、峰值双份数据、save/reload、后续修改、borrow/span/handle失效规则；V1 reader/writer继续互读，若超出V1另立版本设计 |
| P7c | 同保证的竞品对照 | 当前 trusted detached 生命周期仍保留，另行设计足够接近的输入保证/资源所有权模式；只读映射、对象解码、builder 可变模式分别列场景 | 不把 FlatBuffers trusted UnPack 解释为完整 Verifier；不把 cista NONE 解释为无任何检查；全部库同业务、完整保存/释放/重载账本 |

P6a 是待验证的首选原型，而非预先采用。它可能在顺序区间很多时减少查询，但随机顺序会多出分支和边界检查；必须包含 reverse/random/adversarial 对照和完整生命周期预算。不得为了获得 end hint 先收集全部区间再排序，破坏访问子对象前的在线拒绝。若不改善可保持现版本，不能反复重试挑出有利样本。

后续速度因果研究应把当前基线与新候选作为同一窗口的显式角色，先定义新的身份集合、平衡日程、多重比较、样本及预算。现五库 285-child 协议不支持无修改加入第六角色；本轮保持原协议，只比较最终候选与四个固定竞品，不用跨窗口旧/新均值推出优化百分比。

新的 workload、信任模式、节点数据结构或公共修改 API 各自形成独立实施包，沿用“设计与反例 → 单变量实现 → normal/SAN/fault/兼容 → 固定机制诊断 → 冻结与唯一测量 → 采用/拒绝/不确定”顺序。业务前提未具备的 N7 不在此处自动展开。

当前诊断原件位于 `/root/xoffset-performance-roadmap/20261017/v2/phase-profile-v1/` 与 `P12-v1/counts-v1/`。便携选集只复制日志、派生统计和身份；原 perf.data、wire、canonical 与可执行文件留在 Linux 路径，不能称为独立 runtime 分发。
