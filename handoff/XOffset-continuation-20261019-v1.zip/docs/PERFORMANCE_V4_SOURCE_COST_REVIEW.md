# V4 source-cost review: logical work is not measured CPU work

Status: source/counter review and the retained descriptive-phase update complete.
Root's `report-v2/report.json` body audit passed for all1200 actual children
(600conditioning and600primary); its measurement qualification remains false.
Only the primary cohort enters the existing statistics:24primary warmups are
excluded, leaving576 measured rows,96per role, without trimming. This review
does not independently repeat that full body audit or rank libraries. No compiler,
target, profiler, benchmark or test was launched for this review. No additional
measurement window is proposed.

Inputs are the immutable v3 main `39ff8d4f...0c55725` (216565 B), the immutable v4
main `7a7bbf20...c6710ac` (230968 B), and root's two one-iteration fixed-M count
runs under `/root/xoffset-performance-v4/20261018/v1/mechanism-v1/`.
The actual-run review is
`docs/coordination/performance-v4-20261018/mechanism-final-review.json`, SHA256
`d7efff3a3b4dfe53baac644780834759b9c1bfeccdbddb9d378da4fd1c1b678a`.
Its author wrote the count tooling and reviewed root's actual results; that is
not an independent cross-author source audit of the tool itself.

## What v3 already does for primitive elements

The actual helper in both versions is named `validate_wire_value`, rather than
`validate_wire_object`.

In the v3 header:

- Lines3256–3276 validate the vector's allocator binding, size/capacity,
  relative data pointer, full payload address/alignment and allocation metadata,
  then register its owning interval.
- Lines3277–3279 spell a loop calling `validate_wire_value(data[i], ctx)`.
- Lines3299–3335 instantiate a generic `if constexpr` dispatch. For `uint8_t`,
  `uint32_t` and the other admitted non-bool scalar leaves, none of the branches
  is selected: they are not bool, arrays, owning containers or classes. Their
  instantiated validator body is empty. Enum leaves are likewise not checked
  for application-level enumerator validity in v3.
- An array or an admitted record containing only such leaves recursively reaches
  empty operations. In contrast, bool at lines3301–3304 reads/checks its byte
  representation; owning bindings/ranges and set/map strict ordering at
  lines3307–3325 have observable validation behavior.

The old template definitions are visible in the same translation unit. An `-O3`
compiler may inline the empty leaf calls and delete the now empty loop, including
the traversal's machine loads/branches. Explicitly writing the source loop does
not establish that a million loop iterations executed in the bare binary.
Conversely, merely observing no standalone scalar-validator symbol would not
prove the loop was removed: it could have been inlined into a still existing
loop. A specific caller/control-flow inspection is needed to establish the
machine-code fact for a given specialization.

No full bare disassembly has been reread for this initial small-source review.
Accordingly the conclusion is **old loop elimination is legal and plausible,
not established here as the actual binary's behavior**. No speed or saved-time
claim follows from this source analysis.

## What the v4 trait actually establishes

V4 lines3455–3475 prove a conservative compile-time no-check predicate: bool
remains true, unknown/non-admitted types remain true, owning containers remain
true, and scalar leaves without an old validation action may be false.
Lines3526–3530 still validate and register each vector allocation before the
conditional element traversal at3531–3538. Lines3555–3556 omit no-check reflected
members; bool and sorted-key checks remain at3562–3583.

The derived diagnostic's `no_op_vector_elements_elided` event is one
`+= value.size_` on each selected vector, not a counter executing once for each
old element visit. Its values3,670,016 on initial load and4,521,984 on reload
therefore count **logical source-level potential iterations omitted by the
trait**, not old native instructions, actual reads, retired branches, CPU cycles
or elapsed time saved. Adding a per-element counter to the old empty loop would
itself make that loop observable and defeat this particular optimization; such
a counted old loop would not recover the original bare runtime cost.

The trait is useful as explicit semantic information and can make optimization
less dependent on inlining decisions, but it cannot by itself demonstrate a
performance improvement over a compiler that already removes the noops.

## Fixed-M mechanisms that did and did not change

These are observations from two count-only processes, each one iteration. They
are not formal timing samples or a decomposition of the sole campaign's time.

| Mechanism | v3 | v4 | Supported interpretation |
| --- | ---: | ---: | --- |
| Actual Core owner-lookup function entries |106496|98304|8192 entries avoided, without assigning a time per entry |
| Tail helper entries |22528|22528|Same attempted helper route count |
| Downstream Core tail calls / false outcomes |8192/8192|0/0|V4 rejects8192 physical nontail candidates earlier |
| Physical nontail prefilter rejections |0 (not present)|8192|Counter records the actual new early-return path |
| Successful tail expansions |0|0|This fixed M does not exercise the new path's successful tail-growth benefit |
| Dynamic logical allocate calls |53248|53248|No reduction in arena allocation calls |
| Nonempty retire calls |45056|45056|No reduction in nonempty arena retire calls |
| Logical requested allocation bytes |5134026|5134026|Same payload requests; not host allocation/RSS |
| Freelist lookups / owner acquisitions |53248/98304|53248/98304|These underlying allocator activities remain |
| New bulk API fresh / inplace successes |API absent|24576/0|Observed bulk operations all took the fresh path |
| New bulk successful rhs copy bytes |API absent|2490368|Required new rhs bytes copied, **not** a measured saved-byte count |

The v3 adapter used resize followed by copy; v4 uses the explicit live-span
assignment API. Source-level old-prefix/default-initialization writes that this
API avoids are candidate optimization opportunities. Their execution in the old
bare binary is not proved by counting the new API's required rhs copy. Inlining,
alias analysis and dead-store elimination may also remove some old writes. The
new bulk counter must not be relabeled as an actual old-to-new copy reduction.

The existing string-copy audit is identical in the two runs:18432 fresh string
replacements,146601 logical old bytes not copied,659146 rhs bytes copied and
zero string tail expansions. Those string mechanisms were already in v3 and
cannot be credited as a new v4 improvement.

The actual adapter's primitive sequence replacement now enters `assign_range`;
its other direct default-resize sites are record/attribute class containers.
Thus a successful primitive `resize_default_scalar` regression test establishes
the API behavior, but is not evidence of the same fast path being used in this
fixed-M trace. The aggregate tail-success count here is zero.

## Dense/paired validation exchanges work rather than deleting graph checks

| Graph phase | v3 | v4 |
| --- | ---: | ---: |
| Initial owned/free registrations |196612/0|196612/0|
| Reload owned/free registrations |204804/8192|204804/8192|
| Initial real upstream requests / bytes |6/1686576|1/1713608|
| Reload real upstream requests / bytes |7/4423888|2/4459664|
| Initial logical scratch request bytes |1560208|1713576|
| Reload logical scratch request bytes |3536928|4459600|
| Initial marked64-bit words |338946|361410|
| Reload marked64-bit words |414722|437186|

All validation scratch live bytes/chunks return to zero and actual requests
balance releases in both runs. V4 uses one/two dense indexes and no paged tail
for this extent. It makes fewer upstream calls, but requests27032/35776 more
upstream bytes, respectively. Dense logical scratch also increases here. This
is not evidence of lower RSS, fewer faults or less zero-fill time.

V3 can represent351 full pages using full-page tags. The observed extra22464
v4 word-mark events in either graph phase equal351×64. Dense and paged events
must therefore be interpreted with their different implementations. Similarly,
v3's separate overlap-query count and v4's paired-query count do not have an
identical unit of work: on initial load, empty free coverage is cheap; on reload,
pairing changes the shared traversal. Counting fewer query functions does not
by itself quantify fewer instructions or a time saving.

All original allocation/header/binding/bounds work and online first-error
semantics still apply. Reload must also validate the existing free-list links,
size classes, byte totals and free/owned exclusions; it is not merely initial
load with a different buffer size, and is not rebuilding a new host free list.
It is invalid to subtract initial-load time from reload and label the difference
as a pure free-list or extra-check cost without a controlled attribution.

## Force-inline and code-size evidence is limited

Root's preserved bare inspection reports ELF `.text`121160→122728 B and file
size209136→213272 B. Its extracted symbol labels include out-of-line
`validate_storage_range` and `validate_binding` in v3, neither in v4;
`checked_relative` is absent in both lists. This establishes a symbol-emission
change in those binaries as reported by that inspection. It does not prove the
old calls' dynamic frequency, code hotness, instruction count, successful CSE,
elimination of a particular division, or a runtime benefit. Increased code size
can itself have costs; none are quantified here. Actual alignment metadata may
still require a dynamic check, and existing constant-mask operations must not be
advertised again as a newly removed modulo.

## Emit already has one owning output copy

The suspected vector-to-string chain is absent in this actual version. The v4
adapter at `adapters/xoffset/adapter.hpp:91` directly returns
`state->save_verified()` as `std::string`; `TypedXBuffer:4793` directly delegates
to `XBuffer::save_verified<T>()` at4484–4545. This header has no `to_bytes` or
`to_buffer` entry with an intermediate owning vector on this path.

`save_verified<T>()`:

1. Checks compile-time admission and the existing typed-access/schema guards
   (4485–4488; guard implementations4697–4724).
2. Calls `shrink_to_fit()` and locates the root and allocator state
   (4491–4500; helper locations4217 and4045).
3. Builds the88-byte V1 transport header, with reserved size normalized to used
   payload size. The defined V1 flags are zero (3829), and `crc32c` is set to zero
   (4524): it does not run a CRC payload pass.
4. Allocates/grows the final string. The feature-macro branch4533–4538 uses
   `resize_and_overwrite`, followed by one header memcpy and one payload memcpy.
   The portable fallback4540–4542 reserves and appends header/payload directly.
   Neither source path creates a full temporary vector, converts a full vector
   to string, or explicitly zero-fills the entire string before copying.

It does not call `verify_structural_wire_graph` or `validate_wire_value` during
emit. Its verified-name guards preserve the existing typed/schema authorization;
they are not a newly repeated whole-graph validation pass. This is consistent
with the actual emit snapshot's zero validation-registration counters. This note
does not strengthen the public API's existing guarantee by silently assuming
that emit rescans arbitrarily mutated raw memory.

For this fixed M result, the necessary source-level transfer is17830784 payload
bytes plus88 header bytes, total17830872 output bytes. Output allocator metadata,
terminator writes and possible OS demand-zero/fault work are separate; no claim
is made that the physical allocator performs no zeroing. There is no additional
full-wire copy or explicit zero-fill to budget as a prospective saving here.

`XBufferCore::shrink_to_fit()` at390–396 is also not graph compaction:

- `prune_free_blocks()` at669–677 scans/removes out-of-used-extent entries from
  the **host Core `free_blocks_` vector**. It does not traverse/pack the object
  graph or copy all payload bytes. Its cost need not be O(1) if that host vector
  is nonempty; that vector is not synonymous with the serialized allocator's
  size-class free lists.
- `used_end_clamped()` at680–686 computes the normalized logical used extent.
- `VirtualMemoryStorage::resize_logical()` at254–262, when shrinking, only
  changes `logical_bytes_`. It keeps the reservation and page permissions and
  does not move/rewrite payload, reclaim pages or issue a second full copy.

The adapter's `const State&` is a const `unique_ptr`, not a const pointee: the
existing emit may prune host bookkeeping and shrink logical extent. A future
explicit const serialization API could compute the same normalized header and
copy without these state changes, with separately specified postconditions.
It must preserve existing admission, guard, overflow/OOM, V1 output and lifetime
guarantees; it is not a way to remove a copy already absent. Retargeting the old
API would need to respect observable size/bookkeeping semantics, not silently
change them.

The current shared adapter contract already accepts each library's native owning
output through `wire_view`: XOffset string, cista serialized byte owner,
FlatBuffers `builder.Release()`, Cap'n Proto word array, and cereal's moved
string-stream result. It does not impose an extra common `vector<uint8_t>`
conversion. A new borrowed/scatter-gather output, state transfer, or sink-only
write may be useful in another application, but it changes the owning independent
output and cleanup/reload scenario. It cannot replace that phase within the
already frozen campaign and be presented as the same comparison.

## A cross-operation validation cache is not justified

The public API exposes mutable roots, references and raw data/buffer access.
Those aliases can remain live across operations and modify bytes without a
subsequent library mutation call. A mutation epoch or a previous typed-load
verified flag does not witness all such writes. Caching a validation certificate
across calls would therefore weaken the current full-check contract unless a
new API enforced an appropriate immutable/sealed ownership discipline. Trusted
application input alone is not such an enforcement mechanism.

Subsequent performance designs should instead study a fused full-check walk,
lower per-check constants, or an ownership/control-block arrangement that can be
proved safe across callback/new-handler/move/swap/release boundaries. None of
these has a demonstrated elapsed-time benefit in the current evidence, and no
unchecked path or reused caller input is proposed.

## All retained primary samples: descriptive costs, not a qualified ranking

The following are arithmetic means in milliseconds from
`C4/descriptive-window-results.json`, all96measured primary rows per role. Query
is before+after; cleanup is modified-state retirement+reloaded-state cleanup.
Rows follow the declared role order rather than a ranking. Both conditioning
and primary outputs passed root's body audit; conditioning rows are not silently
mixed into these phase means.

| Role | Load | Reload | Mutate | Two queries | Emit | Cleanup | Total |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| v3 old XOffset |8.692320|14.628808|12.393267|13.272037|5.927335|1.030891|55.944657|
| v4 new XOffset |9.297927|14.837767|12.183510|13.385249|6.114759|1.023252|56.842464|
| cista |10.493548|8.830174|7.557708|12.747272|12.600272|2.307801|54.536776|
| FlatBuffers |7.210909|3.521719|8.176972|14.040092|13.046472|10.824690|56.820854|
| Cap'n Proto |9.490062|16.922876|24.157197|38.430503|11.480763|0.831420|101.312820|
| cereal |7.958764|4.828977|7.412919|13.148415|12.422496|6.486304|52.257873|

All six A/A intervals failed to establish the predefined equivalence. This is
**not proof that every underlying implementation is non-equivalent to itself**.
The accepted report keeps `measurement_qualified=false`, `comparison=null`,
`target_achieved=false` and `old_new_improvement_established=false`.
The v4 arithmetic mean is0.897806ms above the v3 mean in this retained cohort;
this is an unqualified observation, not an established regression, a header-only
causal effect, or evidence that the source optimizations must be ineffective in
every environment. Equally, the source-level elisions and lower owner counts
do not establish any causal header improvement in the current evidence.

The cista contrast illustrates why the whole lifecycle matters: v4's observed
reload/mutation differences are+6.007592/+4.625802ms, while load/emit differences
are−1.195621/−6.485513ms, before the query/cleanup differences. None of these
differences can be relabeled entirely as validation overhead; the native state,
allocation, copying, layout and traversal work differ and the window is not
qualified. Selecting only emit or initial load would hide costs paid elsewhere.

## Remaining engineering budget, not a reachable-time promise

Using cereal's smallest **observed arithmetic competitor mean**52.2578727604ms
only as a design input, the20%-lower latency budget is41.8062982083ms. The v4
observed mean56.8424637396ms leaves15.0361655313ms, or26.4523466% of that observed
mean, to address. This arithmetic is not the protocol's paired geometric
contrast/confidence calculation, and does not make the unqualified window pass.

Several limits rule out a small or imaginary single fix:

- V4 load+reload is24.1356936771ms and everything else32.7067700625ms. If every
  other phase stayed fixed, load+reload would have to fall to9.0995281458ms,
  a62.2984602% reduction. No source or count evidence currently demonstrates that
  such a reduction can preserve all checks.
- Merely matching cereal's observed load+reload would still leave3.6882122292ms
  of the target gap. It is not a forecast that these phases can or should match:
  XOffset must retain its own complete V1 allocation/binding/interval/free-list
  validation and detached-owning lifetime.
- Even the impossible removal of the entire observed6.1147590729ms emit phase
  leaves8.9214064583ms to address. There is no extra full-wire output copy here
  to remove in the first place. Eliminating the entire12.1835100313ms mutation
  phase alone would still leave2.8526555ms, so that too cannot be the sole lever.
- The observed query-total difference from cereal is only0.236834375ms; it is
  not a plausible explanation for the15.036ms budget. Shared query semantics
  and work must remain intact rather than being omitted to meet a target.

## Decision boundary and next design inputs

1. Preserve the sole window, all failed qualification evidence and all declared
   non-warmup rows. No extra run, trimmed subset or widened equivalence band may
   be used to seek a favorable current outcome.
2. Establish measurement qualification separately in any future authorized
   protocol/candidate. Existing diagnostic ratios remain explicitly unqualified;
   passing body/functional audits does not replace the A/A requirement.
3. Prioritize work demonstrated to remain in the actual binary and full lifecycle,
   not primitive leaf calls whose source body is already empty. Fused exact
   validation/marking and dense full-page constants may be research directions,
   but fewer function counters alone cannot establish that they reduce real work.
4. A stable arena storage/control block could be researched for the remaining
   owner-acquisition route, only after callback/new-handler/move/swap/release/OOM
   proofs. There is no permission here to reuse an unsafe cached Core pointer or
   a stale validation certificate. Preserve online rejection, bool/ordering
   checks and real serialized free-list validation.
5. Retain v3 as the recommendation baseline and v4 as a separate functional
   experiment. V4 has not established the requested goal or a causal header
   improvement and should not automatically replace v3. Any later promotion
   needs documented function/resource tradeoffs plus qualified goal evidence.

No implementation change or new measurement is requested by this review.
