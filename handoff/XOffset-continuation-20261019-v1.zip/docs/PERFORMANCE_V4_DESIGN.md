# Performance v4 设计、研究与实施路线

2026-10-18。真实基线是已验收功能的 v3：主头 `39ff8d4f75029f86caaa9bc37b47f9066067611a2cf90c75c9de572bc0c55725`，不是 Git HEAD 所代表的原交接源码。v3 的600进程窗口全部正确，但六角色 A/A 未证等价，保留其未合格状态，不重跑或追认。

本轮在独立 managed worktree `C:/Users/gzsufanchen/.codex/worktrees/performance-v4/xoffsetdatastructure开发` 实施，Linux 新目录 `/root/xoffset-performance-v4/20261018/v1`。原工作区、v3 源码/档案和旧失败保留；7,783 个历史文件身份进入新保护清单。没有 TaskCreate/TaskUpdate 工具，以 `docs/coordination/performance-v4-20261018/plan.json` 管理阶段。Superpowers 未调用。

## 竞争目标与成本预算

主场景仍是 M mixed-growth trusted-detached 完整生命周期：16,384 records、28,673 mutations、两轮各55,299 queries，包含 owning 初载、两次查询、变长修改、owning 输出、退休修改状态、重载与清理。schema、模型/trace、结果及计时边界不变；不能省略生产校验、借用输入、切换长期驻留或只比getter。

“超过全部竞品”继续按上一版较严格目标验收：对 cista、FlatBuffers、Cap’n Proto、cereal 四个固定版本，同窗配对几何完整生命周期延迟比及同时单侧上界均≤0.80，并通过全部6角色 A/A。旧/新 XOffset 同窗另作改进控制。目标是验收条件，不是已知可实现的承诺；不能因为仅达到点估计或一个竞品而标记完成。

v3 未合格窗口只作工程观察：新 X55.341ms，load8.663/reload14.401/mutate12.133，两次query13.273，emit5.811，其余约1.060；cereal50.909ms。0.8×cereal≈40.727ms，仅此假设预算就仍差14.614ms/26.406%。工程分配先取36ms留误差余量：load5、reload6、mutate7、两query13、emit4、退休清理1ms。这个拆分没有带宽下界或可达性证明，也不会改变正式统计阈值。

## 加载/重载：内存访问形状与编译期工作消除

v3 的 exact byte bitmap 已去掉实际登记树；继续优化树不是当前问题。修改后重载 owned204,804/free8,192，partial页6,772、PMR上游4,423,888B；相比初载 owned196,612/free0，不只是同一对象重复读。V1 free-list已有链、offset/header/size-class/freebytes 与 owned/free 无重叠仍必须完整校验，不把阶段差直接当某个检查的耗时。

1. **有硬预算的hybrid位图。** 首次真实validated extent≤64MiB时，为每个index惰性申请连续dense prefix；free首次真实登记才申请。prefix按4096 arena字节边界上取整；每页另1bit nonempty summary，与dense words共一次allocation。每index最大8MiB+2KiB，双index最大16MiB+4KiB逻辑存储；owned/free各用独立的显式new_delete上游PMR资源，避免第二个同尺寸dense请求被共享chunk几何增长放大，仍另计PMR slack/resource；这不是RSS。extent更大走原paged路径，绝不把64MiB变成输入上限。detail helper后续extent增长只增加paged tail，不迁移prefix、不影子重复存储同一位。实际extent外padding不被登记，合法后续增长可使用。
2. **配对owned/free查询。** 同一范围共享page/word与mask遍历，完整保留全局错误优先级：owned/live冲突可立即拒绝；先遇free冲突只能记pending，继续查可能后遇的owned，最后按原顺序抛错。不是一遇任何冲突就返回。两表示/最多两边界资源全部prepare后才能commit coverage/count/extent。OOM可留下未使用scratch，但不得部分登记或发布typed root。
3. **消除无作用的标量递归。** 递归trait仅对可证明没有任何wire检查的非bool标量/enum及其纯聚合/数组判空。bool必须验证representation；所有string/vector/set/map及含它们的base/member必须访问，set/map顺序检查不能消失。vector完整payload/header/ownership仍在元素遍历前登记。递归类型不能使trait无限实例化；非V1公共容器路径不能被错误判为安全。
4. **小helper常量传播。** 对validate_storage_range/checked_relative/validate_binding做有平台guard的有限force-inline或alignment常量专化。generic任意alignment行为保留；错误优先级不改。v3反汇编已证明metadata alignment模运算本来是mask，不能重复计收益。禁止全面inline导致文本膨胀，native -O3依赖和反汇编另核实际结果。

dense对小R大U有更大零填成本，paged对稀疏大arena有优势；64MiB是显式scratch数学预算，不能用模型大小/类型名/竞品ID选路径。需要阈值两侧、dense→paged tail增长、word/page边界、全页、首/第二资源失败、两个冲突优先级、完整typed-load failure sweep及独立pairwise oracle。

## 修改：保留旧语义，提供合法批量赋值

v3普通uint8/uint32的初始化在实际代码中已被编译为memset，不能再把“改成批量初始化”当新增收益。M每阶段现有非tail block的位置也不能被假设成tail。先做可证的保守改动：

- try_expand_dynamic_bytes已读取allocation header时，按64-bit physical end与arena used_end做只读非tail预筛；Core原完整检查保留，避免明确非tail仍查询owner。scalar默认resize可在真正尾部扩展后完整value-init suffix，容量公式不变，VM失败立即抛出不经新allocation重试；fill/custom/nontrivial原路径不动。M是否命中由固定机制计数决定。
- 不把单次函数内Core*自动视为安全cache。release_cached_blocks→deallocate_impl→host vector allocation以及异常构造均可能调用用户new_handler；move/swap/release可改变owner身份。没有证明前不跨这些边界复用owner，不加TLS/global裸指针缓存，也不持全局锁跨回调。原失败反例继续有效。安全复用若无法证明就明确拒绝，而不伪称完成该优化。
- 增加后向兼容的受约束公共 `assign(span<const T>)`/等价命名批量操作（最终名称在实施记录固定）：仅non-cv、trivially-copyable、trivially-destructible且trivially-copy-constructible元素（最后一条是fresh memmove隐式创建生命周期的充分条件；仅trivial assignment的非implicit-lifetime类不准入）。语义为全量替换，in-capacity memmove，增长fresh准备rel32→直接复制rhs→commit→retire。源可为self完整/子span、同arena其他live对象或外部span；退休旧块前必须读完rhs。count>cap时cap=count，否则保cap，保持现有resize+copy容量规则；旧resize的value-init承诺不变。空/overflow/OOM/foreign arena/旧头被free-list覆盖都要专测。16字节容器布局与V1不变。

这是新增通用API，原“public_API_unchanged”自设字段应改为明确的“既有API保持后向兼容+列出新增API”。用户未禁止增加API，不需要为常规设计选择停下确认。最终报告必须区分它与旧操作内部优化。

## 竞品功能与集成公平性

比较的是共同业务，安全保证不完全相同：XOffset仍做完整生产结构/allocator/owned-free校验；cista v0.16 NONE仍有结构检查；FlatBuffers为可信ObjectAPI且未额外Verifier；Cap’n Proto为bounded reader→detached builder；cereal为BinaryArchive/native DTO。不能为匹配较少保证的成本而把X改成unchecked。

新增批量赋值不能只给new X更好的接入。固定cista `containers/vector.h:174–190` 已有public set(begin,end)，当前adapter helper却逐push；本轮同时让其使用该合法bulk API（源都是外部DTO vector，无selfalias）。FlatBuffers/cereal已用std::vector批量赋值，Cap’n Proto保留已有合法builder写入。版本commit不改，adapter实际源码单独绑定；旧X控制保留原接入，因此旧新收益是“library+合法integration”的组合，不宣称纯header因果。

## 测量设计：相同前驱条件的新执行封套

旧窗六个A/A点估计都在±5%内；失败是同时区间未被等价带包含，不是已证六个真实偏差都超5%。旧600元数据发现first的288个前驱只有19个同role，second全部288个同role；AB/BA标签平衡不能消掉这个实际顺序差。wall/CPU相近变化不支持把原因全归抢占，缺少同步频率/缓存观测不能宣称因果。

内层 `sc-six-role-cluster-t-v1` 统计模块逐字保留：600 primary jobs=24warmup+576正式行，48blocks/8个macrocycles/df7，6角色chronological A/A同时区间必须全在[1/1.05,1.05]，五contrast同时单侧判定保持。A/A与contrast是两个不同95% family，不说11区间联合95%，也不保证独立正态模型在宿主成立。

新outer envelope为每个primary预先固定一个同role全生命周期conditioning child，共1200实际native：600conditioners+24primarywarmup+576推断行。每个conditioner同样校验实际canonical/query/wire，预先排除所有推断/阶段均值；不读取其耗时作节奏、样本、阈值或是否继续的决策。这样对齐直接前驱，仍不保证更早缓存/热历史或宿主独占，A/A照常可失败。不能用它追认v3或跨窗算因果。

outer预算：1200children、20秒/child、45分钟/窗、32GiB真实wire、64GiB真实保留输出、至少2GiB额外磁盘余量；内层16GiB只约束600primary输出，两个账本分列。每个actual receipt、顺序、argv/env、pid、输出哈希、清理、失败前缀和未执行项都审计；不伪装旧600 native协议。新old_xoffset绑定v3实际裸binary，而不是v3窗口里的v2控制。源码/actual deps/runtime/解释器/7工具/两X与四竞品、模式权限和完整日程先冻结，真实复制并describe后再开唯一窗口；3代理quiet，无编译/重测试/归档并行。任何硬错误封存停止，不追加、不重跑挑数据。

## 阶段与写入边界

| 阶段 | 责任与写入边界 | 验收/依赖 |
| --- | --- | --- |
| P0 | root：独立worktree、7783保护身份、新目录、研究/预算/本设计 | 不覆盖v3；实际基线不是HEAD |
| P1a | linux_validation：`build/performance-v4/validation`私有补丁/测试/计数变换 | 不改共享头，不native |
| P1b | root唯一生产集成、normal/SAN针对门禁 | 独立oracle、bool/顺序/异常、真实OOM |
| P2a | windows_validation：`build/performance-v4/mutation`私有补丁/测试 | 明确拒绝未证owner cache，新增bulk API别名/故障 |
| P2b | root顺序集成、仅合法adapter改动、normal/SAN | 旧API/布局/V1保持，竞品合法bulk审查 |
| P3 | root执行；代理交叉只读审查 | 全库normal/SAN/正控、五库SML各80、4旧控制V1双向48、alpha-S2、schema夹具双向、干净安装/子工程各3 |
| P4a | n7_prerequisites：`build/performance-v4/review`研究/事前协议；root实现新outer runner，另代理独立pure/实际copy审查 | 统计源码不改；conditioning账本与外层预算明确 |
| P4b | root唯一全局租约正式测量 | 新候选唯一窗口，1200actual，其他代理quiet |
| P5 | 代理独立复算/审查，root封存结果/保护核验/便携metadata | 功能、机制、资格、竞争目标四个状态分别报告 |

阶段自动推进，不等进度确认；正确性失败先定位并在新attempt目录修复，旧失败不改。固定一次非计时M机制诊断逐阶段检查所有canonical/query，计数真实表述owner调用、allocation/retirement、dense/paged请求与释放；计数版不参加正式速度比较。不通过就不能冻结；目标未达到如实给剩余差距，不能以退化保证或换场景制造完成。

## 研究依据

- [LLVM Vectorizers](https://llvm.org/docs/Vectorizers.html)：通过实际优化诊断判断循环是否被消除/向量化；不能把源码循环直接算逐元素成本。
- [Clang Users Manual](https://clang.llvm.org/docs/UsersManual.html)：小常量memcpy与alias规则；不用违反alias假设的强制指针cast换性能。
- [LLVM Language Extensions](https://clang.llvm.org/docs/LanguageExtensions.html)：有guard的编译器属性及其边界，不靠不安全assume声明独立性。
- [Intel优化手册入口](https://www.intel.com/content/www/us/en/developer/articles/technical/intel64-and-ia32-architectures-optimization.html)：微架构成本需要实际代码/平台证据，不能从除法或缺页次数给固定毫秒承诺。
- [固定cista v0.16 vector源码](https://github.com/felixguendling/cista/blob/015b94e66c4c0d7c1ef29742383a024c84fbbba1/include/cista/containers/vector.h)：本轮bulk公平性按真实固定API而非当前最新版猜测。

N7仍缺真实业务入口；原生Windows full P2996未建立。两者不因本轮优化而关闭。不提交、推送、合并、发布或触发远端CI。
