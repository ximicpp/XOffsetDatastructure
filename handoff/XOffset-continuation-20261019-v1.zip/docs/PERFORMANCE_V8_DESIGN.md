# V8：请求身份与单word精确校验

实际开发控制为V6 B-only，主头fb66f961…/OS22f181b5…。V7两个候选均已否决，旧54/108样本和所有失败不动。新源码/构建/输出为WSL `/root/xoffset-performance-v8/20261018/v1`；工具为`build/performance-v8-20261018`，台账为`docs/coordination/performance-v8-20261018/plan.json`。本轮不是新正式五库窗口，目标尚未达成。

Key将两个32位请求字段无损打包，生产guard后在bucket循环外一次计算。保留head/state/epoch、first-fit、中间删除失效、拒绝区间、retire/reuse和生命周期。只改host cursor；不加wire字段，不恢复旧A的mask，不混入V7位扫描或取余候选。作者交付独立数学/边界/Cartesian/seeded oracle及实际指针模型，原OOM/回调/别名等相关八项测试保留。正常/SAN各9项实际通过，独立源码审查无确认阻断；效果仍待固定窗口。

Word只在V6 B的prepared dense/same-page/extent门禁后特化单64位bitmap word（物理8字节，覆盖64个arena字节）。owned优先、free其次，所有冲突检查完成后无throw提交；整word只用summary，部分word必须guarded read保留邻bit。cross-word/page、冷状态、extent增长、sparse和准备失败继续正确回退，资源预算和initialized-word门禁不变。正常/SAN各11项实际通过，与Key合计40项。首次变换器因END匹配两个重载在编译前拒绝；v2只收窄唯一签名，原区域SHA保持，算法inc/测试/CMake字节不变，失败目录保留。效果准备尚未执行；不把功能通过写成收益。

第三代理的eligible诊断先在静审发现原driver还有第三次post-audit load，v1错误地把两个目标phase当两次总调用。v1源码和阻断记录保留，执行前v2最小修正：总3次，第3次明确识别但不reset/snapshot或计入目标phase，额外/嵌套仍错误。原driver及完整审计体不改。唯一一次M诊断已通过完整endpoint canonical/query及精确wire核对；工具prepare/compile与那次native运行在同一共享租约中完成，没有重复或额外性能样本。

| 基线诊断 | 初载 | 修改后重载 |
|---|---:|---:|
| 登记总量 | 196612 | 212996 |
| 单word eligible | 103569 | 103568 |
| 其中整word | 565 | 565 |
| 其中部分word | 103004 | 103003 |
| 验证器PMR逻辑峰值bytes | 1766688 | 4597824 |
| upstream峰值bytes | 1766720 | 4597888 |
| upstream申请/释放次数 | 1/1 | 2/2 |
| 结束live bytes/chunks | 0/0 | 0/0 |

这是基线source事件和验证器资源诊断，不是硬件流量、候选耗时或候选scratch实测。初载eligible全部命中原bbox快返，仍需读目标word以保留邻bit；重载大多进入原paired路径。单word特化可能减少通用Span/边界状态和分支，不能把表中的data-word读取数一律当作可消除量。新热路径无新增申请的证明和armed-resource测试与整体PMR峰值的测量分开陈述。

执行前已固定内部设计：V6/Key/Word，72个平衡triplet=216新进程，六排列各12次，每角色每位置24次，Key主目标mutate、Word主目标reload。用封存V7最大修改log SD0.17212规划，SE约0.020285、主界log半宽约0.04045；不保证power、独立性或1%精度，不根据V8结果扩样。两个主目标单侧Bonferroni2上界<1；八阶段+总量×2共18项另用双侧联合95%筛查，非目标/总量下界>1或未定义contrast则否决。两族分别95%，不是合并整体95%。

CPU2、20秒child、600秒整个worker含封存、780秒仅外层清理容限、保留8GiB、guest/backing初始各16GiB及2GiB余量。原7输出槽投影和每次完整真值、实际source/driver/CMake/依赖/SDK/binary前后绑定、原共享runner/清理契约均复用。5个原driver九阶段validate（3normal+2SAN）和10个原协议检查在准备阶段执行；改变分项目标的纯数据检查随源码适配，但不扩大工具体系。计时与编译/扫描等重负载互斥。没有预热、剔除、替换、重试或追加。

保留决定事前固定：两者都无资格则保留V6；仅一个合格则进入完整最终候选门禁；两个合格选择主目标上界较小者，精确相等选Key。不在本预算测未登记组合，不假定收益相加。最终拟集成者需要完整相关normal/SAN、原业务九阶段、恶意输入、直接前代与旧V1双向、安装及子工程消费。没有候选合格时记录否决，不强行集成。

root唯一调度实际重负载，两个代理分别拥有候选文件，第三代理做诊断和交叉审查。没有调用Superpowers，不提交、推送、合并、发布或触发远端CI。原生Windows P2996与N7业务入口仍开放；原竞品目标持续保留，局部内部结果不能冒充全部竞品达标。
