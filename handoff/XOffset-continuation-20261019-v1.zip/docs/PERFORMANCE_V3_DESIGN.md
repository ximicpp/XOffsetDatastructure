# 下一版性能优化设计与实施路线

2026-10-17。本版从已验收功能但计时未合格的 v2 候选继续，主头 SHA256 `e0f905694031c88618b8e2b453f6ac2400872e36a9caf82233c1d9e1dfabaf7a`。独立可编辑目录为 `C:/Users/gzsufanchen/.codex/worktrees/performance-v3/xoffsetdatastructure开发`，Linux 新目录为 `/root/xoffset-performance-v3/20261017/v1`。不覆盖 v2、alpha 档案或失败证据；不提交、推送、合并、发布或触发远端 CI。Superpowers 未调用。

## 胜负场景和目标

主场景继续使用 M mixed-growth trusted-detached 完整生命周期：16,384 record、28,673 修改、55,299 查询，包含 owning 初载、两次查询、变长修改、owning 输出、退休修改状态、重载和清理。时间边界、模型、trace、schema、竞品版本和模式均保留；不把只读映射或移除加载成本当本场景胜利。N7 业务前提仍不具备。

“明显超过”预先定义为：在新的同一窗口内，对 cista、FlatBuffers、Cap’n Proto、cereal 四个竞品，候选完整生命周期 wall latency 比值均不超过 0.80，且预注册同时置信区间的上界也不超过 0.80。这意味着至少少用 20% 时间，不把速度倍数和延迟百分比混写。还须披露各阶段、wire 和进程资源；不能仅挑选有利竞品或子阶段。目标尚未达到，不构成保证。

v2 未合格窗口中，XOffset 118.73 ms，最快观察为 cereal 51.94 ms；这些仅用于工程预算，没有正式排名。相应规划预算约 41.55 ms，XOffset 加载以外已占约 33.09 ms，若其余不动，两次加载仅能用约 8.46 ms。因此单纯池化节点、少做几个 lookup 无法充分支持目标，需要移除加载中的逐区间树维护，并继续压低修改开销。新旧 XOffset 同窗比较用于识别本次收益，不能从跨窗口均值估计因果加速。

## V1：将在线区间树替换为精确占用位图

v2 中加载叶样本主要落在 `register_owned_range`，树节点数约 20 万，key 比较为数百万。新方案分别维护 owned/free 两个字节精确位图：arena 中每个字节对应一个 bit，范围 `[begin,end)` 的 word 掩码执行 overlap 查询和登记；不是把未对齐范围向 8 字节取整。

先验证指针、长度、溢出和实际 extent，再按旧优先级完整检查两类 overlap，最后 prepare 目标页并 commit 标记。owned 登记优先拒绝 owned overlap，再拒绝 live/free；free 登记优先拒绝 live overlap，再拒绝 free overlap。子对象必须仍在其父 buffer 登记成功之后才访问，不能先收集所有区间最后排序校验。重复 allocation、共享子对象、包含交叉和空闲链表环必须在原步骤被拒绝。

位图分段惰性申请，目录依据已验证的实际存储范围而非对象声明数量。首选每 4096 个 arena 字节一页 512 字节位图，以实际反例和实现审查定稿。正常已登记范围在每类内部互斥，所以所有成功范围的 word 检查与标记总量受实际 arena 覆盖量约束：`O(R + U/64)`，其中 R 是登记次数、U 是已验证字节范围；首个失败另加至多一次范围扫描。无需 `O(R log R)` 的节点查询与平衡。随机/逆序插入具有相同位图访问上界，不依赖遍历近似地址有序。

两类逻辑位图加目录的规划空间约 `U/4 + U/256`，另计惰性页舍入及 PMR upstream slack，最终报告按实际结构修正公式。单个大型连续分配需要扫描其 bitmap words，必须单独验证；不能只报小 allocation 的常数复杂度。成功/失败时占用集合不变式与实际资源申请分开：OOM 可以留下尚未使用的 scratch 页，但不得部分登记范围或发布 typed root，所有 scratch 随 context 释放。多个 context、默认 PMR 隔离和可重入失败仍需验证。

保留旧三参 map helper 的函数类型用于内部对照；生产登记不能维护影子 map。原测试对 tree 的迭代/find/节点申请假设须迁移为真实 bitmap 状态核对，继续保留独立 pairwise oracle、错误优先级与逐步骤故障注入。旧 PMR 节点计数不再冒充当前工作量。

LLVM 官方文档区分 dense bit-vector 的逐 word 运算与 sparse 表示的随机访问代价，支持先选简单 word bitmap 而非默认稀疏链表结构；它不保证本项目的实际速度。[LLVM Programmer’s Manual](https://www.llvm.org/docs/ProgrammersManual.html)。Boost 的块级位图接口也体现相同基本表示；本版不为此升级依赖或新增 Boost 子模块。[Boost DynamicBitset](https://www.boost.org/library/latest/dynamic_bitset/)。

## V2：避免全量替换前复制旧字符串

审查 `XFixedString::assign` 的增长分支。原 reserve 可能先复制旧内容，随后 assign 再将其全部覆盖。新路径应在 in-place 和 try-expand 规则保持的前提下，准备新 buffer 和 rel32，直接从原 rhs 复制新内容，终止字符成功写入后无抛提交并退休旧 allocation。源可能是自身完整 view、子串或 arena 内其他对象，复制必须在退休旧 buffer 之前完成。

不承诺 arena 申请或 owner 查找减少；首要机制收益是避免被完整覆盖的旧字节复制。容量策略、空串语义、增长/上限、绑定、异常与别名保证不变。`resize` 后逐元素覆盖仍含公共 API 所要求的构造，不能在无新契约的情况下删去它。已有 `resize_and_overwrite` 输出优化不能重复计收益。进一步修改保护缓存必须先证明 epoch/move/swap/release 和 ancestor alias 安全，不能直接跳过原检查。

## 分工与阶段

| 阶段 | 工作 | 责任与写入边界 | 验收 |
| --- | --- | --- | --- |
| V0 | 基线、研究、成本预算和协议预注册 | root：新 worktree、新协调账本 | v2 与历史受保护，真实工具链身份可核 |
| V1a | bitmap 结构、补丁、oracle/OOM 测试 | linux_validation：`build/performance-v3/interval-index` | 先给设计，再独立补丁；不改共享头或 native 执行 |
| V1b | 顺序集成 bitmap | root 唯一生产头/CMake 写入者 | 针对 normal/SAN、独立拒绝 oracle、实际 OOM、旧新 typed load |
| V2a | 全量字符串替换与测试 | windows_validation：`build/performance-v3/mutation` | alias、跨 arena、in-place/增长与真实故障；名称不代表 Windows P2996 已通过 |
| V2b | 顺序集成修改优化 | root | 不受 benchmark 模式特化，机制预算真实 |
| V3 | 完整库、五库 S/M/L、V1、消费 | root 执行，代理只读审查 | normal/SAN、正控、双向 reader/writer、干净安装与子工程 |
| V4 | 固定机制诊断 | root 唯一 native 执行者 | 真实裸头→诊断头确定变换、实际对象依赖、九阶段 canonical/query；不作时间样本 |
| V5a | 六角色协议、审查与冻结 | n7_prerequisites 设计/审查；root 实现 | 旧X/newX+四竞品，同业务和保存/退休/释放账本，先冻结预算/统计再测 |
| V5b | 单一正式窗口 | root，其他代理停止重负载 | 编译/重测试/归档不并行；不追加样本或重跑挑数据 |
| V6 | 独立结果审查、旧证据保护和验收 | 三代理只读交叉审查，root 封存 | 目标达成、未达成、计时不确定分别报告；失败证据不改 |

状态在 `docs/coordination/performance-v3-20261017/plan.json`。当前工具没有 TaskCreate/TaskUpdate，使用可审计账本逐阶段自动推进。每次构建/修正保留新 attempt 目录，不删除首次失败；正确性修复后可以继续功能验证，不把它算性能重试。

## 测量设计要求

新的六角色协议不能伪装旧五库 285-child 协议。旧协议和失败窗口完全保留，新协议独立命名和版本，预先写清角色、平衡日程、样本数、warmup、wall/CPU 口径、配对规则、同时区间、环境诊断和失败规则。稳定性门槛须服务于 20% 可检出目标；不得在看到本版结果后调整阈值或选择统计方法。固定预算内的环境资格与正式效应判定分别列明，资格失败不得重开窗口直到通过。

每个角色必须执行相同 canonical 和 query 检查，实际 binary/headers/runtime/source 身份绑定，原输入脱离、owning wire 和所有实际生产校验保持计时。旧X/newX都为无插桩 Release -O3。对新候选的安全检查额外成本可另行研究，但不能将 unchecked 模式用于本版胜负判断。只读映射、长期驻留或更接近安全保证的比较可以另建场景，不能替换本版主目标。

若本版无法达到目标，交付实际差距和已验证优化，明确未达成；不以降低校验、删去操作、换场景、隐去临时内存、放宽 V1 或筛选失败窗口来制造结果。
