# v5：测量资格、真实成本与实现路线

2026-10-18，开发候选；不提交、推送、合并、发布或触发远端 CI。

真实起点是功能已验收的 v4 主头 `7a7bbf204785ac073a1111533c924e2894b8a9b0b6c6b0030eac0c538c6710ac`，不是 Git HEAD。旧 v4 的六项 A/A 未证等价、竞争目标未达成，状态保持原样。新 worktree 为 `C:/Users/gzsufanchen/.codex/worktrees/performance-v5/xoffsetdatastructure开发`；新原生目录为 `/root/xoffset-performance-v5/20261018/v1`。

## 不变的目标与保证

仍在相同 M mixed-growth trusted-detached、owning 完整生命周期上比较四个固定竞品和旧 XOffset 控制。新候选相对每个竞品的几何延迟比点估计及同时单侧上界均须 ≤0.80，并且全部 A/A 合格，才验收“明显超过”。不以换场景、只比查询、借用输入或省略校验达标。

保留 V1 wire/container 布局、完整在线校验、错误优先级、OOM/异常保证及既有 API。公共 API 的生命周期与用户回调保证优先于裸指针缓存。历史源、工具、成功/失败证据不可回写；所有新构建、诊断、资格检查和唯一正式窗口使用新目录。没有 TaskCreate 工具，以 coordination 下的 `plan.json` 管理阶段。

## 已知事实和待证假设

- 六 A/A 区间全部包含 1；未完全位于 `[1/1.05,1.05]`，说明等价资格不足，不能宣称已证六种真实顺序偏差。
- 旧统计有 8 个 macrocycle、df7，同时临界值约3.636。必须查实际配对离散度、时间相关与资源观测；不能把48块直接改名为独立样本缩窄区间。新协议的样本量、推断单元及模型在新测量前冻结，不用于回算旧窗口为合格。
- 宿主只读检查为 i9-13900K、24物理核/32逻辑CPU、平衡电源；WSL却报告16核/32CPU的虚拟拓扑。guest CPU2亲和不能证明物理P核独占。全局租约只覆盖遵守它的任务，不能宣称排除了全部宿主噪声。
- v4 的owner入口减少8192，但arena申请仍53248；bulk全部fresh、尾部扩展成功0。非bool标量叶校验旧模板已为空，实际消除情况应看机器码；源码潜在迭代数不是节省CPU工作。dense减少上游调用却增加请求字节和全页word标记。保存路径已有单次输出复制。

## 阶段和代理写入边界

| 阶段 | 负责人及输出边界 | 验收 |
|---|---|---|
| R0 诊断 | root集成；measurement代理只写`build/performance-v5/measurement`；旧数据只读 | AA精度/趋势/CPU与wall证据；真实热点、成本变化和无法归因的部分分开 |
| R1 可靠测量 | measurement提出协议、root执行限额资格诊断；独立代理审查 | 固定精度预算、相关性模型、真实runner请求类型回归；任何资格诊断均事前限额，不作跨库排名或反复重试 |
| R2 owner/修改 | mutation代理只写`build/performance-v5/mutation`补丁/测试；root唯一集成 | 稳定host身份，move/swap/release/new_handler/重入/OOM/线程退出覆盖；不持registry锁跨用户代码，不跨回调保存裸Core指针 |
| R3 位图 | validation代理只写`build/performance-v5/validation`补丁/测试 | 精确word-any/full摘要与惰性data word；独立oracle、owned优先、资源故障、边界与稀疏大arena；显式scratch预算 |
| R4 门禁 | root串行执行，代理交叉读审 | 全库normal/SAN、正控、五库S/M/L、V1旧控制双向、干净安装/子工程消费、实际依赖绑定及非计时机制 |
| R5 冻结/正式窗 | root唯一执行，全体代理quiet | 通过资格和功能后冻结源/工具/依赖/日程；新目录唯一单窗口五库＋旧X控制，不追加或挑样本 |
| R6 验收 | 代理独立复算，root保护核验/封存 | 功能、测量完整性、统计资格、竞争目标分别记录；未达标不晋升基线 |

R2初步设计是payload生命周期绑定的host-only稳定OwnerRecord；Core移动只更新record，热定位不缓存跨回调Core地址。缓存必须辨别dead record和基址复用，冷路径分配不得发生在registry锁内。实际53248个live申请中，多数来自必要的新内容和新record，不虚报消除了申请次数；优先降低真实申请链常数。

R3初步设计为每页word-any/full两条64bit摘要，范围内部完整word只查/置摘要，最多两个边界读写data word；未初始化data必须受摘要严格保护。保留dense prefix和lazy paged tail，按原硬预算反算dense阈值，较大extent仍合法进入paged路径。复杂度减少不直接换算成毫秒收益。

## 环境和研究依据

先使用项目独立工具链与Linux原生磁盘，重负载全部取得共享租约；正式窗口不并行编译、扫描、归档或代理native任务。不擅自重启WSL或改变所有发行版的全局配置。增加可获得的CPU时间、上下文切换、缺页、调度等待观测，并明确没有观测到的宿主频率/物理调度。

- [Google Benchmark：Reducing Variance](https://github.com/google/benchmark/blob/main/docs/reducing_variance.md)：频率、抢占、SMT、缓存和CPU选择都可能影响方差；建议本身不是本机因果证据。
- [Microsoft WSL配置](https://learn.microsoft.com/en-us/windows/wsl/wsl-config)：`.wslconfig`作用于全部WSL2发行版，processors是VM配置；不把它当物理核心隔离证明。
- [Linux Scheduler Statistics](https://www.kernel.org/doc/html/latest/scheduler/sched-stats.html)：`/proc/<pid>/schedstat`提供CPU执行与runqueue等待等字段；实际是否启用需本机核验。
- [Linux perf sched文档](https://github.com/torvalds/linux/blob/master/tools/perf/Documentation/perf-sched.txt)：仅在事件/权限可用时使用调度观测，不伪造缺失计数。

N7仍缺真实业务入口，原生Windows完整P2996仍开放，不因本轮性能工作关闭。
