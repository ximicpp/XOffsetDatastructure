"""Pure Python evidence/statistics tests: no native executable is launched."""
import copy
import hashlib
import importlib.util
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
import core as C
import protocol as P
import campaign as H


def put(path,raw):
    path = Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(raw)


def reseal(path):
    (path/"manifest.json").unlink()
    C.write(path/"manifest.json",dict(schema_version=1,files=C.inventory(path,exclude_roots=("queue",))))


def fixture(path,n=16384):
    path.mkdir(parents=True)
    for name in H.FILES:
        put(path/name,("synthetic-test-only:"+name).encode())
    put(path/"queries.bin",H.query_pair((path/"query-before.bin").read_bytes(),(path/"query-after.bin").read_bytes()))
    manifest = dict(schema="sc-fixture-v1",model_version=1,n=n,seed="xoffset-competitor-v1",trace_name="mixed-growth-v1",query_name="query-v1",
        input_digest=C.sha(path/"input.canonical.bin"),final_digest=C.sha(path/"final.canonical.bin"),query_before_digest=C.sha(path/"query-before.bin"),query_after_digest=C.sha(path/"query-after.bin"),query_count=1,mutation_count=9,
        stages=[dict(stage=i,mutation_count=1,canonical_sha256=hashlib.sha256(str(i).encode()).hexdigest()) for i in range(1,10)],
        files={name:dict(bytes=(path/name).stat().st_size,sha256=C.sha(path/name)) for name in H.FILES})
    C.write(path/"fixture.json",manifest)


def native(path,entry,fixture_dir,input_wire,wire,canon,queries,total=1000000):
    put(wire,b"synthetic-output-wire")
    shutil.copyfile(fixture_dir/"final.canonical.bin",canon)
    shutil.copyfile(fixture_dir/"queries.bin",queries)
    row = dict(schema_version=1,kind="serialization-comparison-native-result",library=entry["library"],status="passed",
        phase_ns={p:str(total//8) for p in H.PHASES},total_ns=str(total),
        input_sha256=C.sha(input_wire),trace_sha256=C.sha(fixture_dir/"trace.bin"),final_wire_sha256=C.sha(wire),final_canonical_sha256=C.sha(canon),
        queries_sha256=C.sha(queries),query_before_sha256=C.sha(fixture_dir/"query-before.bin"),query_after_sha256=C.sha(fixture_dir/"query-after.bin"),
        peak_rss_before_audit_kib="100",peak_rss_after_audit_kib="101",cpu_ns="1000",minor_faults="1",major_faults="0",record_count=str(C.read(fixture_dir/"fixture.json")["n"]))
    C.write(path,row)
    return row


def synthetic_frozen(path,window="/original/run"):
    path.mkdir()
    fixture(path/"fixture")
    binaries = {}
    for lib in P.LIBRARIES:
        put(path/"bin"/lib,("NOT-EXECUTABLE-synthetic-"+lib).encode())
        put(path/"input-wires"/(lib+".wire"),b"synthetic-input-"+lib.encode())
        binaries[lib] = dict(path="/unavailable/original/bin/"+lib,prefix=[],library=P.IDENTITIES[lib][0],commit=P.IDENTITIES[lib][1],trust_mode="trusted-synthetic",load_contract="detached")
    profile = dict(schema_version=1,platform_class="wsl2-vm-x86_64",lock_dir="/original/shared/build/vm-coordination",
        environment={"LANG":"C","LC_ALL":"C","PATH":"/usr/bin:/bin","TZ":"UTC"},binaries=binaries,closure={"not-included-runtime":"/unavailable/runtime"})
    C.write(path/"profile.json",profile)
    H.save_tools(path)
    runtime = dict(binaries={lib:C.file_id(path/"bin"/lib) for lib in P.LIBRARIES},closure={"synthetic-only":{}},tools=H.tools_identity(),interpreter=dict(path="/exact/python3",identity=dict(bytes="123",sha256="1"*64)),environment=profile["environment"],platform_class=profile["platform_class"])
    C.write(path/"runtime.json",runtime)
    C.write(path/"schedule.json",P.schedule())
    C.write(path/"policy.json",P.POLICY)
    C.write(path/"functional-reference-manifest.json",dict(schema_version=1,files={}))
    C.write(path/"functional-reference-status.json",dict(synthetic_test_only=True))
    C.write(path/"p4-evidence.json",dict(synthetic_test_only=True))
    C.write(path/"authorization.json",dict(schema_version=1,user_authorization="Synthetic unit test only, never a real timing authorization",p4_evidence="/external/synthetic-p4.json",p4_passed=True,quiet_window_confirmed=True,window_out=window))
    C.seal(path,dict(schema_version=1,kind="sc-frozen",status="complete",window_out=window,functional_manifest=C.file_id(path/"functional-reference-manifest.json"),p4_evidence=C.file_id(path/"p4-evidence.json"),
        predicted_new_wire_bytes=str(285*21),final_wire_bytes={lib:"21" for lib in P.LIBRARIES},performance_accepted=False,old_N3_authorization_reused=False))
    return profile,runtime


def synthetic_run(root,count=55,fail_anchor=True):
    out = root/"run"
    out.mkdir()
    frozen=out/"frozen"
    profile,runtime = synthetic_frozen(frozen)
    external=C.sha(frozen/"manifest.json")
    C.write(out/"frozen-pin.json",dict(sha256=external))
    C.write(out/"runtime-before.json",runtime)
    C.write(out/"runtime-after.json",runtime)
    H.save_tools(out)
    original=PurePosixPath("/original/run")
    command=["/exact/python3","/exact/campaign.py","run","--frozen","/original/frozen","--frozen-sha256",external,"--out",str(original),"--queue",str(original/"queue")]
    request=dict(schema_version=1,run_id="unique-synthetic",owner="W3",kind="timing",command=command,cwd="/original",out=str(original/"queue"),lock_dir=profile["lock_dir"],runner_sha256=C.sha(H.RUNNER),timeout_seconds=2700,created_at="2026-10-17T00:00:00+00:00",wait_seconds=0,termination_grace_seconds=2)
    (out/"queue").mkdir()
    C.write(out/"queue/request.json",request)
    context=dict(schema_version=1,action="run",original_output=str(original),request=request,queue_request_sha256=C.sha(out/"queue/request.json"),
        interpreter=dict(path="/exact/python3",identity=dict(bytes="123",sha256="1"*64)),requested_interpreter="/exact/python3",adapter_path="/exact/campaign.py",tools=H.tools_identity(),
        inputs={"--frozen":dict(original_path="/original/frozen/manifest.json",identity=C.file_id(frozen/"manifest.json"))})
    C.write(out/"execution-context.json",context)
    jobs=P.schedule()[:count]
    samples=[]
    (out/"commands").mkdir()
    for index,job in enumerate(jobs):
        lib,name=job["library"],job["id"]
        entry=profile["binaries"][lib]
        prefix=original/"commands"/name
        wire,canon,queries,result=(prefix.with_suffix(e) for e in (".wire",".canonical",".queries",".native.json"))
        actual=out/"commands"/name
        actual.parent.mkdir(exist_ok=True)
        total=1000000
        if fail_anchor and job["kind"]=="aa" and job["side"]=="A": total=2000000
        row=native(actual.with_suffix(".native.json"),entry,frozen/"fixture",frozen/"input-wires"/(lib+".wire"),actual.with_suffix(".wire"),actual.with_suffix(".canonical"),actual.with_suffix(".queries"),total)
        argv=H.command(entry,"run","--wire",original/"frozen/input-wires"/(lib+".wire"),"--trace",original/"frozen/fixture/trace.bin","--wire-out",wire,"--canonical-out",canon,"--queries-out",queries,"--result",result,binary=original/"frozen/bin"/lib)
        receipt=dict(schema_version=1,argv=argv,execution_environment=profile["environment"],timeout_seconds=20,started_monotonic_ns=str(100000000+index*10000000),finished_monotonic_ns=str(105000000+index*10000000),returncode=0,timed_out=False,pid=index+100,launch_error=None,file_limit_bytes=str(1024**2))
        C.write(actual.with_suffix(".receipt.json"),receipt)
        put(actual.with_suffix(".stdout"),b"")
        put(actual.with_suffix(".stderr"),b"")
        samples.append(dict(job=job,total_ns=row["total_ns"]))
    failed=count!=285 or fail_anchor
    qresult=dict(schema_version=1,run_id=request["run_id"],owner="W3",kind="timing",status="failed" if failed else "complete",command_returncode=1 if failed else 0,command_elapsed_seconds=3.0,finished_at="2026-10-17T00:00:03+00:00",cleanup={"live":[],"zombies":[],"process_groups":[]})
    C.write(out/"queue/result.json",qresult)
    for name in ("stdout.log","stderr.log","supervisor.log"): put(out/"queue"/name,b"")
    C.write(out/"queue/events.json",[])
    qfiles=C.inventory(out/"queue")
    C.write(out/"queue/manifest.json",dict(schema_version=1,files=[dict(path=k,bytes=int(v["bytes"]),sha256=v["sha256"]) for k,v in qfiles.items()]))
    rebuilt=P.summary(samples)
    if failed: rebuilt["performance_accepted"]=False
    C.write(out/"summary.json",rebuilt)
    C.seal(out,dict(schema_version=1,kind="sc-run",status="failed" if failed else "complete",error="anchor qualification failed: pre" if failed else None,
        attempted=jobs,successful_children=count,unexecuted=P.schedule()[count:],new_wire_bytes=str(count*len(b"synthetic-output-wire")),elapsed_ns="3000000000",performance_accepted=not failed))
    return out,external


def synthetic_functional(root):
    profile,runtime=synthetic_frozen(root/"basis")
    out=root/"functional";out.mkdir()
    prepared=out/"prepared";prepared.mkdir()
    put(prepared/"reference.py",b"# synthetic fixture source, never executed\n")
    for size,n in H.SIZES.items(): fixture(prepared/size,n)
    C.seal(prepared,dict(schema_version=1,kind="sc-prepared",status="complete",fixture_source=C.file_id(prepared/"reference.py"),original_fixture_source="/external/reference.py",record_counts=H.SIZES,performance_accepted=False))
    C.write(out/"profile.json",profile)
    C.write(out/"runtime-before.json",runtime);C.write(out/"runtime-after.json",runtime);H.save_tools(out)
    original=PurePosixPath("/original/functional")
    argv=["/exact/python3","/exact/campaign.py","functional","--prepared","/external/prepared","--profile","/external/profile.json","--out",str(original),"--queue",str(original/"queue")]
    request=dict(schema_version=1,run_id="unique-synthetic-functional",owner="W3",kind="functional",command=argv,cwd="/original",out=str(original/"queue"),lock_dir=profile["lock_dir"],runner_sha256=C.sha(H.RUNNER),timeout_seconds=3600,created_at="2026-10-17T00:00:00+00:00",wait_seconds=0,termination_grace_seconds=2)
    (out/"queue").mkdir();C.write(out/"queue/request.json",request)
    context=dict(schema_version=1,action="functional",original_output=str(original),request=request,queue_request_sha256=C.sha(out/"queue/request.json"),interpreter=runtime["interpreter"],requested_interpreter="/exact/python3",adapter_path="/exact/campaign.py",tools=H.tools_identity(),
        inputs={"--prepared":dict(original_path="/external/prepared/manifest.json",identity=C.file_id(prepared/"manifest.json")),"--profile":dict(original_path="/external/profile.json",identity=C.file_id(out/"profile.json"))})
    C.write(out/"execution-context.json",context)
    jobs=H.functional_jobs();completed=[];descriptions={}
    for index,job in enumerate(jobs):
        name,lib,size,action=job["id"],job["library"],job["size"],job["action"]
        actual=out/"commands"/name;actual.parent.mkdir(exist_ok=True)
        put(actual.with_suffix(".stdout"),b"");put(actual.with_suffix(".stderr"),b"")
        if action=="describe":
            description=dict(schema_version=1,library=profile["binaries"][lib]["library"],commit=profile["binaries"][lib]["commit"],trust_mode="trusted-synthetic",load_contract="detached",capabilities={"trusted_mutable":True})
            actual.with_suffix(".stdout").unlink();C.write(actual.with_suffix(".stdout"),description);descriptions[lib]=description
        else:
            prefix=out/"commands"/(lib+"-"+size);f=prepared/size
            if action=="encode": put(prefix.with_suffix(".input.wire"),b"synthetic-input-wire")
            elif action=="inspect-input": shutil.copyfile(f/"input.canonical.bin",prefix.with_suffix(".initial.canonical"))
            elif action=="validate": C.write(prefix.with_suffix(".validation.json"),dict(schema_version=1,kind="serialization-comparison-validation",library=profile["binaries"][lib]["library"],status="passed",stages=[s["canonical_sha256"] for s in C.read(f/"fixture.json")["stages"]]))
            elif action=="run": native(prefix.with_suffix(".native.json"),profile["binaries"][lib],f,prefix.with_suffix(".input.wire"),prefix.with_suffix(".wire"),prefix.with_suffix(".canonical"),prefix.with_suffix(".queries"))
            else:
                shutil.copyfile(f/"final.canonical.bin",prefix.with_suffix(".reloaded.canonical"))
                completed.append(dict(library=lib,size=size,input_wire=prefix.with_suffix(".input.wire").relative_to(out).as_posix(),result=prefix.with_suffix(".native.json").relative_to(out).as_posix()))
        receipt=dict(schema_version=1,argv=H.functional_argv(job,profile,original),execution_environment=profile["environment"],timeout_seconds=60,started_monotonic_ns=str(100000000+index*10000000),finished_monotonic_ns=str(105000000+index*10000000),returncode=0,timed_out=False,pid=index+100,launch_error=None,file_limit_bytes=str(512*1024**2))
        C.write(actual.with_suffix(".receipt.json"),receipt)
    C.write(out/"queue/result.json",dict(schema_version=1,run_id=request["run_id"],owner="W3",kind="functional",status="complete",command_returncode=0,command_elapsed_seconds=3.,finished_at="2026-10-17T00:00:03+00:00",cleanup={"live":[],"process_groups":[],"zombies":[]}))
    for name in ("stdout.log","stderr.log","supervisor.log"): put(out/"queue"/name,b"")
    C.write(out/"queue/events.json",[])
    qfiles=C.inventory(out/"queue");C.write(out/"queue/manifest.json",dict(schema_version=1,files=[dict(path=k,bytes=int(v["bytes"]),sha256=v["sha256"]) for k,v in qfiles.items()]))
    C.seal(out,dict(schema_version=1,kind="sc-functional",status="complete",error=None,completed=completed,descriptions=descriptions,attempted=jobs,unexecuted=[],p4_complete=False,performance_accepted=False))
    return out


class Primitives(unittest.TestCase):
    def test_launch_preflight_refuses_no_time_or_insufficient_ceiling(self):
        with tempfile.TemporaryDirectory() as tmp,mock.patch.object(H.time,"monotonic",return_value=100),mock.patch.object(H,"execute") as execute:
            attempted=[]
            for cap,deadline,retained,expected,limit,budget in ((20,100,0,1,5,10),(60,99.9,0,0,5,None),(20,110,6,1,5,10)):
                with self.subTest(cap=cap,deadline=deadline,budget=budget),self.assertRaises(C.ProtocolError):
                    timeout=H.launch_preflight(Path(tmp)/"unstarted",deadline,cap,retained,expected,limit,budget)
                    attempted.append("never-started")
                    H.execute([],Path(tmp)/"unstarted",timeout,{})
            self.assertEqual(attempted,[])
            execute.assert_not_called()
            self.assertEqual(H.launch_preflight(Path(tmp)/"fresh",101,20,0,1,5,10),1)
    def test_strict_json_and_decimal(self):
        for raw in (b'{"a":1,"a":2}',b'{"x":NaN}',b'{"x":1e999}',b'{}{}',b'\xff'):
            with self.subTest(raw=raw),self.assertRaises(C.ProtocolError): C.parse(raw)
        for value in (1,True,"01","+1","-0",str(2**64)):
            with self.subTest(value=value),self.assertRaises(C.ProtocolError): C.decimal(value)
        self.assertEqual(C.decimal("15740387299717957747"),15740387299717957747)

    def test_manifest_changes_extra_path_and_types(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);put(root/"raw",b"abc");C.seal(root,dict(status="complete"))
            C.check_inventory(root)
            put(root/"extra",b"")
            with self.assertRaises(C.ProtocolError): C.check_inventory(root)
        for path in ("../x","/x","a//b","a/./b","a\\b","C:x"):
            with self.subTest(path=path),self.assertRaises(C.ProtocolError): C.relative(path)

    def test_tree_empty_and_symlink(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/"empty").mkdir();before=C.tree_id(root)
            put(root/"empty/value",b"changed")
            self.assertNotEqual(before,C.tree_id(root))
            try: (root/"link").symlink_to(root/"empty",target_is_directory=True)
            except OSError: self.skipTest("symlink privilege unavailable")
            self.assertIn("./link@link",C.tree_id(root))
            (root/"empty/cycle").symlink_to(root,target_is_directory=True)
            with self.assertRaises(C.ProtocolError): C.tree_id(root)

    def test_dangling_source_link_spelling_and_later_materialization(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/"source";root.mkdir()
            target=Path(tmp)/"optional-build-system/rules"
            link=root/"ekam-rules"
            try: link.symlink_to("../optional-build-system/rules",target_is_directory=True)
            except OSError: self.skipTest("symlink privilege unavailable")
            missing=C.tree_id(root)
            self.assertEqual(missing["./ekam-rules@link"],"../optional-build-system/rules")
            self.assertEqual(missing["./ekam-rules@unavailable"]["kind"],"missing-symlink-target")
            self.assertEqual(missing["./ekam-rules@unavailable"]["resolved_target"],str(target))
            with self.assertRaises(C.ProtocolError): C.file_id(link)
            with self.assertRaises(C.ProtocolError): C.tree_id(root/"ordinary-missing")
            target.mkdir(parents=True);put(target/"rule",b"newly available")
            available=C.tree_id(root)
            self.assertNotEqual(missing,available)
            self.assertNotIn("./ekam-rules@unavailable",available)
            self.assertEqual(available["./ekam-rules/rule"],C.file_id(target/"rule"))
            shutil.rmtree(target)
            self.assertEqual(C.tree_id(root),missing)
            link.unlink();link.symlink_to("../optional-build-system/./rules",target_is_directory=True)
            self.assertNotEqual(C.tree_id(root),missing)

    def test_dangling_parent_chain_and_link_cycle(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/"source";root.mkdir()
            try:
                (root/"chain").symlink_to("../missing-parent/child",target_is_directory=True)
                (root/"via-parent").symlink_to("chain/rules",target_is_directory=True)
            except OSError: self.skipTest("symlink privilege unavailable")
            missing=C.tree_id(root)
            self.assertEqual(missing["./via-parent@unavailable"]["resolved_target"],str(Path(tmp)/"missing-parent/child/rules"))
            (Path(tmp)/"missing-parent/child/rules").mkdir(parents=True)
            self.assertNotEqual(C.tree_id(root),missing)
            (root/"loop-a").symlink_to("loop-b")
            (root/"loop-b").symlink_to("loop-a")
            with self.assertRaises(C.ProtocolError): C.tree_id(root)

    def test_real_querypair_contract_and_stage_digest(self):
        reference=H.import_fixture(H.ROOT/"experiments/serialization_comparison/model/reference.py")
        initial=reference.generate_snapshot(1)
        trace,_final=reference.generate_trace(initial)
        before=reference.evaluate_queries(initial,trace.queries)
        encoded=reference.encode_query_results(before)
        self.assertEqual(H.query_pair(encoded,encoded),reference.encode_query_pair(before,before))

    def test_prepare_calls_actual_python_fixture_and_refuses_reuse(self):
        with tempfile.TemporaryDirectory() as tmp,mock.patch.object(H,"SIZES",{"S":128}):
            out=Path(tmp)/"prepared"
            self.assertEqual(H.prepare(H.ROOT/"experiments/serialization_comparison/model/reference.py",out)["status"],"audit-passed")
            self.assertFalse((out/"__pycache__").exists())
            with self.assertRaises(C.ProtocolError): H.prepare(H.ROOT/"experiments/serialization_comparison/model/reference.py",out)

    def test_native_execution_requires_live_global_lease(self):
        with tempfile.TemporaryDirectory() as tmp:
            with mock.patch.object(H.subprocess,"Popen") as popen:
                with self.assertRaises((C.ProtocolError,OSError)): H.active_queue(Path(tmp),{},"run",{})
                popen.assert_not_called()


class Statistics(unittest.TestCase):
    def test_schedule_exact_counts_positions_and_prefix(self):
        rows=P.schedule()
        self.assertEqual(len(rows),285)
        self.assertEqual(sum(r["kind"]=="aa" for r in rows),120)
        self.assertEqual(sum(r["kind"]=="comparison" for r in rows),150)
        for lib in P.LIBRARIES:
            for position in range(5): self.assertEqual(sum(r["kind"]=="comparison" and r["library"]==lib and r["position"]==position for r in rows),6)
        self.assertEqual([max(i for i,j in enumerate(rows) if j.get("anchor")==a)+1 for a in P.ANCHORS],[55,170,285])
        samples=[dict(job=j,total_ns="1000") for j in rows[:55]]
        self.assertTrue(P.anchor_gates(samples,"pre")["qualified"])
        samples[15]["total_ns"]="2000"
        self.assertFalse(P.anchor_gates(samples,"pre")["qualified"])
        samples.append(dict(job=rows[55],total_ns="1000"))
        with self.assertRaises(C.ProtocolError): P.summary(samples)

    def test_reproducible_resampling_and_quantile(self):
        # Independent direct SHA oracle for the ordinary (non-rejected) index.
        for b,s,j in ((0,0,0),(0,1,0),(9999,1,14)):
            raw=("xoffset-bb-v1|%s|%s|%s|0"%(b,s,j)).encode()
            self.assertEqual(P.bootstrap_index(b,s,j),15*s+int.from_bytes(hashlib.sha256(raw).digest()[:8],"little")%15)
        self.assertEqual(P.quantile([0,10],0.25),2.5)

    def test_comparison_and_warmup_exclusion(self):
        samples=[dict(job=j,total_ns="1000" if j["kind"]!="comparison" or j["library"]=="xoffset" else "1200") for j in P.schedule()]
        # Absurd warmup times cannot enter either the anchor or main estimator.
        for sample in samples[:15]: sample["total_ns"]="9999999999"
        result=P.summary(samples)
        self.assertTrue(result["measurement_qualified"])
        self.assertEqual(result["excluded_warmup_children"],15)
        for lib in P.LIBRARIES[1:]:
            self.assertAlmostEqual(result["comparison"]["comparisons"][lib]["median_paired_ratio"],1.2)
            self.assertEqual(result["comparison"]["comparisons"][lib]["decision"],"competitor_slower_at_relevance_threshold")

    def test_drift_gate_cannot_be_hidden_by_local_pairs(self):
        samples=[]
        for job in P.schedule()[:170]:
            samples.append(dict(job=job,total_ns="1100" if job.get("anchor")=="mid" else "1000"))
        result=P.anchor_gates(samples,"mid")
        self.assertFalse(result["qualified"])
        self.assertTrue(all(r["anchors"]["mid"]["qualified"] for r in result["libraries"].values()))


class OfflineAudit(unittest.TestCase):
    def test_complete_queue_strict_created_to_finished_budget(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp),0,False)
            profile=H.read_profile(out/"frozen/profile.json")
            path=out/"queue/result.json"
            for elapsed,finished,passes in ((2700.,"2026-10-17T00:45:00+00:00",True),
                                           (2699.99,"2026-10-17T00:45:00.000001+00:00",False),
                                           (2700.1,"2026-10-17T00:45:00.100000+00:00",False)):
                row=C.read(path);row.update(status="complete",command_returncode=0,command_elapsed_seconds=elapsed,finished_at=finished);path.unlink();C.write(path,row)
                (out/"queue/manifest.json").unlink();qfiles=C.inventory(out/"queue");C.write(out/"queue/manifest.json",dict(schema_version=1,files=[dict(path=k,bytes=int(v["bytes"]),sha256=v["sha256"]) for k,v in qfiles.items()]))
                with self.subTest(elapsed=elapsed,finished=finished):
                    if passes: self.assertEqual(H.queue_audit(out,profile,"run")["status"],"complete")
                    else:
                        with self.assertRaises(C.ProtocolError): H.queue_audit(out,profile,"run")

    def test_successful_receipt_and_native_result_have_no_cleanup_allowance(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp),1,False)
            path=out/"commands/j000.receipt.json";receipt=C.read(path)
            receipt["finished_monotonic_ns"]=str(int(receipt["started_monotonic_ns"])+20000000001)
            path.unlink();C.write(path,receipt)
            with self.assertRaises(C.ProtocolError): H._receipt(out,"j000",receipt["argv"],receipt["execution_environment"],maximum=20,file_limit=1024**2)
            profile=H.read_profile(out/"frozen/profile.json")
            with self.assertRaises(C.ProtocolError): H.native_result(out/"commands/j000.native.json",profile["binaries"]["xoffset"],out/"frozen/fixture",out/"frozen/input-wires/xoffset.wire",out/"commands/j000.wire",out/"commands/j000.canonical",out/"commands/j000.queries",receipt,21)

    def test_exit_zero_observed_late_is_recorded_as_timeout(self):
        for interval,passes in ((20000000000,True),(20000000001,False)):
            with self.subTest(interval=interval),tempfile.TemporaryDirectory() as tmp:
                process=mock.Mock();process.pid=123;process.wait.return_value=0;process.returncode=0;process.poll.return_value=0
                prefix=Path(tmp)/"child"
                with mock.patch.object(H.subprocess,"Popen",return_value=process),mock.patch.object(H.time,"monotonic_ns",side_effect=[100,100+interval]):
                    if passes: H.execute(["synthetic-never-executed"],prefix,20,{"LANG":"C"})
                    else:
                        with self.assertRaises(C.ProtocolError): H.execute(["synthetic-never-executed"],prefix,20,{"LANG":"C"})
                self.assertEqual(C.read(prefix.with_suffix(".receipt.json"))["timed_out"],not passes)
    def test_preflight_empty_prefix_and_deadline_failure_are_auditable(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp),0,False)
            path=out/"status.json";row=C.read(path);row["error"]="child deadline exhausted before launch";row["elapsed_ns"]="2700000100000";path.unlink();C.write(path,row)
            path=out/"queue/result.json";row=C.read(path);row["command_elapsed_seconds"]=2700.001;row["finished_at"]="2026-10-17T00:45:00.001000+00:00";path.unlink();C.write(path,row)
            (out/"queue/manifest.json").unlink();qfiles=C.inventory(out/"queue");C.write(out/"queue/manifest.json",dict(schema_version=1,files=[dict(path=k,bytes=int(v["bytes"]),sha256=v["sha256"]) for k,v in qfiles.items()]))
            reseal(out)
            self.assertEqual(H.audit(out,pin,H.postrun_pin(out))["status"],"audit-preserved-failure")
            self.assertEqual(C.read(out/"status.json")["attempted"],[])

    def test_last_child_deterministic_size_rejection_preserves_failure(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp),1,False)
            put(out/"commands/j000.wire",b"synthetic-output-wire-with-an-extra-tail")
            path=out/"commands/j000.native.json";row=C.read(path);row["final_wire_sha256"]=C.sha(out/"commands/j000.wire");path.unlink();C.write(path,row)
            path=out/"status.json";row=C.read(path);row["successful_children"]=0;row["new_wire_bytes"]=str((out/"commands/j000.wire").stat().st_size);row["error"]="deterministic final wire size changed";path.unlink();C.write(path,row)
            (out/"summary.json").unlink();C.write(out/"summary.json",P.summary([]));reseal(out)
            self.assertEqual(H.audit(out,pin,H.postrun_pin(out))["status"],"audit-preserved-failure")

    def test_receipt_span_and_elapsed_ledgers_are_bound(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp))
            path=out/"status.json";row=C.read(path);row["elapsed_ns"]="1";path.unlink();C.write(path,row);reseal(out)
            with self.assertRaises(C.ProtocolError): H.audit(out,pin)
    def test_complete_80_child_functional_offline_and_stage_tamper(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=synthetic_functional(Path(tmp))
            self.assertEqual(H.audit(out)["status"],"audit-passed")
            path=out/"commands/xoffset-S.validation.json";row=C.read(path);row["stages"][0]="0"*64;path.unlink();C.write(path,row);reseal(out)
            with self.assertRaises(C.ProtocolError): H.audit(out)

    def test_timeout_partial_wire_exact_failure_prefix(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp),1,False)
            path=out/"commands/j000.receipt.json";row=C.read(path);row["timed_out"]=True;row["returncode"]=-9;path.unlink();C.write(path,row)
            put(out/"commands/j000.wire",b"partial-wire")
            for ext in (".native.json",".canonical",".queries"): (out/"commands"/("j000"+ext)).unlink()
            path=out/"status.json";row=C.read(path);row["successful_children"]=0;row["new_wire_bytes"]=str(len(b"partial-wire"));row["error"]="native child failed/timed out";path.unlink();C.write(path,row)
            (out/"summary.json").unlink();C.write(out/"summary.json",P.summary([]));reseal(out)
            self.assertEqual(H.audit(out,pin,H.postrun_pin(out))["status"],"audit-preserved-failure")
            path=out/"status.json";row=C.read(path);row["new_wire_bytes"]="0";path.unlink();C.write(path,row);reseal(out)
            with self.assertRaises(C.ProtocolError): H.audit(out,pin)
    def test_complete_bundle_requires_independent_post_pin_for_acceptance(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp),285,False)
            self.assertFalse(H.audit(out,pin)["performance_accepted"])
            post=H.postrun_pin(out)
            self.assertTrue(H.audit(out,pin,post)["performance_accepted"])
            path=out/"commands/j000.native.json";row=C.read(path);row["cpu_ns"]="9000";path.unlink();C.write(path,row);reseal(out)
            with self.assertRaises(C.ProtocolError): H.audit(out,pin,post)

    def test_composite_postpin_binds_queue_reseal(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp))
            post=H.postrun_pin(out)
            path=out/"queue/result.json";row=C.read(path);row["command_elapsed_seconds"]=3.5;row["finished_at"]="2026-10-17T00:00:03.500000+00:00";path.unlink();C.write(path,row)
            (out/"queue/manifest.json").unlink();qfiles=C.inventory(out/"queue");C.write(out/"queue/manifest.json",dict(schema_version=1,files=[dict(path=k,bytes=int(v["bytes"]),sha256=v["sha256"]) for k,v in qfiles.items()]))
            # Internal consistency remains possible, but the external composite pin rejects.
            self.assertEqual(H.audit(out,pin)["status"],"audit-preserved-failure")
            with self.assertRaises(C.ProtocolError): H.audit(out,pin,post)

    def test_preserved_failed_anchor_portable_and_external_pin(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp))
            self.assertEqual(H.audit(out,pin)["status"],"audit-preserved-failure")
            with self.assertRaises(C.ProtocolError): H.audit(out)
            with self.assertRaises(C.ProtocolError): H.audit(out,"0"*64)

    def test_resealed_wrong_argv_is_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            out,pin=synthetic_run(Path(tmp))
            path=out/"commands/j000.receipt.json"
            row=C.read(path);row["argv"][0]="/wrong/binary";path.unlink();C.write(path,row);reseal(out)
            with self.assertRaises(C.ProtocolError): H.audit(out,pin)

    def test_resealed_overlap_and_summary_tamper_are_detected(self):
        for mutate in ("overlap","summary"):
            with self.subTest(mutate=mutate),tempfile.TemporaryDirectory() as tmp:
                out,pin=synthetic_run(Path(tmp))
                path=out/("commands/j001.receipt.json" if mutate=="overlap" else "summary.json")
                row=C.read(path)
                if mutate=="overlap": row["started_monotonic_ns"]="100000001"
                else: row["measurement_qualified"]=True
                path.unlink();C.write(path,row);reseal(out)
                with self.assertRaises(C.ProtocolError): H.audit(out,pin)

    def test_raw_wire_mutation_after_reseal_and_cleanup_residue(self):
        for mutate in ("wire","cleanup"):
            with self.subTest(mutate=mutate),tempfile.TemporaryDirectory() as tmp:
                out,pin=synthetic_run(Path(tmp))
                if mutate=="wire": put(out/"commands/j000.wire",b"bad")
                else:
                    path=out/"queue/result.json";row=C.read(path);row["cleanup"]["live"]=[999];path.unlink();C.write(path,row)
                    (out/"queue/manifest.json").unlink();qfiles=C.inventory(out/"queue");C.write(out/"queue/manifest.json",dict(schema_version=1,files=[dict(path=k,bytes=int(v["bytes"]),sha256=v["sha256"]) for k,v in qfiles.items()]))
                reseal(out)
                with self.assertRaises(C.ProtocolError): H.audit(out,pin)

    def test_timeout_launch_failure_capture_without_running_process(self):
        with tempfile.TemporaryDirectory() as tmp:
            prefix=Path(tmp)/"child"
            with mock.patch.object(H.subprocess,"Popen",side_effect=FileNotFoundError("synthetic launch error")),self.assertRaises(C.ProtocolError):
                H.execute(["/never/executed"],prefix,1,{"LANG":"C"})
            row=C.read(prefix.with_suffix(".receipt.json"))
            self.assertIsNone(row["pid"])
            self.assertIsNone(row["returncode"])
            self.assertIn("FileNotFoundError",row["launch_error"])

    def test_timeout_receipt_is_preserved_without_running_process(self):
        with tempfile.TemporaryDirectory() as tmp:
            process=mock.Mock()
            process.pid=123
            process.wait.side_effect=[H.subprocess.TimeoutExpired(["synthetic"],1),-9]
            process.returncode=-9
            process.poll.return_value=-9
            prefix=Path(tmp)/"child"
            with mock.patch.object(H.subprocess,"Popen",return_value=process),self.assertRaises(C.ProtocolError):
                H.execute(["synthetic-never-executed"],prefix,1,{"LANG":"C"})
            row=C.read(prefix.with_suffix(".receipt.json"))
            self.assertTrue(row["timed_out"])
            self.assertEqual(row["returncode"],-9)
            process.kill.assert_called_once()


if __name__=="__main__": unittest.main()
