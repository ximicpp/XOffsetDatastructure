# Five-library campaign tools

This directory is separate from the released alpha and historical N3 tools.
`campaign.py` has independent `prepare`, `functional`, `freeze`, `run`, `audit`,
and `report` commands. Native commands are not started by imports, prepare,
freeze, audit, report or unit tests. Only `functional` and `run` invoke adapters;
they require the existing WSL global `run_job.py` lease and its direct child
relationship. The current first campaign uses owner `W3`, native WSL processes,
and the stable `build/vm-coordination/queue.lock`; Docker is not supported by this
ownership adapter. Never remove or replace the shared lock inode.

All execution paths must be absolute. Outputs must be fresh. Run Python with
`-B` to avoid bytecode/cache files, especially when inspecting immutable bundles.

## Prepare and functional acceptance

`prepare --fixture-module ABS/reference.py --out ABS/prepared` imports the single
Python reference module and directly calls `generate_fixture(out, n, seed)` for
128 / 16384 / 131072 records. It preserves the module, exact oracle bytes and
SHA-256 inventories. It does not construct any candidate-library object.
Query-pair encoding is `SCQPAIR1`, u32 LE version 1, then two u64 LE
length-prefixed complete `SCQUERY1` documents, matching the reference encoder.

The functional command is:

```text
python -B campaign.py functional --prepared ABS --profile ABS/profile.json --out ABS/functional --queue ABS/functional/queue
```

Launch that exact absolute Python/script command via the existing
`experiments/vm_coordination/run_job.py run --owner W3 --kind functional`.
Create only the queue subdirectory through the maintained runner, which creates
its parent. Use a bounded queue timeout up to 3600 seconds. There are exactly 80
functional child slots: for each library one describe, then for S/M/L an encode,
initial fresh inspect, nine-stage validate, complete run, and final fresh inspect.
Every output is compared with the independent Python oracle. Functional times
are not performance samples. These gates do not on their own complete P4's
sanitizer, resource-failure or wider capability requirements.

Profile schema (exact top-level fields):

```json
{
  "schema_version": 1,
  "platform_class": "wsl2-vm-x86_64",
  "lock_dir": "/absolute/original/project/build/vm-coordination",
  "environment": {"LANG":"C","LC_ALL":"C","PATH":"/usr/bin:/bin","TZ":"UTC"},
  "binaries": {
    "xoffset": {"path":"/absolute/xoffset", "prefix":[], "library":"xoffset-alpha1", "commit":"7539433ab96d69c4a07b1db5c0a13786da85cdcd", "trust_mode":"ACTUAL-DESCRIBE-VALUE", "load_contract":"detached"}
  },
  "closure": {"environment-lock":"/absolute/environment.json", "source":"/absolute/source-tree", "runtime":"/absolute/runtime-tree", "contract":"/absolute/contract-v1.json"}
}
```

The example abbreviates `binaries`; all five logical keys are required:
`xoffset`, `cista`, `flatbuffers`, `capnproto`, `cereal`. Native library IDs and
commits must match `protocol.IDENTITIES`. `prefix` may explicitly invoke a loader
with its fixed arguments; the actual adapter binary follows the prefix. Include
the loader and every runtime/codegen/source/header/driver/contract input in the
reviewed closure. A JSON declaration cannot discover omitted compiler inputs;
P1/P3/P6 independently review closure completeness. Identities bind regular
files, empty directories, symlink target spelling and resolved content, rejecting
cycles. An existing source symlink with an absent optional external target is
bound by its original target spelling and a `missing-symlink-target` marker with
the resolved unavailable path, including missing parent chains; it is not skipped.
Later target creation/removal changes the identity. Missing ordinary paths still
reject, and critical file identities still require actual regular files.
The interpreter bytes and all four maintained Python/runner files are
also bound. Before/after source/runtime changes invalidate the attempt.

## Freeze and the reserved formal run

`freeze --functional ABS --authorization ABS/p6.json --window-out ABS/new-run --out ABS/new-frozen`
requires a fully audited normal functional bundle plus this exact P6 object:

```json
{
  "schema_version":1,
  "user_authorization":"Current user instruction covering this new campaign; never old N3",
  "p4_evidence":"/absolute/reviewed-p4-evidence.json",
  "p4_passed":true,
  "quiet_window_confirmed":true,
  "window_out":"/absolute/new-run"
}
```

These are root-reviewed technical prerequisites plus the actual current user
authorization ("制定实施方案，并开始实施"), not a request for another user approval.
Root records that existing authorization for conditional execution of the one
planned campaign; no repeated per-stage user confirmation is required. Freeze
copies the five binaries, M input wires, oracle, policy/schedule, authorization,
P4 evidence and protocol source. Original source/runtime trees remain references
with frozen inventories; they are not fully archived. The upstream functional
manifest/status are preserved references, not a claim to embed all upstream
functional bytes. Freeze/run do not edit these inputs.

Root must independently record the SHA-256 of `frozen/manifest.json` before run.
`run --frozen ABS --frozen-sha256 EXTERNAL --out ABS --queue ABS/queue` must then
be the direct W3 timing command of the maintained global runner, with at most
2700 seconds. It checks actual interpreter, argv, input bindings, shared lease
holder and run identity. This directory's existence is not timing permission.
P6 and root's sole execution window remain mandatory.

The maximum schedule is 10 A/A warmup + 5 comparison warmup + 120 A/A anchor +
150 comparison = 285 children. Each child has a 20-second cap including
post-audit/output; total window is 45 minutes, new wire budget 16 GiB. Initial
budget estimates use real functional final-wire sizes. POSIX file-size limits
bound individual child files, and all partial wire outputs count against the
retained-wire total. Any native/semantic/identity/budget failure stops the exact
schedule prefix without replacement. Any library failing any anchor invalidates
the whole five-library comparison cell. Local pre, incremental mid, full post,
pooled order/MAD and cross-anchor gates are independently reconstructed.
All no-launch time, wire-ceiling and evidence-slot checks precede the attempted
ledger. Run and audit share the exact frozen wire-size check. Receipt span must
fit the coordinator elapsed time, which must fit the outer queue elapsed time
(1 ms accounting allowance). A sealed deadline failure can slightly exceed the
inner deadline while remaining a preserved failure; successful runs must obey
the strict 2700-second bound and can never use that failure allowance.
Successful child intervals must be no greater than their declared timeout, with
no cleanup grace; an observed late exit-0 child is recorded as timed out. A
complete queue must satisfy both command elapsed and UTC request-created through
result-finished time within the hard total bound, including sealing/hash output.
Failed queues may retain their declared wait/termination grace plus 1 second of
supervisor accounting; that allowance never qualifies successful samples.

## Offline audit and evidence limits

After the outer queue finishes, root independently records a composite post-run
pin binding both manifests. `pin --bundle ABS` is a read-only helper:
`SHA256(b"SC-POST-RUN-PIN-v1\0" + raw32(main_manifest_SHA256) + raw32(queue_manifest_SHA256))`.
It grants no authorization. Run audit/report accept the pre-run manifest pin and
this post-run composite pin:

```text
python -B campaign.py pin --bundle ABS/run
python -B campaign.py audit --bundle ABS/run --frozen-sha256 PRE-RUN-PIN --postrun-pin POST-RUN-COMPOSITE-PIN
python -B campaign.py report --bundle ABS/run --frozen-sha256 PRE-RUN-PIN --postrun-pin POST-RUN-COMPOSITE-PIN --out ABS/new-report
```

The pre-run pin protects preregistration. The post-run pin protects raw evidence
and the completed queue's cleanup/exit against coordinated rewriting and
re-sealing of either local inventory. A run audit
without the independent pre-run pin rejects; without the final pin it can check
internal consistency but cannot accept performance. A run report requires both.
Functional audit can also receive `--postrun-pin`; without it, functional audit
only establishes internal consistency. Root reviews that original functional run
and the P4 evidence before freeze. These pins are hash-bound evidence, not a
digital signature or sender authentication.

Audit never executes candidates or imports archived protocol code. It reconstructs
commands using saved original path strings, then reads only the relocated bundle.
It hashes full retained wire files and checks native-reported hashes and exact
canonical/query oracle bytes. It does not independently implement five wire
decoders; production of post-canonical bytes and independent-process reload are
separate functional/native evidence, disclosed rather than claimed as a pure
Python semantic decode of each wire. Missing large files are an audit failure;
a curated metadata-only copy is not a complete audit bundle.

Valid early stops remain `audit-preserved-failure`, with exact attempted prefix,
raw receipts, explicit failure/no-output information and unexecuted suffix. An
unsealed abrupt interruption remains incomplete evidence and is never accepted
as a successful run. Queue cleanup must be complete before offline acceptance.

Statistics use complete five-library blocks and exclude 15 warmups plus A/A
samples. SHA-256 rejection sampling creates 10000 fixed two-stratum bootstrap
draws (15 blocks per half); percentile Type-7 tails are .00625/.99375 for four
Bonferroni comparisons. Family coverage is nominal, not a small-sample guarantee.
No p99, automatic adoption, retry-to-qualify or historical N3 closure is produced.
Interpretation still requires independent P8 review, especially temporal
dependence and representativeness.

Pure Python tests:

```text
python -B -m unittest discover -s tools/serialization_comparison/tests -v
python -B -O -m unittest discover -s tools/serialization_comparison/tests -v
```
