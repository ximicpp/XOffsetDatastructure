"""Frozen first-campaign schedule and pure statistics. No native execution."""
from __future__ import annotations

import hashlib
import math
from statistics import median

try:
    from . import core as C
except ImportError:
    import core as C

LIBRARIES = ("xoffset", "cista", "flatbuffers", "capnproto", "cereal")
IDENTITIES = {
    "xoffset":("xoffset-alpha1","7539433ab96d69c4a07b1db5c0a13786da85cdcd"),
    "cista":("cista-v0.16","015b94e66c4c0d7c1ef29742383a024c84fbbba1"),
    "flatbuffers":("flatbuffers-v25.12.19","7e163021e59cca4f8e1e35a7c828b5c6b7915953"),
    "capnproto":("capnproto-v1.5.0","373e61ec89e2359f1c362e9b2eadc552f4779306"),
    "cereal":("cereal-v1.3.2","ebef1e929807629befafbb2918ea1a08c7194554")}
CELL = "V1-M-mixed-growth-trusted-detached"
ANCHORS = ("pre", "mid", "post")
POLICY = dict(maximum_children=285, maximum_window_seconds=2700,
              maximum_child_seconds=20, maximum_new_wire_bytes=str(16*1024**3),
              bootstrap_resamples=10000, target_ratio=1.05, anchor_ratio=1.02,
              initial_records=16384, no_retry=True, whole_cell_qualification=True)


def schedule():
    rows = []

    def add(library, kind, **extra):
        rows.append(dict(id="j%03d" % len(rows), library=library, kind=kind, **extra))

    for lib in LIBRARIES:
        for side in ("A", "B"):
            add(lib, "warmup-aa", anchor="warmup", pair=0, side=side, order="AB")
    for lib in LIBRARIES:
        add(lib, "warmup-comparison", block=-1, position=LIBRARIES.index(lib))

    def anchor(name):
        for pair in range(4):
            order = "AB" if pair % 2 == 0 else "BA"
            # Rotate libraries across pairs and anchors; each pair stays adjacent.
            shift = (pair + ANCHORS.index(name)) % 5
            for lib in LIBRARIES[shift:] + LIBRARIES[:shift]:
                for side in order:
                    add(lib, "aa", anchor=name, pair=pair, side=side, order=order)

    def blocks(start):
        for block in range(start, start+15):
            shift = block % 5
            for position, lib in enumerate(LIBRARIES[shift:] + LIBRARIES[:shift]):
                add(lib, "comparison", block=block, position=position)

    anchor("pre")
    blocks(0)
    anchor("mid")
    blocks(15)
    anchor("post")
    C.require(len(rows) == POLICY["maximum_children"], "internal schedule count mismatch")
    return rows


def mad(values):
    center = median(values)
    return median(abs(x-center) for x in values)


def _pair_stats(pairs):
    logs = [math.log(a/b) for a,b,_order in pairs]
    ratios = [a/b for a,b,_order in pairs]
    strata = {order: median(a/b for a,b,o in pairs if o == order) for order in ("AB", "BA")}
    mid = median(ratios)
    scaled = 1.4826 * mad(logs)
    return dict(paired_ratios=ratios, median_ratio=mid, scaled_log_mad=scaled,
                order_medians=strata,
                qualified=0.98 <= mid <= 1.02 and scaled <= math.log(1.02)
                and all(0.98 <= v <= 1.02 for v in strata.values()))


def anchor_gates(samples, completed):
    C.require(completed in ANCHORS, "unknown completed anchor")
    selected = ANCHORS[:ANCHORS.index(completed)+1]
    result = {}
    for lib in LIBRARIES:
        local, all_pairs, centers = {}, [], {"pooled":[], "A":[], "B":[]}
        for name in selected:
            rows = [r for r in samples if r["job"]["kind"] == "aa" and r["job"]["library"] == lib and r["job"]["anchor"] == name]
            C.require(len(rows) == 8, "incomplete anchor")
            pairs = []
            sides = {"A":[], "B":[]}
            for pair in range(4):
                members = [r for r in rows if r["job"]["pair"] == pair]
                C.require(len(members) == 2 and {r["job"]["side"] for r in members} == {"A","B"}, "invalid AA pair")
                values = {r["job"]["side"]: C.decimal(r["total_ns"], positive=True) for r in members}
                order = "AB" if pair % 2 == 0 else "BA"
                C.require(all(r["job"]["order"] == order for r in members), "AA order mismatch")
                pairs.append((values["A"], values["B"], order))
                for side in sides:
                    sides[side].append(values[side])
            local[name] = _pair_stats(pairs)
            all_pairs.extend(pairs)
            for side in ("A", "B"):
                centers[side].append(median(sides[side]))
            centers["pooled"].append(median(sides["A"] + sides["B"]))
        drifts = {side:max(v)/min(v) for side,v in centers.items()}
        pooled = _pair_stats(all_pairs) if completed == "post" else None
        qualified = all(v["qualified"] for v in local.values()) and all(v <= 1.02 for v in drifts.values())
        if pooled is not None:
            # Post pooled median ratio itself is not an additional plan gate.
            qualified = qualified and pooled["scaled_log_mad"] <= math.log(1.02) and all(0.98 <= v <= 1.02 for v in pooled["order_medians"].values())
        result[lib] = dict(anchors=local, drift_ratios=drifts, pooled=pooled, qualified=qualified)
    return dict(completed_anchor=completed, libraries=result, qualified=all(r["qualified"] for r in result.values()))


def bootstrap_index(b, s, j):
    C.require(C.integer(b, 0, 9999) and C.integer(s, 0, 1) and C.integer(j, 0, 14), "invalid resampling index")
    limit = 2**64 - (2**64 % 15)
    k = 0
    while True:
        raw = ("xoffset-bb-v1|%d|%d|%d|%d" % (b,s,j,k)).encode("ascii")
        value = int.from_bytes(hashlib.sha256(raw).digest()[:8], "little")
        if value < limit:
            return 15*s + value % 15
        k += 1


def quantile(values, q):
    C.require(values and math.isfinite(q) and 0 <= q <= 1, "invalid quantile")
    values = sorted(values)
    h = (len(values)-1)*q
    lo = math.floor(h)
    return values[lo] + (values[min(lo+1,len(values)-1)]-values[lo])*(h-lo)


def compare(samples):
    rows = [r for r in samples if r["job"]["kind"] == "comparison"]
    C.require(len(rows) == 150, "comparison requires 30 complete blocks")
    logs = {lib:[] for lib in LIBRARIES[1:]}
    for block in range(30):
        members = [r for r in rows if r["job"]["block"] == block]
        C.require(len(members) == 5 and {r["job"]["library"] for r in members} == set(LIBRARIES), "incomplete comparison block")
        values = {r["job"]["library"]: C.decimal(r["total_ns"], positive=True) for r in members}
        for lib in logs:
            logs[lib].append(math.log(values[lib]/values["xoffset"]))
    distributions = {lib:[] for lib in logs}
    for b in range(10000):
        indices = [bootstrap_index(b,s,j) for s in (0,1) for j in range(15)]
        for lib, values in logs.items():
            distributions[lib].append(math.exp(median(values[i] for i in indices)))
    results = {}
    for lib, values in logs.items():
        interval = [quantile(distributions[lib],q) for q in (0.00625,0.99375)]
        lo, hi = interval
        decision = "uncertain"
        if lo > 1.05:
            decision = "competitor_slower_at_relevance_threshold"
        elif hi < 1/1.05:
            decision = "competitor_faster_at_relevance_threshold"
        elif lo > 1/1.05 and hi < 1.05:
            decision = "practical_equivalence_estimate"
        results[lib] = dict(median_paired_ratio=math.exp(median(values)), paired_log_ratios=values,
                            confidence_level=0.9875, percentile_interval=interval,
                            decision=decision, independent_units=30)
    return dict(method="stratified-whole-block-percentile-v1", resamples=10000,
                nominal_family_confidence=0.95, exact_coverage_guaranteed=False, comparisons=results)


def summary(samples):
    jobs = schedule()
    C.require(len(samples) <= len(jobs), "extra sample")
    for index, sample in enumerate(samples):
        C.require(C.same(sample["job"],jobs[index]), "samples are not exact executed schedule prefix")
    gates = []
    for anchor in ANCHORS:
        end = max(i for i,j in enumerate(jobs) if j.get("anchor") == anchor) + 1
        if len(samples) >= end:
            gate = anchor_gates(samples[:end], anchor)
            gates.append(gate)
            C.require(len(samples) <= end or gate["qualified"], "execution continued after failed anchor")
            if not gate["qualified"]:
                break
    qualified = len(samples) == 285 and len(gates) == 3 and all(g["qualified"] for g in gates)
    return dict(schema_version=1, cell=CELL, successful_children=len(samples),
                excluded_warmup_children=sum(s["job"]["kind"].startswith("warmup") for s in samples),
                anchor_gates=gates, measurement_qualified=qualified,
                comparison=compare(samples) if qualified else None,
                old_N3_closed=False, performance_accepted=False)
