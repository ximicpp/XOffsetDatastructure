#!/bin/bash
# Platform matrix (v1.1 O7), Linux arm64 column: full CTest and the cross-compiler wire corpus
# of one XOffsetDatastructure commit, built with GCC 16 (and P2996 Clang when its arm64 tarball
# is installed) inside the M4's colima Linux arm64 VM. Unattended batch for mac_queue.sh
# (macOS bash 3.2). Not timed: it can run whenever the queue is free, e.g. as the last step of
# the RC checkpoint batch. Measures only: no push, no merge, no library change.
#
# Results ($XOQ_OUT): RESULT.md (one row per compiler), <cc>_PLATFORM_RESULT.md and
# <cc>_logs.tar.gz (tools/platform_matrix.sh output), <cc>_corpus.tar.gz (test_cross_compiler_wire
# --write), vm_env.txt, SHA256SUMS. The cloud compares the corpus byte for byte with the
# Linux x86-64 GCC 16 reference of the same commit.
#   exit 2  inputs, VM, image or container setup failed (nothing built)
#   exit 3  a build, CTest or corpus step failed (see RESULT.md)
#   exit 0  every column that ran passed
#
# To queue for another commit: change COMMIT and TREE below (tree checked in the cloud), keep
# the rest. The commit must contain tools/platform_matrix.sh (#132, merged 79da8c7).
set -u -o pipefail
# XO_* overrides exist only for the cloud dry run of this script (x86-64 image, stub colima).
COMMIT=${XO_COMMIT:-e913d220d1f42bf90883396e63286651ba50a352}
TREE=${XO_TREE:-71354565c4268712a16b8dcdc2a30214b3993f93}
XOQ_OUT=${XOQ_OUT:-$PWD/out}; mkdir -p "$XOQ_OUT"
export PATH=/opt/homebrew/bin:/usr/local/bin:$PATH
H=${XO_H1:-/Volumes/XOffsetCS/h1}                  # colima home and arm64 toolchain of 「GCC 16 Mac 计时」
TAG=${COMMIT:0:7}
W=${XO_W:-/Volumes/XOffsetCS/platform/arm64-$TAG}  # this batch (shared into the VM at the same path)
export COLIMA_HOME=$H/colima
PROF=h1
export DOCKER_CONTEXT=${XO_DOCKER_CONTEXT:-colima-$PROF}
EXPORT=${XO_EXPORT:-/Volumes/XOffsetCS/perf-gate/tools-96be66d/xo_export.sh}
EXPORT_SHA=64d7a188da31ceb72034ff962b0953e029f2fd14594ae590a68ef46322979f04
export XO_GIT=${XO_GIT:-/Volumes/XOffsetCS/git}
G=${XO_IMAGE:-gcc@sha256:325784a7e64cece62cc2ba202f8ee9e9b6e09dbcecabe98697a79a41148b177a}   # gcc:16 linux/arm64, GCC 16.2.0
ARCH=${XO_ARCH:-aarch64}
TC_TAR=${XO_TC_TAR:-$H/toolchain/p2996-d77eff1-linux-aarch64.tar.xz}
TC_SHA=${XO_TC_SHA:-b8a1f39dfb8676ed0e1818cab34671752c7655223ecc22dceb356aa0ca81cad6}
RT=xo-arm64                                        # runtime container
VOL=xo-arm64-work                                  # build volume (the VM disk, not virtiofs)
utc() { date -u +%Y-%m-%dT%H:%M:%SZ; }
log() { echo "== $(utc) $*"; }
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
vm() { docker exec "$RT" bash -c "$1"; }
ROWS=""
row() { ROWS="$ROWS$1
"; }

finish() {
    local rc=$1
    log "finish rc=$rc"
    {
        echo "# Linux arm64 platform column, $COMMIT"
        echo
        echo "- $(utc), colima profile $PROF, image $G"
        [ -f "$XOQ_OUT/vm_env.txt" ] && echo "- VM: $(grep -m1 Linux "$XOQ_OUT/vm_env.txt"); $(grep -m1 PAGESIZE "$XOQ_OUT/vm_env.txt")"
        echo "- exit $rc"
        echo
        echo "| compiler | result | ctest | corpus files |"
        echo "| --- | --- | --- | --- |"
        printf '%s' "$ROWS"
        [ -n "${STOPMSG:-}" ] && { echo; echo "STOP: $STOPMSG"; }
    } > "$XOQ_OUT/RESULT.md"
    cat "$XOQ_OUT/RESULT.md"
    ( cd "$XOQ_OUT" && for f in *; do [ -f "$f" ] && [ "$f" != SHA256SUMS ] && shasum -a 256 "$f"; done > SHA256SUMS )
    docker rm -f "$RT" > /dev/null 2>&1; docker volume rm "$VOL" > /dev/null 2>&1
    rm -rf "${W:?}/src"
    colima stop --profile $PROF > /dev/null 2>&1
    exit "$rc"
}
stop() { STOPMSG=$1; echo "STOP: $1"; finish "${2:-2}"; }

log "0. inputs"
case "$COMMIT$TREE" in *@*) echo "STOP: COMMIT/TREE not filled in"; exit 2 ;; esac
for c in colima docker git shasum; do command -v $c > /dev/null || { echo "STOP: $c not found"; exit 2; }; done
[ -f "$EXPORT" ] && [ "$(sha "$EXPORT")" = "$EXPORT_SHA" ] || { echo "STOP: $EXPORT missing or sha differs"; exit 2; }
[ ! -e "$W" ] || { echo "STOP: $W exists (left over from an earlier attempt: look before removing it)"; exit 2; }
mkdir -p "$W"
P2996=0
[ -f "$TC_TAR" ] && [ "$(sha "$TC_TAR")" = "$TC_SHA" ] && P2996=1
log "1. export $COMMIT"
bash "$EXPORT" "$COMMIT" "$W/src" > "$XOQ_OUT/export.log" 2>&1 || stop "export failed (export.log)"
[ "$(git -C "$XO_GIT/XOffsetDatastructure.git" rev-parse "$COMMIT^{tree}")" = "$TREE" ] || stop "tree of $COMMIT is not $TREE"
[ -f "$W/src/tools/platform_matrix.sh" ] || stop "$COMMIT has no tools/platform_matrix.sh"

log "2. VM"
mkdir -p "$COLIMA_HOME"
if colima status --profile $PROF > /dev/null 2>&1; then
    stop "colima profile $PROF is already running (another batch uses it?)"
fi
CPU=$(sysctl -n hw.perflevel0.physicalcpu); MEMG=$(( $(sysctl -n hw.memsize) / 1073741824 ))
if [ "$MEMG" -ge 32 ]; then VMMEM=12; elif [ "$MEMG" -ge 24 ]; then VMMEM=8; else VMMEM=6; fi
colima start --profile $PROF --vm-type vz --arch aarch64 --cpu "$CPU" --memory "$VMMEM" --disk 40 \
    --mount-type virtiofs --mount "$W:w" --runtime docker > "$XOQ_OUT/colima_start.log" 2>&1 \
    || stop "colima start failed (colima_start.log)"
{ colima list; docker info --format '{{.OperatingSystem}} {{.Architecture}} NCPU={{.NCPU}} Mem={{.MemTotal}}'
  colima ssh --profile $PROF -- sh -c 'uname -srm; echo PAGESIZE $(getconf PAGESIZE); echo nproc $(nproc)'; } > "$XOQ_OUT/vm_env.txt" 2>&1
docker pull -q "$G" > /dev/null || stop "docker pull $G failed"
docker run --rm "$G" sh -c 'uname -m; g++ --version | head -1' > "$XOQ_OUT/image.txt" 2>&1
grep -q "$ARCH" "$XOQ_OUT/image.txt" && grep -q '16\.2\.0' "$XOQ_OUT/image.txt" || stop "image is not aarch64 GCC 16.2.0"
if [ $P2996 = 1 ] && ! docker run --rm -v h1tc:/opt/p2996 "$G" cat /opt/p2996/.tc_sha 2>/dev/null | grep -qx "$TC_SHA"; then
    docker volume rm h1tc > /dev/null 2>&1
    docker run --rm -i -v h1tc:/opt/p2996 "$G" sh -c \
      "tar -xJ -C /opt/p2996 --strip-components=1 && echo $TC_SHA > /opt/p2996/.tc_sha" < "$TC_TAR" || P2996=0
fi
docker inspect "$RT" > /dev/null 2>&1 && stop "container $RT exists (left over: look before removing it)"
docker volume inspect "$VOL" > /dev/null 2>&1 && stop "volume $VOL exists (left over: look before removing it)"
MNT="-v $VOL:/work -v $W:$W"; [ $P2996 = 1 ] && MNT="$MNT -v h1tc:/opt/p2996"
docker run -d --name "$RT" -e W="$W" $MNT "$G" sleep infinity > /dev/null || stop "$RT start failed"
vm 'cp -a $W/src /work/src' || stop "copy into $VOL failed"
CMAKE_ARG=""   # the container downloads the pinned CMake; the cloud dry run hands it a local copy
[ -n "${XO_CMAKE_ARCHIVE:-}" ] && cp "$XO_CMAKE_ARCHIVE" "$W/cmake.tar.gz" && CMAKE_ARG="--archive $W/cmake.tar.gz"
vm "cd /work/src && python3 tools/prepare_vm_cmake.py --platform linux-$ARCH --out /work/cmake-tool $CMAKE_ARG" > "$XOQ_OUT/cmake_tool.log" 2>&1 \
    || stop "prepare_vm_cmake failed (cmake_tool.log)"

log "3. build, CTest, corpus"
RC=0
column() {  # column NAME CMAKE-ARGS ENV
    local name=$1 args=$2 envs=$3 b=/work/b-$1 e r ct n
    vm "export PATH=/work/cmake-tool/root/bin:\$PATH $envs; cd /work/src && bash tools/platform_matrix.sh host --build $b -j $CPU -- $args" \
        > "$XOQ_OUT/${name}_run.log" 2>&1; e=$?
    vm "cat $b/PLATFORM_RESULT.md" > "$XOQ_OUT/${name}_PLATFORM_RESULT.md" 2>/dev/null
    vm "tar -C $b -cf - platform-logs" | gzip > "$XOQ_OUT/${name}_logs.tar.gz"
    n=$(vm "ls $b/corpus 2>/dev/null | wc -l" | tr -d ' ')
    [ "${n:-0}" -gt 0 ] && vm "tar -C $b -cf - corpus" | gzip > "$XOQ_OUT/${name}_corpus.tar.gz"
    ct=$(grep -E -m1 'tests passed|tests failed' "$XOQ_OUT/${name}_PLATFORM_RESULT.md" | sed 's/^| ctest summary | //; s/ | |$//')
    if [ $e -eq 0 ]; then r=passed; else r="**failed** (rc $e)"; RC=3; fi
    row "| $name | $r | ${ct:-none} | ${n:-0} |"
}
column gcc16 "-DCMAKE_CXX_COMPILER=g++" ""
if [ $P2996 = 1 ]; then
    column p2996 "-DCMAKE_CXX_COMPILER=/opt/p2996/bin/clang++" "LD_LIBRARY_PATH=/opt/p2996/lib/$ARCH-unknown-linux-gnu"
else
    row "| p2996 | not run: $TC_TAR missing or sha differs | | |"
fi
finish $RC
