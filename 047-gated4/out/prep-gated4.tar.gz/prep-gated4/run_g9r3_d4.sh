#!/bin/bash
# G9R3 for GATE_D4 (run_g9r3.sh of 「G9 重定位税诊断」 with t0 = 43669586): embedded in run_gated4.sh (macOS bash 3.2).
# Steps file: /mnt/project-files/g9-reloc-20261027/MAC_STEPS_G9R3.md. Design thread 「G9 重定位税诊断」.
# Measures only (class 0): no push, no merge, no library change, no ctest.
#   run_g9r3.sh T1_COMMIT [T1_TREE]      (or G9R_T1 / G9R_T1_TREE in the environment)
# t0 = next_cpp26 43669586 (#146 merge, the GATE_D4 control); t1 = the GATE_D4 head (iterator class PR), which must
# descend from t0. With T1_TREE the tree of t1 is checked as well.
#   1. bench/reloc of t0 (31 cases, G9 judges str.assign_short.view, k 19) built against the library of t0 and
#      of t1, in the default build and with -falign-functions=64 (t0a, t1a: identical code at the same
#      cache-line offset, so that a layout effect is not taken for a code effect)
#   2. timing: 4 blocks, each one quiet gate and then t0 t1 t1 t0 (blocks 2 and 4: t1 t0 t0 t1) and the same
#      for t0a / t1a, back to back (a run takes about 2 s): 8 runs per point, --rounds 101
#   3. per G9 item: xo / std at both points and t1 / t0 with the O3 rule; G9 count at both points
#   4. disassembly of the four reloc_bench builds, gzipped, for the cloud to read
# The quiet gate: no compiler, load1 < 3 for 180 s; the screen is darkened and recorded only.
# Exit: 0 done, 2 a preparation check failed, 5 the quiet gate was never met. Whatever exists is copied.
set -u -o pipefail
# XO_* overrides exist only for the cloud dry run of this script.
XOQ_OUT=${XOQ_OUT:-$PWD/out}; mkdir -p "$XOQ_OUT"
PG=${XO_PG:-/Volumes/XOffsetCS/perf-gate}
EXPORT=${XO_EXPORT:-$PG/tools-96be66d/xo_export.sh}
EXPORT_SHA=64d7a188da31ceb72034ff962b0953e029f2fd14594ae590a68ef46322979f04
export XO_GIT=${XO_GIT:-/Volumes/XOffsetCS/git}
GIT=$XO_GIT/XOffsetDatastructure.git
T=${XO_T:-/Volumes/XOffsetCS/toolchain/p2996-d77eff1}
SDK=${XO_SDK:-/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk}
QUIET_S=${XO_QUIET_S:-180}
ROUNDS=${XO_ROUNDS:-101}
TAG=g9r3
SRC=$PG/src/$TAG; BLD=$PG/build/$TAG; R=$PG/runs/$TAG-$(date -u +%Y%m%dT%H%M%SZ)
T1=${1:-${G9R_T1:-}}; T1_TREE=${2:-${G9R_T1_TREE:-}}
NAMES=(t0 t1)
COMMITS=(43669586b5ad29962050e36dff8ffc252917f868 "$T1")
LABELS=("next_cpp26 43669586 (#146 merge, with #149)" "GATE_D4 head claude/d-iter-20261027 (XFixedVector iterator class PR)")
T0_TREE=dc3e42d4fb25ef7e2cb4aa98bff6e3460377f989
RL_TREE=a7e8b02792a9cf4258e012fe4881330c6c9d5e59   # bench/reloc of t0: 31 cases
RC=0; STATE_RELOC="not run"; STATE_DISASM="not run"
utc() { date -u +%Y-%m-%dT%H:%M:%SZ; }
log() { echo "== $(utc) $*"; }
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
dark() { pmset displaysleepnow > /dev/null 2>&1 || true; }

finish() {
    RC=$1
    log "finish rc=$RC"
    if [ -d "$R" ]; then
        tar -C "$(dirname "$R")" -czf "$XOQ_OUT/g9r3_raw.tar.gz" "$(basename "$R")" 2>/dev/null
        for f in RESULT.md points.txt analyze_t0.md analyze_t1.md reloc_points.md g9_items.md quiet.log; do
            [ -f "$R/$f" ] && cp "$R/$f" "$XOQ_OUT/"
        done
        rm -rf "${R:?}"   # the raw is in $XOQ_OUT (Mac disk)
    fi
    printf 't1 %s\nreloc %s\ndisasm %s\nrc %s\n' "${T1:-none}" "$STATE_RELOC" "$STATE_DISASM" "$RC" > "$XOQ_OUT/VERDICTS.txt"
    ( cd "$XOQ_OUT" && find . -type f ! -name SHA256SUMS | sort | while read -r f; do shasum -a 256 "$f"; done > SHA256SUMS )
    rm -rf "${BLD:?}" "${SRC:?}"
    exit "$RC"
}
stop() { echo "STOP: $1"; finish "${2:-2}"; }

# ---------------------------------------------------------------- 0. tools and inputs
log "0. tools"
echo "$T1" | grep -Eq '^[0-9a-f]{40}$' || stop "t1: give the integration head as a full 40-character commit (got '${T1}')"
[ -z "$T1_TREE" ] || echo "$T1_TREE" | grep -Eq '^[0-9a-f]{40}$' || stop "t1 tree: want 40 hex characters (got '$T1_TREE')"
[ "$T1" != "${COMMITS[0]}" ] || stop "t1 is t0"
[ -f "$EXPORT" ] && [ "$(sha "$EXPORT")" = "$EXPORT_SHA" ] || stop "$EXPORT: missing or sha256 differs (want $EXPORT_SHA)"
for f in "$T/bin/clang++" "$SDK"; do [ -e "$f" ] || stop "missing $f"; done
for d in "$SRC" "$BLD" "$R"; do [ ! -e "$d" ] || stop "$d exists (left over from an earlier attempt: look before removing it)"; done
mkdir -p "$SRC" "$BLD" "$R"
cmake --version | head -1; ninja --version; "$T/bin/clang++" --version | head -1
sw_vers 2>/dev/null | tr '\n' ' '; echo; sysctl -n machdep.cpu.brand_string 2>/dev/null || true

# ---------------------------------------------------------------- 1. sources
log "1. export"
for i in 0 1; do
    n=${NAMES[$i]}; c=${COMMITS[$i]}
    bash "$EXPORT" "$c" "$SRC/$n" > "$R/export_$n.log" 2>&1 || stop "export $n $c failed (export_$n.log)"
    t=$(git -C "$GIT" rev-parse "$c^{tree}")
    want=$T0_TREE; [ "$n" = t1 ] && want=$T1_TREE
    [ -z "$want" ] || [ "$t" = "$want" ] || stop "$n: tree $t, expected $want"
    echo "$n $c tree $t typelayout $(git -C "$GIT" ls-tree "$c" external/typelayout | awk '{print $3}') (${LABELS[$i]})" | tee -a "$R/points.txt"
done
git -C "$GIT" merge-base --is-ancestor "${COMMITS[0]}" "$T1" || stop "t1 $T1 does not descend from t0 ${COMMITS[0]}"
d=$(git -C "$GIT" -c core.abbrev=7 diff "${COMMITS[0]}..$T1" | shasum -a 256 | awk '{print $1}')
{
    echo "t1: diff over t0 sha256 $d ($(git -C "$GIT" diff --stat "${COMMITS[0]}..$T1" | tail -1))"
    echo "t1: library header diff over t0: $(git -C "$GIT" diff --stat "${COMMITS[0]}..$T1" -- xoffsetdatastructure.hpp xoffset_virtual_memory.hpp | tail -1)"
    echo "t1: first-parent commits over t0:"; git -C "$GIT" log --first-parent --format='  %h %s' "${COMMITS[0]}..$T1" | head -40
} | tee -a "$R/points.txt"
[ "$(git -C "$GIT" rev-parse "${COMMITS[0]}:bench/reloc")" = "$RL_TREE" ] || stop "bench/reloc tree of t0 differs"
rt1=$(git -C "$GIT" rev-parse "$T1:bench/reloc" 2>/dev/null || echo none)
if [ "$rt1" = "$RL_TREE" ]; then echo "bench/reloc of t1: same tree as t0"; else echo "bench/reloc of t1: tree $rt1 differs from t0 ($RL_TREE): t0's is timed against both libraries"; fi | tee -a "$R/points.txt"
RLS=$SRC/t0/bench/reloc   # the one bench/reloc, built against both libraries
python3 "$SRC/t0/bench/check_manifest.py" "$RLS" || stop "bench/reloc manifest check failed"

# ---------------------------------------------------------------- 2. builds
log "2. build"
CXXF=${XO_CXXFLAGS:--stdlib=libc++ -pthread -isysroot $SDK}
P2996_FLAGS=(-G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=$T/bin/clang++ -DCMAKE_OSX_SYSROOT=$SDK
  "-DCMAKE_EXE_LINKER_FLAGS=${XO_LDFLAGS:--L$T/lib -Wl,-rpath,$T/lib}")
# t0a / t1a: the same two builds with every function starting on a 64 B boundary (layout check, g9_items.md)
ALIGN=-falign-functions=64
for n in t0 t1 t0a t1a; do
    f=$CXXF; [ "${n%a}" != "$n" ] && f="$CXXF $ALIGN"
    cmake -S "$RLS" -B "$BLD/cm-$n" "${P2996_FLAGS[@]}" "-DCMAKE_CXX_FLAGS=$f" -DXOFFSET_ROOT="$SRC/${n%a}" > "$R/build_$n.log" 2>&1 \
      && cmake --build "$BLD/cm-$n" >> "$R/build_$n.log" 2>&1 || stop "reloc_bench $n build failed (build_$n.log)"
    mkdir -p "$BLD/$n"; cp -p "$BLD/cm-$n/reloc_bench" "$BLD/$n/"; rm -rf "${BLD:?}/cm-$n"
    echo "reloc_bench $n sha256 $(sha "$BLD/$n/reloc_bench")" | tee -a "$R/points.txt"
done
for n in t0 t1 t0a t1a; do
    "$BLD/$n/reloc_bench" --mode verify > "$R/verify_$n.log" 2>&1 || stop "reloc verify $n failed (verify_$n.log)"
    echo "reloc verify $n: $(tail -1 "$R/verify_$n.log")"
done

# disassembly (not timed): the cloud checks the mid insert / erase shape at t1 and where the hot functions start
OBJDUMP=""
for o in "$T/bin/llvm-objdump" "$(command -v objdump 2>/dev/null)"; do [ -n "$o" ] && [ -x "$o" ] && { OBJDUMP=$o; break; }; done
if [ -n "$OBJDUMP" ]; then
    for n in t0 t1 t0a t1a; do
        "$OBJDUMP" -d --no-show-raw-insn -C "$BLD/$n/reloc_bench" 2>/dev/null | gzip -9 > "$XOQ_OUT/disasm_$n.txt.gz"
    done
    STATE_DISASM="done ($OBJDUMP)"
else
    STATE_DISASM="no objdump found"
fi
echo "disasm: $STATE_DISASM"

# ---------------------------------------------------------------- 3. timing
log "3. timing"
quiet() {
    local ok=0 waited=0 l ws busy
    dark
    while [ $ok -lt "$QUIET_S" ]; do
        l=$(sysctl -n vm.loadavg 2>/dev/null | awk '{print $2}'); l=${l:-0}
        ws=$(ps -A -o %cpu=,comm= | awk '/WindowServer/ {s += $1} END {print s + 0}')
        busy=$(ps -A -o comm= | grep -E -c '(^|/)(clang|clang\+\+|ld|ninja|cmake|make|ctest|cc1plus|swift-frontend)$')
        if [ "$busy" -eq 0 ] && awk -v l="$l" 'BEGIN {exit !(l < 3)}'; then ok=$((ok + 10)); else ok=0; fi
        [ $waited -ge 43200 ] && { echo "$(utc) $1 quiet timeout (load $l, WindowServer $ws%, compilers $busy)" >> "$R/quiet.log"; return 1; }
        sleep 10; waited=$((waited + 10))
    done
    echo "$(utc) $1 start: waited ${waited}s load $l WindowServer $ws% remote $(ps -A -o comm= | grep -E -c 'UU|ScreenSharing|screensharingd|RemoteDesktop')" >> "$R/quiet.log"
}
STATE_RELOC=started
for b in 1 2 3 4; do
    quiet "block $b" || stop "reloc: quiet gate never met before block $b (nothing timed after that)" 5
    if [ $((b % 2)) -eq 1 ]; then o="t0 t1 t1 t0 t0a t1a t1a t0a"; else o="t1 t0 t0 t1 t1a t0a t0a t1a"; fi
    k_t0=0; k_t1=0; k_t0a=0; k_t1a=0
    for n in $o; do
        eval "k_$n=\$((k_$n + 1)); j=\$k_$n"   # the run of point n within the block: 1 or 2
        "$BLD/$n/reloc_bench" --rounds "$ROUNDS" --out "$R/raw_${n}_$b$j.jsonl" > "$R/run_${n}_$b$j.log" 2>&1 || stop "reloc $n $b$j failed"
    done
done
STATE_RELOC="timed"

# ---------------------------------------------------------------- 4. analysis
log "4. analysis"
A=$RLS/tools/analyze.py
for n in t0 t1; do python3 "$A" "$R"/raw_${n}_*.jsonl > "$R/analyze_$n.md" 2>&1; done
# per case: the median XOffset and baseline ns per op of each file, GM over the files; t1 / t0
python3 - "$R" > "$R/reloc_points.md" <<'PY'
import glob, json, math, statistics as st, sys
R = sys.argv[1]
def meds(f):
    xo, base = {}, {}
    for line in open(f):
        x = json.loads(line)
        if 'case' not in x or x.get('round', 0) <= 0: continue
        c = x['case']; ns = x['ns']
        xo.setdefault(c, []).append(ns['xoffset'] / x['ops'])
        other = [k for k in ns if k != 'xoffset']
        if other: base.setdefault(c, []).append(ns[other[0]] / x['ops'])
    return {c: st.median(a) for c, a in xo.items()}, {c: st.median(a) for c, a in base.items()}
gm = lambda a: math.exp(sum(map(math.log, a)) / len(a)) if a else float('nan')
pts = {n: [meds(f) for f in sorted(glob.glob(f'{R}/raw_{n}_*.jsonl'))] for n in ('t0', 't1', 't0a', 't1a')}
cases = sorted({c for m in pts['t0'] for c in m[0]})
print('| case | t0 xo ns/op | t1 xo ns/op | t1 / t0 | first baseline ns/op (t0 runs) | t1a / t0a (aligned) |')
print('| --- | ---: | ---: | ---: | ---: | ---: |')
for c in cases:
    a = gm([m[0][c] for m in pts['t0'] if c in m[0]]); b = gm([m[0][c] for m in pts['t1'] if c in m[0]])
    s = gm([m[1][c] for m in pts['t0'] if c in m[1]])
    aa = gm([m[0][c] for m in pts['t0a'] if c in m[0]]); ba = gm([m[0][c] for m in pts['t1a'] if c in m[0]])
    print(f'| {c} | {a:.2f} | {b:.2f} | {b / a:.3f} | {s:.2f} | {ba / aa:.3f} |')
PY
# per G9 item and reported comparison: the GM of the per-round ratios xo / baseline at t0 and t1 (rounds of
# all files pooled, as analyze.py), t1 / t0 of it with a two-sided 95% interval (Welch); "worse" marks a
# comparison whose interval lies above 1 and whose two halves (blocks 1-2 and blocks 3-4, compared
# separately) are both above 1; "worse?" any other whose point estimate exceeds 1.01. The same for the
# XOffset time alone, both again for the aligned pair, and the layout check of what is worse
python3 - "$R" > "$R/g9_items.md" <<'PY'
import glob, json, math, re, statistics as st, sys
R = sys.argv[1]
def load(n):  # per comparison, one list of per-round logs per run file, in run order
    lr, ab, prim = {}, {}, {}
    fs = sorted(glob.glob(f'{R}/raw_{n}_*.jsonl'), key=lambda f: int(re.findall(r'_(\d+)\.jsonl$', f)[0]))
    for i, f in enumerate(fs):
        for line in open(f):
            x = json.loads(line)
            if 'case' not in x or 'ns' not in x: continue
            c = x['case']; prim[c] = x.get('primary'); xo = x['ns']['xoffset']
            ab.setdefault(c, [[] for _ in fs])[i].append(math.log(xo / x['ops']))
            for b, v in x['ns'].items():
                if b != 'xoffset': lr.setdefault((c, b), [[] for _ in fs])[i].append(math.log(xo / v))
    return lr, ab, prim
def tq(df):
    z = 1.959964
    return z + (z ** 3 + z) / (4 * df) + (5 * z ** 5 + 16 * z ** 3 + 3 * z) / (96 * df ** 2)
flat = lambda fs: [v for f in fs for v in f]
def cmp(xf, yf):  # y / x from per-file per-round logs: GM of each, ratio, two-sided 95% Welch interval, halves, note
    x, y = flat(xf), flat(yf)
    m0, m1 = st.mean(x), st.mean(y)
    v0, v1 = st.variance(x) / len(x), st.variance(y) / len(y)
    se = math.sqrt(v0 + v1)
    df = (v0 + v1) ** 2 / (v0 ** 2 / (len(x) - 1) + v1 ** 2 / (len(y) - 1)) if se > 0 else 1e9
    d = m1 - m0; h = tq(max(df, 30)) * se
    r, lo, hi = math.exp(d), math.exp(d - h), math.exp(d + h)
    hx, hy = (len(xf) + 1) // 2, (len(yf) + 1) // 2
    halves = [math.exp(st.mean(flat(yf[:hy])) - st.mean(flat(xf[:hx]))), math.exp(st.mean(flat(yf[hy:])) - st.mean(flat(xf[hx:])))]
    note = 'worse' if lo > 1.0 and min(halves) > 1.0 else ('worse?' if r > 1.01 else '')
    return math.exp(m0), math.exp(m1), r, lo, hi, halves, note
def ok(a, b, k): return k in a and k in b and len(a[k]) > 1 and len(b[k]) > 1 and all(len(f) > 1 for f in a[k] + b[k])
D = {n: load(n) for n in ('t0', 't1', 't0a', 't1a')}
prim = D['t0'][2]
cls = lambda k: 'G9' if prim.get(k[0]) == k[1] else 'report'
res = {}
for p0, p1, title in (('t0', 't1', 'default build'),
                      ('t0a', 't1a', 'functions aligned to 64 B, layout check')):
    (lr0, ab0, _), (lr1, ab1, _) = D[p0], D[p1]
    if not lr0 or not lr1:
        print(f'## {p1} / {p0} ({title})\n\nno data\n'); continue
    print(f'## XOffset / baseline, {p1} / {p0} ({title})\n')
    print(f'| case | baseline | class | {p0} GM | {p1} GM | {p1} / {p0} | 95% interval | halves | note |')
    print('| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |')
    worse, maybe = [], []
    for k in sorted(lr0, key=lambda k: (cls(k) != 'G9', k)):
        if not ok(lr0, lr1, k): continue
        g0, g1, r, lo, hi, hv, note = res.setdefault((p0, k), cmp(lr0[k], lr1[k]))
        if note == 'worse': worse.append(f'{k[0]} / {k[1]} ({cls(k)}) {r:.3f}')
        if note == 'worse?': maybe.append(f'{k[0]} / {k[1]} ({cls(k)}) {r:.3f}')
        print(f'| {k[0]} | {k[1]} | {cls(k)} | {g0:.3f} | {g1:.3f} | {r:.3f} | {lo:.3f}–{hi:.3f} | {hv[0]:.3f}, {hv[1]:.3f} | {note} |')
    print(f'\nworse at {p1} than {p0} (by the rule): ' + ('; '.join(worse) if worse else 'none'))
    print(f'\nabove 1.01 but not worse by the rule: ' + ('; '.join(maybe) if maybe else 'none') + '\n')
    print(f'## XOffset ns/op alone, {p1} / {p0} ({title})\n')
    print(f'| case | {p0} ns/op | {p1} ns/op | {p1} / {p0} | 95% interval | halves | note |\n| --- | ---: | ---: | ---: | --- | --- | --- |')
    slow = []
    for c in sorted(ab0):
        if not ok(ab0, ab1, c): continue
        g0, g1, r, lo, hi, hv, note = res.setdefault((p0, c), cmp(ab0[c], ab1[c]))
        if note == 'worse': slow.append(f'{c} {r:.3f}')
        print(f'| {c} | {g0:.4g} | {g1:.4g} | {r:.3f} | {lo:.3f}–{hi:.3f} | {hv[0]:.3f}, {hv[1]:.3f} | {note} |')
    print(f'\nXOffset slower at {p1} than {p0} (worse by the rule): ' + ('; '.join(slow) if slow else 'none') + '\n')
print('## layout check: what is worse at t1 in the default build, in the aligned build\n')
print('| comparison | t1 / t0 | t1a / t0a | 95% interval (aligned) | aligned |\n| --- | ---: | ---: | --- | --- |')
n = 0
for (p0, k), v in sorted(res.items(), key=lambda kv: str(kv[0])):
    if p0 != 't0' or v[6] != 'worse': continue
    a = res.get(('t0a', k)); n += 1
    name = f'{k[0]} / {k[1]} ({cls(k)})' if isinstance(k, tuple) else f'{k} (XOffset ns/op)'
    if a is None: print(f'| {name} | {v[2]:.3f} | – | – | no data |'); continue
    print(f'| {name} | {v[2]:.3f} | {a[2]:.3f} | {a[3]:.3f}–{a[4]:.3f} | {"still worse" if a[6] == "worse" else ("worse?" if a[6] else "not worse")} |')
if n == 0: print('| none | | | | |')
PY
{
    echo "# G9R3 result ($(utc))"; echo
    echo "t0 ${COMMITS[0]} (${LABELS[0]}); t1 $T1 (${LABELS[1]}); bench/reloc of t0 ($RL_TREE) for both."; echo
    echo '```'; cat "$R/points.txt"; echo '```'; echo
    echo "## G9 items, t1 / t0 and the aligned pair t1a / t0a (no item worse than t0 43669586)"; echo; cat "$R/g9_items.md"; echo
    echo "## reloc t1 / t0 (median per file, GM of 8 files each)"; echo; cat "$R/reloc_points.md"; echo
    echo "## analyze t0 (G9 at 43669586)"; echo; echo '```'; cat "$R/analyze_t0.md"; echo '```'; echo
    echo "## analyze t1 (G9 at the integration head)"; echo; echo '```'; cat "$R/analyze_t1.md"; echo '```'; echo
    echo "## quiet"; echo; echo '```'; cat "$R/quiet.log"; echo '```'
} > "$R/RESULT.md"
STATE_RELOC=done
cat "$R/g9_items.md"
grep -E -i 'G9|pass|fail' "$R/analyze_t1.md" | tail -5
finish 0
