#!/usr/bin/env python3
# analyze_d2.py RUN_DIR > RESULT.md
# Reads RUN_DIR/NNN_<build>.jsonl (d2_probe --json; builds "base" = v3.1.0,
# "head" = the 3.2 head) and writes the d2 tables and verdicts (Markdown).
import json, math, os, re, statistics as st, sys

T975 = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262,
        10: 2.228, 11: 2.201, 12: 2.179, 13: 2.160, 14: 2.145, 15: 2.131, 20: 2.086, 30: 2.042}
def t975(df):
    return T975.get(df) or T975[max(k for k in T975 if k <= df)]

def ci_mean(xs):
    n = len(xs); m = st.mean(xs)
    if n < 2: return m, float('nan'), float('nan')
    h = t975(n - 1) * st.stdev(xs) / math.sqrt(n)
    return m, m - h, m + h

def ci_gm(ratios):
    m, lo, hi = ci_mean([math.log(r) for r in ratios])
    return math.exp(m), math.exp(lo), math.exp(hi)

run = sys.argv[1]
procs = []  # (seq, build, {(cycle, variant): {round: ns}})
for f in sorted(os.listdir(run)):
    m = re.match(r'(\d+)_(base|head)\.jsonl$', f)
    if not m: continue
    cells = {}
    for line in open(os.path.join(run, f)):
        r = json.loads(line)
        cells.setdefault((r['cycle'], r['variant']), {})[r['round']] = r['ns']
    procs.append((int(m.group(1)), m.group(2), cells))
if not procs:
    print('no d2 runs found'); sys.exit(1)
cycles = sorted({c for _, _, cells in procs for c, _ in cells})
BASE = ['xo.read', 'xo.reload', 'xo.reverify', 'syn.q+scan', 'syn.w8+scan', 'syn.q', 'syn.scan', 'fb.verify', 'fb.read']
ORDER = BASE + ['t.empty'] + [v + '.t' for v in BASE if v != 'xo.reverify']
seen = {v for _, _, cells in procs for _, v in cells}
variants = [v for v in ORDER if v in seen] + sorted(seen - set(ORDER))

def med(cells, c, v): return st.median(cells[(c, v)].values())
def per_round(cells, c, f):
    rs = sorted(cells[(c, 'xo.read')])
    return [f(lambda v: cells[(c, v)][r]) for r in rs]

out = []
p = out.append
p('# d2：逐次计时口径与 3.2 head（Mac 微基准）\n')
p(f'进程 {len(procs)} 个（base {sum(b == "base" for _, b, _ in procs)}，head {sum(b == "head" for _, b, _ in procs)}），'
  f'每个进程每格 {len(next(iter(procs[0][2].values())))} 轮，每轮每格 2048 次读。cycle 是 slg_bench 的周期（报告随周期变小）。\n')
p('base 是 v3.1.0；head 是 3.2 的 head（根指针缓存、finish 用已知 offset 找根、reload 固定开销）。'
  '`.t` 变体把每次读单独放进 slg_bench 的 timed()（runner.hpp：前后各一次 steady_clock::now()，差值累加进 std::map 的 "D.read"）；'
  '不带 `.t` 的变体 2048 次读共用一对时钟，与 d1 相同。\n')

for b in ('base', 'head'):
    ps = [c for _, bb, c in procs if bb == b]
    if not ps: continue
    p(f'## 每次读的中位数 ns（{b}，各进程中位数的均值）\n')
    p('| 变体 | ' + ' | '.join(f'cycle {c}' for c in cycles) + ' | 周期平均 |')
    p('| --- |' + ' ---: |' * (len(cycles) + 1))
    for v in variants:
        vals = [st.mean(med(cells, c, v) for cells in ps) for c in cycles]
        p(f'| {v} | ' + ' | '.join(f'{x:.2f}' for x in vals) + f' | {st.mean(vals):.2f} |')
    p('')

def rows_for(b):
    ps = [c for _, bb, c in procs if bb == b]
    def row(name, f, fmt='{:.2f} [{:.2f}, {:.2f}]', gm=False):
        vals = []
        for c in cycles:
            xs = [st.median(per_round(cells, c, f)) for cells in ps]
            vals.append(ci_gm(xs) if gm else ci_mean(xs))
        p(f'| {name} | ' + ' | '.join(fmt.format(*x) for x in vals) + ' |')
        return vals
    p(f'## {b} 内部（每个进程先取逐轮值的中位数，再对进程求均值和 95% 区间）\n')
    p('| 量 | ' + ' | '.join(f'cycle {c}' for c in cycles) + ' |')
    p('| --- |' + ' ---: |' * len(cycles))
    r = {}
    r['timer'] = row('计时本身 ns = t.empty', lambda g: g('t.empty'))
    pen = lambda v: (lambda g: g(v + '.t') - g('t.empty') - g(v))
    r['pen_xo'] = row('逐次计时附加 ns：xo.read（xo.read.t − t.empty − xo.read）', pen('xo.read'))
    r['pen_xr'] = row('逐次计时附加 ns：xo.reload', pen('xo.reload'))
    r['pen_fb'] = row('逐次计时附加 ns：fb.read', pen('fb.read'))
    r['pen_fv'] = row('逐次计时附加 ns：fb.verify', pen('fb.verify'))
    r['pen_d'] = row('xoffset 多付的 ns = 附加(xo.read) − 附加(fb.read)',
                     lambda g: (g('xo.read.t') - g('xo.read')) - (g('fb.read.t') - g('fb.read')))
    r['dfb'] = row('D÷FB，整批计时 = xo.read ÷ fb.read', lambda g: g('xo.read') / g('fb.read'), '{:.3f} [{:.3f}, {:.3f}]', True)
    r['dfb_t'] = row('D÷FB，逐次计时 = xo.read.t ÷ fb.read.t（slg_bench 口径）', lambda g: g('xo.read.t') / g('fb.read.t'),
                     '{:.3f} [{:.3f}, {:.3f}]', True)
    r['ex'] = row('syn 超额，整批 ns = q+scan − q − scan', lambda g: g('syn.q+scan') - g('syn.q') - g('syn.scan'))
    r['ex_t'] = row('syn 超额，逐次 ns = q+scan.t − q.t − scan.t + t.empty',
                    lambda g: g('syn.q+scan.t') - g('syn.q.t') - g('syn.scan.t') + g('t.empty'))
    r['w8_t'] = row('syn.w8+scan.t ÷ syn.q+scan.t', lambda g: g('syn.w8+scan.t') / g('syn.q+scan.t'),
                    '{:.3f} [{:.3f}, {:.3f}]', True)
    row('校验（已落定）ns = xo.reverify − xo.reload', lambda g: g('xo.reverify') - g('xo.reload'))
    row('查询 ns = xo.read − xo.reload', lambda g: g('xo.read') - g('xo.reload'))
    p('')
    return r
R = {b: rows_for(b) for b in ('base', 'head') if any(bb == b for _, bb, _ in procs)}

seq = sorted(procs)
pairs = []
for i in range(0, len(seq) - 1, 2):
    a, b = seq[i], seq[i + 1]
    if {a[1], b[1]} == {'base', 'head'}:
        q, w = (a, b) if a[1] == 'base' else (b, a)
        pairs.append((q[2], w[2]))
p(f'## head ÷ base（相邻的 base、head 进程配对，{len(pairs)} 对；比值是进程中位数之比的几何均值和 95% 区间）\n')
p('| 变体 | ' + ' | '.join(f'cycle {c}' for c in cycles) + ' | ns 差（周期平均，head − base） |')
p('| --- |' + ' ---: |' * (len(cycles) + 1))
hb = {}
for v in ('xo.read.t', 'xo.read', 'xo.reload.t', 'xo.reload', 'xo.reverify', 'fb.read.t', 'fb.read', 'syn.q+scan'):
    if not pairs or v not in seen: continue
    cellsv = [ci_gm([med(w, c, v) / med(q, c, v) for q, w in pairs]) for c in cycles]
    dm, dlo, dhi = ci_mean([st.mean(med(w, c, v) - med(q, c, v) for c in cycles) for q, w in pairs])
    hb[v] = (cellsv, (dm, dlo, dhi))
    p(f'| {v} | ' + ' | '.join('{:.3f} [{:.3f}, {:.3f}]'.format(*x) for x in cellsv) + f' | {dm:+.2f} [{dlo:+.2f}, {dhi:+.2f}] |')
p('')
p('fb.read、fb.read.t 和 syn.q+scan 两份构建里是同一份代码（不经过库），它们的 head ÷ base 应在 1 附近，用来看两份二进制之间的布局和进程差异。\n')

p('## 判定（预先登记，只报，不是门禁）\n')
if 'base' in R:
    r = R['base']
    pd = r['pen_d']
    more = all(x[1] > 0 for x in pd)
    p(f'- 口径差（base）：逐次计时下 xoffset 比 FlatBuffers 多付 {st.mean(x[0] for x in pd):.2f} ns（周期平均）；'
      f'**{"每个周期区间下限 > 0：两套 harness 的差别有一块是 xoffset 独有的逐次计时代价" if more else "并非每个周期区间下限都 > 0：逐次计时不能解释 xoffset 独有的差距"}**。'
      f'D÷FB 整批 {st.mean(x[0] for x in r["dfb"]):.3f}，逐次 {st.mean(x[0] for x in r["dfb_t"]):.3f}（周期平均，slg_bench INT4 是 1.117）。')
    ex = r['ex_t']; w8 = r['w8_t']
    stall_t = all(x[1] > 0 for x in ex) and st.mean(x[0] for x in ex) >= 1.0 and all(x[2] < 1 for x in w8)
    p(f'- 逐次计时下的转发停顿：超额 {st.mean(x[0] for x in ex):.2f} ns（周期平均）；**{"成立：第 2 步要按逐次口径重新评估" if stall_t else "不成立：第 2 步维持不做"}**'
      '（要求：每个周期超额区间下限 > 0，平均 ≥ 1 ns，且 8 B 拷贝每个周期都更快）。')
if 'xo.read.t' in hb:
    cellsv, (dm, dlo, dhi) = hb['xo.read.t']
    if all(x[2] < 1 for x in cellsv): v = 'head 更快'
    elif all(x[1] > 1 for x in cellsv): v = 'head 更慢'
    else: v = '不确定（区间跨 1）'
    p(f'- head 对 base（slg_bench 口径 xo.read.t）：{dm:+.2f} ns [{dlo:+.2f}, {dhi:+.2f}]，**{v}**（要求：每个周期比值上限 < 1）。')
print('\n'.join(out))
