// fwd_probe: times the loops of fwd_probe.S and prints cycles per iteration.
//   fwd_probe [iterations=50000000] [rounds=9] [--json out.json]
// Each round runs every variant once, in a rotated order; the table reports the
// fastest and the median round. Cycles come from xo_add_chain (8 dependent adds,
// 8 cycles per iteration) timed in the same rounds.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#if defined(__APPLE__)
#include <pthread.h>
#endif

extern "C" {
std::uint64_t xo_add_chain(void*, std::uint64_t);
void xo_f1_w_w(void*, std::uint64_t);
void xo_f2_x_x(void*, std::uint64_t);
void xo_f3_w_then_x(void*, std::uint64_t);
void xo_f4_w_then_ldp_lo(void*, std::uint64_t);
void xo_f5_w_then_ldp_hi(void*, std::uint64_t);
void xo_f6_x_then_ldp_x(void*, std::uint64_t);
void xo_f7_stp_then_ldp(void*, std::uint64_t);
void xo_f8_q_then_ldp(void*, std::uint64_t);
void xo_f9_q_then_w(void*, std::uint64_t);
void xo_f10_x_then_ldp_hi(void*, std::uint64_t);
}

namespace {
struct Variant {
    const char* name;
    const char* what;
    void (*fn)(void*, std::uint64_t);
};
void calib(void* b, std::uint64_t n) { (void)xo_add_chain(b, n); }

const Variant variants[] = {
    {"calib", "8 dependent adds (8 cycles)", calib},
    {"F1", "str w, ldr w same 4 B", xo_f1_w_w},
    {"F2", "str x, ldr x same 8 B", xo_f2_x_x},
    {"F3", "str w, ldr x over it (low half)", xo_f3_w_then_x},
    {"F4", "str w size_, ldp w,w [#8] (xo push_back)", xo_f4_w_then_ldp_lo},
    {"F5", "str w size_, ldp w,w [#4] (begin+size)", xo_f5_w_then_ldp_hi},
    {"F6", "str x end, ldp x,x [#0] (libc++ vector)", xo_f6_x_then_ldp_x},
    {"F7", "stp w,w, ldp w,w same 8 B", xo_f7_stp_then_ldp},
    {"F8", "str q head, ldp w,w [#8] inside", xo_f8_q_then_ldp},
    {"F9", "str q head, ldr w [#8] inside", xo_f9_q_then_w},
    {"F10", "str x [#8], ldp w,w [#4] straddling", xo_f10_x_then_ldp_hi},
};
constexpr std::size_t K = sizeof(variants) / sizeof(variants[0]);

double now_ns() {
    return double(std::chrono::duration_cast<std::chrono::nanoseconds>(
                      std::chrono::steady_clock::now().time_since_epoch()).count());
}
double median(std::vector<double> v) {
    std::sort(v.begin(), v.end());
    const std::size_t n = v.size();
    return n % 2 ? v[n / 2] : 0.5 * (v[n / 2 - 1] + v[n / 2]);
}
}  // namespace

int main(int argc, char** argv) {
    std::uint64_t iters = 50000000;
    int rounds = 9;
    const char* json = nullptr;
    int pos = 0;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--json") && i + 1 < argc) json = argv[++i];
        else if (pos == 0) { iters = std::strtoull(argv[i], nullptr, 10); ++pos; }
        else if (pos == 1) { rounds = std::atoi(argv[i]); ++pos; }
    }
    if (iters == 0 || rounds < 1) { std::fprintf(stderr, "usage: fwd_probe [iterations] [rounds] [--json out]\n"); return 2; }
#if defined(__APPLE__)
    pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
#endif
    alignas(64) static unsigned char buf[64];
    std::vector<std::vector<double>> ns(K);
    for (int r = -1; r < rounds; ++r) {  // round -1 warms up
        for (std::size_t j = 0; j < K; ++j) {
            const std::size_t k = (j + std::size_t(r < 0 ? 0 : r)) % K;
            std::memset(buf, 0, sizeof buf);
            const double t0 = now_ns();
            variants[k].fn(buf, iters);
            const double t = now_ns() - t0;
            if (r >= 0) ns[k].push_back(t / double(iters));
        }
    }
    const double cyc_ns = *std::min_element(ns[0].begin(), ns[0].end()) / 8.0;  // ns per cycle
    std::printf("fwd_probe: %llu iterations x %d rounds; calibration %.4f ns/cycle (%.2f GHz)\n",
                (unsigned long long)iters, rounds, cyc_ns, 1.0 / cyc_ns);
    std::printf("%-5s %-44s %9s %9s %9s %9s\n", "case", "pattern", "min ns", "med ns", "min cyc", "med cyc");
    std::string out = "{\"iterations\": " + std::to_string(iters) + ", \"rounds\": " + std::to_string(rounds) +
                      ", \"ns_per_cycle\": " + std::to_string(cyc_ns) + ", \"cases\": [";
    for (std::size_t k = 0; k < K; ++k) {
        const double mn = *std::min_element(ns[k].begin(), ns[k].end()), md = median(ns[k]);
        std::printf("%-5s %-44s %9.3f %9.3f %9.2f %9.2f\n", variants[k].name, variants[k].what, mn, md, mn / cyc_ns, md / cyc_ns);
        out += std::string(k ? ", " : "") + "{\"case\": \"" + variants[k].name + "\", \"ns\": [";
        for (std::size_t i = 0; i < ns[k].size(); ++i) out += (i ? ", " : "") + std::to_string(ns[k][i]);
        out += "]}";
    }
    out += "]}\n";
    if (json) {
        if (FILE* f = std::fopen(json, "w")) { std::fputs(out.c_str(), f); std::fclose(f); }
        else { std::fprintf(stderr, "cannot write %s\n", json); return 1; }
    }
    return 0;
}
