# L2 Mac 门禁批次 2026-10-27-ckpt3-30af216

- head `30af216f6063316fb3348188f1570e53ecf26468`（CKPT3 head = next_cpp26 30af216 (#129 G9 L4 merged), build-r3d params）；anchor `35492720b5981d9672c8b8f00037dcb687aaf9fd`（3549272 (CKPT2b head, G8 checkpoint), build-r3d params）
- CKPT3: third checkpoint (merge rules v2; since 3549272: S #126 #127 #128 #129 = G9 L1-L4, 0 #120 #121 #125); anchor 3549272 (CKPT2b: pass); L1 L2 L3 bisection points, deferred
- **结论：pending**。正式部分 pending（合并 2 批），SLG pass。
- 环境失效规则（frozen by 性能优化 2026-10-23 14:51Z, not re…）：计时期间每 4 s 采一次屏幕负载，超限采样占比 >5% 即失效，同目录最多补跑一次。
- 8 个二进制在磁盘上用等长文件名（head→head, head_aa→hdaa, anchor→anch, r3→r3fz, cista→cist, flatbuffers→flat, capnproto→capn, cereal→cere）；raw 里的标签不变。每个二进制和 wire 各存 3 份独立文件，第 r 轮用第 r % 3 份（W0b 等长文件名后 A/A mutate 仍偏 1.2%，历次冻结之间在 -0.7% 到 +1.2% 之间变化，像是按文件的效应，轮换副本把它平均掉）。
- FREEZE.json sha256 `604e6209ae5c2944f9b2aa59c67b950381f7565aca75fa4ec9d69b04b52ada49`；mac_gate.py `fad50bd8854112ed351b2d21816d18e5e8553d1eca353afeb9dcc4481da212d5`；xc_ab.py `a95160a635e4d59f61cfaa66fdcbd31366a41a2ba645b1f9ddaf6164942abc60`

## 1. 新口径：head÷anchor（门禁）

逐周期 log 比值，各批周期合并；单侧 95% 上界，Bonferroni k=3。三项最大上界 ≤1.02 通过，1.02–1.03 待定（诊断后加跑一批、三批合并再判，>1.02 即失败），>1.03 失败。A/A（head_aa÷head，同一统计量）每项双侧区间含 1 且偏差 ≤1%，否则无效。

| 范围 | read_sum | mutate | emit_after | 最大上界 | 判定 | A/A read_sum / mutate / emit_after | A/A |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **合并 2 批（判定）** | 0.9974 [0.9842, 1.0093] | 0.9881 [0.9736, 1.0011] | 0.9881 [0.9747, 1.0001] | 1.0093 | pending | 0.9968 / 0.9928 / 1.0035 | 有效 |
| formal-1（单批，只报） | 1.0019 [0.9831, 1.0189] | 0.9826 [0.9637, 0.9995] | 0.9769 [0.9594, 0.9925] | 1.0189 | pass | 0.9957 / 0.9892 / 1.0007 | **无效** |
| formal-2（单批，只报） | 0.9929 [0.9738, 1.0101] | 0.9937 [0.9713, 1.0140] | 0.9994 [0.9791, 1.0177] | 1.0177 | pass | 0.9980 / 0.9964 / 1.0064 | 有效 |

区间列为 几何均值 [双侧下界, 单侧上界]。

**两批不一致，未合并判定（待定，先诊断再加跑一批）：** formal-1 vs formal-2 emit_after: 0.9769 vs 0.9994

逐周期 head÷anchor 比值的分位数（只报，看重尾是否由少数周期造成）：

| 范围 | read_sum p10 / 中位数 / p90 | mutate p10 / 中位数 / p90 | emit_after p10 / 中位数 / p90 |
| --- | --- | --- | --- |
| 合并 | 0.9364 / 0.9943 / 1.0733 | 0.9181 / 0.9897 / 1.0614 | 0.9140 / 0.9923 / 1.0839 |
| formal-1 | 0.9490 / 0.9988 / 1.0756 | 0.9178 / 0.9829 / 1.0545 | 0.9084 / 0.9791 / 1.0509 |
| formal-2 | 0.9258 / 0.9922 / 1.0668 | 0.9223 / 0.9930 / 1.0734 | 0.9160 / 0.9976 / 1.0946 |

### head÷anchor、head÷r3 其余指标（只报，双侧 95% k=12）

| 范围 | load | read_sum | mutate | emit_after | reload | total |
| --- | --- | --- | --- | --- | --- | --- |
| 合并 head÷anchor | 0.9974 [0.9882, 1.0067] | 0.9974 [0.9815, 1.0136] | 0.9881 [0.9707, 1.0058] | 0.9881 [0.9720, 1.0044] | 0.9919 [0.9720, 1.0122] | 0.9935 [0.9807, 1.0066] |
| formal-1 head÷anchor | 0.9992 [0.9861, 1.0124] | 1.0019 [0.9792, 1.0252] | 0.9826 [0.9598, 1.0058] | 0.9769 [0.9558, 0.9983] | 0.9848 [0.9533, 1.0174] | 0.9927 [0.9748, 1.0110] |
| formal-2 head÷anchor | 0.9956 [0.9821, 1.0094] | 0.9929 [0.9699, 1.0165] | 0.9937 [0.9666, 1.0215] | 0.9994 [0.9749, 1.0245] | 0.9991 [0.9741, 1.0246] | 0.9943 [0.9752, 1.0139] |
| 合并 head÷r3 | 0.4191 [0.4158, 0.4224] | 0.9513 [0.9387, 0.9641] | 0.9734 [0.9593, 0.9877] | 0.9853 [0.9700, 1.0008] | 0.4549 [0.4481, 0.4618] | 0.7938 [0.7866, 0.8010] |
| formal-1 head÷r3 | 0.4222 [0.4176, 0.4269] | 0.9547 [0.9350, 0.9748] | 0.9811 [0.9603, 1.0024] | 0.9869 [0.9673, 1.0070] | 0.4550 [0.4437, 0.4666] | 0.7972 [0.7858, 0.8088] |
| formal-2 head÷r3 | 0.4161 [0.4114, 0.4208] | 0.9480 [0.9316, 0.9646] | 0.9657 [0.9462, 0.9856] | 0.9836 [0.9594, 1.0084] | 0.4548 [0.4468, 0.4631] | 0.7904 [0.7814, 0.7995] |

head÷r3 是 G4 的数据（R3 冻结二进制 df876f6c），G4 判定归「性能优化」。

### 旧 norm 项（#30 等合并判据）

cereal:mutate norm head÷anchor（同轮里 cereal 约掉，等于 head÷anchor 的 mutate）。判据：合并后的几何均值 ≤1.016；单侧 95% 上界（k=2）只报。

| 范围 | 几何均值 | 单侧上界 | 几何均值 ≤门槛 |
| --- | --- | --- | --- |
| **合并（判据）** | 0.9881 | 1.0001 | 是 |
| formal-1 | 0.9826 | 0.9981 | 是 |
| formal-2 | 0.9937 | 1.0123 | 是 |

## 2. 旧口径：ROUND3 12 项（照原样，逐批）

head÷对手，联合单侧 95% 上界 k=12。

| 项 | 门槛 | formal-1 | formal-2 |
| --- | --- | --- | --- |
| cista:read_sum | 1.05 | 0.811 / 0.824 通过 | 0.799 / 0.810 通过 |
| cista:mutate | 1.05 | 0.711 / 0.724 通过 | 0.707 / 0.718 通过 |
| cista:emit_after | 0.2 | 0.146 / 0.148 通过 | 0.144 / 0.146 通过 |
| flatbuffers:read_sum | 1.05 | 0.623 / 0.634 通过 | 0.611 / 0.622 通过 |
| flatbuffers:mutate | 1.05 | 0.603 / 0.615 通过 | 0.601 / 0.614 通过 |
| flatbuffers:emit_after | 0.2 | 0.136 / 0.138 通过 | 0.136 / 0.138 通过 |
| capnproto:read_sum | 1.05 | 0.216 / 0.220 通过 | 0.211 / 0.214 通过 |
| capnproto:mutate | 1.05 | 0.251 / 0.255 通过 | 0.247 / 0.250 通过 |
| capnproto:emit_after | 0.2 | 0.384 / 0.391 **不通过** | 0.385 / 0.394 **不通过** |
| cereal:read_sum | 1.05 | 0.870 / 0.887 通过 | 0.858 / 0.877 通过 |
| cereal:mutate | 1.05 | 1.017 / 1.039 通过 | 1.012 / 1.031 通过 |
| cereal:emit_after | 0.2 | 0.190 / 0.193 通过 | 0.188 / 0.191 通过 |
| 通过数 head | | 11/12 | 11/12 |
| 通过数 anchor（同批） | | 10/12 | 11/12 |
| 通过数 r3（同批） | | 10/12 | 10/12 |
| 8 阶段 A/A（旧规则，只报） | | 无效（cleanup） | 无效（cleanup） |

reload 辅助比值（head÷对手，双侧 k=8）：

| 批 | cista | flatbuffers | capnproto | cereal |
| --- | --- | --- | --- | --- |
| formal-1 | 0.2088 [0.2040, 0.2136] | 0.4646 [0.4537, 0.4756] | 0.3667 [0.3581, 0.3755] | 0.3748 [0.3656, 0.3843] |
| formal-2 | 0.2060 [0.2033, 0.2087] | 0.4618 [0.4547, 0.4691] | 0.3681 [0.3629, 0.3733] | 0.3707 [0.3656, 0.3759] |

## 3. SLG M（head、anchor 交替进程 ABBA×3，SLG_REUSE=1，四家；1 组合并）

### 新口径 head÷anchor

每个进程的值 = 第 1–40 周期 log(xoffset 场景合计 ÷ 同周期三家几何均值) 的均值；Welch t，双侧 95%，k=4，各组进程合并。A、B、C 最大上界 ≤1.02 通过；1.02–1.03 待定，加跑一组 ABBA×3、两组合并后 ≤1.02 通过、否则失败；>1.03 失败。D 只报。

**SLG 判定：pass**（A、B、C 最大上界 1.0087）

| 场景 | head÷anchor（合并） | ≤1.02 |
| --- | --- | --- |
| A | 0.9787 [0.9545, 1.0034] | 是 |
| B | 0.9702 [0.9519, 0.9889] | 是 |
| C | 0.9900 [0.9717, 1.0087] | 是 |
| D | 0.9784 [0.9562, 1.0012] | 只报 |

按组（只报）；趋势调整 = 每组内对进程序号做线性回归后的 head÷anchor，双侧 k=4，只用于诊断会话内漂移，不参与判定：

| 组 | A Welch / 趋势调整 | B Welch / 趋势调整 | C Welch / 趋势调整 | D Welch / 趋势调整 | 漂移（最后÷第一个进程）|
| --- | --- | --- | --- | --- | --- |
| slg | 0.9787 [0.9545, 1.0034] / 0.9787 [0.9553, 1.0026] | 0.9702 [0.9519, 0.9889] / 0.9702 [0.9546, 0.9861] | 0.9900 [0.9717, 1.0087] / 0.9900 [0.9703, 1.0101] | 0.9784 [0.9562, 1.0012] / 0.9784 [0.9552, 1.0022] | head A 1.003 B 1.019 C 0.987 D 0.999；anchor A 0.975 B 1.004 C 0.998 D 1.010 |

ABBA 配对（只报，不参与判定）：每 4 个连续进程一块，块内 head 均值减 anchor 均值，块间 t，双侧 95% k=4。点估计与 Welch 相同；每组只有 3 块，自由度 2，区间通常更宽：

| 组 | A | B | C | D |
| --- | --- | --- | --- | --- |
| slg | 0.9787 [0.9266, 1.0337] | 0.9702 [0.9420, 0.9993] | 0.9900 [0.9210, 1.0641] | 0.9784 [0.9178, 1.0430] |
| 合并 | 0.9787 [0.9266, 1.0337] | 0.9702 [0.9420, 0.9993] | 0.9900 [0.9210, 1.0641] | 0.9784 [0.9178, 1.0430] |

进程数 head 6、anchor 6。

### 旧口径 G1–G3（head 进程合并）

每个 head 进程一个几何均值比值，进程间 t，单侧 95%，k=12；括号里是第一个 head 进程按 analyze.py 逐周期的上界。A、B、C ≤0.50 为达标。

| 场景 | cereal | protobuf | flatbuffers |
| --- | --- | --- | --- |
| A | 0.240 / 0.243 (0.257) | 0.088 / 0.089 (0.093) | 0.310 / 0.318 (0.327) |
| B | 0.131 / 0.134 (0.133) | 0.068 / 0.069 (0.069) | 0.169 / 0.173 (0.173) |
| C | 0.106 / 0.108 (0.111) | 0.063 / 0.064 (0.065) | 0.238 / 0.243 (0.252) |
| D | 0.332 / 0.345 (0.370) | 0.516 / 0.527 (0.579) | 1.340 / 1.371 (1.418) |

## 4. 环境

- 开跑条件 formal-1：2026-10-27T05:33:58+00:00 ok=True, quiet_s_required=180.0, waited_s=241.0, load1=2.03, quiet_s=240.9, screen={'WindowServer': 3.1, 'UURemoteServer': 0.0, 'parsecd': 0.0}, remote_active=[], screen_over=[], screen_gated=False
- 开跑条件 formal-2：2026-10-27T05:46:10+00:00 ok=True, quiet_s_required=180.0, waited_s=241.0, load1=2.24, quiet_s=240.9, screen={'WindowServer': 4.0, 'UURemoteServer': 0.0, 'parsecd': 0.0}, remote_active=[], screen_over=[], screen_gated=False
- 开跑条件 slg：2026-10-27T05:57:22+00:00 ok=True, quiet_s_required=180.0, waited_s=241.0, load1=1.91, quiet_s=241.0, screen={'WindowServer': 4.1, 'UURemoteServer': 0.0, 'parsecd': 0.0}, remote_active=[], screen_over=[], screen_gated=False
- formal-1：2026-10-27T05:37:59+00:00 → 2026-10-27T05:46:10+00:00，load [2.029296875, 2.021484375, 1.7802734375] → [2.13623046875, 2.10693359375, 1.89990234375]，CPU 采样 {'samples': 242, 'other_busy_samples': 73, 'compile_samples': 0, 'other_busy_top': {'WindowServer': 68, 'Claude Helper (Renderer)': 6, 'duetexpertd': 2, 'XprotectService': 1, 'runningboardd': 1}, 'chrome_busy_mean': 0, 'chrome_busy_max': 0, 'load1_max': 2.5}
  - 计时期间屏幕采样：0/123 次采样超限（0.0%，上限 5%），按进程 无，最高 pcpu {'WindowServer': 45.2, 'UURemoteServer': 0.3, 'parsecd': 0.0}；远程桌面活动（≥5%）0/123 次采样，只记录；WindowServer ≥20% 36/123 次采样，有效
- formal-2：2026-10-27T05:50:11+00:00 → 2026-10-27T05:57:22+00:00，load [2.244140625, 2.07177734375, 1.9248046875] → [2.3017578125, 2.18994140625, 2.0234375]，CPU 采样 {'samples': 212, 'other_busy_samples': 4, 'compile_samples': 0, 'other_busy_top': {'Claude Helper (Renderer)': 3, 'Codex (Renderer)': 1}, 'chrome_busy_mean': 0, 'chrome_busy_max': 0, 'load1_max': 2.59}
  - 计时期间屏幕采样：0/108 次采样超限（0.0%，上限 5%），按进程 无，最高 pcpu {'WindowServer': 4.0, 'UURemoteServer': 0.5, 'parsecd': 0.0}；远程桌面活动（≥5%）0/108 次采样，只记录；WindowServer ≥20% 0/108 次采样，有效
- slg 计时期间屏幕采样：0/15 次采样超限（0.0%，上限 5%），按进程 无，最高 pcpu {'WindowServer': 4.1, 'UURemoteServer': 0.0, 'parsecd': 0.0}；远程桌面活动（≥5%）0/15 次采样，只记录；WindowServer ≥20% 0/15 次采样，有效
- formal-1 A/A 逐轮 log 比值 sd（噪声；历史安静批次 mutate 约 0.06–0.08）：read_sum 0.095，mutate 0.090，emit_after 0.114；mutate 按副本 0.9578 / 0.9960 / 1.0147
- formal-2 A/A 逐轮 log 比值 sd（噪声；历史安静批次 mutate 约 0.06–0.08）：read_sum 0.089，mutate 0.090，emit_after 0.121；mutate 按副本 0.9957 / 1.0052 / 0.9885
- host macOS-26.3-arm64-arm-64bit；冻结 2026-10-27T05:33:58+00:00
- 二进制 sha256：head `328d8872af63ecee…`；head_aa `328d8872af63ecee…`；anchor `3340584675ac4ab9…`；r3 `6d4a33ba1f8547dc…`；cista `13bf74996c1723ce…`；flatbuffers `684f7be86bd7b628…`；capnproto `5a7625c96f0a3e7b…`；cereal `c897ba0d1a11a0e8…`
- SLG 树 bench/slg of 30af216 (v3 tree, git tree ffd88a16, unchanged since f8eebf4), used for every point（sha256 `2a010b04d53b4049727c4061b9ac750f26ff55bff2bb56da78a3f65c1c91081e`），slg_head `92dc470c974baf8c…`，slg_anch `cd5eac056a30d4f0…`
- 准备检查：gate_sml_head exit 0；slg_verify_reuse_head exit 0；slg_verify_default_head exit 0；gate_sml_anch exit 0；slg_verify_reuse_anch exit 0；slg_verify_default_anch exit 0
