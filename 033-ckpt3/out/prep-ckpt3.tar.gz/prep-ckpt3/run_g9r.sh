#!/bin/bash
# G9R: G9 relocation-tax diagnosis batch for throughput-20261026/mac_queue.sh (macOS bash 3.2).
# Steps file: /mnt/project-files/g9-reloc-20261027/MAC_STEPS_G9R.md. Design thread 「G9 重定位税诊断」.
# Measures only: no push, no merge, no library change. Not a merge gate: queue it after the merge gates.
#   1. fwd_probe: arm64 store-to-load forwarding latencies (sources embedded below, sha256 checked),
#      once before and once after the reloc runs
#   2. bench/reloc of next_cpp26 30af216 (L1-L5 merged), built against the library of 3549272 (t0) and of
#      30af216 (t1): 4 runs each, --rounds 101, order t0 t1 / t1 t0 / t0 t1 / t1 t0, quiet gate
#      before every timed run (no compiler, load1 < 3 for 180 s; the screen is darkened and recorded only)
#   3. disassembly of both reloc_bench binaries, gzipped, for the cloud to read
# Exit: 0 done, 2 a preparation check failed, 5 the quiet gate was never met. Whatever exists is copied.
set -u -o pipefail
# XO_* overrides exist only for the cloud dry run of this script.
XOQ_OUT=${XOQ_OUT:-$PWD/out}; mkdir -p "$XOQ_OUT"
PG=${XO_PG:-/Volumes/XOffsetCS/perf-gate}
EXPORT=${XO_EXPORT:-$PG/tools-96be66d/xo_export.sh}
EXPORT_SHA=64d7a188da31ceb72034ff962b0953e029f2fd14594ae590a68ef46322979f04
export XO_GIT=${XO_GIT:-/Volumes/XOffsetCS/git}
GIT=$XO_GIT/XOffsetDatastructure.git
T=${XO_T:-/Volumes/XOffsetCS/toolchain/p2996-d77eff1}
SDK=${XO_SDK:-/Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk}
QUIET_S=${XO_QUIET_S:-180}
ROUNDS=${XO_ROUNDS:-101}
PROBE_ITERS=${XO_PROBE_ITERS:-50000000}
PROBE_CXX=${XO_PROBE_CXX:-$T/bin/clang++}
PROBE_RUN=${XO_PROBE_RUN:-}   # cloud dry run only: qemu-aarch64
TAG=g9r
SRC=$PG/src/$TAG; BLD=$PG/build/$TAG; R=$PG/runs/$TAG-$(date -u +%Y%m%dT%H%M%SZ)
NAMES=(t0 t1)
COMMITS=(35492720b5981d9672c8b8f00037dcb687aaf9fd 30af216f6063316fb3348188f1570e53ecf26468)
TREES=(509b344339ea42adc60f8a66be3bd98d839219a8 039f816a0d30dd6acb25c55fe340d40f811edb2d)
LABELS=("next_cpp26 3549272 (G8 checkpoint)" "next_cpp26 30af216 (L5 #125, L1 #126, L2 #127, L3 #128, L4 #129; also #120, #121)")
# git -c core.abbrev=7 diff t0..t1 | shasum -a 256 (19 files, +475/-88)
DIFF1=8d42e43b2fbdc9a8ea17e96aaca3fe750402ecd42b512d14dbe003928ab19349
RL_TREE=aabaa1ed859747bc5237fe471e8107c6f92c642d   # bench/reloc of t1: 31 cases; G9 judges str.assign_short.view (k 19)
PROBE_S_SHA=36157ed3b927ab5add06d7748ef14788820364e7e21c4f2128966b9f1a7e2c71
PROBE_CPP_SHA=b91f39195f1ef38093cb774d2211d52206351a89a4ce31c6d2b6d8e0aeacf6ad
RC=0; STATE_PROBE="not run"; STATE_RELOC="not run"; STATE_DISASM="not run"
utc() { date -u +%Y-%m-%dT%H:%M:%SZ; }
log() { echo "== $(utc) $*"; }
sha() { shasum -a 256 "$1" | awk '{print $1}'; }
dark() { pmset displaysleepnow > /dev/null 2>&1 || true; }

finish() {
    RC=$1
    log "finish rc=$RC"
    if [ -d "$R" ]; then
        tar -C "$(dirname "$R")" -czf "$XOQ_OUT/g9r_raw.tar.gz" "$(basename "$R")" 2>/dev/null
        for f in RESULT.md probe_1.txt probe_2.txt analyze_t0.md analyze_t1.md reloc_points.md quiet.log; do
            [ -f "$R/$f" ] && cp "$R/$f" "$XOQ_OUT/"
        done
    fi
    printf 'probe %s\nreloc %s\ndisasm %s\nrc %s\n' "$STATE_PROBE" "$STATE_RELOC" "$STATE_DISASM" "$RC" > "$XOQ_OUT/VERDICTS.txt"
    ( cd "$XOQ_OUT" && find . -type f ! -name SHA256SUMS | sort | while read -r f; do shasum -a 256 "$f"; done > SHA256SUMS )
    rm -rf "${BLD:?}" "${SRC:?}"
    exit "$RC"
}
stop() { echo "STOP: $1"; finish "${2:-2}"; }

# ---------------------------------------------------------------- 0. tools and inputs
log "0. tools"
[ -f "$EXPORT" ] && [ "$(sha "$EXPORT")" = "$EXPORT_SHA" ] || stop "$EXPORT: missing or sha256 differs (want $EXPORT_SHA)"
for f in "$T/bin/clang++" "$SDK"; do [ -e "$f" ] || stop "missing $f"; done
for d in "$SRC" "$BLD" "$R"; do [ ! -e "$d" ] || stop "$d exists (left over from an earlier attempt: look before removing it)"; done
mkdir -p "$SRC" "$BLD" "$R"
cmake --version | head -1; ninja --version; "$T/bin/clang++" --version | head -1
sw_vers 2>/dev/null | tr '\n' ' '; echo; sysctl -n machdep.cpu.brand_string 2>/dev/null || true

# The probe sources (also at /mnt/project-files/g9-reloc-20261027/probe/, same sha256).
write_probe_sources() {
cat > "$P/fwd_probe.S" <<'XO_PROBE_EOF'
// fwd_probe.S: arm64 store-to-load forwarding probe for G9 (vec.push_back and the
// per-op overhead of vec.mid_*, set.*). Every variant is a loop whose only
// loop-carried chain runs through memory: load, add, store, and the next
// iteration's load of the bytes just stored. cycles/iter is the latency of that
// chain, so a load that cannot take its bytes from the store queue shows up as
// a longer iteration. x0 = 64-byte buffer (a container head lives at [x0]),
// x1 = iterations (> 0). Mach-O symbols carry a leading underscore.
#ifdef __APPLE__
#define SYM(n) _##n
#else
#define SYM(n) n
#endif
// A function entry: exported, 64-byte aligned. (';' separates statements in
// GNU syntax but starts a comment for Apple's arm64 assembler, so a macro.)
.macro FUNC name
    .globl \name
    .p2align 6
\name:
.endm
#define FN(n) FUNC SYM(n)

    .text

// Calibration: 8 dependent adds per iteration, 8 cycles/iter.
FN(xo_add_chain)
    mov     x2, #0
1:  add     x2, x2, #1
    add     x2, x2, #1
    add     x2, x2, #1
    add     x2, x2, #1
    add     x2, x2, #1
    add     x2, x2, #1
    add     x2, x2, #1
    add     x2, x2, #1
    subs    x1, x1, #1
    b.ne    1b
    mov     x0, x2
    ret

// F1: 4-byte store, 4-byte load of the same bytes (size_ alone).
FN(xo_f1_w_w)
1:  ldr     w8, [x0, #8]
    add     w8, w8, #1
    str     w8, [x0, #8]
    subs    x1, x1, #1
    b.ne    1b
    ret

// F2: 8-byte store, 8-byte load of the same bytes.
FN(xo_f2_x_x)
1:  ldr     x8, [x0, #8]
    add     x8, x8, #1
    str     x8, [x0, #8]
    subs    x1, x1, #1
    b.ne    1b
    ret

// F3: 4-byte store at the low half, then one 8-byte load over it.
FN(xo_f3_w_then_x)
1:  ldr     x8, [x0, #8]
    add     w8, w8, #1
    str     w8, [x0, #8]
    subs    x1, x1, #1
    b.ne    1b
    ret

// F4: the XVector push_back loop on arm64 today: ldp {size_, capacity_} at
// [#8], compare, 4-byte store of size_ (the low half of the next ldp).
FN(xo_f4_w_then_ldp_lo)
1:  ldp     w8, w9, [x0, #8]
    cmp     w8, w9
    add     w8, w8, #1
    str     w8, [x0, #8]
    subs    x1, x1, #1
    b.ne    1b
    ret

// F5: begin() + size(): ldp {data_delta, size_} at [#4], 4-byte store of
// size_ (the high half of the next ldp), as erase / insert then the next op.
FN(xo_f5_w_then_ldp_hi)
1:  ldp     w9, w8, [x0, #4]
    add     w8, w8, #1
    str     w8, [x0, #8]
    subs    x1, x1, #1
    b.ne    1b
    ret

// F6: libc++ vector: ldp {begin, end} of 8 bytes each, 8-byte store of end
// (exactly the high register of the next ldp).
FN(xo_f6_x_then_ldp_x)
1:  ldp     x9, x8, [x0]
    add     x8, x8, #4
    str     x8, [x0, #8]
    subs    x1, x1, #1
    b.ne    1b
    ret

// F7: the pair stored as a pair: stp {size_, capacity_}, ldp of the same 8 bytes.
FN(xo_f7_stp_then_ldp)
1:  ldp     w8, w9, [x0, #8]
    add     w8, w8, #1
    stp     w8, w9, [x0, #8]
    subs    x1, x1, #1
    b.ne    1b
    ret

// F8: the whole 16-byte head stored at once (v0 holds the other three
// fields), then the ldp {size_, capacity_} inside it.
FN(xo_f8_q_then_ldp)
    ldr     q0, [x0]
1:  ldp     w8, w9, [x0, #8]
    add     w8, w8, #1
    mov     v0.s[2], w8
    str     q0, [x0]
    subs    x1, x1, #1
    b.ne    1b
    ret

// F9: the whole 16-byte head stored, then a 4-byte load of size_ inside it.
FN(xo_f9_q_then_w)
    ldr     q0, [x0]
1:  ldr     w8, [x0, #8]
    add     w8, w8, #1
    mov     v0.s[2], w8
    str     q0, [x0]
    subs    x1, x1, #1
    b.ne    1b
    ret

// F10: 8-byte store of {size_, capacity_}, then the ldp {data_delta, size_}
// at [#4] that straddles it (store covers only the high half of the load).
FN(xo_f10_x_then_ldp_hi)
1:  ldp     w9, w8, [x0, #4]
    add     w8, w8, #1
    ldr     w10, [x0, #12]
    bfi     x8, x10, #32, #32
    str     x8, [x0, #8]
    subs    x1, x1, #1
    b.ne    1b
    ret
XO_PROBE_EOF
cat > "$P/fwd_probe.cpp" <<'XO_PROBE_EOF'
// fwd_probe: times the loops of fwd_probe.S and prints cycles per iteration.
//   fwd_probe [iterations=50000000] [rounds=9] [--json out.json]
// Each round runs every variant once, in a rotated order; the table reports the
// fastest and the median round. Cycles come from xo_add_chain (8 dependent adds,
// 8 cycles per iteration) timed in the same rounds.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#if defined(__APPLE__)
#include <pthread.h>
#endif

extern "C" {
std::uint64_t xo_add_chain(void*, std::uint64_t);
void xo_f1_w_w(void*, std::uint64_t);
void xo_f2_x_x(void*, std::uint64_t);
void xo_f3_w_then_x(void*, std::uint64_t);
void xo_f4_w_then_ldp_lo(void*, std::uint64_t);
void xo_f5_w_then_ldp_hi(void*, std::uint64_t);
void xo_f6_x_then_ldp_x(void*, std::uint64_t);
void xo_f7_stp_then_ldp(void*, std::uint64_t);
void xo_f8_q_then_ldp(void*, std::uint64_t);
void xo_f9_q_then_w(void*, std::uint64_t);
void xo_f10_x_then_ldp_hi(void*, std::uint64_t);
}

namespace {
struct Variant {
    const char* name;
    const char* what;
    void (*fn)(void*, std::uint64_t);
};
void calib(void* b, std::uint64_t n) { (void)xo_add_chain(b, n); }

const Variant variants[] = {
    {"calib", "8 dependent adds (8 cycles)", calib},
    {"F1", "str w, ldr w same 4 B", xo_f1_w_w},
    {"F2", "str x, ldr x same 8 B", xo_f2_x_x},
    {"F3", "str w, ldr x over it (low half)", xo_f3_w_then_x},
    {"F4", "str w size_, ldp w,w [#8] (xo push_back)", xo_f4_w_then_ldp_lo},
    {"F5", "str w size_, ldp w,w [#4] (begin+size)", xo_f5_w_then_ldp_hi},
    {"F6", "str x end, ldp x,x [#0] (libc++ vector)", xo_f6_x_then_ldp_x},
    {"F7", "stp w,w, ldp w,w same 8 B", xo_f7_stp_then_ldp},
    {"F8", "str q head, ldp w,w [#8] inside", xo_f8_q_then_ldp},
    {"F9", "str q head, ldr w [#8] inside", xo_f9_q_then_w},
    {"F10", "str x [#8], ldp w,w [#4] straddling", xo_f10_x_then_ldp_hi},
};
constexpr std::size_t K = sizeof(variants) / sizeof(variants[0]);

double now_ns() {
    return double(std::chrono::duration_cast<std::chrono::nanoseconds>(
                      std::chrono::steady_clock::now().time_since_epoch()).count());
}
double median(std::vector<double> v) {
    std::sort(v.begin(), v.end());
    const std::size_t n = v.size();
    return n % 2 ? v[n / 2] : 0.5 * (v[n / 2 - 1] + v[n / 2]);
}
}  // namespace

int main(int argc, char** argv) {
    std::uint64_t iters = 50000000;
    int rounds = 9;
    const char* json = nullptr;
    int pos = 0;
    for (int i = 1; i < argc; ++i) {
        if (!std::strcmp(argv[i], "--json") && i + 1 < argc) json = argv[++i];
        else if (pos == 0) { iters = std::strtoull(argv[i], nullptr, 10); ++pos; }
        else if (pos == 1) { rounds = std::atoi(argv[i]); ++pos; }
    }
    if (iters == 0 || rounds < 1) { std::fprintf(stderr, "usage: fwd_probe [iterations] [rounds] [--json out]\n"); return 2; }
#if defined(__APPLE__)
    pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
#endif
    alignas(64) static unsigned char buf[64];
    std::vector<std::vector<double>> ns(K);
    for (int r = -1; r < rounds; ++r) {  // round -1 warms up
        for (std::size_t j = 0; j < K; ++j) {
            const std::size_t k = (j + std::size_t(r < 0 ? 0 : r)) % K;
            std::memset(buf, 0, sizeof buf);
            const double t0 = now_ns();
            variants[k].fn(buf, iters);
            const double t = now_ns() - t0;
            if (r >= 0) ns[k].push_back(t / double(iters));
        }
    }
    const double cyc_ns = *std::min_element(ns[0].begin(), ns[0].end()) / 8.0;  // ns per cycle
    std::printf("fwd_probe: %llu iterations x %d rounds; calibration %.4f ns/cycle (%.2f GHz)\n",
                (unsigned long long)iters, rounds, cyc_ns, 1.0 / cyc_ns);
    std::printf("%-5s %-44s %9s %9s %9s %9s\n", "case", "pattern", "min ns", "med ns", "min cyc", "med cyc");
    std::string out = "{\"iterations\": " + std::to_string(iters) + ", \"rounds\": " + std::to_string(rounds) +
                      ", \"ns_per_cycle\": " + std::to_string(cyc_ns) + ", \"cases\": [";
    for (std::size_t k = 0; k < K; ++k) {
        const double mn = *std::min_element(ns[k].begin(), ns[k].end()), md = median(ns[k]);
        std::printf("%-5s %-44s %9.3f %9.3f %9.2f %9.2f\n", variants[k].name, variants[k].what, mn, md, mn / cyc_ns, md / cyc_ns);
        out += std::string(k ? ", " : "") + "{\"case\": \"" + variants[k].name + "\", \"ns\": [";
        for (std::size_t i = 0; i < ns[k].size(); ++i) out += (i ? ", " : "") + std::to_string(ns[k][i]);
        out += "]}";
    }
    out += "]}\n";
    if (json) {
        if (FILE* f = std::fopen(json, "w")) { std::fputs(out.c_str(), f); std::fclose(f); }
        else { std::fprintf(stderr, "cannot write %s\n", json); return 1; }
    }
    return 0;
}
XO_PROBE_EOF
}

# ---------------------------------------------------------------- 1. sources
log "1. export"
for i in 0 1; do
    n=${NAMES[$i]}; c=${COMMITS[$i]}
    bash "$EXPORT" "$c" "$SRC/$n" > "$R/export_$n.log" 2>&1 || stop "export $n $c failed (export_$n.log)"
    t=$(git -C "$GIT" rev-parse "$c^{tree}")
    [ "$t" = "${TREES[$i]}" ] || stop "$n: tree $t, expected ${TREES[$i]}"
    echo "$n $c tree $t typelayout $(git -C "$GIT" ls-tree "$c" external/typelayout | awk '{print $3}') (${LABELS[$i]})"
done
d=$(git -C "$GIT" -c core.abbrev=7 diff "${COMMITS[0]}..${COMMITS[1]}" | shasum -a 256 | awk '{print $1}')
[ "$d" = "$DIFF1" ] || stop "t1: diff over t0 sha256 $d, expected $DIFF1"
echo "t1: diff over t0 ${d:0:12} ($(git -C "$GIT" diff --stat "${COMMITS[0]}..${COMMITS[1]}" | tail -1))"
[ "$(git -C "$GIT" rev-parse "${COMMITS[1]}:bench/reloc")" = "$RL_TREE" ] || stop "bench/reloc tree of t1 differs"
RLS=$SRC/t1/bench/reloc   # the one bench/reloc, built against both libraries
python3 "$SRC/t1/bench/check_manifest.py" "$RLS" || stop "bench/reloc manifest check failed"
P=$R/probe; mkdir -p "$P"
write_probe_sources
[ "$(sha "$P/fwd_probe.S")" = "$PROBE_S_SHA" ] || stop "fwd_probe.S sha256 differs"
[ "$(sha "$P/fwd_probe.cpp")" = "$PROBE_CPP_SHA" ] || stop "fwd_probe.cpp sha256 differs"

# ---------------------------------------------------------------- 2. builds
log "2. build"
P2996_FLAGS=(-G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=$T/bin/clang++ -DCMAKE_OSX_SYSROOT=$SDK
  "-DCMAKE_CXX_FLAGS=${XO_CXXFLAGS:--stdlib=libc++ -pthread -isysroot $SDK}"
  "-DCMAKE_EXE_LINKER_FLAGS=${XO_LDFLAGS:--L$T/lib -Wl,-rpath,$T/lib}")
for n in t0 t1; do
    cmake -S "$RLS" -B "$BLD/cm-$n" "${P2996_FLAGS[@]}" -DXOFFSET_ROOT="$SRC/$n" > "$R/build_$n.log" 2>&1 \
      && cmake --build "$BLD/cm-$n" >> "$R/build_$n.log" 2>&1 || stop "reloc_bench $n build failed (build_$n.log)"
    mkdir -p "$BLD/$n"; cp -p "$BLD/cm-$n/reloc_bench" "$BLD/$n/"; rm -rf "${BLD:?}/cm-$n"
    echo "reloc_bench $n sha256 $(sha "$BLD/$n/reloc_bench")"
done
# shellcheck disable=SC2086
"$PROBE_CXX" -O2 -std=c++17 ${XO_PROBE_FLAGS:--stdlib=libc++ -isysroot $SDK -L$T/lib -Wl,-rpath,$T/lib} \
    "$P/fwd_probe.cpp" "$P/fwd_probe.S" -o "$BLD/fwd_probe" > "$R/build_probe.log" 2>&1 || stop "fwd_probe build failed (build_probe.log)"
for n in t0 t1; do
    "$BLD/$n/reloc_bench" --mode verify > "$R/verify_$n.log" 2>&1 || stop "reloc verify $n failed (verify_$n.log)"
    echo "reloc verify $n: $(tail -1 "$R/verify_$n.log")"
done
$PROBE_RUN "$BLD/fwd_probe" 100000 1 > "$R/probe_check.txt" 2>&1 || stop "fwd_probe check run failed (probe_check.txt)"

# disassembly (not timed): the cloud reads the push_back loop, the SHIFT rebase loop and the string assigns
OBJDUMP=""
for o in "$T/bin/llvm-objdump" "$(command -v objdump 2>/dev/null)"; do [ -n "$o" ] && [ -x "$o" ] && { OBJDUMP=$o; break; }; done
if [ -n "$OBJDUMP" ]; then
    for n in t0 t1; do "$OBJDUMP" -d --no-show-raw-insn -C "$BLD/$n/reloc_bench" 2>/dev/null | gzip -9 > "$XOQ_OUT/disasm_$n.txt.gz"; done
    "$OBJDUMP" -d --no-show-raw-insn "$BLD/fwd_probe" 2>/dev/null | gzip -9 > "$XOQ_OUT/disasm_probe.txt.gz"
    STATE_DISASM="done ($OBJDUMP)"
else
    STATE_DISASM="no objdump found"
fi
echo "disasm: $STATE_DISASM"

# ---------------------------------------------------------------- 3. timing
log "3. timing"
quiet() {
    local ok=0 waited=0 l ws busy
    dark
    while [ $ok -lt "$QUIET_S" ]; do
        l=$(sysctl -n vm.loadavg 2>/dev/null | awk '{print $2}'); l=${l:-0}
        ws=$(ps -A -o %cpu=,comm= | awk '/WindowServer/ {s += $1} END {print s + 0}')
        busy=$(ps -A -o comm= | grep -E -c '(^|/)(clang|clang\+\+|ld|ninja|cmake|make|ctest|cc1plus|swift-frontend)$')
        if [ "$busy" -eq 0 ] && awk -v l="$l" 'BEGIN {exit !(l < 3)}'; then ok=$((ok + 10)); else ok=0; fi
        [ $waited -ge 43200 ] && { echo "$(utc) $1 quiet timeout (load $l, WindowServer $ws%, compilers $busy)" >> "$R/quiet.log"; return 1; }
        sleep 10; waited=$((waited + 10))
    done
    echo "$(utc) $1 start: waited ${waited}s load $l WindowServer $ws% remote $(ps -A -o comm= | grep -E -c 'UU|ScreenSharing|screensharingd|RemoteDesktop')" >> "$R/quiet.log"
}
STATE_PROBE=started; STATE_RELOC=started
quiet "probe 1" || stop "quiet gate never met before probe 1 (nothing timed)" 5
$PROBE_RUN "$BLD/fwd_probe" "$PROBE_ITERS" 9 --json "$R/probe_1.json" > "$R/probe_1.txt" 2>&1 || stop "fwd_probe run 1 failed"
cat "$R/probe_1.txt"
ORD=("t0 t1" "t1 t0" "t0 t1" "t1 t0")
for i in 1 2 3 4; do for n in ${ORD[$((i - 1))]}; do
    quiet "reloc $n $i" || stop "reloc: quiet gate never met before $n $i (nothing timed after that)" 5
    "$BLD/$n/reloc_bench" --rounds "$ROUNDS" --out "$R/raw_${n}_$i.jsonl" > "$R/run_${n}_$i.log" 2>&1 || stop "reloc $n $i failed"
done; done
quiet "probe 2" || stop "quiet gate never met before probe 2" 5
$PROBE_RUN "$BLD/fwd_probe" "$PROBE_ITERS" 9 --json "$R/probe_2.json" > "$R/probe_2.txt" 2>&1 || stop "fwd_probe run 2 failed"
cat "$R/probe_2.txt"
STATE_PROBE=done

# ---------------------------------------------------------------- 4. analysis
log "4. analysis"
A=$RLS/tools/analyze.py
for n in t0 t1; do python3 "$A" "$R"/raw_${n}_*.jsonl > "$R/analyze_$n.md" 2>&1; done
# per case: the median XOffset and baseline ns per op of each file, GM over the 4 files; t1 / t0
python3 - "$R" > "$R/reloc_points.md" <<'PY'
import glob, json, math, statistics as st, sys
R = sys.argv[1]
def meds(f):
    xo, base = {}, {}
    for line in open(f):
        x = json.loads(line)
        if 'case' not in x or x.get('round', 0) <= 0: continue
        c = x['case']; ns = x['ns']
        xo.setdefault(c, []).append(ns['xoffset'] / x['ops'])
        other = [k for k in ns if k != 'xoffset']
        if other: base.setdefault(c, []).append(ns[other[0]] / x['ops'])
    return {c: st.median(a) for c, a in xo.items()}, {c: st.median(a) for c, a in base.items()}
gm = lambda a: math.exp(sum(map(math.log, a)) / len(a)) if a else float('nan')
pts = {n: [meds(f) for f in sorted(glob.glob(f'{R}/raw_{n}_*.jsonl'))] for n in ('t0', 't1')}
cases = sorted({c for m in pts['t0'] for c in m[0]})
print('| case | t0 xo ns/op | t1 xo ns/op | t1 / t0 | first baseline ns/op (t0 runs) |\n| --- | ---: | ---: | ---: | ---: |')
for c in cases:
    a = gm([m[0][c] for m in pts['t0'] if c in m[0]]); b = gm([m[0][c] for m in pts['t1'] if c in m[0]])
    s = gm([m[1][c] for m in pts['t0'] if c in m[1]])
    print(f'| {c} | {a:.2f} | {b:.2f} | {b / a:.3f} | {s:.2f} |')
PY
{
    echo "# G9R result ($(utc))"; echo
    echo "t0 ${COMMITS[0]} (${LABELS[0]}); t1 ${COMMITS[1]} (${LABELS[1]}); bench/reloc of t1 ($RL_TREE) for both."; echo
    echo "## fwd_probe"; echo; echo '```'; cat "$R/probe_1.txt"; echo; cat "$R/probe_2.txt"; echo '```'; echo
    echo "## reloc t1 / t0 (median per file, GM of 4 files)"; echo; cat "$R/reloc_points.md"; echo
    echo "## analyze t0"; echo; echo '```'; cat "$R/analyze_t0.md"; echo '```'; echo
    echo "## analyze t1"; echo; echo '```'; cat "$R/analyze_t1.md"; echo '```'; echo
    echo "## quiet"; echo; echo '```'; cat "$R/quiet.log"; echo '```'
} > "$R/RESULT.md"
STATE_RELOC=done
cat "$R/reloc_points.md"
finish 0
