## XOffset / baseline, t1 / t0 (default build)

| case | baseline | class | t0 GM | t1 GM | t1 / t0 | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.726 | 0.728 | 1.003 | 1.001–1.005 | 1.000, 1.005 | worse |
| hero.mid_insert.ord | std::vector | G9 | 0.758 | 0.756 | 0.998 | 0.995–1.002 | 0.995, 1.002 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.365 | 0.366 | 1.003 | 1.001–1.005 | 1.000, 1.006 |  |
| map.erase.fresh | std::flat_map | G9 | 0.936 | 0.941 | 1.005 | 1.003–1.008 | 1.010, 1.000 | worse |
| map.find.fresh | std::flat_map | G9 | 0.807 | 0.805 | 0.998 | 0.996–1.000 | 0.996, 0.999 |  |
| map.insert.fresh | std::flat_map | G9 | 0.866 | 0.873 | 1.008 | 1.006–1.011 | 1.009, 1.007 | worse |
| nested.build.ord | std | G9 | 0.326 | 0.326 | 0.999 | 0.996–1.002 | 0.996, 1.002 |  |
| reset | std | G9 | 0.241 | 0.261 | 1.086 | 1.072–1.100 | 0.990, 1.192 | worse? |
| set.erase.fresh | std::flat_set | G9 | 1.085 | 1.090 | 1.004 | 1.001–1.006 | 1.005, 1.002 | worse |
| set.find.fresh | std::flat_set | G9 | 0.754 | 0.755 | 1.001 | 0.999–1.002 | 1.002, 1.000 |  |
| set.insert.fresh | std::flat_set | G9 | 1.011 | 0.999 | 0.988 | 0.986–0.990 | 0.993, 0.984 |  |
| str.append | std::string | G9 | 0.350 | 0.426 | 1.217 | 1.212–1.223 | 1.212, 1.223 | worse |
| str.assign_long | std::string | G9 | 0.867 | 0.800 | 0.924 | 0.922–0.925 | 0.924, 0.923 |  |
| str.assign_short.view | std::string | G9 | 0.343 | 0.341 | 0.994 | 0.992–0.997 | 0.988, 1.001 |  |
| vec.iterate | std::vector | G9 | 1.001 | 1.000 | 0.999 | 0.999–1.000 | 1.000, 0.999 |  |
| vec.mid_erase | std::vector | G9 | 1.016 | 1.014 | 0.998 | 0.996–1.000 | 0.997, 1.000 |  |
| vec.mid_insert | std::vector | G9 | 0.982 | 0.956 | 0.974 | 0.972–0.976 | 0.975, 0.973 |  |
| vec.push_back | std::vector | G9 | 1.115 | 1.131 | 1.014 | 1.011–1.017 | 1.020, 1.008 | worse |
| vec.push_back_grow | std::vector | G9 | 0.775 | 0.765 | 0.987 | 0.983–0.991 | 0.981, 0.992 |  |
| hero.mid_erase.plain | std::vector | report | 4.066 | 4.001 | 0.984 | 0.981–0.987 | 0.976, 0.992 |  |
| hero.mid_insert.plain | std::vector | report | 4.185 | 4.185 | 1.000 | 0.996–1.004 | 0.998, 1.002 |  |
| hero.push_back_grow.plain | std::vector | report | 0.403 | 0.406 | 1.009 | 1.007–1.010 | 1.006, 1.011 | worse |
| map.erase.fresh | std::map | report | 0.741 | 0.747 | 1.007 | 1.005–1.010 | 1.009, 1.006 | worse |
| map.erase.reused | std::flat_map | report | 1.081 | 1.082 | 1.001 | 0.998–1.004 | 1.002, 1.000 |  |
| map.erase.reused | std::map | report | 1.641 | 1.662 | 1.013 | 1.007–1.019 | 1.014, 1.012 | worse |
| map.find.fresh | std::map | report | 0.325 | 0.320 | 0.987 | 0.983–0.990 | 0.985, 0.988 |  |
| map.find.reused | std::flat_map | report | 0.807 | 0.808 | 1.002 | 0.999–1.004 | 1.002, 1.001 |  |
| map.find.reused | std::map | report | 0.734 | 0.694 | 0.945 | 0.942–0.949 | 0.941, 0.950 |  |
| map.insert.fresh | std::map | report | 0.736 | 0.749 | 1.017 | 1.014–1.020 | 1.008, 1.026 | worse |
| map.insert.reused | std::flat_map | report | 1.001 | 1.006 | 1.005 | 1.003–1.007 | 1.006, 1.004 | worse |
| map.insert.reused | std::map | report | 1.815 | 1.840 | 1.014 | 1.008–1.019 | 1.005, 1.022 | worse |
| nested.build.plain | std | report | 0.337 | 0.338 | 1.002 | 0.999–1.005 | 1.001, 1.003 |  |
| set.erase.fresh | std::set | report | 0.671 | 0.674 | 1.003 | 1.001–1.006 | 1.006, 1.000 | worse |
| set.erase.reused | std::flat_set | report | 1.141 | 1.137 | 0.997 | 0.993–1.000 | 1.000, 0.993 |  |
| set.erase.reused | std::set | report | 1.322 | 1.365 | 1.032 | 1.023–1.042 | 1.026, 1.039 | worse |
| set.find.fresh | std::set | report | 0.299 | 0.300 | 1.002 | 0.998–1.007 | 1.003, 1.002 |  |
| set.find.reused | std::flat_set | report | 0.755 | 0.755 | 1.000 | 0.998–1.001 | 1.000, 1.000 |  |
| set.find.reused | std::set | report | 0.663 | 0.781 | 1.179 | 1.174–1.184 | 1.184, 1.174 | worse |
| set.insert.fresh | std::set | report | 0.659 | 0.654 | 0.992 | 0.988–0.995 | 0.980, 1.004 |  |
| set.insert.reused | std::flat_set | report | 1.085 | 1.085 | 1.000 | 0.997–1.003 | 1.003, 0.998 |  |
| set.insert.reused | std::set | report | 1.446 | 1.449 | 1.002 | 0.994–1.011 | 1.001, 1.003 |  |
| str.assign_short | std::string | report | 1.770 | 1.764 | 0.996 | 0.993–1.000 | 0.998, 0.995 |  |
| str.assign_short.copy | std::string | report | 1.150 | 1.150 | 1.000 | 0.997–1.002 | 0.999, 1.000 |  |

worse at t1 than t0 (by the rule): hero.mid_erase.ord / std::vector (G9) 1.003; map.erase.fresh / std::flat_map (G9) 1.005; map.insert.fresh / std::flat_map (G9) 1.008; set.erase.fresh / std::flat_set (G9) 1.004; str.append / std::string (G9) 1.217; vec.push_back / std::vector (G9) 1.014; hero.push_back_grow.plain / std::vector (report) 1.009; map.erase.fresh / std::map (report) 1.007; map.erase.reused / std::map (report) 1.013; map.insert.fresh / std::map (report) 1.017; map.insert.reused / std::flat_map (report) 1.005; map.insert.reused / std::map (report) 1.014; set.erase.fresh / std::set (report) 1.003; set.erase.reused / std::set (report) 1.032; set.find.reused / std::set (report) 1.179

above 1.01 but not worse by the rule: reset / std (G9) 1.086

## XOffset ns/op alone, t1 / t0 (default build)

| case | t0 ns/op | t1 ns/op | t1 / t0 | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 163.7 | 163.4 | 0.998 | 0.998–0.999 | 0.998, 0.999 |  |
| hero.mid_erase.plain | 912 | 896.8 | 0.983 | 0.981–0.986 | 0.975, 0.992 |  |
| hero.mid_insert.ord | 227.8 | 227.4 | 0.998 | 0.996–1.000 | 0.997, 0.999 |  |
| hero.mid_insert.plain | 1254 | 1251 | 0.998 | 0.995–1.001 | 0.999, 0.997 |  |
| hero.push_back_grow.ord | 31.91 | 31.93 | 1.001 | 0.999–1.002 | 1.005, 0.997 |  |
| hero.push_back_grow.plain | 35.18 | 35.44 | 1.008 | 1.006–1.009 | 1.011, 1.004 | worse |
| map.erase.fresh | 33 | 33.09 | 1.003 | 1.001–1.004 | 1.004, 1.001 | worse |
| map.erase.reused | 29.59 | 29.74 | 1.005 | 1.004–1.007 | 1.010, 1.001 | worse |
| map.find.fresh | 5.286 | 5.285 | 1.000 | 0.998–1.001 | 1.001, 0.998 |  |
| map.find.reused | 5.298 | 5.305 | 1.001 | 1.000–1.003 | 1.001, 1.001 |  |
| map.insert.fresh | 32.26 | 32.28 | 1.001 | 0.999–1.002 | 1.003, 0.998 |  |
| map.insert.reused | 29.55 | 29.57 | 1.001 | 0.999–1.002 | 1.005, 0.996 |  |
| nested.build.ord | 272.5 | 269.9 | 0.990 | 0.988–0.993 | 0.990, 0.991 |  |
| nested.build.plain | 279.4 | 279.7 | 1.001 | 0.999–1.003 | 0.994, 1.008 |  |
| reset | 30.83 | 30.86 | 1.001 | 0.993–1.008 | 0.999, 1.003 |  |
| set.erase.fresh | 29.8 | 29.79 | 1.000 | 0.999–1.000 | 1.002, 0.997 |  |
| set.erase.reused | 23.22 | 23.25 | 1.002 | 0.998–1.005 | 1.007, 0.996 |  |
| set.find.fresh | 4.879 | 4.879 | 1.000 | 1.000–1.001 | 1.000, 1.000 |  |
| set.find.reused | 4.88 | 4.877 | 0.999 | 0.998–1.000 | 0.999, 0.999 |  |
| set.insert.fresh | 29.25 | 28.97 | 0.990 | 0.988–0.992 | 0.993, 0.988 |  |
| set.insert.reused | 22.95 | 22.97 | 1.001 | 0.999–1.003 | 1.004, 0.997 |  |
| str.append | 1.537 | 1.552 | 1.010 | 1.006–1.014 | 1.018, 1.001 | worse |
| str.assign_long | 2.945 | 2.719 | 0.923 | 0.922–0.925 | 0.924, 0.923 |  |
| str.assign_short | 0.9373 | 0.9271 | 0.989 | 0.986–0.993 | 0.991, 0.988 |  |
| str.assign_short.copy | 0.6254 | 0.6213 | 0.994 | 0.989–0.998 | 0.999, 0.988 |  |
| str.assign_short.view | 0.9435 | 0.9369 | 0.993 | 0.989–0.997 | 0.998, 0.989 |  |
| vec.iterate | 0.03317 | 0.03314 | 0.999 | 0.999–1.000 | 1.000, 0.999 |  |
| vec.mid_erase | 40.12 | 40.25 | 1.003 | 1.002–1.005 | 1.003, 1.004 | worse |
| vec.mid_insert | 40.53 | 40.35 | 0.996 | 0.994–0.997 | 0.996, 0.995 |  |
| vec.push_back | 0.2973 | 0.2982 | 1.003 | 0.991–1.015 | 0.984, 1.022 |  |
| vec.push_back_grow | 0.2808 | 0.2786 | 0.992 | 0.986–0.999 | 0.992, 0.993 |  |

XOffset slower at t1 than t0 (worse by the rule): hero.push_back_grow.plain 1.008; map.erase.fresh 1.003; map.erase.reused 1.005; str.append 1.010; vec.mid_erase 1.003

## XOffset / baseline, t1a / t0a (functions aligned to 64 B, layout check)

| case | baseline | class | t0a GM | t1a GM | t1a / t0a | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.731 | 0.729 | 0.997 | 0.994–1.000 | 1.002, 0.993 |  |
| hero.mid_insert.ord | std::vector | G9 | 0.758 | 0.755 | 0.997 | 0.994–1.000 | 0.994, 1.001 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.366 | 0.360 | 0.984 | 0.981–0.986 | 0.976, 0.991 |  |
| map.erase.fresh | std::flat_map | G9 | 0.944 | 0.942 | 0.998 | 0.995–1.000 | 0.996, 0.999 |  |
| map.find.fresh | std::flat_map | G9 | 0.809 | 0.808 | 0.999 | 0.997–1.001 | 0.998, 1.000 |  |
| map.insert.fresh | std::flat_map | G9 | 0.867 | 0.867 | 1.000 | 0.997–1.003 | 1.007, 0.993 |  |
| nested.build.ord | std | G9 | 0.320 | 0.320 | 1.003 | 1.000–1.006 | 1.018, 0.988 |  |
| reset | std | G9 | 0.251 | 0.263 | 1.047 | 1.041–1.052 | 1.090, 1.005 | worse |
| set.erase.fresh | std::flat_set | G9 | 1.095 | 1.091 | 0.996 | 0.993–1.000 | 0.999, 0.994 |  |
| set.find.fresh | std::flat_set | G9 | 0.756 | 0.756 | 1.000 | 0.998–1.002 | 0.999, 1.001 |  |
| set.insert.fresh | std::flat_set | G9 | 1.001 | 1.000 | 0.998 | 0.996–1.001 | 1.000, 0.996 |  |
| str.append | std::string | G9 | 0.432 | 0.425 | 0.983 | 0.978–0.988 | 1.002, 0.964 |  |
| str.assign_long | std::string | G9 | 0.867 | 0.866 | 0.999 | 0.997–1.001 | 0.998, 1.001 |  |
| str.assign_short.view | std::string | G9 | 0.343 | 0.343 | 1.001 | 0.999–1.004 | 1.002, 1.001 |  |
| vec.iterate | std::vector | G9 | 1.001 | 1.001 | 1.000 | 0.999–1.001 | 0.999, 1.001 |  |
| vec.mid_erase | std::vector | G9 | 1.024 | 1.020 | 0.996 | 0.993–0.999 | 0.989, 1.003 |  |
| vec.mid_insert | std::vector | G9 | 0.991 | 0.965 | 0.973 | 0.971–0.976 | 0.971, 0.976 |  |
| vec.push_back | std::vector | G9 | 1.124 | 1.118 | 0.995 | 0.992–0.998 | 0.997, 0.993 |  |
| vec.push_back_grow | std::vector | G9 | 0.756 | 0.758 | 1.003 | 0.999–1.008 | 0.995, 1.011 |  |
| hero.mid_erase.plain | std::vector | report | 4.056 | 4.030 | 0.993 | 0.990–0.997 | 0.991, 0.996 |  |
| hero.mid_insert.plain | std::vector | report | 4.155 | 4.135 | 0.995 | 0.992–0.999 | 0.985, 1.006 |  |
| hero.push_back_grow.plain | std::vector | report | 0.403 | 0.400 | 0.993 | 0.991–0.995 | 0.984, 1.003 |  |
| map.erase.fresh | std::map | report | 0.746 | 0.749 | 1.005 | 1.002–1.007 | 1.002, 1.007 | worse |
| map.erase.reused | std::flat_map | report | 1.080 | 1.086 | 1.006 | 1.003–1.009 | 1.004, 1.008 | worse |
| map.erase.reused | std::map | report | 1.602 | 1.666 | 1.040 | 1.033–1.047 | 1.046, 1.033 | worse |
| map.find.fresh | std::map | report | 0.323 | 0.324 | 1.001 | 0.997–1.005 | 0.998, 1.004 |  |
| map.find.reused | std::flat_map | report | 0.808 | 0.808 | 1.000 | 0.998–1.002 | 0.999, 1.001 |  |
| map.find.reused | std::map | report | 0.734 | 0.738 | 1.006 | 1.001–1.010 | 1.013, 0.998 |  |
| map.insert.fresh | std::map | report | 0.742 | 0.727 | 0.980 | 0.976–0.984 | 0.974, 0.987 |  |
| map.insert.reused | std::flat_map | report | 1.006 | 1.006 | 1.000 | 0.997–1.003 | 1.000, 1.000 |  |
| map.insert.reused | std::map | report | 1.779 | 1.812 | 1.018 | 1.012–1.024 | 1.014, 1.023 | worse |
| nested.build.plain | std | report | 0.330 | 0.334 | 1.012 | 1.009–1.016 | 1.027, 0.998 | worse? |
| set.erase.fresh | std::set | report | 0.675 | 0.676 | 1.002 | 0.999–1.005 | 1.004, 0.999 |  |
| set.erase.reused | std::flat_set | report | 1.142 | 1.135 | 0.994 | 0.991–0.998 | 0.992, 0.996 |  |
| set.erase.reused | std::set | report | 1.320 | 1.350 | 1.023 | 1.015–1.031 | 1.029, 1.017 | worse |
| set.find.fresh | std::set | report | 0.300 | 0.300 | 0.998 | 0.994–1.003 | 0.998, 0.999 |  |
| set.find.reused | std::flat_set | report | 0.755 | 0.755 | 1.000 | 0.998–1.002 | 1.000, 1.000 |  |
| set.find.reused | std::set | report | 0.677 | 0.683 | 1.009 | 1.006–1.011 | 1.005, 1.012 | worse |
| set.insert.fresh | std::set | report | 0.652 | 0.650 | 0.997 | 0.994–1.000 | 1.003, 0.991 |  |
| set.insert.reused | std::flat_set | report | 1.081 | 1.083 | 1.002 | 0.998–1.005 | 1.000, 1.004 |  |
| set.insert.reused | std::set | report | 1.394 | 1.418 | 1.017 | 1.007–1.027 | 1.022, 1.013 | worse |
| str.assign_short | std::string | report | 1.768 | 1.764 | 0.998 | 0.997–0.999 | 0.997, 0.998 |  |
| str.assign_short.copy | std::string | report | 1.150 | 1.149 | 0.999 | 0.998–1.000 | 1.000, 0.998 |  |

worse at t1a than t0a (by the rule): reset / std (G9) 1.047; map.erase.fresh / std::map (report) 1.005; map.erase.reused / std::flat_map (report) 1.006; map.erase.reused / std::map (report) 1.040; map.insert.reused / std::map (report) 1.018; set.erase.reused / std::set (report) 1.023; set.find.reused / std::set (report) 1.009; set.insert.reused / std::set (report) 1.017

above 1.01 but not worse by the rule: nested.build.plain / std (report) 1.012

## XOffset ns/op alone, t1a / t0a (functions aligned to 64 B, layout check)

| case | t0a ns/op | t1a ns/op | t1a / t0a | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 165.5 | 163.8 | 0.990 | 0.987–0.993 | 0.997, 0.983 |  |
| hero.mid_erase.plain | 911.6 | 904.5 | 0.992 | 0.990–0.995 | 0.991, 0.993 |  |
| hero.mid_insert.ord | 228.8 | 228.5 | 0.999 | 0.997–1.000 | 0.998, 0.999 |  |
| hero.mid_insert.plain | 1251 | 1240 | 0.991 | 0.990–0.993 | 0.988, 0.995 |  |
| hero.push_back_grow.ord | 31.88 | 31.61 | 0.992 | 0.989–0.994 | 0.991, 0.993 |  |
| hero.push_back_grow.plain | 35.28 | 35.11 | 0.995 | 0.993–0.997 | 0.992, 0.999 |  |
| map.erase.fresh | 33.02 | 33.03 | 1.000 | 0.999–1.002 | 1.000, 1.001 |  |
| map.erase.reused | 29.65 | 29.76 | 1.004 | 1.002–1.005 | 1.002, 1.006 | worse |
| map.find.fresh | 5.288 | 5.289 | 1.000 | 0.998–1.002 | 1.000, 1.001 |  |
| map.find.reused | 5.305 | 5.303 | 1.000 | 0.998–1.001 | 0.998, 1.001 |  |
| map.insert.fresh | 32.3 | 32.24 | 0.998 | 0.996–1.000 | 0.999, 0.997 |  |
| map.insert.reused | 29.54 | 29.57 | 1.001 | 0.998–1.004 | 1.003, 0.999 |  |
| nested.build.ord | 267.3 | 269.3 | 1.008 | 1.005–1.010 | 1.019, 0.996 |  |
| nested.build.plain | 275.6 | 281.7 | 1.022 | 1.017–1.027 | 1.050, 0.995 | worse? |
| reset | 29.57 | 31.07 | 1.051 | 1.045–1.057 | 1.111, 0.994 | worse? |
| set.erase.fresh | 29.81 | 29.78 | 0.999 | 0.997–1.001 | 0.999, 0.999 |  |
| set.erase.reused | 23.28 | 23.19 | 0.996 | 0.993–0.999 | 0.996, 0.997 |  |
| set.find.fresh | 4.884 | 4.882 | 1.000 | 0.998–1.001 | 0.998, 1.001 |  |
| set.find.reused | 4.879 | 4.877 | 1.000 | 0.998–1.001 | 0.999, 1.001 |  |
| set.insert.fresh | 28.95 | 28.89 | 0.998 | 0.996–1.000 | 1.000, 0.996 |  |
| set.insert.reused | 22.9 | 22.84 | 0.998 | 0.995–1.000 | 0.995, 1.001 |  |
| str.append | 1.581 | 1.547 | 0.978 | 0.974–0.983 | 0.981, 0.976 |  |
| str.assign_long | 2.952 | 2.942 | 0.997 | 0.994–0.999 | 0.997, 0.996 |  |
| str.assign_short | 0.9405 | 0.9334 | 0.992 | 0.989–0.996 | 0.997, 0.988 |  |
| str.assign_short.copy | 0.6287 | 0.624 | 0.993 | 0.988–0.997 | 0.995, 0.990 |  |
| str.assign_short.view | 0.9442 | 0.938 | 0.993 | 0.990–0.997 | 1.002, 0.985 |  |
| vec.iterate | 0.03343 | 0.03324 | 0.994 | 0.992–0.997 | 0.999, 0.990 |  |
| vec.mid_erase | 40.79 | 40.55 | 0.994 | 0.991–0.997 | 0.991, 0.997 |  |
| vec.mid_insert | 40.56 | 40.73 | 1.004 | 1.002–1.006 | 1.006, 1.003 | worse |
| vec.push_back | 0.2759 | 0.2722 | 0.986 | 0.983–0.990 | 0.994, 0.979 |  |
| vec.push_back_grow | 0.2708 | 0.2694 | 0.995 | 0.992–0.998 | 0.998, 0.992 |  |

XOffset slower at t1a than t0a (worse by the rule): map.erase.reused 1.004; vec.mid_insert 1.004

## layout check: what is worse at t1 in the default build, in the aligned build

| comparison | t1 / t0 | t1a / t0a | 95% interval (aligned) | aligned |
| --- | ---: | ---: | --- | --- |
| hero.push_back_grow.plain (XOffset ns/op) | 1.008 | 0.995 | 0.993–0.997 | not worse |
| map.erase.fresh (XOffset ns/op) | 1.003 | 1.000 | 0.999–1.002 | not worse |
| map.erase.reused (XOffset ns/op) | 1.005 | 1.004 | 1.002–1.005 | still worse |
| str.append (XOffset ns/op) | 1.010 | 0.978 | 0.974–0.983 | not worse |
| vec.mid_erase (XOffset ns/op) | 1.003 | 0.994 | 0.991–0.997 | not worse |
| hero.mid_erase.ord / std::vector (G9) | 1.003 | 0.997 | 0.994–1.000 | not worse |
| hero.push_back_grow.plain / std::vector (report) | 1.009 | 0.993 | 0.991–0.995 | not worse |
| map.erase.fresh / std::flat_map (G9) | 1.005 | 0.998 | 0.995–1.000 | not worse |
| map.erase.fresh / std::map (report) | 1.007 | 1.005 | 1.002–1.007 | still worse |
| map.erase.reused / std::map (report) | 1.013 | 1.040 | 1.033–1.047 | still worse |
| map.insert.fresh / std::flat_map (G9) | 1.008 | 1.000 | 0.997–1.003 | not worse |
| map.insert.fresh / std::map (report) | 1.017 | 0.980 | 0.976–0.984 | not worse |
| map.insert.reused / std::flat_map (report) | 1.005 | 1.000 | 0.997–1.003 | not worse |
| map.insert.reused / std::map (report) | 1.014 | 1.018 | 1.012–1.024 | still worse |
| set.erase.fresh / std::flat_set (G9) | 1.004 | 0.996 | 0.993–1.000 | not worse |
| set.erase.fresh / std::set (report) | 1.003 | 1.002 | 0.999–1.005 | not worse |
| set.erase.reused / std::set (report) | 1.032 | 1.023 | 1.015–1.031 | still worse |
| set.find.reused / std::set (report) | 1.179 | 1.009 | 1.006–1.011 | still worse |
| str.append / std::string (G9) | 1.217 | 0.983 | 0.978–0.988 | not worse |
| vec.push_back / std::vector (G9) | 1.014 | 0.995 | 0.992–0.998 | not worse |
