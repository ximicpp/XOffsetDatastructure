# G9R3 result (2026-10-28T18:19:04Z)

t0 9ef5ce75d72a172660a97d9fb4e188da3945f6c6 (v3.1.0 9ef5ce75 (library of the INT4 head e913d22)); t1 70a07a059cd82417bb0bb0a69ca9dea91c3b21ff (CKPT4 head (next_cpp26)); bench/reloc of t0 (aabaa1ed859747bc5237fe471e8107c6f92c642d) for both.

```
t0 9ef5ce75d72a172660a97d9fb4e188da3945f6c6 tree deb8af3b0cadbd09c4f51e7917da8c3496dc62b8 typelayout fe295929d0a5bfa7809fb737a6eb3db279599346 (v3.1.0 9ef5ce75 (library of the INT4 head e913d22))
t1 70a07a059cd82417bb0bb0a69ca9dea91c3b21ff tree 1fcf90357c114744114e582ba2d0d68f59d6f728 typelayout fe295929d0a5bfa7809fb737a6eb3db279599346 (CKPT4 head (next_cpp26))
t1: diff over t0 sha256 2321054a4f1c8502ffa6d582761936dabdf0db718251975550146519e0295dc9 ( 328 files changed, 29234 insertions(+), 2628 deletions(-))
t1: library header diff over t0:  2 files changed, 1532 insertions(+), 911 deletions(-)
t1: first-parent commits over t0:
  70a07a05 docs: macOS client row from pack 1108193 (137/137, corpus edits byte-identical) (#179)
  1108193d Merge pull request #177 from ximicpp/claude/portable-schema-20261028 (class S)
  f7ea8339 Merge pull request #176 from ximicpp/claude/release-3.2.0-rc.2 (class 0)
  ffef6f32 Merge pull request #172 from ximicpp/claude/rc1-platform-records-20261028 (class S)
  e489b6ab Merge pull request #171 from ximicpp/claude/phone-host-opnew-20261028 (class 0)
  f750f11e Merge pull request #175 from ximicpp/claude/mapdemo-writeback-mac-20261028 (class 0)
  c8049925 Merge pull request #174 from ximicpp/claude/mapdemo-writeback-20261028 (class 0)
  bdf895de Merge pull request #173 from ximicpp/claude/schema-guard-cxx20-note-20261028 (class 0)
  ed045009 Merge pull request #169 from ximicpp/claude/noexc-receive-speed-20261028 (class S)
  3a06f38e Merge pull request #162 from ximicpp/claude/phone-host-20261028 (class S)
  2a823fe4 Merge pull request #170 from ximicpp/codex/schema-guard-review (class 0)
  9cef5f53 Merge pull request #168 from ximicpp/claude/mapdemo-old-client-20261028 (class 0)
  32ab499d Merge #167: MSVC: no C5030 from register_owned_bitmap (class S)
  964b2bc0 Merge pull request #163 from ximicpp/claude/freeze-record-lines-20261028 (class 0)
  59012329 Merge pull request #166 from ximicpp/claude/small-msg-dict-20261028 (class 0)
  39de6364 Merge pull request #164 from ximicpp/claude/release-3.2.0-rc.1 (class 0)
  625571d2 Merge pull request #165 from ximicpp/claude/client-columns-20261028 (class 0)
  6ee9e6d7 Merge pull request #160 from ximicpp/claude/ios-vm-region-20261028 (class 0)
  acf92c41 Merge pull request #161 from ximicpp/claude/mapdemo-ios-sim-20261028 (class 0)
  af601ea0 Merge pull request #158 from ximicpp/claude/mapdemo-macos-window-20261028 (class 0)
  bb7714cf Merge pull request #157 from ximicpp/claude/mapdemo-noexc-20261028 (class 0)
  7ddfcee3 Merge pull request #155 from ximicpp/claude/mingw-tls-fix-20261028 (class S)
  c928334d Merge pull request #156 from ximicpp/claude/ledger-153-20261028
  7680be41 Merge pull request #153 from ximicpp/claude/d-iter-20261027 (class L)
  579ca446 Merge pull request #154 from ximicpp/claude/mapdemo-android-emu-20261028 (class 0)
  7599286a Merge pull request #151 from ximicpp/claude/fuzz-nightly-evolution-20261027 (class 0)
  92404a27 Merge pull request #148 from ximicpp/claude/no-exceptions-20261027 (class S)
  00b5d351 Merge pull request #152 from ximicpp/claude/mapdemo-e2e-20261027 (class 0)
  ed1852ab Merge pull request #150 from ximicpp/claude/docs-k-field-table-20261027 (class 0)
  43669586 Merge pull request #146 from ximicpp/claude/schema-evolution-20261027 (class 0)
  5af77d34 Merge pull request #149 from ximicpp/claude/client-native-cpp20-20261027 (class S)
  f0308ee7 Merge pull request #147 from ximicpp/claude/d-read-root-20261027 (class L)
  431a7ee2 Merge pull request #145 from ximicpp/claude/schema-handshake-e1-20261027 (class 0)
  c5968008 Merge pull request #144 from ximicpp/claude/client-docs-sc9-20261027 (class 0)
  d2db6627 Merge pull request #143 from ximicpp/claude/anchor-v3.1.0-20261027 (class 0)
bench/reloc of t1: tree a7e8b02792a9cf4258e012fe4881330c6c9d5e59 differs from t0 (aabaa1ed859747bc5237fe471e8107c6f92c642d): t0's is timed against both libraries
reloc_bench t0 sha256 fccdef1448731cfe460f520e3fabc7ec825494ee4bb2be4bd2d4227ef3ffa41b
reloc_bench t1 sha256 8d7cf69da8f65111da5837039b75d16cf334d51cd6254d5cef1e9d6033665e20
reloc_bench t0a sha256 b9a3d4539809de34cd94106c20b31517af5cb2a8a32a8fdeb48a7619be731810
reloc_bench t1a sha256 6e809e648798c44452f1edefc4ea856bd6f3d6c152c8fc5480886d6ff2e74116
```

## G9 items, t1 / t0 and the aligned pair t1a / t0a (no item worse than v3.1.0)

## XOffset / baseline, t1 / t0 (default build)

| case | baseline | class | t0 GM | t1 GM | t1 / t0 | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.723 | 0.727 | 1.005 | 1.002–1.007 | 1.006, 1.003 | worse |
| hero.mid_insert.ord | std::vector | G9 | 0.759 | 0.758 | 0.998 | 0.995–1.002 | 1.003, 0.994 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.381 | 0.383 | 1.007 | 1.005–1.009 | 1.004, 1.009 | worse |
| map.erase.fresh | std::flat_map | G9 | 0.937 | 0.941 | 1.004 | 1.002–1.007 | 1.005, 1.003 | worse |
| map.find.fresh | std::flat_map | G9 | 0.784 | 0.784 | 1.000 | 0.998–1.002 | 0.999, 1.001 |  |
| map.insert.fresh | std::flat_map | G9 | 0.870 | 0.867 | 0.996 | 0.994–0.998 | 0.999, 0.994 |  |
| nested.build.ord | std | G9 | 0.347 | 0.349 | 1.008 | 1.003–1.012 | 0.995, 1.021 |  |
| reset | std | G9 | 0.224 | 0.223 | 0.996 | 0.977–1.015 | 1.040, 0.954 |  |
| set.erase.fresh | std::flat_set | G9 | 1.087 | 1.085 | 0.998 | 0.996–0.999 | 0.998, 0.997 |  |
| set.find.fresh | std::flat_set | G9 | 0.755 | 0.756 | 1.001 | 0.998–1.004 | 1.001, 1.002 |  |
| set.insert.fresh | std::flat_set | G9 | 0.995 | 0.998 | 1.003 | 1.000–1.006 | 1.002, 1.004 | worse |
| str.append | std::string | G9 | 0.419 | 0.428 | 1.024 | 1.019–1.028 | 1.035, 1.013 | worse |
| str.assign_long | std::string | G9 | 0.864 | 0.800 | 0.925 | 0.923–0.927 | 0.928, 0.923 |  |
| str.assign_short.view | std::string | G9 | 0.343 | 0.317 | 0.923 | 0.921–0.926 | 0.921, 0.926 |  |
| vec.iterate | std::vector | G9 | 0.952 | 1.001 | 1.051 | 1.048–1.054 | 1.051, 1.051 | worse |
| vec.mid_erase | std::vector | G9 | 1.013 | 1.023 | 1.009 | 1.007–1.012 | 1.006, 1.013 | worse |
| vec.mid_insert | std::vector | G9 | 0.959 | 0.991 | 1.033 | 1.031–1.036 | 1.034, 1.033 | worse |
| vec.push_back | std::vector | G9 | 1.143 | 1.118 | 0.978 | 0.974–0.982 | 0.981, 0.976 |  |
| vec.push_back_grow | std::vector | G9 | 0.777 | 0.787 | 1.014 | 1.011–1.017 | 1.015, 1.013 | worse |
| hero.mid_erase.plain | std::vector | report | 4.043 | 4.066 | 1.006 | 1.002–1.009 | 1.010, 1.001 | worse |
| hero.mid_insert.plain | std::vector | report | 4.231 | 4.076 | 0.963 | 0.960–0.967 | 0.961, 0.965 |  |
| hero.push_back_grow.plain | std::vector | report | 0.421 | 0.420 | 0.998 | 0.996–1.001 | 0.996, 1.001 |  |
| map.erase.fresh | std::map | report | 0.741 | 0.732 | 0.988 | 0.984–0.991 | 0.990, 0.985 |  |
| map.erase.reused | std::flat_map | report | 1.080 | 1.078 | 0.998 | 0.994–1.001 | 0.998, 0.998 |  |
| map.erase.reused | std::map | report | 1.651 | 1.617 | 0.980 | 0.973–0.987 | 0.982, 0.977 |  |
| map.find.fresh | std::map | report | 0.315 | 0.315 | 0.998 | 0.994–1.002 | 1.000, 0.996 |  |
| map.find.reused | std::flat_map | report | 0.784 | 0.785 | 1.001 | 0.998–1.003 | 1.002, 0.999 |  |
| map.find.reused | std::map | report | 0.718 | 0.714 | 0.994 | 0.989–0.999 | 0.969, 1.020 |  |
| map.insert.fresh | std::map | report | 0.750 | 0.743 | 0.991 | 0.988–0.995 | 0.994, 0.988 |  |
| map.insert.reused | std::flat_map | report | 1.005 | 1.001 | 0.997 | 0.993–1.000 | 0.999, 0.994 |  |
| map.insert.reused | std::map | report | 1.818 | 1.846 | 1.015 | 1.008–1.022 | 1.013, 1.017 | worse |
| nested.build.plain | std | report | 0.358 | 0.358 | 1.001 | 0.997–1.005 | 0.985, 1.017 |  |
| set.erase.fresh | std::set | report | 0.668 | 0.661 | 0.990 | 0.986–0.993 | 0.999, 0.981 |  |
| set.erase.reused | std::flat_set | report | 1.137 | 1.140 | 1.002 | 0.999–1.005 | 1.003, 1.001 |  |
| set.erase.reused | std::set | report | 1.356 | 1.321 | 0.975 | 0.968–0.981 | 0.981, 0.968 |  |
| set.find.fresh | std::set | report | 0.301 | 0.302 | 1.002 | 0.997–1.007 | 1.002, 1.002 |  |
| set.find.reused | std::flat_set | report | 0.754 | 0.756 | 1.004 | 1.001–1.007 | 1.002, 1.006 | worse |
| set.find.reused | std::set | report | 0.704 | 0.723 | 1.027 | 1.023–1.031 | 1.027, 1.026 | worse |
| set.insert.fresh | std::set | report | 0.656 | 0.649 | 0.989 | 0.987–0.992 | 0.989, 0.989 |  |
| set.insert.reused | std::flat_set | report | 1.080 | 1.084 | 1.004 | 1.002–1.006 | 1.003, 1.005 | worse |
| set.insert.reused | std::set | report | 1.419 | 1.459 | 1.028 | 1.019–1.036 | 1.022, 1.033 | worse |
| str.assign_short | std::string | report | 1.766 | 1.768 | 1.001 | 0.999–1.004 | 1.000, 1.002 |  |
| str.assign_short.copy | std::string | report | 1.149 | 1.148 | 1.000 | 0.994–1.005 | 1.001, 0.998 |  |

worse at t1 than t0 (by the rule): hero.mid_erase.ord / std::vector (G9) 1.005; hero.push_back_grow.ord / std::vector (G9) 1.007; map.erase.fresh / std::flat_map (G9) 1.004; set.insert.fresh / std::flat_set (G9) 1.003; str.append / std::string (G9) 1.024; vec.iterate / std::vector (G9) 1.051; vec.mid_erase / std::vector (G9) 1.009; vec.mid_insert / std::vector (G9) 1.033; vec.push_back_grow / std::vector (G9) 1.014; hero.mid_erase.plain / std::vector (report) 1.006; map.insert.reused / std::map (report) 1.015; set.find.reused / std::flat_set (report) 1.004; set.find.reused / std::set (report) 1.027; set.insert.reused / std::flat_set (report) 1.004; set.insert.reused / std::set (report) 1.028

above 1.01 but not worse by the rule: none

## XOffset ns/op alone, t1 / t0 (default build)

| case | t0 ns/op | t1 ns/op | t1 / t0 | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 163.2 | 164.1 | 1.005 | 1.003–1.007 | 1.005, 1.005 | worse |
| hero.mid_erase.plain | 909 | 914.2 | 1.006 | 1.003–1.008 | 1.009, 1.002 | worse |
| hero.mid_insert.ord | 228.4 | 227.8 | 0.997 | 0.995–1.000 | 1.000, 0.995 |  |
| hero.mid_insert.plain | 1262 | 1220 | 0.966 | 0.964–0.968 | 0.964, 0.968 |  |
| hero.push_back_grow.ord | 33.17 | 33.47 | 1.009 | 1.007–1.010 | 1.010, 1.007 | worse |
| hero.push_back_grow.plain | 36.7 | 36.75 | 1.001 | 0.999–1.003 | 1.003, 0.999 |  |
| map.erase.fresh | 32.98 | 33.05 | 1.002 | 1.000–1.004 | 1.003, 1.001 | worse |
| map.erase.reused | 29.68 | 29.64 | 0.998 | 0.996–1.001 | 0.998, 0.999 |  |
| map.find.fresh | 5.14 | 5.138 | 1.000 | 0.998–1.001 | 1.001, 0.999 |  |
| map.find.reused | 5.156 | 5.153 | 1.000 | 0.998–1.001 | 0.999, 1.000 |  |
| map.insert.fresh | 32.28 | 32.27 | 1.000 | 0.998–1.001 | 0.997, 1.002 |  |
| map.insert.reused | 29.55 | 29.56 | 1.000 | 0.998–1.003 | 1.001, 1.000 |  |
| nested.build.ord | 294.8 | 295.5 | 1.002 | 0.999–1.006 | 1.002, 1.003 |  |
| nested.build.plain | 301.7 | 301.8 | 1.001 | 0.997–1.004 | 0.996, 1.005 |  |
| reset | 30.02 | 30.53 | 1.017 | 1.012–1.022 | 1.040, 0.994 | worse? |
| set.erase.fresh | 29.8 | 29.77 | 0.999 | 0.998–1.000 | 0.999, 0.999 |  |
| set.erase.reused | 23.25 | 23.3 | 1.002 | 0.999–1.005 | 1.002, 1.003 |  |
| set.find.fresh | 4.885 | 4.903 | 1.004 | 1.001–1.006 | 1.002, 1.005 | worse |
| set.find.reused | 4.882 | 4.895 | 1.003 | 1.000–1.005 | 1.003, 1.002 | worse |
| set.insert.fresh | 28.93 | 28.87 | 0.998 | 0.996–0.999 | 0.997, 0.998 |  |
| set.insert.reused | 22.79 | 22.84 | 1.002 | 1.000–1.004 | 1.001, 1.003 |  |
| str.append | 1.55 | 1.546 | 0.998 | 0.993–1.002 | 1.006, 0.990 |  |
| str.assign_long | 2.937 | 2.717 | 0.925 | 0.923–0.927 | 0.927, 0.924 |  |
| str.assign_short | 0.9279 | 0.9313 | 1.004 | 1.000–1.007 | 1.005, 1.002 | worse |
| str.assign_short.copy | 0.6324 | 0.6173 | 0.976 | 0.969–0.983 | 0.958, 0.995 |  |
| str.assign_short.view | 0.9394 | 0.938 | 0.999 | 0.995–1.002 | 0.999, 0.998 |  |
| vec.iterate | 0.03222 | 0.03392 | 1.053 | 1.048–1.058 | 1.054, 1.051 | worse |
| vec.mid_erase | 40.2 | 40.47 | 1.007 | 1.005–1.009 | 1.007, 1.006 | worse |
| vec.mid_insert | 40.9 | 41.36 | 1.011 | 1.008–1.014 | 1.008, 1.015 | worse |
| vec.push_back | 0.2944 | 0.2911 | 0.989 | 0.978–1.000 | 0.988, 0.990 |  |
| vec.push_back_grow | 0.2814 | 0.2867 | 1.019 | 1.012–1.026 | 1.018, 1.019 | worse |

XOffset slower at t1 than t0 (worse by the rule): hero.mid_erase.ord 1.005; hero.mid_erase.plain 1.006; hero.push_back_grow.ord 1.009; map.erase.fresh 1.002; set.find.fresh 1.004; set.find.reused 1.003; str.assign_short 1.004; vec.iterate 1.053; vec.mid_erase 1.007; vec.mid_insert 1.011; vec.push_back_grow 1.019

## XOffset / baseline, t1a / t0a (functions aligned to 64 B, layout check)

| case | baseline | class | t0a GM | t1a GM | t1a / t0a | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.726 | 0.722 | 0.994 | 0.991–0.997 | 0.995, 0.994 |  |
| hero.mid_insert.ord | std::vector | G9 | 0.762 | 0.761 | 1.000 | 0.996–1.004 | 0.996, 1.003 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.381 | 0.381 | 1.001 | 0.998–1.003 | 1.003, 0.998 |  |
| map.erase.fresh | std::flat_map | G9 | 0.940 | 0.942 | 1.002 | 1.000–1.004 | 1.005, 0.999 |  |
| map.find.fresh | std::flat_map | G9 | 0.785 | 0.784 | 0.999 | 0.997–1.002 | 0.998, 1.000 |  |
| map.insert.fresh | std::flat_map | G9 | 0.872 | 0.869 | 0.996 | 0.994–0.998 | 1.001, 0.991 |  |
| nested.build.ord | std | G9 | 0.349 | 0.354 | 1.014 | 1.010–1.018 | 1.023, 1.005 | worse |
| reset | std | G9 | 0.246 | 0.212 | 0.863 | 0.852–0.874 | 0.755, 0.986 |  |
| set.erase.fresh | std::flat_set | G9 | 1.088 | 1.093 | 1.005 | 1.001–1.008 | 1.003, 1.006 | worse |
| set.find.fresh | std::flat_set | G9 | 0.756 | 0.755 | 0.999 | 0.996–1.001 | 0.999, 0.998 |  |
| set.insert.fresh | std::flat_set | G9 | 0.999 | 0.999 | 1.000 | 0.998–1.001 | 0.998, 1.002 |  |
| str.append | std::string | G9 | 0.426 | 0.429 | 1.006 | 1.001–1.012 | 1.001, 1.012 | worse |
| str.assign_long | std::string | G9 | 0.866 | 0.867 | 1.000 | 0.998–1.003 | 1.001, 1.000 |  |
| str.assign_short.view | std::string | G9 | 0.342 | 0.342 | 0.999 | 0.997–1.001 | 0.999, 0.999 |  |
| vec.iterate | std::vector | G9 | 1.000 | 1.001 | 1.001 | 0.999–1.002 | 1.000, 1.001 |  |
| vec.mid_erase | std::vector | G9 | 1.017 | 1.019 | 1.002 | 1.000–1.004 | 1.009, 0.996 |  |
| vec.mid_insert | std::vector | G9 | 0.955 | 0.993 | 1.040 | 1.037–1.043 | 1.040, 1.040 | worse |
| vec.push_back | std::vector | G9 | 1.117 | 1.120 | 1.003 | 1.000–1.005 | 1.007, 0.999 |  |
| vec.push_back_grow | std::vector | G9 | 0.783 | 0.771 | 0.985 | 0.980–0.989 | 0.983, 0.986 |  |
| hero.mid_erase.plain | std::vector | report | 4.049 | 4.031 | 0.996 | 0.993–0.998 | 0.999, 0.992 |  |
| hero.mid_insert.plain | std::vector | report | 4.174 | 4.179 | 1.001 | 0.997–1.005 | 0.994, 1.009 |  |
| hero.push_back_grow.plain | std::vector | report | 0.423 | 0.421 | 0.995 | 0.992–0.998 | 1.002, 0.987 |  |
| map.erase.fresh | std::map | report | 0.742 | 0.734 | 0.989 | 0.986–0.992 | 0.991, 0.986 |  |
| map.erase.reused | std::flat_map | report | 1.084 | 1.075 | 0.992 | 0.988–0.996 | 0.990, 0.993 |  |
| map.erase.reused | std::map | report | 1.609 | 1.587 | 0.986 | 0.979–0.994 | 0.962, 1.011 |  |
| map.find.fresh | std::map | report | 0.314 | 0.314 | 1.000 | 0.996–1.004 | 0.998, 1.002 |  |
| map.find.reused | std::flat_map | report | 0.785 | 0.785 | 1.001 | 0.998–1.003 | 1.001, 1.000 |  |
| map.find.reused | std::map | report | 0.700 | 0.707 | 1.011 | 1.006–1.016 | 1.017, 1.006 | worse |
| map.insert.fresh | std::map | report | 0.750 | 0.750 | 1.000 | 0.998–1.003 | 0.996, 1.005 |  |
| map.insert.reused | std::flat_map | report | 1.001 | 1.003 | 1.002 | 0.998–1.006 | 1.000, 1.003 |  |
| map.insert.reused | std::map | report | 1.850 | 1.857 | 1.004 | 0.997–1.010 | 0.984, 1.023 |  |
| nested.build.plain | std | report | 0.357 | 0.361 | 1.010 | 1.006–1.014 | 1.016, 1.004 | worse |
| set.erase.fresh | std::set | report | 0.678 | 0.658 | 0.971 | 0.968–0.974 | 0.974, 0.968 |  |
| set.erase.reused | std::flat_set | report | 1.141 | 1.147 | 1.005 | 1.000–1.010 | 1.005, 1.005 | worse |
| set.erase.reused | std::set | report | 1.314 | 1.309 | 0.996 | 0.988–1.005 | 0.975, 1.019 |  |
| set.find.fresh | std::set | report | 0.289 | 0.299 | 1.034 | 1.030–1.039 | 1.034, 1.035 | worse |
| set.find.reused | std::flat_set | report | 0.755 | 0.757 | 1.002 | 0.999–1.005 | 1.001, 1.004 |  |
| set.find.reused | std::set | report | 0.675 | 0.686 | 1.017 | 1.013–1.021 | 1.034, 1.000 | worse? |
| set.insert.fresh | std::set | report | 0.656 | 0.657 | 1.002 | 0.999–1.004 | 1.003, 1.001 |  |
| set.insert.reused | std::flat_set | report | 1.083 | 1.081 | 0.998 | 0.995–1.001 | 0.996, 1.000 |  |
| set.insert.reused | std::set | report | 1.457 | 1.462 | 1.004 | 0.995–1.012 | 0.997, 1.010 |  |
| str.assign_short | std::string | report | 1.767 | 1.763 | 0.998 | 0.996–1.000 | 1.000, 0.996 |  |
| str.assign_short.copy | std::string | report | 1.151 | 1.146 | 0.996 | 0.992–1.000 | 0.995, 0.996 |  |

worse at t1a than t0a (by the rule): nested.build.ord / std (G9) 1.014; set.erase.fresh / std::flat_set (G9) 1.005; str.append / std::string (G9) 1.006; vec.mid_insert / std::vector (G9) 1.040; map.find.reused / std::map (report) 1.011; nested.build.plain / std (report) 1.010; set.erase.reused / std::flat_set (report) 1.005; set.find.fresh / std::set (report) 1.034

above 1.01 but not worse by the rule: set.find.reused / std::set (report) 1.017

## XOffset ns/op alone, t1a / t0a (functions aligned to 64 B, layout check)

| case | t0a ns/op | t1a ns/op | t1a / t0a | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 163.8 | 164.3 | 1.003 | 1.001–1.005 | 1.006, 1.000 |  |
| hero.mid_erase.plain | 908.7 | 907.7 | 0.999 | 0.996–1.001 | 1.005, 0.993 |  |
| hero.mid_insert.ord | 229.6 | 230 | 1.002 | 1.000–1.004 | 1.003, 1.000 |  |
| hero.mid_insert.plain | 1251 | 1249 | 0.999 | 0.996–1.001 | 0.997, 1.000 |  |
| hero.push_back_grow.ord | 33.3 | 33.14 | 0.995 | 0.993–0.997 | 0.999, 0.992 |  |
| hero.push_back_grow.plain | 36.67 | 36.47 | 0.995 | 0.993–0.997 | 0.999, 0.990 |  |
| map.erase.fresh | 33 | 33.01 | 1.000 | 0.999–1.002 | 1.002, 0.999 |  |
| map.erase.reused | 29.74 | 29.57 | 0.994 | 0.992–0.996 | 0.990, 0.998 |  |
| map.find.fresh | 5.138 | 5.132 | 0.999 | 0.997–1.000 | 0.997, 1.000 |  |
| map.find.reused | 5.155 | 5.156 | 1.000 | 0.998–1.002 | 0.998, 1.002 |  |
| map.insert.fresh | 32.26 | 32.22 | 0.999 | 0.998–1.000 | 0.999, 0.998 |  |
| map.insert.reused | 29.58 | 29.53 | 0.998 | 0.995–1.001 | 0.997, 0.999 |  |
| nested.build.ord | 294.2 | 295.4 | 1.004 | 1.001–1.007 | 1.004, 1.004 | worse |
| nested.build.plain | 301.5 | 301.8 | 1.001 | 0.998–1.004 | 1.004, 0.998 |  |
| reset | 29.89 | 30.54 | 1.022 | 1.016–1.027 | 1.040, 1.003 | worse |
| set.erase.fresh | 29.86 | 29.8 | 0.998 | 0.996–1.000 | 0.997, 0.999 |  |
| set.erase.reused | 23.36 | 23.36 | 1.000 | 0.997–1.004 | 1.001, 0.999 |  |
| set.find.fresh | 4.885 | 4.883 | 1.000 | 0.998–1.001 | 1.000, 0.999 |  |
| set.find.reused | 4.882 | 4.888 | 1.001 | 0.999–1.004 | 1.000, 1.003 |  |
| set.insert.fresh | 28.9 | 28.87 | 0.999 | 0.998–1.000 | 0.998, 1.000 |  |
| set.insert.reused | 22.85 | 22.83 | 0.999 | 0.996–1.002 | 0.999, 0.999 |  |
| str.append | 1.551 | 1.554 | 1.002 | 0.997–1.006 | 1.005, 0.999 |  |
| str.assign_long | 2.943 | 2.945 | 1.001 | 0.998–1.003 | 1.005, 0.996 |  |
| str.assign_short | 0.9311 | 0.9322 | 1.001 | 0.998–1.004 | 1.011, 0.991 |  |
| str.assign_short.copy | 0.6243 | 0.626 | 1.003 | 0.998–1.008 | 1.013, 0.993 |  |
| str.assign_short.view | 0.9351 | 0.9396 | 1.005 | 1.002–1.008 | 1.019, 0.991 |  |
| vec.iterate | 0.03322 | 0.03352 | 1.009 | 1.006–1.012 | 1.000, 1.018 |  |
| vec.mid_erase | 40.43 | 40.54 | 1.003 | 1.001–1.004 | 1.005, 1.001 | worse |
| vec.mid_insert | 40.51 | 40.58 | 1.002 | 1.000–1.004 | 1.002, 1.002 |  |
| vec.push_back | 0.2717 | 0.2716 | 1.000 | 0.999–1.000 | 1.000, 1.000 |  |
| vec.push_back_grow | 0.2751 | 0.2755 | 1.002 | 0.999–1.005 | 1.011, 0.992 |  |

XOffset slower at t1a than t0a (worse by the rule): nested.build.ord 1.004; reset 1.022; vec.mid_erase 1.003

## layout check: what is worse at t1 in the default build, in the aligned build

| comparison | t1 / t0 | t1a / t0a | 95% interval (aligned) | aligned |
| --- | ---: | ---: | --- | --- |
| hero.mid_erase.ord (XOffset ns/op) | 1.005 | 1.003 | 1.001–1.005 | not worse |
| hero.mid_erase.plain (XOffset ns/op) | 1.006 | 0.999 | 0.996–1.001 | not worse |
| hero.push_back_grow.ord (XOffset ns/op) | 1.009 | 0.995 | 0.993–0.997 | not worse |
| map.erase.fresh (XOffset ns/op) | 1.002 | 1.000 | 0.999–1.002 | not worse |
| set.find.fresh (XOffset ns/op) | 1.004 | 1.000 | 0.998–1.001 | not worse |
| set.find.reused (XOffset ns/op) | 1.003 | 1.001 | 0.999–1.004 | not worse |
| str.assign_short (XOffset ns/op) | 1.004 | 1.001 | 0.998–1.004 | not worse |
| vec.iterate (XOffset ns/op) | 1.053 | 1.009 | 1.006–1.012 | not worse |
| vec.mid_erase (XOffset ns/op) | 1.007 | 1.003 | 1.001–1.004 | still worse |
| vec.mid_insert (XOffset ns/op) | 1.011 | 1.002 | 1.000–1.004 | not worse |
| vec.push_back_grow (XOffset ns/op) | 1.019 | 1.002 | 0.999–1.005 | not worse |
| hero.mid_erase.ord / std::vector (G9) | 1.005 | 0.994 | 0.991–0.997 | not worse |
| hero.mid_erase.plain / std::vector (report) | 1.006 | 0.996 | 0.993–0.998 | not worse |
| hero.push_back_grow.ord / std::vector (G9) | 1.007 | 1.001 | 0.998–1.003 | not worse |
| map.erase.fresh / std::flat_map (G9) | 1.004 | 1.002 | 1.000–1.004 | not worse |
| map.insert.reused / std::map (report) | 1.015 | 1.004 | 0.997–1.010 | not worse |
| set.find.reused / std::flat_set (report) | 1.004 | 1.002 | 0.999–1.005 | not worse |
| set.find.reused / std::set (report) | 1.027 | 1.017 | 1.013–1.021 | worse? |
| set.insert.fresh / std::flat_set (G9) | 1.003 | 1.000 | 0.998–1.001 | not worse |
| set.insert.reused / std::flat_set (report) | 1.004 | 0.998 | 0.995–1.001 | not worse |
| set.insert.reused / std::set (report) | 1.028 | 1.004 | 0.995–1.012 | not worse |
| str.append / std::string (G9) | 1.024 | 1.006 | 1.001–1.012 | still worse |
| vec.iterate / std::vector (G9) | 1.051 | 1.001 | 0.999–1.002 | not worse |
| vec.mid_erase / std::vector (G9) | 1.009 | 1.002 | 1.000–1.004 | not worse |
| vec.mid_insert / std::vector (G9) | 1.033 | 1.040 | 1.037–1.043 | still worse |
| vec.push_back_grow / std::vector (G9) | 1.014 | 0.985 | 0.980–0.989 | not worse |

## reloc t1 / t0 (median per file, GM of 8 files each)

| case | t0 xo ns/op | t1 xo ns/op | t1 / t0 | first baseline ns/op (t0 runs) | t1a / t0a (aligned) |
| --- | ---: | ---: | ---: | ---: | ---: |
| hero.mid_erase.ord | 163.08 | 163.82 | 1.005 | 224.85 | 1.002 |
| hero.mid_erase.plain | 909.05 | 913.93 | 1.005 | 224.64 | 0.999 |
| hero.mid_insert.ord | 227.70 | 227.37 | 0.999 | 299.61 | 0.999 |
| hero.mid_insert.plain | 1258.37 | 1216.18 | 0.966 | 299.71 | 0.999 |
| hero.push_back_grow.ord | 33.06 | 33.38 | 1.010 | 86.91 | 0.995 |
| hero.push_back_grow.plain | 36.60 | 36.68 | 1.002 | 87.08 | 0.995 |
| map.erase.fresh | 32.95 | 32.99 | 1.001 | 35.15 | 1.000 |
| map.erase.reused | 29.52 | 29.53 | 1.000 | 27.31 | 0.994 |
| map.find.fresh | 5.14 | 5.14 | 1.000 | 6.55 | 0.999 |
| map.find.reused | 5.15 | 5.15 | 1.000 | 6.56 | 1.000 |
| map.insert.fresh | 32.23 | 32.26 | 1.001 | 37.02 | 0.999 |
| map.insert.reused | 29.47 | 29.48 | 1.000 | 29.34 | 0.999 |
| nested.build.ord | 293.05 | 294.43 | 1.005 | 847.93 | 1.003 |
| nested.build.plain | 300.45 | 300.53 | 1.000 | 841.00 | 1.001 |
| reset | 29.99 | 30.50 | 1.017 | 133.97 | 1.020 |
| set.erase.fresh | 29.78 | 29.74 | 0.999 | 27.38 | 1.000 |
| set.erase.reused | 23.00 | 23.12 | 1.005 | 20.33 | 1.003 |
| set.find.fresh | 4.88 | 4.89 | 1.004 | 6.46 | 0.999 |
| set.find.reused | 4.88 | 4.88 | 1.002 | 6.46 | 1.000 |
| set.insert.fresh | 28.89 | 28.89 | 1.000 | 28.97 | 0.998 |
| set.insert.reused | 22.73 | 22.79 | 1.003 | 21.03 | 1.001 |
| str.append | 1.52 | 1.52 | 1.001 | 3.64 | 1.006 |
| str.assign_long | 2.93 | 2.71 | 0.925 | 3.39 | 0.999 |
| str.assign_short | 0.92 | 0.92 | 1.001 | 0.52 | 1.000 |
| str.assign_short.copy | 0.62 | 0.61 | 0.998 | 0.54 | 1.023 |
| str.assign_short.view | 0.93 | 0.93 | 1.000 | 2.71 | 0.999 |
| vec.iterate | 0.03 | 0.03 | 1.051 | 0.03 | 1.001 |
| vec.mid_erase | 40.03 | 40.35 | 1.008 | 39.61 | 1.006 |
| vec.mid_insert | 40.89 | 41.36 | 1.011 | 42.62 | 1.002 |
| vec.push_back | 0.29 | 0.29 | 0.987 | 0.26 | 0.999 |
| vec.push_back_grow | 0.28 | 0.29 | 1.021 | 0.36 | 1.004 |

## analyze t0 (G9 at v3.1.0)

```
files: 8  compiler: clang 21.0.0git (https://github.com/bloomberg/clang-p2996.git d77eff1cbd78fd065668acf93b1f5f400d39134d)
G9 comparisons k = 19; one-sided 95% UB, Bonferroni t quantile 0.99737; limit UB <= 1.05

| case                         | baseline       | role   |    n |  xo ns/op | base ns/op |     GM |     UB | verdict |
| ---------------------------- | -------------- | ------ | ---: | --------: | ---------: | -----: | -----: | ------- |
| vec.push_back                | std::vector    | G9     |  808 |      0.28 |       0.24 |  1.143 |  1.148 | fail    |
| vec.push_back_grow           | std::vector    | G9     |  808 |      0.27 |       0.35 |  0.777 |  0.779 | pass    |
| vec.iterate                  | std::vector    | G9     |  808 |      0.03 |       0.03 |  0.952 |  0.955 | pass    |
| vec.mid_insert               | std::vector    | G9     |  808 |     40.53 |      42.24 |  0.959 |  0.961 | pass    |
| vec.mid_erase                | std::vector    | G9     |  808 |     40.04 |      39.55 |  1.013 |  1.015 | pass    |
| hero.mid_erase.ord           | std::vector    | G9     |  808 |    163.41 |     225.25 |  0.723 |  0.725 | pass    |
| hero.mid_insert.ord          | std::vector    | G9     |  808 |    227.86 |     295.58 |  0.759 |  0.762 | pass    |
| hero.push_back_grow.ord      | std::vector    | G9     |  808 |     33.12 |      87.14 |  0.381 |  0.381 | pass    |
| hero.mid_erase.plain         | std::vector    | report |  808 |    908.85 |     224.61 |  4.043 |  4.057 | report  |
| hero.mid_insert.plain        | std::vector    | report |  808 |   1258.47 |     304.69 |  4.231 |  4.246 | report  |
| hero.push_back_grow.plain    | std::vector    | report |  808 |     36.62 |      87.04 |  0.421 |  0.422 | report  |
| str.assign_short             | std::string    | report |  808 |      0.92 |       0.52 |  1.766 |  1.768 | report  |
| str.assign_long              | std::string    | G9     |  808 |      2.93 |       3.39 |  0.864 |  0.866 | pass    |
| str.assign_short.view        | std::string    | G9     |  808 |      0.93 |       2.71 |  0.343 |  0.344 | pass    |
| str.assign_short.copy        | std::string    | report |  808 |      0.60 |       0.52 |  1.149 |  1.157 | report  |
| str.append                   | std::string    | G9     |  808 |      1.54 |       3.63 |  0.419 |  0.420 | pass    |
| map.insert.fresh             | std::flat_map  | G9     |  808 |     32.23 |      37.03 |  0.870 |  0.872 | pass    |
| map.insert.fresh             | std::map       | report |  808 |     32.23 |      42.72 |  0.750 |  0.752 | report  |
| map.find.fresh               | std::flat_map  | G9     |  808 |      5.15 |       6.55 |  0.784 |  0.786 | pass    |
| map.find.fresh               | std::map       | report |  808 |      5.15 |      16.35 |  0.315 |  0.316 | report  |
| map.erase.fresh              | std::flat_map  | G9     |  808 |     32.96 |      35.16 |  0.937 |  0.938 | pass    |
| map.erase.fresh              | std::map       | report |  808 |     32.96 |      44.27 |  0.741 |  0.743 | report  |
| set.insert.fresh             | std::flat_set  | G9     |  808 |     28.89 |      28.97 |  0.995 |  0.999 | pass    |
| set.insert.fresh             | std::set       | report |  808 |     28.89 |      44.03 |  0.656 |  0.657 | report  |
| set.find.fresh               | std::flat_set  | G9     |  808 |      4.87 |       6.46 |  0.755 |  0.757 | pass    |
| set.find.fresh               | std::set       | report |  808 |      4.87 |      16.29 |  0.301 |  0.303 | report  |
| set.erase.fresh              | std::flat_set  | G9     |  808 |     29.79 |      27.34 |  1.087 |  1.089 | fail    |
| set.erase.fresh              | std::set       | report |  808 |     29.79 |      44.27 |  0.668 |  0.670 | report  |
| map.insert.reused            | std::flat_map  | report |  808 |     29.46 |      29.38 |  1.005 |  1.008 | report  |
| map.insert.reused            | std::map       | report |  808 |     29.46 |      16.11 |  1.818 |  1.829 | report  |
| map.find.reused              | std::flat_map  | report |  808 |      5.15 |       6.56 |  0.784 |  0.787 | report  |
| map.find.reused              | std::map       | report |  808 |      5.15 |       7.17 |  0.718 |  0.722 | report  |
| map.erase.reused             | std::flat_map  | report |  808 |     29.46 |      27.34 |  1.080 |  1.084 | report  |
| map.erase.reused             | std::map       | report |  808 |     29.46 |      17.58 |  1.651 |  1.662 | report  |
| set.insert.reused            | std::flat_set  | report |  808 |     22.71 |      21.00 |  1.080 |  1.082 | report  |
| set.insert.reused            | std::set       | report |  808 |     22.71 |      15.79 |  1.419 |  1.432 | report  |
| set.find.reused              | std::flat_set  | report |  808 |      4.87 |       6.46 |  0.754 |  0.755 | report  |
| set.find.reused              | std::set       | report |  808 |      4.87 |       7.00 |  0.704 |  0.706 | report  |
| set.erase.reused             | std::flat_set  | report |  808 |     23.03 |      20.35 |  1.137 |  1.142 | report  |
| set.erase.reused             | std::set       | report |  808 |     23.03 |      16.68 |  1.356 |  1.365 | report  |
| nested.build.ord             | std            | G9     |  808 |    292.97 |     847.66 |  0.347 |  0.349 | pass    |
| reset                        | std            | G9     |  808 |     29.30 |     117.19 |  0.224 |  0.229 | pass    |
| nested.build.plain           | std            | report |  808 |    300.78 |     843.11 |  0.358 |  0.359 | report  |

G9: 17 of 19 comparisons have UB <= 1.05; above: vec.push_back, set.erase.fresh
```

## analyze t1 (G9 at the integration head)

```
files: 8  compiler: clang 21.0.0git (https://github.com/bloomberg/clang-p2996.git d77eff1cbd78fd065668acf93b1f5f400d39134d)
G9 comparisons k = 19; one-sided 95% UB, Bonferroni t quantile 0.99737; limit UB <= 1.05

| case                         | baseline       | role   |    n |  xo ns/op | base ns/op |     GM |     UB | verdict |
| ---------------------------- | -------------- | ------ | ---: | --------: | ---------: | -----: | -----: | ------- |
| vec.push_back                | std::vector    | G9     |  808 |      0.27 |       0.24 |  1.118 |  1.122 | fail    |
| vec.push_back_grow           | std::vector    | G9     |  808 |      0.28 |       0.35 |  0.787 |  0.790 | pass    |
| vec.iterate                  | std::vector    | G9     |  808 |      0.03 |       0.03 |  1.001 |  1.004 | pass    |
| vec.mid_insert               | std::vector    | G9     |  808 |     40.69 |      41.02 |  0.991 |  0.994 | pass    |
| vec.mid_erase                | std::vector    | G9     |  808 |     40.36 |      39.47 |  1.023 |  1.025 | pass    |
| hero.mid_erase.ord           | std::vector    | G9     |  808 |    164.06 |     225.26 |  0.727 |  0.729 | pass    |
| hero.mid_insert.ord          | std::vector    | G9     |  808 |    227.86 |     294.28 |  0.758 |  0.760 | pass    |
| hero.push_back_grow.ord      | std::vector    | G9     |  808 |     33.41 |      87.08 |  0.383 |  0.384 | pass    |
| hero.mid_erase.plain         | std::vector    | report |  808 |    913.41 |     224.61 |  4.066 |  4.081 | report  |
| hero.mid_insert.plain        | std::vector    | report |  808 |   1216.80 |     305.34 |  4.076 |  4.093 | report  |
| hero.push_back_grow.plain    | std::vector    | report |  808 |     36.70 |      87.04 |  0.420 |  0.421 | report  |
| str.assign_short             | std::string    | report |  808 |      0.92 |       0.52 |  1.768 |  1.775 | report  |
| str.assign_long              | std::string    | G9     |  808 |      2.71 |       3.39 |  0.800 |  0.802 | pass    |
| str.assign_short.view        | std::string    | G9     |  808 |      0.93 |       2.93 |  0.317 |  0.318 | pass    |
| str.assign_short.copy        | std::string    | report |  808 |      0.60 |       0.52 |  1.148 |  1.150 | report  |
| str.append                   | std::string    | G9     |  808 |      1.50 |       3.60 |  0.428 |  0.430 | pass    |
| map.insert.fresh             | std::flat_map  | G9     |  808 |     32.23 |      37.19 |  0.867 |  0.868 | pass    |
| map.insert.fresh             | std::map       | report |  808 |     32.23 |      42.89 |  0.743 |  0.746 | report  |
| map.find.fresh               | std::flat_map  | G9     |  808 |      5.15 |       6.55 |  0.784 |  0.786 | pass    |
| map.find.fresh               | std::map       | report |  808 |      5.15 |      16.36 |  0.315 |  0.316 | report  |
| map.erase.fresh              | std::flat_map  | G9     |  808 |     32.96 |      35.07 |  0.941 |  0.944 | pass    |
| map.erase.fresh              | std::map       | report |  808 |     32.96 |      44.84 |  0.732 |  0.734 | report  |
| set.insert.fresh             | std::flat_set  | G9     |  808 |     28.89 |      28.89 |  0.998 |  1.000 | pass    |
| set.insert.fresh             | std::set       | report |  808 |     28.89 |      44.43 |  0.649 |  0.650 | report  |
| set.find.fresh               | std::flat_set  | G9     |  808 |      4.89 |       6.47 |  0.756 |  0.758 | pass    |
| set.find.fresh               | std::set       | report |  808 |      4.89 |      16.32 |  0.302 |  0.303 | report  |
| set.erase.fresh              | std::flat_set  | G9     |  808 |     29.71 |      27.34 |  1.085 |  1.087 | fail    |
| set.erase.fresh              | std::set       | report |  808 |     29.71 |      44.68 |  0.661 |  0.663 | report  |
| map.insert.reused            | std::flat_map  | report |  808 |     29.46 |      29.38 |  1.001 |  1.005 | report  |
| map.insert.reused            | std::map       | report |  808 |     29.46 |      15.87 |  1.846 |  1.859 | report  |
| map.find.reused              | std::flat_map  | report |  808 |      5.15 |       6.56 |  0.785 |  0.787 | report  |
| map.find.reused              | std::map       | report |  808 |      5.15 |       7.31 |  0.714 |  0.718 | report  |
| map.erase.reused             | std::flat_map  | report |  808 |     29.54 |      27.26 |  1.078 |  1.082 | report  |
| map.erase.reused             | std::map       | report |  808 |     29.54 |      17.82 |  1.617 |  1.628 | report  |
| set.insert.reused            | std::flat_set  | report |  808 |     22.79 |      21.08 |  1.084 |  1.086 | report  |
| set.insert.reused            | std::set       | report |  808 |     22.79 |      15.46 |  1.459 |  1.470 | report  |
| set.find.reused              | std::flat_set  | report |  808 |      4.88 |       6.45 |  0.756 |  0.759 | report  |
| set.find.reused              | std::set       | report |  808 |      4.88 |       6.81 |  0.723 |  0.725 | report  |
| set.erase.reused             | std::flat_set  | report |  808 |     23.11 |      20.35 |  1.140 |  1.143 | report  |
| set.erase.reused             | std::set       | report |  808 |     23.11 |      17.25 |  1.321 |  1.330 | report  |
| nested.build.ord             | std            | G9     |  808 |    294.28 |     843.75 |  0.349 |  0.351 | pass    |
| reset                        | std            | G9     |  808 |     30.59 |     121.75 |  0.223 |  0.227 | pass    |
| nested.build.plain           | std            | report |  808 |    300.78 |     839.84 |  0.358 |  0.360 | report  |

G9: 17 of 19 comparisons have UB <= 1.05; above: vec.push_back, set.erase.fresh
```

## quiet

```
2026-10-28T18:09:47Z block 1 start: waited 180s load 1.96 WindowServer 1.2% remote 4
2026-10-28T18:12:51Z block 2 start: waited 180s load 1.51 WindowServer 1.2% remote 4
2026-10-28T18:15:56Z block 3 start: waited 180s load 1.57 WindowServer 1.1% remote 4
2026-10-28T18:19:00Z block 4 start: waited 180s load 1.33 WindowServer 1.2% remote 4
```
