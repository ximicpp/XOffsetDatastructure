#!/usr/bin/env python3
# analyze_d1.py RUN_DIR > RESULT.md
# Reads RUN_DIR/NNN_<build>.jsonl (d1_probe --json, builds "q" = library as
# released, "w8" = the same library with the small dense reload copy in 8 B
# stores) and writes the d1 result tables and verdicts (Markdown).
import json, math, os, re, statistics as st, sys

T975 = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262,
        10: 2.228, 11: 2.201, 12: 2.179, 13: 2.160, 14: 2.145, 15: 2.131, 20: 2.086, 30: 2.042}
def t975(df):
    return T975.get(df) or T975[max(k for k in T975 if k <= df)]

def ci_mean(xs):
    n = len(xs); m = st.mean(xs)
    if n < 2: return m, float('nan'), float('nan')
    h = t975(n - 1) * st.stdev(xs) / math.sqrt(n)
    return m, m - h, m + h

def ci_gm(ratios):
    m, lo, hi = ci_mean([math.log(r) for r in ratios])
    return math.exp(m), math.exp(lo), math.exp(hi)

run = sys.argv[1]
procs = []  # (seq, build, {(cycle, variant): {round: ns}})
for f in sorted(os.listdir(run)):
    m = re.match(r'(\d+)_(q|w8)\.jsonl$', f)
    if not m: continue
    cells = {}
    for line in open(os.path.join(run, f)):
        r = json.loads(line)
        cells.setdefault((r['cycle'], r['variant']), {})[r['round']] = r['ns']
    procs.append((int(m.group(1)), m.group(2), cells))
if not procs:
    print('no d1 runs found'); sys.exit(1)
cycles = sorted({c for _, _, cells in procs for c, _ in cells})
ORDER = ['xo.read', 'xo.reload', 'xo.reverify', 'syn.q+scan', 'syn.w8+scan', 'syn.q', 'syn.scan', 'fb.verify', 'fb.read']
seen = {v for _, _, cells in procs for _, v in cells}
variants = [v for v in ORDER if v in seen] + sorted(seen - set(ORDER))

def med(cells, c, v): return st.median(cells[(c, v)].values())
def per_round(cells, c, f):
    rs = sorted(cells[(c, 'xo.read')])
    return [f(lambda v: cells[(c, v)][r]) for r in rs]

out = []
p = out.append
p('# d1：拷贝与校验之间的转发停顿（Mac 微基准）\n')
p(f'进程 {len(procs)} 个（q {sum(b == "q" for _, b, _ in procs)}，w8 {sum(b == "w8" for _, b, _ in procs)}），'
  f'每个进程每格 {len(next(iter(procs[0][2].values())))} 轮，每轮每格 2048 次读。cycle 是 slg_bench 的周期（报告随周期变小）。\n')
p('q 是 v3.1.0 原样的库（小型 dense reload 用 memcpy 拷贝）；w8 是同一个库，只把这一处拷贝改成 8 B 存储。\n')

# 1. medians
for b in ('q', 'w8'):
    ps = [c for _, bb, c in procs if bb == b]
    if not ps: continue
    p(f'## 每次读的中位数 ns（{b}，各进程中位数的均值）\n')
    p('| 变体 | ' + ' | '.join(f'cycle {c}' for c in cycles) + ' | 周期平均 |')
    p('| --- |' + ' ---: |' * (len(cycles) + 1))
    for v in variants:
        vals = [st.mean(med(cells, c, v) for cells in ps) for c in cycles]
        p(f'| {v} | ' + ' | '.join(f'{x:.2f}' for x in vals) + f' | {st.mean(vals):.2f} |')
    p('')

# 2. within q: synthetic stall, settled verification, query, D/FB in the probe
qs = [c for _, b, c in procs if b == 'q']
p('## q 内部的拆分（每个进程先取逐轮值的中位数，再对进程求均值和 95% 区间）\n')
p('| 量 | ' + ' | '.join(f'cycle {c}' for c in cycles) + ' |')
p('| --- |' + ' ---: |' * len(cycles))
def row(name, f, fmt='{:.2f} [{:.2f}, {:.2f}]', gm=False):
    vals = []
    for c in cycles:
        xs = [st.median(per_round(cells, c, f)) for cells in qs]
        vals.append(ci_gm(xs) if gm else ci_mean(xs))
    p(f'| {name} | ' + ' | '.join(fmt.format(*x) for x in vals) + ' |')
    return vals
excess = row('syn 超额 ns = q+scan − q − scan', lambda g: g('syn.q+scan') - g('syn.q') - g('syn.scan'))
synr = row('syn.w8+scan ÷ syn.q+scan', lambda g: g('syn.w8+scan') / g('syn.q+scan'), '{:.3f} [{:.3f}, {:.3f}]', True)
row('校验（已落定）ns = xo.reverify − xo.reload', lambda g: g('xo.reverify') - g('xo.reload'))
row('查询 ns = xo.read − xo.reload', lambda g: g('xo.read') - g('xo.reload'))
dfb = row('探针内 D÷FB = xo.read ÷ fb.read', lambda g: g('xo.read') / g('fb.read'), '{:.3f} [{:.3f}, {:.3f}]', True)
row('xo.reload ÷ fb.verify', lambda g: g('xo.reload') / g('fb.verify'), '{:.3f} [{:.3f}, {:.3f}]', True)
p('')

# 3. across builds: ABBA neighbours paired
seq = sorted(procs)
pairs = []
for i in range(0, len(seq) - 1, 2):
    a, b = seq[i], seq[i + 1]
    if {a[1], b[1]} == {'q', 'w8'}:
        q, w = (a, b) if a[1] == 'q' else (b, a)
        pairs.append((q[2], w[2]))
p(f'## w8 ÷ q（相邻的 q、w8 进程配对，{len(pairs)} 对；比值是进程中位数之比的几何均值和 95% 区间）\n')
p('| 变体 | ' + ' | '.join(f'cycle {c}' for c in cycles) + ' | ns 差（周期平均，w8 − q） |')
p('| --- |' + ' ---: |' * (len(cycles) + 1))
xo_ratio = {}
for v in ('xo.read', 'xo.reload', 'xo.reverify', 'syn.q+scan', 'fb.read'):
    cellsv, diffs = [], []
    for c in cycles:
        rs = [med(w, c, v) / med(q, c, v) for q, w in pairs]
        cellsv.append(ci_gm(rs))
    for q, w in pairs:
        diffs.append(st.mean(med(w, c, v) - med(q, c, v) for c in cycles))
    dm, dlo, dhi = ci_mean(diffs)
    xo_ratio[v] = (cellsv, (dm, dlo, dhi))
    p(f'| {v} | ' + ' | '.join('{:.3f} [{:.3f}, {:.3f}]'.format(*x) for x in cellsv) + f' | {dm:+.2f} [{dlo:+.2f}, {dhi:+.2f}] |')
p('')
p('syn.q+scan 和 fb.read 两份构建里是同一份代码（不经过库的拷贝），它们的 w8 ÷ q 应在 1 附近，用来看两份二进制之间的布局和进程差异。\n')

# 4. verdicts (pre-registered in MAC_STEPS_D1.md)
p('## 判定\n')
ex_avg = st.mean(x[0] for x in excess); ex_lo_all = all(x[1] > 0 for x in excess)
syn_stall = ex_lo_all and ex_avg >= 1.0 and all(x[2] < 1 for x in synr)
p(f'- 合成停顿：超额周期平均 {ex_avg:.2f} ns；{"每个周期区间下限 > 0" if ex_lo_all else "并非每个周期区间下限都 > 0"}；'
  f'w8+scan ÷ q+scan {"每个周期上限 < 1" if all(x[2] < 1 for x in synr) else "并非每个周期上限都 < 1"}。'
  f'**{"成立" if syn_stall else "不成立"}**（要求：每个周期超额区间下限 > 0，平均 ≥ 1 ns，且 8 B 拷贝每个周期都更快）。')
(rc, (dm, dlo, dhi)) = xo_ratio['xo.reload']
if pairs:
    if all(x[2] < 1 for x in rc) and dhi <= -0.5:
        v = 'w8 更快：第 2 步（改小 payload 拷贝形状）值得做'
    elif all(x[1] > 1 for x in rc) and dlo > 0:
        v = 'w8 更慢：不做第 2 步，停顿（若有）不能靠 8 B 拷贝消除'
    else:
        v = '不确定：区间跨 1 或差值不足 0.5 ns，不据此做第 2 步'
    p(f'- 库内拷贝：xo.reload 的 w8 − q 为 {dm:+.2f} ns [{dlo:+.2f}, {dhi:+.2f}]。**{v}**'
      '（要求：每个周期比值上限 < 1，且平均差值区间上限 ≤ −0.5 ns）。')
p(f'- 探针内 D÷FB（q，各周期）：' + '，'.join(f'cycle {c} {x[0]:.3f}' for c, x in zip(cycles, dfb)) +
  '。只用来对照 slg_bench 的 D÷FB 量级，不是门禁。')
print('\n'.join(out))
