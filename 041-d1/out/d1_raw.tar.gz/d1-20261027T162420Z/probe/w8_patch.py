# d1 probe patch (measurement only): the in-place copy of the small dense
# reload (VirtualMemoryStorage::assign_in_place) in 8 B stores instead of memcpy.
import sys
p = sys.argv[1]
s = open(p).read()
head = '    bool assign_in_place(const char* bytes, std::size_t length, std::size_t at) noexcept {\n'
old = '        std::memcpy(base_ + at, bytes, length - at);\n'
new = ('        {   // d1 probe: 8 B loads and stores, one pair per iteration\n'
       '            char* dst = base_ + at;\n'
       '            const std::size_t n = length - at;\n'
       '#pragma clang loop unroll(disable) vectorize(disable) interleave(disable)\n'
       '            for (std::size_t i = 0; i < n; i += 8) {\n'
       '                std::uint64_t w;\n'
       '                std::memcpy(&w, bytes + i, 8);\n'
       '                __asm__("" : "+r"(w));\n'
       '                std::memcpy(dst + i, &w, 8);\n'
       '            }\n'
       '        }\n')
i = s.index(head)
j = s.index(old, i)
assert s.count(head) == 1 and j - i < 200, "assign_in_place not found where expected"
s = s[:j] + new + s[j + len(old):]
open(p, 'w').write(s)
