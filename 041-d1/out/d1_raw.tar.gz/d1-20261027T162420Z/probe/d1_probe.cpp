// d1_probe: is there a store-to-load forwarding stall between the payload copy
// and the verification of reload_verified (SLG scenario D, Mac M4)?
//
// Thread 「D 场景追平 FlatBuffers」, 3.2 SC-7 step 1. Measurement only. On the
// same D wires as slg_bench (scale M, seed 20261021; the 512 reports of each of
// several cycles, default 1, 10, 20 and 40 of slg_bench's 1-40; 2048 reads per
// cell), one binary times:
//   xo.read      reload_verified<Report> + query_report (slg_bench D.read, reuse protocol)
//   xo.reload    reload_verified<Report> only
//   xo.reverify  reload_verified<Report>, then the same structural verification
//                again on the settled payload (xo.reverify - xo.reload = verification
//                without a copy just before it)
//   syn.q+scan   memcpy of the stored payload bytes into a 64 B aligned buffer at
//                offset 48, then a validator-like pass of 4 B loads, one per 8 B
//   syn.w8+scan  the same copy with 8 B stores only, then the same pass
//   syn.q        the memcpy alone;  syn.scan  the pass alone, on settled bytes
//   fb.verify    flatbuffers::Verifier on the FlatBuffers wire of the same report
//   fb.read      Verifier + unpack + query_report (slg_bench D.read for flatbuffers)
// Two builds of this file are compared: against the library as released (its
// small dense reload copies with memcpy) and against the same library with
// that one copy done in 8 B stores (XOFFSET probe patch, see run_d1.sh).
//
//   d1_probe [--rounds 101] [--warmup 5] [--cycles 1,10,20,40] [--json out.jsonl] [--label name]
//
// Each round runs every (variant, cycle) cell once over 2048 reads, in an order
// rotated per round; ns per read is the cell's time / 2048. A self-check first runs
// every xo variant and fb.read on every wire and compares the query results.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <memory_resource>
#include <optional>
#include <string>
#include <vector>
#include "slg/generic.hpp"
#include "slg/model_std.hpp"
#include "slg/model_xoffset.hpp"
#include "slg/trace.hpp"
#include "flatbuffers_format.hpp"

using namespace slg;
using Clock = std::chrono::steady_clock;
namespace xo = XOffsetDatastructure;

namespace {

constexpr std::size_t kReportInitial = 4 * 1024; // as xoffset_runner.hpp
constexpr std::size_t kHeader = sizeof(xo::XWireHeaderV2);
constexpr std::size_t kPayloadBegin = xo::XWIRE_PAYLOAD_BEGIN;

xo::XBufferPool& pool() { // as xoffset_runner.hpp (reuse protocol)
    static xo::XBufferPool p(xo::XBufferPool::Limits{16, 16 * (std::size_t(256) << 20), std::size_t(256) << 20});
    return p;
}
xo::XBuffer::MaximumCapacity cap() {
    return xo::XBuffer::maximum_capacity(std::size_t(256) << 20).with_growth(xo::XGrowPolicy::Automatic).with_pool(pool());
}

volatile std::uint64_t g_sink = 0;

[[gnu::noinline]] void copy_w8(char* dst, const char* src, std::size_t n) {
    // 8 B loads and stores, one pair per iteration: the asm keeps the compiler
    // from turning the loop back into memcpy or into 16 B / paired stores.
#pragma clang loop unroll(disable) vectorize(disable) interleave(disable)
    for (std::size_t i = 0; i < n; i += 8) {
        std::uint64_t w;
        std::memcpy(&w, src + i, 8);
        __asm__("" : "+r"(w));
        std::memcpy(dst + i, &w, 8);
    }
}
[[gnu::noinline]] void copy_q(char* dst, const char* src, std::size_t n) { std::memcpy(dst, src, n); }
[[gnu::noinline]] std::uint64_t scan(const char* p, std::size_t n) {
    std::uint64_t s = 0;
#pragma clang loop unroll(disable) vectorize(disable) interleave(disable)
    for (std::size_t i = 0; i < n; i += 8) {
        std::uint32_t v;
        std::memcpy(&v, p + i, 4);
        s += v;
    }
    return s;
}

struct Wire {
    std::string xo;                       // XOffset 2.1 wire (save_verified)
    flatbuffers::DetachedBuffer fb;       // FlatBuffers wire of the same report
    const char* stored = nullptr;         // payload bytes from offset 48
    std::size_t stored_bytes = 0;
    const char* holes = nullptr;
    std::size_t hole_count = 0;
};

double median(std::vector<double> v) {
    std::sort(v.begin(), v.end());
    const auto n = v.size();
    return n == 0 ? 0 : (n % 2 ? v[n / 2] : 0.5 * (v[n / 2 - 1] + v[n / 2]));
}

} // namespace

struct WireSet {
    int cycle = 0;
    std::vector<stdm::Report> reports;
    std::vector<Wire> wires;
    std::size_t xo_bytes = 0, fb_bytes = 0, max_used = 0, with_holes = 0;
};

std::vector<int> parse_cycles(const std::string& s) {
    std::vector<int> out;
    std::size_t i = 0;
    while (i < s.size()) {
        const auto j = s.find(',', i);
        out.push_back(std::atoi(s.substr(i, j == std::string::npos ? std::string::npos : j - i).c_str()));
        if (j == std::string::npos) break;
        i = j + 1;
    }
    return out;
}

int main(int argc, char** argv) {
    int rounds = 101, warmup = 5;
    std::string json, label = "d1", cycles_arg = "1,10,20,40";
    for (int i = 1; i < argc; ++i) {
        const std::string a = argv[i];
        auto next = [&]() -> std::string { if (i + 1 >= argc) { std::fprintf(stderr, "%s needs a value\n", a.c_str()); std::exit(2); } return argv[++i]; };
        if (a == "--rounds") rounds = std::atoi(next().c_str());
        else if (a == "--warmup") warmup = std::atoi(next().c_str());
        else if (a == "--json") json = next();
        else if (a == "--label") label = next();
        else if (a == "--cycles") cycles_arg = next();
        else { std::fprintf(stderr, "unknown argument %s\n", a.c_str()); return 2; }
    }
    const auto cycles = parse_cycles(cycles_arg);
    if (cycles.empty() || !std::is_sorted(cycles.begin(), cycles.end()) || cycles.front() < 0) {
        std::fprintf(stderr, "--cycles: ascending cycle numbers\n"); return 2;
    }

    // The D reports of slg_bench cycles `cycles` (scale M, seed 20261021), built
    // as the std runner builds them: scenarios A (battle request -> simulate ->
    // report, results applied to the armies) and B (season edits written back)
    // of every earlier cycle evolve the players first.
    const Scale& sc = *find_scale("M");
    const std::uint64_t seed = 20261021;
    using FB = FlatBuffersFormat;
    std::vector<stdm::PlayerState> players;
    std::vector<int> armies;
    for (int i = 0; i < sc.players; ++i) players.push_back(make_player(seed, i + 1));
    for (const auto& p : players) armies.push_back(int(p.armies.size()));
    std::vector<WireSet> sets;
    for (int c = 0; c <= cycles.back(); ++c) {
        std::vector<stdm::Report> reports;
        for (const Pairing& pr : make_pairings(seed, c, sc, armies)) {
            auto& att = players[std::size_t(pr.ap)].armies[std::size_t(pr.aa)];
            auto& def = players[std::size_t(pr.dp)].armies[std::size_t(pr.da)];
            const auto req = FB::encode_battle_request(pr.battle_id, pr.seed, att, def);
            stdm::BattleMsg m, r;
            FB::decode(FB::bytes(req), m);
            simulate_battle(m);
            FB::decode(FB::bytes(FB::encode(m)), r);
            apply_battle_army(att, r.attacker);
            apply_battle_army(def, r.defender);
            reports.push_back(r.report);
        }
        const auto migrants = pick_migrants(seed, c, sc);
        for (std::size_t k = 0; k < migrants.size(); ++k) {
            auto& slot = players[std::size_t(migrants[k])];
            stdm::PlayerState m, r;
            FB::decode(FB::bytes(FB::encode(slot)), m);
            season_edits(m, mix_seed(seed, uint64_t(c) * 1000003u + k), sc.season_ops);
            FB::decode(FB::bytes(FB::encode(m)), r);
            slot = std::move(r);
        }
        if (std::find(cycles.begin(), cycles.end(), c) != cycles.end()) {
            sets.emplace_back();
            sets.back().cycle = c;
            sets.back().reports = std::move(reports);
        }
    }
    for (auto& set : sets) {
        set.wires.resize(set.reports.size());
        for (std::size_t k = 0; k < set.reports.size(); ++k) {
            auto b = xo::XBuffer::create<xm::Report>(kReportInitial, cap());
            copy_report(b.root<xm::Report>(), set.reports[k]);
            Wire& w = set.wires[k];
            w.xo = b.save_verified<xm::Report>();
            w.fb = FB::encode(set.reports[k]);
            xo::XWireHeaderV2 h;
            std::memcpy(&h, w.xo.data(), sizeof(h));
            if (h.extent_count != 0 || h.used_bytes > 32768) {
                std::fprintf(stderr, "cycle %d wire %zu is not a small dense wire\n", set.cycle, k); return 3;
            }
            w.stored = w.xo.data() + kHeader;
            w.stored_bytes = h.used_bytes - kPayloadBegin;
            w.holes = w.stored + w.stored_bytes;
            w.hole_count = h.hole_count;
            set.with_holes += h.hole_count != 0;
            set.max_used = std::max<std::size_t>(set.max_used, h.used_bytes);
            set.xo_bytes += w.xo.size();
            set.fb_bytes += w.fb.size();
        }
    }
    const int reads = sc.report_reads;

    auto d = xo::XBuffer::create<xm::Report>(kReportInitial, cap());
    stdm::Report dr;
    FB::Reuse rz;
    alignas(64) static char dst[65536];

    // Self-check: every xo variant and fb.read agree on every wire.
    for (const auto& set : sets)
        for (std::size_t k = 0; k < set.wires.size(); ++k) {
            const auto& w = set.wires[k];
            d.reload_verified<xm::Report>(w.xo);
            const auto a = query_report(d.root<xm::Report>());
            xo::detail::verify_structural_wire_graph(d.unsafe_root<xm::Report>(), d, std::pmr::new_delete_resource(),
                                                     w.holes, w.hole_count, true, nullptr, nullptr);
            rz.decode(FB::bytes(w.fb), dr);
            const auto b = query_report(dr);
            if (a != b || a != query_report(set.reports[k])) {
                std::fprintf(stderr, "self-check: cycle %d wire %zu differs\n", set.cycle, k); return 4;
            }
            copy_q(dst + kPayloadBegin, w.stored, w.stored_bytes);
            const auto s1 = scan(dst + kPayloadBegin, w.stored_bytes);
            copy_w8(dst + kPayloadBegin, w.stored, w.stored_bytes);
            if (scan(dst + kPayloadBegin, w.stored_bytes) != s1 ||
                std::memcmp(dst + kPayloadBegin, w.stored, w.stored_bytes) != 0) {
                std::fprintf(stderr, "self-check: cycle %d copy %zu differs\n", set.cycle, k); return 4;
            }
        }

    struct Variant { const char* name; std::function<void(const Wire&)> op; };
    const std::vector<Variant> vs = {
        {"xo.read", [&](const Wire& w) { d.reload_verified<xm::Report>(w.xo); g_sink = g_sink + query_report(d.root<xm::Report>()); }},
        {"xo.reload", [&](const Wire& w) { d.reload_verified<xm::Report>(w.xo); g_sink = g_sink + d.epoch(); }},
        {"xo.reverify", [&](const Wire& w) {
             d.reload_verified<xm::Report>(w.xo);
             xo::detail::verify_structural_wire_graph(d.unsafe_root<xm::Report>(), d, std::pmr::new_delete_resource(),
                                                      w.holes, w.hole_count, true, nullptr, nullptr);
             g_sink = g_sink + d.epoch(); }},
        {"syn.q+scan", [&](const Wire& w) { copy_q(dst + kPayloadBegin, w.stored, w.stored_bytes); g_sink = g_sink + scan(dst + kPayloadBegin, w.stored_bytes); }},
        {"syn.w8+scan", [&](const Wire& w) { copy_w8(dst + kPayloadBegin, w.stored, w.stored_bytes); g_sink = g_sink + scan(dst + kPayloadBegin, w.stored_bytes); }},
        {"syn.q", [&](const Wire& w) { copy_q(dst + kPayloadBegin, w.stored, w.stored_bytes); g_sink = g_sink + 1; }},
        {"syn.scan", [&](const Wire& w) { g_sink = g_sink + scan(dst + kPayloadBegin, w.stored_bytes); }},
        {"fb.verify", [&](const Wire& w) { g_sink = g_sink + std::uintptr_t(FB::verified_root<stdm::Report>(FB::bytes(w.fb))); }},
        {"fb.read", [&](const Wire& w) { rz.decode(FB::bytes(w.fb), dr); g_sink = g_sink + query_report(dr); }},
    };
    // One cell per (variant, cycle set); every round runs each cell once, in an
    // order rotated per round.
    struct Cell { std::size_t v, s; std::vector<double> ns; };
    std::vector<Cell> cells;
    for (std::size_t s = 0; s < sets.size(); ++s)
        for (std::size_t v = 0; v < vs.size(); ++v) cells.push_back({v, s, {}});
    const std::size_t K = cells.size();

    FILE* jf = json.empty() ? nullptr : std::fopen(json.c_str(), "w");
    if (!json.empty() && !jf) { std::fprintf(stderr, "cannot write %s\n", json.c_str()); return 2; }
    for (int r = -warmup; r < rounds; ++r) {
        for (std::size_t j = 0; j < K; ++j) {
            auto& c = cells[(j + std::size_t(r + warmup) * 7u) % K];
            const auto& op = vs[c.v].op;
            const auto& wires = sets[c.s].wires;
            const auto t0 = Clock::now();
            for (int q = 0; q < reads; ++q) op(wires[std::size_t(q) % wires.size()]);
            const auto t1 = Clock::now();
            const double ns = double(std::chrono::duration_cast<std::chrono::nanoseconds>(t1 - t0).count()) / reads;
            if (r < 0) continue;
            c.ns.push_back(ns);
            if (jf) std::fprintf(jf, "{\"label\":\"%s\",\"round\":%d,\"cycle\":%d,\"variant\":\"%s\",\"ns\":%.3f}\n",
                                 label.c_str(), r, sets[c.s].cycle, vs[c.v].name, ns);
        }
    }
    if (jf) std::fclose(jf);

    std::printf("d1_probe %s: %d reads per cell and round, %d rounds (+%d warm-up)\n", label.c_str(), reads, rounds, warmup);
    for (const auto& set : sets)
        std::printf("  cycle %d: %zu reports, bytes per report xoffset %zu flatbuffers %zu, max used %zu B, wires with holes %zu\n",
                    set.cycle, set.wires.size(), set.xo_bytes / set.wires.size(), set.fb_bytes / set.wires.size(),
                    set.max_used, set.with_holes);
    std::printf("median ns per read\n%-14s", "variant");
    for (const auto& set : sets) std::printf(" %9s%-3d", "cycle ", set.cycle);
    std::printf("\n");
    for (std::size_t v = 0; v < vs.size(); ++v) {
        std::printf("%-14s", vs[v].name);
        for (std::size_t s = 0; s < sets.size(); ++s) std::printf(" %12.2f", median(cells[s * vs.size() + v].ns));
        std::printf("\n");
    }
    return g_sink == 42 ? 1 : 0;
}
