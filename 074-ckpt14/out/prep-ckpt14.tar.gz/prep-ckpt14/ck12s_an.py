#!/usr/bin/env python3
"""CK12S timing analysis: XOffset stage times per mode, point X / point Y, from slg_bench raw files NNN_<point>.jsonl.

usage: ck12s_an.py RAW_X RAW_F4 > CK12S_TIMING.md

Points: new (#191 head with XBufferCore hot fields together), anc (b6e06788), old (827943cf, the CKPT11 head) and, in
CK12X, nc (new with the root cache carry of #191 turned off, diagnostic). Pairs new/anc, old/anc, new/old, nc/anc,
new/nc (those whose points ran) in each mode: x = --formats xoffset, f4 = the L2 four formats in one process. Per process:
mean over cycles 1..40 of log(ns) of a stage, or of the scenario total (sum of the scenario's stages per cycle,
read_direct left out, as bench/slg/tools/analyze.py). Ratio = exp(mean X - mean Y) over processes, Welch t, two-sided
95%; scenario totals with Bonferroni k = 4, stages without correction. In f4 also "A÷rivals": per process the xoffset
A.total log mean minus the mean of the three rivals' A.total log means (the L2 SLG quantity), same test. Report only.
"""
import glob, json, math, os, sys
from collections import defaultdict

def betacf(a, b, x):
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > 1e-300 else 1e-300); h = d
    for m in range(1, 300):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e-300
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d; d = 1.0 / (d if abs(d) > 1e-300 else 1e-300)
        c = 1.0 + aa / c if abs(c) > 1e-300 else 1e-300
        de = d * c; h *= de
        if abs(de - 1.0) < 1e-12: break
    return h

def ibeta(a, b, x):
    if x <= 0: return 0.0
    if x >= 1: return 1.0
    bt = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log(1 - x))
    return bt * betacf(a, b, x) / a if x < (a + 1) / (a + b + 2) else 1 - bt * betacf(b, a, 1 - x) / b

def t_cdf(t, df):
    p = 0.5 * ibeta(df / 2, 0.5, df / (df + t * t))
    return 1 - p if t > 0 else p

def t_q(p, df):
    lo, hi = 0.0, 100.0
    for _ in range(200):
        mid = (lo + hi) / 2
        if t_cdf(mid, df) < p: lo = mid
        else: hi = mid
    return (lo + hi) / 2

def welch(x, y, k=1):
    nx, ny = len(x), len(y)
    mx, my = sum(x) / nx, sum(y) / ny
    vx = sum((v - mx) ** 2 for v in x) / (nx - 1); vy = sum((v - my) ** 2 for v in y) / (ny - 1)
    se2 = vx / nx + vy / ny; se = math.sqrt(se2)
    df = se2 ** 2 / ((vx / nx) ** 2 / (nx - 1) + (vy / ny) ** 2 / (ny - 1)) if se2 > 0 else nx + ny - 2
    q = t_q(1 - 0.05 / (2 * k), df)
    d = mx - my
    return math.exp(d), math.exp(d - q * se), math.exp(d + q * se)

def load(path):
    per = defaultdict(lambda: defaultdict(dict))   # format -> metric -> cycle -> ns
    for line in open(path):
        r = json.loads(line)
        if "ns" not in r or "format" not in r or r.get("cycle", 0) == 0: continue
        per[r["format"]][r["metric"]][r["cycle"]] = r["ns"]
    res = {}
    for fmt, pm in per.items():
        for s in "ABCD":
            ms = [m for m in pm if m.startswith(s + ".") and not m.endswith("read_direct")]
            cyc = set().union(*(pm[m].keys() for m in ms)) if ms else set()
            pm[s + ".total"] = {c: sum(pm[m].get(c, 0) for m in ms) for c in cyc}
        out = {}
        for m, v in pm.items():
            xs = [math.log(n) for n in v.values() if n > 0]
            if xs: out[m] = sum(xs) / len(xs)
        med = {m: sorted(v.values())[len(v) // 2] for m, v in pm.items() if v}
        res[fmt] = (out, med)
    xo = res.get("xoffset", ({}, {}))
    riv = [res[f][0]["A.total"] for f in res if f != "xoffset" and "A.total" in res[f][0]]
    if len(riv) == 3 and "A.total" in xo[0]:
        xo[0]["A÷rivals"] = xo[0]["A.total"] - sum(riv) / 3
        xo[1]["A÷rivals"] = 0
    return xo

PAIRS = (("new", "anc"), ("old", "anc"), ("new", "old"), ("nc", "anc"), ("new", "nc"))   # pairs whose points ran

def table(pts, mode, verdict):
    for x, y in PAIRS:
        if x not in pts or y not in pts or len(pts[x]) < 2 or len(pts[y]) < 2: continue
        print(f"## {mode}: {x} ÷ {y}\n")
        print("| 指标 | X µs | Y µs | X÷Y | 95% 区间 |")
        print("| --- | ---: | ---: | ---: | --- |")
        metrics = (["A÷rivals"] if "A÷rivals" in pts[x][0][0] else []) + ["A.total", "B.total", "C.total", "D.total"] + \
            sorted(m for m in pts[x][0][0] if m[0] == "A" and "." in m and not m.endswith("total"))
        for m in metrics:
            xs = [p[0][m] for p in pts[x] if m in p[0]]; ys = [p[0][m] for p in pts[y] if m in p[0]]
            if len(xs) < 2 or len(ys) < 2: continue
            r, lo, hi = welch(xs, ys, 4 if m.endswith("total") or m == "A÷rivals" else 1)
            if m == "A÷rivals":
                print(f"| **{m}** | | | {r:.4f} | [{lo:.4f}, {hi:.4f}] |")
            else:
                mx = sorted(p[1][m] for p in pts[x] if m in p[1]); my = sorted(p[1][m] for p in pts[y] if m in p[1])
                print(f"| {'**' + m + '**' if m.endswith('total') else m} | {mx[len(mx) // 2] / 1000:.1f} | {my[len(my) // 2] / 1000:.1f} | {r:.4f} | [{lo:.4f}, {hi:.4f}] |")
            if m in ("A÷rivals", "A.total", "A.req_encode", "A.res_decode"): verdict.append(f"{mode} {x}÷{y} {m} {r:.4f} [{lo:.4f}, {hi:.4f}]")
        print()

def main():
    print("# CK12S timing: XOffset stages, point ÷ point\n")
    verdict = []
    for mode, raw in (("x", sys.argv[1]), ("f4", sys.argv[2])):
        pts = defaultdict(list)
        for f in sorted(glob.glob(os.path.join(raw, "[0-9][0-9][0-9]_*.jsonl"))):
            pts[os.path.basename(f)[4:-6]].append(load(f))
        print(f"{mode} processes: " + ", ".join(f"{p} {len(v)}" for p, v in sorted(pts.items())) + "\n")
        table(pts, mode, verdict)
    print("判读行 x（只报）：" + "；".join(v for v in verdict if v.startswith("x ")))
    print("判读行 f4（只报）：" + "；".join(v for v in verdict if v.startswith("f4 ")))

main()
