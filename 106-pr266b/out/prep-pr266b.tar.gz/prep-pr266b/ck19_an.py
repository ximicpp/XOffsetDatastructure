#!/usr/bin/env python3
# CKPT20 report-only analysis (embedded in run_ckpt20.sh; the cloud recomputes the same from the raw files).
#   ck19_an.py hft  DIR   DIR/<seq>_<point>_<impl>_<access>.json, one book_c line each
#   ck19_an.py demo DIR   DIR/<seq>_<point>.jsonl, slg_bench --mode bench raw (SLG_CASES=demo)
# point is head or anc. Per series: median of the head runs / median of the anchor runs, with a 95% percentile
# bootstrap interval (runs resampled within each point, 4000 draws, fixed seed). demo: one value per process and
# metric = the median over cycles 1.. (cycle 0 dropped, as L2). Report only: nothing here judges or stops the batch.
import json, os, random, statistics, sys


def ratio_ci(h, a, n=4000, seed=19):
    r = random.Random(seed)
    point = statistics.median(h) / statistics.median(a)
    bs = []
    for _ in range(n):
        hh = [h[r.randrange(len(h))] for _ in h]
        aa = [a[r.randrange(len(a))] for _ in a]
        bs.append(statistics.median(hh) / statistics.median(aa))
    bs.sort()
    return point, bs[int(0.025 * n)], bs[int(0.975 * n) - 1]


def hft(d):
    runs, digests, bad = {}, set(), []
    for f in sorted(os.listdir(d)):
        if not f.endswith('.json'):
            continue
        seq, pt, impl, acc = f[:-5].split('_', 3)
        try:
            j = json.loads(open(os.path.join(d, f)).read().strip().splitlines()[-1])
        except Exception as e:
            bad.append(f'{f}: {e}')
            continue
        digests.add((j['digest'], j['live_orders'], j['levels']))
        runs.setdefault((impl.replace('-', '_'), acc), {}).setdefault(pt, []).append(j['ns_per_event'])
    print('# CKPT20 HFT (report only): 64 books, one XBuffer per book, book_c.cpp, ns/event')
    print()
    print('| impl | access | runs head/anc | head median | anchor median | head/anc | 95% interval |')
    print('|---|---|---|---|---|---|---|')
    out = []
    for (impl, acc), v in sorted(runs.items()):
        h, a = v.get('head', []), v.get('anc', [])
        if len(h) < 2 or len(a) < 2:
            print(f'| {impl} | {acc} | {len(h)}/{len(a)} | | | too few runs | |')
            continue
        p, lo, hi = ratio_ci(h, a)
        out.append(f'{impl}/{acc} {p:.3f}')
        print(f'| {impl} | {acc} | {len(h)}/{len(a)} | {statistics.median(h):.2f} | {statistics.median(a):.2f} | {p:.4f} | [{lo:.4f}, {hi:.4f}] |')
    print()
    print(f'digest / live orders / levels across every run: {"identical" if len(digests) == 1 else "DIFFER"} {sorted(digests)}')
    for b in bad:
        print('unreadable:', b)
    print()
    print('HFT head/anc: ' + ', '.join(out) + ('' if len(digests) == 1 and not bad else ' (DIGEST OR RUN PROBLEM)'))


def demo(d, keys=('UP.apply', 'UC.apply', 'NP.recv', 'UP.send', 'UC.send', 'NP.send', 'UP.recv', 'UC.recv', 'NP.apply')):
    per, byts = {}, {'head': set(), 'anc': set()}
    nproc = {'head': 0, 'anc': 0}
    for f in sorted(os.listdir(d)):
        if not f.endswith('.jsonl'):
            continue
        pt = f[:-6].split('_', 1)[1]
        nproc[pt] += 1
        m = {}
        for line in open(os.path.join(d, f)):
            j = json.loads(line)
            if 'bytes' in j and j.get('format') == 'xoffset':
                byts[pt].add((j['cycle'], j['metric'], j['bytes']))
            if 'metric' not in j or 'ns' not in j or j.get('format') != 'xoffset' or j.get('cycle', 0) == 0:
                continue
            m.setdefault(j['metric'], []).append(j['ns'])
        for k, v in m.items():
            per.setdefault(k, {}).setdefault(pt, []).append(statistics.median(v))
    print(f'# CKPT20 SLG demo cases (report only): xoffset, SLG_CASES=demo SLG_REUSE=1, M, processes head {nproc["head"]} anchor {nproc["anc"]}')
    print()
    print('| metric | head median | anchor median | head/anc | 95% interval |')
    print('|---|---|---|---|---|')
    rows, lead = [], []
    for k in sorted(per):
        h, a = per[k].get('head', []), per[k].get('anc', [])
        if len(h) < 2 or len(a) < 2 or statistics.median(a) == 0:
            continue
        p, lo, hi = ratio_ci(h, a)
        rows.append((k, p, lo, hi, statistics.median(h), statistics.median(a)))
    first = [r for r in rows if r[0] in keys]
    first.sort(key=lambda r: keys.index(r[0]))
    for r in first + [r for r in rows if r[0] not in keys]:
        print(f'| {r[0]} | {r[4]:.0f} | {r[5]:.0f} | {r[1]:.4f} | [{r[2]:.4f}, {r[3]:.4f}] |')
        if r[0] in keys:
            lead.append(f'{r[0]} {r[1]:.3f}')
    print()
    same = byts['head'] == byts['anc'] and len(byts['head']) > 0
    print(f'xoffset byte metrics (every cycle, every metric) head vs anchor: {"identical" if same else "DIFFER"} ({len(byts["head"])} / {len(byts["anc"])} distinct entries)')
    print()
    print('demo head/anc: ' + ', '.join(lead) + ('' if same else ' (BYTES DIFFER)'))


if __name__ == '__main__':
    {'hft': hft, 'demo': demo}[sys.argv[1]](sys.argv[2])
