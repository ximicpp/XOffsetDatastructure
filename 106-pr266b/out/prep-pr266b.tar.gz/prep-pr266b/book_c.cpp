// HFT demo, risk item C: applying L3 order-book events in place.
//
// The same synthetic ITCH-like event stream (normalized updates that carry
// side and price, as the feed handler publishes them) is applied to one of
// three book implementations. Only the event apply is counted.
//
//   pool    hand-written fixed-capacity pool: per side a vector of levels
//           sorted best-last; orders in a per-book pool with a free list, FIFO
//           per level as an intrusive doubly linked list; id -> slot table.
//   xo_nest XOffset, the natural nested model: per side XVector<XLevel>,
//           each level holding XVector<XOrder> in time order; no id index
//           (the order is found by scanning its level).
//   xo_pool the pool layout of `pool`, stored in the book's XBuffer
//           (XVector<YLevel> per side, XVector<YOrder> pool + free list).
//
// Every implementation finds a level by scanning from the best price, so the
// difference is the level / order storage.
#include "xoffsetdatastructure.hpp"

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <cstring>
#include <memory>
#include <string>
#include <vector>

#if defined(BOOKC_IR)
#include <valgrind/callgrind.h>
#define IR_TOGGLE() CALLGRIND_TOGGLE_COLLECT
#else
#define IR_TOGGLE() bookc_clock()
#endif

using namespace XOffsetDatastructure;

#if !defined(BOOKC_IR)
// Without callgrind the two toggles around the measured loop read the clock.
static std::chrono::steady_clock::time_point bookc_t[2];
static int bookc_n = 0;
static void bookc_clock() { bookc_t[bookc_n++ & 1] = std::chrono::steady_clock::now(); }
static double bookc_ns() { return double(std::chrono::duration_cast<std::chrono::nanoseconds>(bookc_t[1] - bookc_t[0]).count()); }
#else
static double bookc_ns() { return 0; }
#endif

// ---- events -------------------------------------------------------------------
struct Ev {
    std::uint64_t id;
    std::int64_t price;
    std::uint64_t ts;
    std::uint32_t qty;     // add: shares; reduce: shares removed
    std::uint16_t book;
    std::uint8_t action;   // 'A' add, 'R' reduce (cancel / execute), 'D' delete
    std::uint8_t side;     // 0 bid, 1 ask
};

struct Rng {
    std::uint64_t s;
    std::uint64_t next() {
        std::uint64_t z = (s += 0x9e3779b97f4a7c15ull);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ull;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebull;
        return z ^ (z >> 31);
    }
    std::uint32_t below(std::uint32_t n) { return std::uint32_t((next() >> 32) * n >> 32); }
    double unit() { return double(next() >> 11) * (1.0 / 9007199254740992.0); }
    std::uint32_t geometric(double p, std::uint32_t cap) {
        std::uint32_t k = 0;
        while (k < cap && unit() > p) ++k;
        return k;
    }
};

// Level lookup from the best end. Levels are sorted best-last: bids ascending,
// asks descending. Returns the index, or ~insert_position when absent.
template <class V>
inline long find_level(const V& lv, std::int64_t px, int side) {
    long i = long(lv.size()) - 1;
    for (; i >= 0; --i) {
        const std::int64_t p = lv[std::size_t(i)].price;
        if (p == px) return i;
        if (side == 0 ? p < px : p > px) break;
    }
    return ~(i + 1);
}

// ---- pool layout (shared by pool and xo_pool) ------------------------------------
struct PoolOrder {
    std::uint64_t id;
    std::uint64_t ts;
    std::int64_t price;
    std::uint32_t qty;
    std::int32_t next;
    std::int32_t prev;
    std::uint32_t pad;
};
struct PoolLevel {
    std::int64_t price;
    std::uint64_t qty;
    std::uint32_t count;
    std::int32_t head;
    std::int32_t tail;
    std::uint32_t pad;
};

template <class LV, class PV>
struct PoolOps {
    static void add(LV& lv, PV& pool, std::int32_t& free_head, std::uint32_t* slot_of, const Ev& e) {
        long li = find_level(lv, e.price, e.side);
        if (li < 0) {
            li = ~li;
            lv.insert(lv.begin() + li, PoolLevel{e.price, 0, 0, -1, -1, 0});
        }
        std::int32_t s;
        if (free_head >= 0) {
            s = free_head;
            free_head = pool[std::size_t(s)].next;
        } else {
            s = std::int32_t(pool.size());
            pool.push_back(PoolOrder{});
        }
        PoolLevel& L = lv[std::size_t(li)];
        pool[std::size_t(s)] = PoolOrder{e.id, e.ts, e.price, e.qty, -1, L.tail, 0};
        if (L.tail >= 0) pool[std::size_t(L.tail)].next = s;
        else L.head = s;
        L.tail = s;
        L.qty += e.qty;
        ++L.count;
        slot_of[e.id] = std::uint32_t(s);
    }
    static void unlink(LV& lv, PV& pool, std::int32_t& free_head, long li, std::int32_t s) {
        PoolOrder& o = pool[std::size_t(s)];
        PoolLevel& L = lv[std::size_t(li)];
        if (o.prev >= 0) pool[std::size_t(o.prev)].next = o.next;
        else L.head = o.next;
        if (o.next >= 0) pool[std::size_t(o.next)].prev = o.prev;
        else L.tail = o.prev;
        L.qty -= o.qty;
        o.next = free_head;
        free_head = s;
        if (--L.count == 0) lv.erase(lv.begin() + li);
    }
    static void remove(LV& lv, PV& pool, std::int32_t& free_head, std::uint32_t* slot_of, const Ev& e) {
        const auto s = std::int32_t(slot_of[e.id]);
        const long li = find_level(lv, e.price, e.side);
        unlink(lv, pool, free_head, li, s);
    }
    static void reduce(LV& lv, PV& pool, std::int32_t& free_head, std::uint32_t* slot_of, const Ev& e) {
        const auto s = std::int32_t(slot_of[e.id]);
        const long li = find_level(lv, e.price, e.side);
        PoolOrder& o = pool[std::size_t(s)];
        if (o.qty == e.qty) { unlink(lv, pool, free_head, li, s); return; }
        o.qty -= e.qty;
        lv[std::size_t(li)].qty -= e.qty;
    }
};

// Hand-written pool in process memory, capacity reserved up front.
struct PoolBook {
    std::vector<PoolLevel> lv[2];
    std::vector<PoolOrder> pool;
    std::int32_t free_head = -1;
    explicit PoolBook(std::size_t order_cap = 0, std::size_t level_cap = 0) {
        pool.reserve(order_cap);
        lv[0].reserve(level_cap);
        lv[1].reserve(level_cap);
    }
};
using StdOps = PoolOps<std::vector<PoolLevel>, std::vector<PoolOrder>>;

// ---- XOffset layouts --------------------------------------------------------------
struct XOrder {
    std::uint64_t id;
    std::uint64_t ts;
    std::uint32_t qty;
    std::uint32_t pad;
};
struct XLevel {
    std::int64_t price;
    std::uint64_t qty;
    std::uint32_t count;
    std::uint32_t pad;
    XVector<XOrder> orders;
};
struct XNestBook {
    std::uint32_t instrument;
    std::uint32_t pad;
    std::uint64_t last_seq;
    XVector<XLevel> bids;
    XVector<XLevel> asks;
};
struct XPoolBook {
    std::uint32_t instrument;
    std::int32_t free_head;
    std::uint64_t last_seq;
    XVector<PoolLevel> bids;
    XVector<PoolLevel> asks;
    XVector<PoolOrder> pool;
};
XOFFSET_RECORD(XOrder, id, ts, qty, pad)
XOFFSET_RECORD(XLevel, price, qty, count, pad, orders)
XOFFSET_RECORD(XNestBook, instrument, pad, last_seq, bids, asks)
XOFFSET_RECORD(PoolLevel, price, qty, count, head, tail, pad)
XOFFSET_RECORD(PoolOrder, id, ts, price, qty, next, prev, pad)
XOFFSET_RECORD(XPoolBook, instrument, free_head, last_seq, bids, asks, pool)
XOFFSET_REGISTER_SCHEMA_NAME(XNestBook, "bookc.XNestBook.v1")
XOFFSET_REGISTER_SCHEMA_NAME(XPoolBook, "bookc.XPoolBook.v1")
struct XPoolStore {
    XVector<XPoolBook> books;
};
XOFFSET_RECORD(XPoolStore, books)
XOFFSET_REGISTER_SCHEMA_NAME(XPoolStore, "bookc.XPoolStore.v1")
struct XNestStore {
    XVector<XNestBook> books;
};
XOFFSET_RECORD(XNestStore, books)
XOFFSET_REGISTER_SCHEMA_NAME(XNestStore, "bookc.XNestStore.v1")

using XPoolOps = PoolOps<XVector<PoolLevel>, XVector<PoolOrder>>;

struct NestOps {
    static void add(XNestBook& b, const Ev& e) {
        auto& lv = e.side == 0 ? b.bids : b.asks;
        long li = find_level(lv, e.price, e.side);
        if (li < 0) {
            li = ~li;
            XLevel fresh{};
            fresh.price = e.price;
            lv.insert(lv.begin() + li, fresh);
        }
        XLevel& L = lv[std::size_t(li)];
        L.orders.push_back(XOrder{e.id, e.ts, e.qty, 0});
        L.qty += e.qty;
        ++L.count;
    }
    static void take(XVector<XLevel>& lv, long li, std::uint64_t id, std::uint32_t q, bool all) {
        XLevel& L = lv[std::size_t(li)];
        auto& os = L.orders;
        std::size_t k = 0;
        while (os[k].id != id) ++k;
        if (all || os[k].qty == q) {
            L.qty -= os[k].qty;
            os.erase(os.begin() + std::ptrdiff_t(k));
            if (--L.count == 0) lv.erase(lv.begin() + li);
        } else {
            os[k].qty -= q;
            L.qty -= q;
        }
    }
    static void remove(XNestBook& b, const Ev& e) {
        auto& lv = e.side == 0 ? b.bids : b.asks;
        take(lv, find_level(lv, e.price, e.side), e.id, 0, true);
    }
    static void reduce(XNestBook& b, const Ev& e) {
        auto& lv = e.side == 0 ? b.bids : b.asks;
        take(lv, find_level(lv, e.price, e.side), e.id, e.qty, false);
    }
};

// ---- digest (identical book state across implementations) --------------------------
inline std::uint64_t mix(std::uint64_t h, std::uint64_t v) { return (h ^ v) * 0x100000001b3ull; }

template <class LV, class PV>
std::uint64_t digest_pool(const LV* lv, const PV& pool) {
    std::uint64_t h = 1469598103934665603ull;
    for (int s = 0; s < 2; ++s)
        for (long i = long(lv[s].size()) - 1; i >= 0; --i) {
            const PoolLevel& L = lv[s][std::size_t(i)];
            h = mix(mix(mix(h, std::uint64_t(L.price)), L.qty), L.count);
            for (std::int32_t o = L.head; o >= 0; o = pool[std::size_t(o)].next)
                h = mix(mix(h, pool[std::size_t(o)].id), pool[std::size_t(o)].qty);
        }
    return h;
}
std::uint64_t digest_nest(const XNestBook& b) {
    std::uint64_t h = 1469598103934665603ull;
    const XVector<XLevel>* lvs[2] = {&b.bids, &b.asks};
    for (int s = 0; s < 2; ++s)
        for (long i = long(lvs[s]->size()) - 1; i >= 0; --i) {
            const XLevel& L = (*lvs[s])[std::size_t(i)];
            h = mix(mix(mix(h, std::uint64_t(L.price)), L.qty), L.count);
            for (const XOrder& o : L.orders) h = mix(mix(h, o.id), o.qty);
        }
    return h;
}

// ---- generator: drives a PoolBook model and records the events ------------------------
struct GenParams {
    std::uint32_t books = 64;
    std::uint32_t live = 150;      // target live orders per book
    std::uint32_t events = 400000; // total (warm-up + measured)
    std::uint64_t seed = 20261104;
};

std::vector<Ev> generate(const GenParams& g) {
    Rng rng{g.seed};
    const std::int64_t tick = 100;   // 1 cent in ITCH Price(4) units
    std::vector<PoolBook> model(g.books);
    std::vector<std::uint32_t> slot_of(std::size_t(g.events) + 2);
    std::vector<std::vector<std::uint64_t>> live(g.books);
    std::vector<std::uint32_t> live_pos(std::size_t(g.events) + 2);
    std::vector<std::uint8_t> side_of(std::size_t(g.events) + 2);
    std::vector<std::int64_t> price_of(std::size_t(g.events) + 2);
    std::vector<std::vector<std::uint64_t>> recent(g.books, std::vector<std::uint64_t>(32, 0));
    std::vector<std::uint32_t> recent_at(g.books, 0);
    std::vector<Ev> out;
    out.reserve(g.events);
    std::uint64_t next_id = 1, ts = 34200000000000ull;
    auto drop_live = [&](std::uint32_t b, std::uint64_t id) {
        auto& L = live[b];
        const auto p = live_pos[id];
        L[p] = L.back();
        live_pos[L[p]] = p;
        L.pop_back();
    };
    for (std::uint32_t n = 0; n < g.events; ++n) {
        ts += 1 + rng.below(2000);
        const std::uint32_t b = rng.below(g.books);
        PoolBook& m = model[b];
        const std::uint32_t nlive = std::uint32_t(live[b].size());
        double p_add = 0.5 + 0.5 * (double(g.live) - double(nlive)) / double(g.live);
        p_add = std::clamp(p_add, 0.2, 0.9);
        Ev e{};
        e.book = std::uint16_t(b);
        e.ts = ts;
        if (nlive == 0 || rng.unit() < p_add) {
            const std::uint8_t side = std::uint8_t(rng.below(2));
            const std::int64_t mid = 1000000 + std::int64_t(b) * 10000;
            const bool has_bid = !m.lv[0].empty(), has_ask = !m.lv[1].empty();
            const std::int64_t best_bid = has_bid ? m.lv[0].back().price : (has_ask ? m.lv[1].back().price - tick : mid - tick);
            const std::int64_t best_ask = has_ask ? m.lv[1].back().price : (has_bid ? m.lv[0].back().price + tick : mid + tick);
            const std::int64_t d = std::int64_t(rng.geometric(0.3, 60));
            std::int64_t px;
            if (side == 0) {
                px = (best_ask - best_bid > tick && rng.unit() < 0.05) ? best_bid + tick : best_bid - d * tick;
                if (px >= best_ask) px = best_ask - tick;
            } else {
                px = (best_ask - best_bid > tick && rng.unit() < 0.05) ? best_ask - tick : best_ask + d * tick;
                if (px <= best_bid) px = best_bid + tick;
            }
            e.action = 'A';
            e.side = side;
            e.id = next_id++;
            e.price = px;
            e.qty = 100u * (1u + rng.geometric(0.4, 20));
            StdOps::add(m.lv[side], m.pool, m.free_head, slot_of.data(), e);
            live_pos[e.id] = std::uint32_t(live[b].size());
            live[b].push_back(e.id);
            side_of[e.id] = side;
            price_of[e.id] = px;
            recent[b][recent_at[b]++ % 32] = e.id;
        } else {
            const double r = rng.unit();
            std::uint64_t id;
            if (r < 0.09) {
                // Execution against the front order of a best level.
                int side = int(rng.below(2));
                if (m.lv[side].empty()) side ^= 1;
                id = m.pool[std::size_t(m.lv[side].back().head)].id;
            } else if (rng.unit() < 0.7) {
                // Cancel of a recent add, when it is still live.
                id = recent[b][rng.below(32)];
                if (id == 0 || live_pos[id] >= live[b].size() || live[b][live_pos[id]] != id)
                    id = live[b][rng.below(nlive)];
            } else {
                id = live[b][rng.below(nlive)];
            }
            e.id = id;
            e.side = side_of[id];
            e.price = price_of[id];
            const std::uint32_t q = m.pool[slot_of[id]].qty;
            if (r < 0.09) {
                e.action = 'R';
                e.qty = rng.unit() < 0.6 ? q : 1u + rng.below(q);
            } else if (r < 0.15 && q > 1) {
                e.action = 'R';
                e.qty = 1u + rng.below(q - 1);
            } else {
                e.action = 'D';
                e.qty = q;
            }
            if (e.action == 'D') StdOps::remove(m.lv[e.side], m.pool, m.free_head, slot_of.data(), e);
            else StdOps::reduce(m.lv[e.side], m.pool, m.free_head, slot_of.data(), e);
            if (e.action == 'D' || e.qty == q) drop_live(b, id);
        }
        out.push_back(e);
    }
    return out;
}

// ---- runner --------------------------------------------------------------------------
int main(int argc, char** argv) {
    std::string impl = "pool";
    GenParams g;
    std::uint32_t warm = 200000;
    std::string access = "handle";   // root: buf.root<T>() per event; handle: XHandle<T> per book
    for (int i = 1; i + 1 < argc; i += 2) {
        const std::string k = argv[i];
        const char* v = argv[i + 1];
        if (k == "--impl") impl = v;
        else if (k == "--books") g.books = std::uint32_t(std::atoi(v));
        else if (k == "--live") g.live = std::uint32_t(std::atoi(v));
        else if (k == "--events") g.events = std::uint32_t(std::atoi(v));
        else if (k == "--warm") warm = std::uint32_t(std::atoi(v));
        else if (k == "--access") access = v;
    }
    const std::vector<Ev> evs = generate(g);
    const std::size_t measured = evs.size() - warm;
    std::uint64_t counts[3] = {0, 0, 0};
    for (std::size_t i = warm; i < evs.size(); ++i) counts[evs[i].action == 'A' ? 0 : evs[i].action == 'R' ? 1 : 2]++;

    std::uint64_t dig = 0;
    std::size_t bytes = 0, live_orders = 0, levels = 0;
    if (impl == "pool") {
        std::vector<PoolBook> books;
        books.reserve(g.books);
        for (std::uint32_t b = 0; b < g.books; ++b) books.emplace_back(4u * g.live, 512);
        std::vector<std::uint32_t> slot_of(std::size_t(g.events) + 2);
        auto apply = [&](const Ev& e) {
            PoolBook& m = books[e.book];
            if (e.action == 'A') StdOps::add(m.lv[e.side], m.pool, m.free_head, slot_of.data(), e);
            else if (e.action == 'R') StdOps::reduce(m.lv[e.side], m.pool, m.free_head, slot_of.data(), e);
            else StdOps::remove(m.lv[e.side], m.pool, m.free_head, slot_of.data(), e);
        };
        // Same loop shape as the XOffset runs (apply called through a lambda).
        auto run = [&](auto&& fn) {
            for (std::size_t i = 0; i < warm; ++i) fn(evs[i]);
            IR_TOGGLE();
            for (std::size_t i = warm; i < evs.size(); ++i) fn(evs[i]);
            IR_TOGGLE();
        };
        run([&](const Ev& e) { apply(e); });
        for (auto& m : books) {
            dig = mix(dig, digest_pool(m.lv, m.pool));
            bytes += m.pool.capacity() * sizeof(PoolOrder) + (m.lv[0].capacity() + m.lv[1].capacity()) * sizeof(PoolLevel);
            levels += m.lv[0].size() + m.lv[1].size();
            for (int s = 0; s < 2; ++s) for (auto& L : m.lv[s]) live_orders += L.count;
        }
    } else if (impl == "xo_nest" || impl == "xo_pool") {
        const bool nest = impl == "xo_nest";
        const auto policy = XBuffer::maximum_capacity(std::size_t(64) << 20).with_growth(XGrowPolicy::Automatic);
        std::vector<XBuffer> bufs;
        bufs.reserve(g.books);
        for (std::uint32_t b = 0; b < g.books; ++b) {
            if (nest) bufs.push_back(XBuffer::create<XNestBook>(64 * 1024, policy));
            else {
                bufs.push_back(XBuffer::create<XPoolBook>(64 * 1024, policy));
                auto& r = bufs.back().root<XPoolBook>();
                r.free_head = -1;
                r.pool.reserve(4u * g.live);
                r.bids.reserve(512);
                r.asks.reserve(512);
            }
        }
        const bool by_root = access == "root";
        // Every loop below is one implementation with one access path: no
        // runtime switch inside the measured loop.
        auto run = [&](auto&& apply) {
            for (std::size_t i = 0; i < warm; ++i) apply(evs[i]);
            IR_TOGGLE();
            for (std::size_t i = warm; i < evs.size(); ++i) apply(evs[i]);
            IR_TOGGLE();
        };
        if (nest) {
            auto apply_to = [](XNestBook& r, const Ev& e) {
                if (e.action == 'A') NestOps::add(r, e);
                else if (e.action == 'R') NestOps::reduce(r, e);
                else NestOps::remove(r, e);
            };
            if (by_root) run([&](const Ev& e) { apply_to(bufs[e.book].root<XNestBook>(), e); });
            else if (access == "ptr") {
                // Raw root pointers held across the run: valid only while no
                // buffer moves (here: pinned storage, no relocation).
                std::vector<XNestBook*> p;
                for (auto& buf : bufs) p.push_back(&buf.root<XNestBook>());
                run([&](const Ev& e) { apply_to(*p[e.book], e); });
            } else {
                std::vector<XHandle<XNestBook>> h;
                for (auto& buf : bufs) h.push_back(buf.handle<XNestBook>());
                run([&](const Ev& e) { apply_to(*h[e.book], e); });
            }
        } else {
            std::vector<std::uint32_t> slot_of(std::size_t(g.events) + 2);
            auto apply_to = [&](XPoolBook& r, const Ev& e) {
                auto& lv = e.side == 0 ? r.bids : r.asks;
                if (e.action == 'A') XPoolOps::add(lv, r.pool, r.free_head, slot_of.data(), e);
                else if (e.action == 'R') XPoolOps::reduce(lv, r.pool, r.free_head, slot_of.data(), e);
                else XPoolOps::remove(lv, r.pool, r.free_head, slot_of.data(), e);
            };
            if (by_root) run([&](const Ev& e) { apply_to(bufs[e.book].root<XPoolBook>(), e); });
            else if (access == "ptr") {
                // Raw root pointers held across the run: valid only while no
                // buffer moves (here: pinned storage, no relocation).
                std::vector<XPoolBook*> p;
                for (auto& buf : bufs) p.push_back(&buf.root<XPoolBook>());
                run([&](const Ev& e) { apply_to(*p[e.book], e); });
            } else {
                std::vector<XHandle<XPoolBook>> h;
                for (auto& buf : bufs) h.push_back(buf.handle<XPoolBook>());
                run([&](const Ev& e) { apply_to(*h[e.book], e); });
            }
        }
        for (auto& buf : bufs) {
            if (nest) {
                const XNestBook& r = buf.root<XNestBook>();
                dig = mix(dig, digest_nest(r));
                levels += r.bids.size() + r.asks.size();
                for (auto* lv : {&r.bids, &r.asks}) for (auto& L : *lv) live_orders += L.count;
                bytes += buf.save_verified<XNestBook>().size();
            } else {
                const XPoolBook& r = buf.root<XPoolBook>();
                const XVector<PoolLevel>* lp[2] = {&r.bids, &r.asks};
                std::uint64_t h = 1469598103934665603ull;
                for (int s = 0; s < 2; ++s)
                    for (long i = long(lp[s]->size()) - 1; i >= 0; --i) {
                        const PoolLevel& L = (*lp[s])[std::size_t(i)];
                        h = mix(mix(mix(h, std::uint64_t(L.price)), L.qty), L.count);
                        for (std::int32_t o = L.head; o >= 0; o = r.pool[std::size_t(o)].next)
                            h = mix(mix(h, r.pool[std::size_t(o)].id), r.pool[std::size_t(o)].qty);
                        live_orders += L.count;
                    }
                dig = mix(dig, h);
                levels += r.bids.size() + r.asks.size();
                bytes += buf.save_verified<XPoolBook>().size();
            }
        }
    } else if (impl == "xo_nest1") {
        // The nested layout, all books in one XBuffer.
        const auto policy = XBuffer::maximum_capacity(std::size_t(256) << 20).with_growth(XGrowPolicy::Automatic);
        XBuffer buf = XBuffer::create<XNestStore>(std::size_t(g.books) * 16 * 1024, policy);
        {
            auto& st = buf.root<XNestStore>();
            st.books.reserve(g.books);
            for (std::uint32_t b = 0; b < g.books; ++b) st.books.emplace_back();
        }
        XNestStore* st = &buf.root<XNestStore>();
        auto apply = [&](const Ev& e) {
            XNestBook& r = st->books[e.book];
            if (e.action == 'A') NestOps::add(r, e);
            else if (e.action == 'R') NestOps::reduce(r, e);
            else NestOps::remove(r, e);
        };
        for (std::size_t i = 0; i < warm; ++i) apply(evs[i]);
        IR_TOGGLE();
        for (std::size_t i = warm; i < evs.size(); ++i) apply(evs[i]);
        IR_TOGGLE();
        for (std::uint32_t b = 0; b < g.books; ++b) {
            const XNestBook& r = st->books[b];
            dig = mix(dig, digest_nest(r));
            levels += r.bids.size() + r.asks.size();
            for (auto* lv : {&r.bids, &r.asks}) for (auto& L : *lv) live_orders += L.count;
        }
        bytes = buf.save_verified<XNestStore>().size();
    } else if (impl == "xo_pool1") {
        // The pool layout, all books in one XBuffer.
        const auto policy = XBuffer::maximum_capacity(std::size_t(256) << 20).with_growth(XGrowPolicy::Automatic);
        XBuffer buf = XBuffer::create<XPoolStore>(std::size_t(g.books) * 64 * 1024, policy);
        {
            auto& st = buf.root<XPoolStore>();
            st.books.reserve(g.books);
            for (std::uint32_t b = 0; b < g.books; ++b) {
                auto& r = st.books.emplace_back();
                r.free_head = -1;
                r.pool.reserve(4u * g.live);
                r.bids.reserve(512);
                r.asks.reserve(512);
            }
        }
        std::vector<std::uint32_t> slot_of(std::size_t(g.events) + 2);
        XPoolStore* st = &buf.root<XPoolStore>();
        auto apply = [&](const Ev& e) {
            XPoolBook& r = st->books[e.book];
            auto& lv = e.side == 0 ? r.bids : r.asks;
            if (e.action == 'A') XPoolOps::add(lv, r.pool, r.free_head, slot_of.data(), e);
            else if (e.action == 'R') XPoolOps::reduce(lv, r.pool, r.free_head, slot_of.data(), e);
            else XPoolOps::remove(lv, r.pool, r.free_head, slot_of.data(), e);
        };
        for (std::size_t i = 0; i < warm; ++i) apply(evs[i]);
        IR_TOGGLE();
        for (std::size_t i = warm; i < evs.size(); ++i) apply(evs[i]);
        IR_TOGGLE();
        for (std::uint32_t b = 0; b < g.books; ++b) {
            const XPoolBook& r = st->books[b];
            const XVector<PoolLevel>* lp[2] = {&r.bids, &r.asks};
            std::uint64_t h = 1469598103934665603ull;
            for (int s = 0; s < 2; ++s)
                for (long i = long(lp[s]->size()) - 1; i >= 0; --i) {
                    const PoolLevel& L = (*lp[s])[std::size_t(i)];
                    h = mix(mix(mix(h, std::uint64_t(L.price)), L.qty), L.count);
                    for (std::int32_t o = L.head; o >= 0; o = r.pool[std::size_t(o)].next)
                        h = mix(mix(h, r.pool[std::size_t(o)].id), r.pool[std::size_t(o)].qty);
                    live_orders += L.count;
                }
            dig = mix(dig, h);
            levels += r.bids.size() + r.asks.size();
        }
        bytes = buf.save_verified<XPoolStore>().size();
    } else {
        std::fprintf(stderr, "unknown impl %s\n", impl.c_str());
        return 2;
    }
    std::printf("{\"access\":\"%s\",\"impl\":\"%s\",\"measured\":%zu,\"adds\":%llu,\"reduces\":%llu,\"deletes\":%llu,"
                "\"live_orders\":%zu,\"levels\":%zu,\"bytes\":%zu,\"digest\":\"%016llx\",\"ns_per_event\":%.2f}\n",
                access.c_str(), impl.c_str(), measured, (unsigned long long)counts[0], (unsigned long long)counts[1],
                (unsigned long long)counts[2], live_orders, levels, bytes, (unsigned long long)dig, bookc_ns() / double(measured));
    return 0;
}
