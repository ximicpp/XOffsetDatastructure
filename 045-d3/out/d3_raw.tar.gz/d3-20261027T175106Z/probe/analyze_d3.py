#!/usr/bin/env python3
# analyze_d3.py RUN_DIR > RESULT.md
# Reads RUN_DIR/NNN_head.jsonl (d3_probe --json, one build: the 3.2 head) and
# writes the d3 tables and verdicts (Markdown).
import json, math, os, re, statistics as st, sys

T975 = {1: 12.706, 2: 4.303, 3: 3.182, 4: 2.776, 5: 2.571, 6: 2.447, 7: 2.365, 8: 2.306, 9: 2.262,
        10: 2.228, 11: 2.201, 12: 2.179, 13: 2.160, 14: 2.145, 15: 2.131, 20: 2.086, 30: 2.042}
def t975(df):
    return T975.get(df) or T975[max(k for k in T975 if k <= df)]

def ci_mean(xs):
    n = len(xs); m = st.mean(xs)
    if n < 2: return m, float('nan'), float('nan')
    h = t975(n - 1) * st.stdev(xs) / math.sqrt(n)
    return m, m - h, m + h

def ci_gm(ratios):
    m, lo, hi = ci_mean([math.log(r) for r in ratios])
    return math.exp(m), math.exp(lo), math.exp(hi)

run = sys.argv[1]
procs = []
for f in sorted(os.listdir(run)):
    m = re.match(r'(\d+)_head\.jsonl$', f)
    if not m: continue
    cells = {}
    for line in open(os.path.join(run, f)):
        r = json.loads(line)
        cells.setdefault((r['cycle'], r['variant']), {})[r['round']] = r['ns']
    procs.append(cells)
if not procs:
    print('no d3 runs found'); sys.exit(1)
cycles = sorted({c for cells in procs for c, _ in cells})
seen = {v for cells in procs for _, v in cells}
BASE = ['xo.reload', 'xo.root', 'xo.first', 'xo.read', 'xo.read.span', 'fb.verify', 'fb.unpack', 'fb.read']
ORDER = BASE + ['t.empty'] + [v + '.t' for v in BASE] + ['xo.query.after.t', 'xo.query.span.after.t', 'fb.query.after.t']
variants = [v for v in ORDER if v in seen] + sorted(seen - set(ORDER))

def med(cells, c, v): return st.median(cells[(c, v)].values())
def per_round(cells, c, f):
    rs = sorted(cells[(c, 't.empty')])
    return [f(lambda v: cells[(c, v)][r]) for r in rs]

out = []
p = out.append
p('# d3：逐次计时下 reload 之后的查询（Mac 微基准）\n')
p(f'进程 {len(procs)} 个，都是 3.2 head；每个进程每格 {len(next(iter(procs[0].values())))} 轮，每轮每格 2048 次读。'
  '`.t` 是 slg_bench 的 timed() 逐次计时；`.span` 是同一个查询改用 std::span 遍历事件（只是探针，不改 harness）。\n')
p('## 每次读的中位数 ns（各进程中位数的均值）\n')
p('| 变体 | ' + ' | '.join(f'cycle {c}' for c in cycles) + ' | 周期平均 |')
p('| --- |' + ' ---: |' * (len(cycles) + 1))
for v in variants:
    vals = [st.mean(med(cells, c, v) for cells in procs) for c in cycles]
    p(f'| {v} | ' + ' | '.join(f'{x:.2f}' for x in vals) + f' | {st.mean(vals):.2f} |')
p('')

p('## 拆分（每个进程先取逐轮值的中位数，再对进程求均值和 95% 区间）\n')
p('| 量 | ' + ' | '.join(f'cycle {c}' for c in cycles) + ' | 周期平均 |')
p('| --- |' + ' ---: |' * (len(cycles) + 1))
def row(name, f, fmt='{:.2f} [{:.2f}, {:.2f}]', gm=False):
    vals = []
    for c in cycles:
        xs = [st.median(per_round(cells, c, f)) for cells in procs]
        vals.append(ci_gm(xs) if gm else ci_mean(xs))
    avg = st.mean(x[0] for x in vals)
    p(f'| {name} | ' + ' | '.join(fmt.format(*x) for x in vals) + (f' | {avg:.3f} |' if gm else f' | {avg:.2f} |'))
    return vals
row('计时本身 = t.empty', lambda g: g('t.empty'))
row('逐次：reload = xo.reload.t − t.empty', lambda g: g('xo.reload.t') - g('t.empty'))
row('逐次：+ root<T>() = xo.root.t − xo.reload.t', lambda g: g('xo.root.t') - g('xo.reload.t'))
row('逐次：+ 首个事件 = xo.first.t − xo.root.t', lambda g: g('xo.first.t') - g('xo.root.t'))
row('逐次：+ 其余查询 = xo.read.t − xo.first.t', lambda g: g('xo.read.t') - g('xo.first.t'))
row('整批：查询 = xo.read − xo.reload', lambda g: g('xo.read') - g('xo.reload'))
row('逐次：只计查询（reload 之后）= xo.query.after.t − t.empty', lambda g: g('xo.query.after.t') - g('t.empty'))
row('逐次：只计 span 查询 = xo.query.span.after.t − t.empty', lambda g: g('xo.query.span.after.t') - g('t.empty'))
row('逐次：只计 FB 查询（decode 之后）= fb.query.after.t − t.empty', lambda g: g('fb.query.after.t') - g('t.empty'))
row('xoffset 多付（同 d2）= (xo.read.t − xo.read) − (fb.read.t − fb.read)',
    lambda g: (g('xo.read.t') - g('xo.read')) - (g('fb.read.t') - g('fb.read')))
row('span 下 xoffset 多付 = (xo.read.span.t − xo.read.span) − (fb.read.t − fb.read)',
    lambda g: (g('xo.read.span.t') - g('xo.read.span')) - (g('fb.read.t') - g('fb.read')))
span_t = row('span 效果，逐次 ns = xo.read.span.t − xo.read.t', lambda g: g('xo.read.span.t') - g('xo.read.t'))
row('span 效果，整批 ns = xo.read.span − xo.read', lambda g: g('xo.read.span') - g('xo.read'))
dfb = row('D÷FB 逐次 = xo.read.t ÷ fb.read.t', lambda g: g('xo.read.t') / g('fb.read.t'), '{:.3f} [{:.3f}, {:.3f}]', True)
dfb_s = row('D÷FB 逐次，span = xo.read.span.t ÷ fb.read.t', lambda g: g('xo.read.span.t') / g('fb.read.t'),
            '{:.3f} [{:.3f}, {:.3f}]', True)
p('')

p('## 判定（预先登记，只报，不是门禁）\n')
avg = st.mean(x[0] for x in span_t)
ok = all(x[2] < 0 for x in span_t) and avg <= -3.5
p(f'- span 遍历（模拟类迭代器）在逐次口径下：{avg:+.2f} ns（周期平均），'
  f'**{"成立：类迭代器能吃掉 d2 多付的 7 ns 的大半，值得给 susu 准备数据包" if ok else "不成立：不足以支持改迭代器类型"}**'
  '（要求：每个周期区间上限 < 0，且周期平均 ≤ −3.5 ns，即 d2 多付 6.9 ns 的一半以上）。')
p(f'- D÷FB 逐次口径：原写法 {st.mean(x[0] for x in dfb):.3f}，span {st.mean(x[0] for x in dfb_s):.3f}（周期平均，只报）。')
print('\n'.join(out))
