## XOffset / baseline, t1 / t0 (default build)

| case | baseline | class | t0 GM | t1 GM | t1 / t0 | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.727 | 0.725 | 0.996 | 0.992–1.001 | 0.994, 0.998 |  |
| hero.mid_insert.ord | std::vector | G9 | 0.763 | 0.755 | 0.990 | 0.985–0.996 | 0.988, 0.992 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.364 | 0.370 | 1.014 | 1.011–1.018 | 1.015, 1.014 | worse |
| map.erase.fresh | std::flat_map | G9 | 0.937 | 0.939 | 1.003 | 1.001–1.005 | 1.003, 1.002 | worse |
| map.find.fresh | std::flat_map | G9 | 0.808 | 0.807 | 0.999 | 0.996–1.001 | 1.000, 0.997 |  |
| map.insert.fresh | std::flat_map | G9 | 0.869 | 0.869 | 1.000 | 0.997–1.002 | 1.007, 0.993 |  |
| nested.build.ord | std | G9 | 0.329 | 0.324 | 0.983 | 0.979–0.988 | 0.997, 0.969 |  |
| reset | std | G9 | 0.247 | 0.252 | 1.020 | 1.009–1.032 | 0.948, 1.099 | worse? |
| set.erase.fresh | std::flat_set | G9 | 1.088 | 1.090 | 1.002 | 0.999–1.005 | 1.003, 1.001 |  |
| set.find.fresh | std::flat_set | G9 | 0.755 | 0.755 | 1.000 | 0.997–1.003 | 1.000, 1.000 |  |
| set.insert.fresh | std::flat_set | G9 | 1.014 | 0.994 | 0.980 | 0.978–0.982 | 0.984, 0.976 |  |
| str.append | std::string | G9 | 0.344 | 0.417 | 1.211 | 1.206–1.216 | 1.200, 1.222 | worse |
| str.assign_long | std::string | G9 | 0.865 | 0.803 | 0.929 | 0.925–0.932 | 0.927, 0.930 |  |
| str.assign_short.view | std::string | G9 | 0.343 | 0.344 | 1.004 | 1.000–1.008 | 1.003, 1.006 | worse |
| vec.iterate | std::vector | G9 | 1.001 | 1.000 | 0.999 | 0.997–1.001 | 1.000, 0.998 |  |
| vec.mid_erase | std::vector | G9 | 1.012 | 1.012 | 1.000 | 0.996–1.004 | 0.998, 1.002 |  |
| vec.mid_insert | std::vector | G9 | 0.984 | 0.960 | 0.976 | 0.971–0.980 | 0.972, 0.979 |  |
| vec.push_back | std::vector | G9 | 1.118 | 1.127 | 1.008 | 1.004–1.012 | 1.008, 1.008 | worse |
| vec.push_back_grow | std::vector | G9 | 0.778 | 0.766 | 0.984 | 0.979–0.989 | 0.979, 0.989 |  |
| hero.mid_erase.plain | std::vector | report | 4.072 | 4.000 | 0.982 | 0.978–0.987 | 0.978, 0.986 |  |
| hero.mid_insert.plain | std::vector | report | 4.207 | 4.201 | 0.998 | 0.994–1.003 | 0.995, 1.002 |  |
| hero.push_back_grow.plain | std::vector | report | 0.403 | 0.410 | 1.017 | 1.013–1.021 | 1.012, 1.023 | worse |
| map.erase.fresh | std::map | report | 0.742 | 0.739 | 0.996 | 0.993–0.999 | 0.993, 0.999 |  |
| map.erase.reused | std::flat_map | report | 1.084 | 1.085 | 1.000 | 0.998–1.003 | 1.002, 0.999 |  |
| map.erase.reused | std::map | report | 1.655 | 1.661 | 1.003 | 0.997–1.010 | 0.994, 1.013 |  |
| map.find.fresh | std::map | report | 0.325 | 0.320 | 0.985 | 0.981–0.990 | 0.987, 0.983 |  |
| map.find.reused | std::flat_map | report | 0.808 | 0.808 | 1.000 | 0.997–1.002 | 1.001, 0.998 |  |
| map.find.reused | std::map | report | 0.743 | 0.679 | 0.913 | 0.909–0.918 | 0.877, 0.951 |  |
| map.insert.fresh | std::map | report | 0.744 | 0.748 | 1.006 | 1.003–1.009 | 1.008, 1.004 | worse |
| map.insert.reused | std::flat_map | report | 1.006 | 1.005 | 0.999 | 0.995–1.003 | 1.005, 0.993 |  |
| map.insert.reused | std::map | report | 1.805 | 1.796 | 0.995 | 0.988–1.002 | 1.015, 0.975 |  |
| nested.build.plain | std | report | 0.335 | 0.334 | 0.997 | 0.995–1.000 | 0.999, 0.996 |  |
| set.erase.fresh | std::set | report | 0.671 | 0.670 | 0.998 | 0.994–1.002 | 0.990, 1.006 |  |
| set.erase.reused | std::flat_set | report | 1.139 | 1.136 | 0.998 | 0.994–1.001 | 0.999, 0.996 |  |
| set.erase.reused | std::set | report | 1.342 | 1.345 | 1.002 | 0.995–1.010 | 0.991, 1.014 |  |
| set.find.fresh | std::set | report | 0.300 | 0.301 | 1.002 | 0.998–1.007 | 1.002, 1.003 |  |
| set.find.reused | std::flat_set | report | 0.755 | 0.755 | 1.001 | 0.999–1.003 | 1.001, 1.001 |  |
| set.find.reused | std::set | report | 0.662 | 0.786 | 1.187 | 1.181–1.193 | 1.177, 1.196 | worse |
| set.insert.fresh | std::set | report | 0.666 | 0.656 | 0.985 | 0.982–0.987 | 0.975, 0.995 |  |
| set.insert.reused | std::flat_set | report | 1.084 | 1.082 | 0.999 | 0.996–1.002 | 1.002, 0.996 |  |
| set.insert.reused | std::set | report | 1.455 | 1.411 | 0.970 | 0.962–0.978 | 0.978, 0.963 |  |
| str.assign_short | std::string | report | 1.768 | 1.769 | 1.000 | 0.997–1.004 | 0.998, 1.003 |  |
| str.assign_short.copy | std::string | report | 1.148 | 1.149 | 1.001 | 0.998–1.004 | 1.000, 1.002 |  |

worse at t1 than t0 (by the rule): hero.push_back_grow.ord / std::vector (G9) 1.014; map.erase.fresh / std::flat_map (G9) 1.003; str.append / std::string (G9) 1.211; str.assign_short.view / std::string (G9) 1.004; vec.push_back / std::vector (G9) 1.008; hero.push_back_grow.plain / std::vector (report) 1.017; map.insert.fresh / std::map (report) 1.006; set.find.reused / std::set (report) 1.187

above 1.01 but not worse by the rule: reset / std (G9) 1.020

## XOffset ns/op alone, t1 / t0 (default build)

| case | t0 ns/op | t1 ns/op | t1 / t0 | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 163.7 | 165 | 1.008 | 1.004–1.011 | 0.998, 1.017 |  |
| hero.mid_erase.plain | 912.3 | 910 | 0.997 | 0.994–1.001 | 0.986, 1.009 |  |
| hero.mid_insert.ord | 228.9 | 229.4 | 1.002 | 0.999–1.006 | 0.988, 1.017 |  |
| hero.mid_insert.plain | 1256 | 1273 | 1.014 | 1.010–1.018 | 1.002, 1.026 | worse |
| hero.push_back_grow.ord | 31.81 | 32.4 | 1.019 | 1.015–1.022 | 1.007, 1.031 | worse |
| hero.push_back_grow.plain | 35.12 | 36.06 | 1.027 | 1.023–1.031 | 1.013, 1.040 | worse |
| map.erase.fresh | 33.03 | 33.03 | 1.000 | 0.998–1.002 | 1.002, 0.998 |  |
| map.erase.reused | 29.75 | 29.85 | 1.003 | 1.001–1.005 | 1.003, 1.003 | worse |
| map.find.fresh | 5.292 | 5.284 | 0.998 | 0.996–1.001 | 1.000, 0.997 |  |
| map.find.reused | 5.301 | 5.307 | 1.001 | 0.999–1.003 | 1.001, 1.002 |  |
| map.insert.fresh | 32.33 | 32.25 | 0.998 | 0.996–1.000 | 0.998, 0.997 |  |
| map.insert.reused | 29.65 | 29.81 | 1.005 | 1.001–1.010 | 1.015, 0.995 |  |
| nested.build.ord | 273.4 | 270.4 | 0.989 | 0.985–0.993 | 0.985, 0.993 |  |
| nested.build.plain | 279.3 | 277.7 | 0.994 | 0.992–0.996 | 0.993, 0.995 |  |
| reset | 30.55 | 30.57 | 1.000 | 0.995–1.006 | 1.003, 0.998 |  |
| set.erase.fresh | 29.83 | 29.79 | 0.999 | 0.996–1.001 | 1.000, 0.998 |  |
| set.erase.reused | 23.21 | 23.26 | 1.002 | 0.999–1.006 | 1.001, 1.003 |  |
| set.find.fresh | 4.886 | 4.887 | 1.000 | 0.998–1.002 | 0.999, 1.002 |  |
| set.find.reused | 4.88 | 4.886 | 1.001 | 1.000–1.003 | 0.999, 1.003 |  |
| set.insert.fresh | 29.35 | 28.9 | 0.985 | 0.983–0.986 | 0.985, 0.984 |  |
| set.insert.reused | 23.02 | 22.86 | 0.993 | 0.992–0.995 | 0.995, 0.991 |  |
| str.append | 1.519 | 1.559 | 1.026 | 1.022–1.030 | 1.019, 1.034 | worse |
| str.assign_long | 2.937 | 2.766 | 0.942 | 0.938–0.946 | 0.931, 0.953 |  |
| str.assign_short | 0.9286 | 0.9468 | 1.020 | 1.015–1.024 | 1.010, 1.029 | worse |
| str.assign_short.copy | 0.6186 | 0.631 | 1.020 | 1.015–1.025 | 1.013, 1.027 | worse |
| str.assign_short.view | 0.934 | 0.9578 | 1.026 | 1.020–1.031 | 1.016, 1.035 | worse |
| vec.iterate | 0.03317 | 0.03356 | 1.012 | 1.008–1.015 | 1.001, 1.022 | worse |
| vec.mid_erase | 40.08 | 40.58 | 1.012 | 1.008–1.017 | 0.999, 1.026 | worse? |
| vec.mid_insert | 40.58 | 40.82 | 1.006 | 1.002–1.010 | 0.994, 1.018 |  |
| vec.push_back | 0.2944 | 0.2947 | 1.001 | 0.989–1.014 | 1.020, 0.982 |  |
| vec.push_back_grow | 0.2813 | 0.2786 | 0.990 | 0.983–0.998 | 0.984, 0.997 |  |

XOffset slower at t1 than t0 (worse by the rule): hero.mid_insert.plain 1.014; hero.push_back_grow.ord 1.019; hero.push_back_grow.plain 1.027; map.erase.reused 1.003; str.append 1.026; str.assign_short 1.020; str.assign_short.copy 1.020; str.assign_short.view 1.026; vec.iterate 1.012

## XOffset / baseline, t1a / t0a (functions aligned to 64 B, layout check)

| case | baseline | class | t0a GM | t1a GM | t1a / t0a | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.729 | 0.730 | 1.000 | 0.998–1.003 | 0.999, 1.002 |  |
| hero.mid_insert.ord | std::vector | G9 | 0.759 | 0.762 | 1.003 | 0.999–1.008 | 0.993, 1.014 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.363 | 0.360 | 0.994 | 0.992–0.997 | 0.995, 0.994 |  |
| map.erase.fresh | std::flat_map | G9 | 0.945 | 0.940 | 0.995 | 0.991–0.999 | 0.996, 0.994 |  |
| map.find.fresh | std::flat_map | G9 | 0.808 | 0.808 | 1.001 | 0.996–1.006 | 1.000, 1.002 |  |
| map.insert.fresh | std::flat_map | G9 | 0.867 | 0.868 | 1.002 | 0.997–1.006 | 1.005, 0.999 |  |
| nested.build.ord | std | G9 | 0.321 | 0.316 | 0.983 | 0.978–0.989 | 0.976, 0.991 |  |
| reset | std | G9 | 0.251 | 0.252 | 1.007 | 1.001–1.014 | 0.987, 1.027 |  |
| set.erase.fresh | std::flat_set | G9 | 1.092 | 1.093 | 1.001 | 0.996–1.006 | 1.000, 1.002 |  |
| set.find.fresh | std::flat_set | G9 | 0.755 | 0.755 | 1.001 | 0.995–1.006 | 1.003, 0.998 |  |
| set.insert.fresh | std::flat_set | G9 | 1.000 | 0.999 | 0.999 | 0.997–1.001 | 1.000, 0.998 |  |
| str.append | std::string | G9 | 0.426 | 0.436 | 1.024 | 1.016–1.031 | 1.004, 1.044 | worse |
| str.assign_long | std::string | G9 | 0.867 | 0.865 | 0.997 | 0.995–1.000 | 0.994, 1.001 |  |
| str.assign_short.view | std::string | G9 | 0.342 | 0.342 | 0.999 | 0.997–1.002 | 0.998, 1.001 |  |
| vec.iterate | std::vector | G9 | 0.999 | 1.001 | 1.002 | 0.996–1.007 | 1.000, 1.004 |  |
| vec.mid_erase | std::vector | G9 | 1.019 | 1.018 | 0.999 | 0.997–1.001 | 1.005, 0.993 |  |
| vec.mid_insert | std::vector | G9 | 0.993 | 0.959 | 0.966 | 0.965–0.968 | 0.966, 0.967 |  |
| vec.push_back | std::vector | G9 | 1.120 | 1.117 | 0.997 | 0.993–1.002 | 1.005, 0.990 |  |
| vec.push_back_grow | std::vector | G9 | 0.763 | 0.772 | 1.011 | 1.006–1.017 | 0.999, 1.024 | worse? |
| hero.mid_erase.plain | std::vector | report | 4.068 | 4.062 | 0.999 | 0.996–1.001 | 0.994, 1.003 |  |
| hero.mid_insert.plain | std::vector | report | 4.167 | 4.174 | 1.002 | 0.998–1.006 | 1.005, 0.998 |  |
| hero.push_back_grow.plain | std::vector | report | 0.403 | 0.403 | 1.000 | 0.998–1.003 | 1.007, 0.994 |  |
| map.erase.fresh | std::map | report | 0.745 | 0.737 | 0.989 | 0.985–0.994 | 0.991, 0.987 |  |
| map.erase.reused | std::flat_map | report | 1.082 | 1.085 | 1.003 | 0.998–1.008 | 1.001, 1.005 |  |
| map.erase.reused | std::map | report | 1.615 | 1.663 | 1.030 | 1.022–1.038 | 1.035, 1.025 | worse |
| map.find.fresh | std::map | report | 0.323 | 0.324 | 1.003 | 0.998–1.009 | 1.001, 1.005 |  |
| map.find.reused | std::flat_map | report | 0.808 | 0.804 | 0.996 | 0.992–0.999 | 0.999, 0.992 |  |
| map.find.reused | std::map | report | 0.716 | 0.718 | 1.002 | 0.996–1.007 | 1.000, 1.003 |  |
| map.insert.fresh | std::map | report | 0.739 | 0.741 | 1.002 | 0.997–1.007 | 1.009, 0.995 |  |
| map.insert.reused | std::flat_map | report | 1.004 | 1.006 | 1.002 | 0.998–1.006 | 1.005, 0.999 |  |
| map.insert.reused | std::map | report | 1.827 | 1.762 | 0.965 | 0.959–0.970 | 0.943, 0.987 |  |
| nested.build.plain | std | report | 0.330 | 0.330 | 0.998 | 0.993–1.003 | 0.992, 1.005 |  |
| set.erase.fresh | std::set | report | 0.676 | 0.672 | 0.995 | 0.990–1.001 | 0.986, 1.004 |  |
| set.erase.reused | std::flat_set | report | 1.144 | 1.139 | 0.996 | 0.991–1.001 | 0.989, 1.003 |  |
| set.erase.reused | std::set | report | 1.325 | 1.359 | 1.025 | 1.015–1.036 | 1.013, 1.038 | worse |
| set.find.fresh | std::set | report | 0.300 | 0.300 | 1.001 | 0.995–1.007 | 1.003, 0.998 |  |
| set.find.reused | std::flat_set | report | 0.756 | 0.755 | 0.998 | 0.992–1.003 | 0.999, 0.997 |  |
| set.find.reused | std::set | report | 0.684 | 0.668 | 0.976 | 0.969–0.984 | 0.993, 0.959 |  |
| set.insert.fresh | std::set | report | 0.648 | 0.651 | 1.005 | 1.001–1.008 | 0.992, 1.018 |  |
| set.insert.reused | std::flat_set | report | 1.080 | 1.079 | 0.999 | 0.993–1.004 | 1.001, 0.997 |  |
| set.insert.reused | std::set | report | 1.422 | 1.363 | 0.959 | 0.948–0.969 | 0.932, 0.986 |  |
| str.assign_short | std::string | report | 1.760 | 1.765 | 1.003 | 0.996–1.011 | 0.997, 1.010 |  |
| str.assign_short.copy | std::string | report | 1.150 | 1.154 | 1.003 | 0.999–1.007 | 1.002, 1.004 |  |

worse at t1a than t0a (by the rule): str.append / std::string (G9) 1.024; map.erase.reused / std::map (report) 1.030; set.erase.reused / std::set (report) 1.025

above 1.01 but not worse by the rule: vec.push_back_grow / std::vector (G9) 1.011

## XOffset ns/op alone, t1a / t0a (functions aligned to 64 B, layout check)

| case | t0a ns/op | t1a ns/op | t1a / t0a | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 164.5 | 164.5 | 1.000 | 0.998–1.003 | 1.001, 0.999 |  |
| hero.mid_erase.plain | 911.4 | 910.6 | 0.999 | 0.996–1.002 | 0.999, 0.999 |  |
| hero.mid_insert.ord | 229.2 | 229.3 | 1.000 | 0.997–1.003 | 0.999, 1.002 |  |
| hero.mid_insert.plain | 1249 | 1249 | 1.000 | 0.997–1.002 | 1.006, 0.993 |  |
| hero.push_back_grow.ord | 31.86 | 31.63 | 0.993 | 0.990–0.995 | 0.998, 0.988 |  |
| hero.push_back_grow.plain | 35.35 | 35.25 | 0.997 | 0.995–0.999 | 1.008, 0.986 |  |
| map.erase.fresh | 32.99 | 33.25 | 1.008 | 1.005–1.011 | 1.001, 1.015 | worse |
| map.erase.reused | 29.63 | 30.18 | 1.018 | 1.014–1.023 | 1.003, 1.034 | worse |
| map.find.fresh | 5.289 | 5.345 | 1.011 | 1.006–1.015 | 1.000, 1.021 | worse? |
| map.find.reused | 5.303 | 5.362 | 1.011 | 1.008–1.014 | 0.999, 1.024 | worse? |
| map.insert.fresh | 32.36 | 32.46 | 1.003 | 1.000–1.007 | 0.999, 1.008 |  |
| map.insert.reused | 29.54 | 29.74 | 1.007 | 1.003–1.010 | 1.001, 1.013 | worse |
| nested.build.ord | 267.7 | 271.1 | 1.012 | 1.008–1.017 | 0.996, 1.029 | worse? |
| nested.build.plain | 275.7 | 278 | 1.009 | 1.004–1.013 | 0.994, 1.024 |  |
| reset | 29.56 | 30.33 | 1.026 | 1.020–1.032 | 0.985, 1.069 | worse? |
| set.erase.fresh | 29.75 | 30.05 | 1.010 | 1.005–1.015 | 1.000, 1.021 | worse? |
| set.erase.reused | 23.34 | 23.51 | 1.007 | 1.002–1.013 | 0.995, 1.019 |  |
| set.find.fresh | 4.883 | 4.958 | 1.015 | 1.009–1.022 | 1.001, 1.030 | worse |
| set.find.reused | 4.934 | 4.926 | 0.998 | 0.990–1.006 | 0.999, 0.998 |  |
| set.insert.fresh | 28.9 | 29.29 | 1.013 | 1.010–1.017 | 0.999, 1.028 | worse? |
| set.insert.reused | 22.83 | 23.19 | 1.015 | 1.010–1.021 | 1.000, 1.031 | worse |
| str.append | 1.576 | 1.573 | 0.998 | 0.991–1.006 | 0.989, 1.008 |  |
| str.assign_long | 2.949 | 2.945 | 0.999 | 0.996–1.001 | 1.002, 0.996 |  |
| str.assign_short | 0.9412 | 0.9361 | 0.995 | 0.990–1.000 | 1.004, 0.985 |  |
| str.assign_short.copy | 0.6253 | 0.6269 | 1.003 | 0.997–1.009 | 1.011, 0.994 |  |
| str.assign_short.view | 0.9432 | 0.9371 | 0.994 | 0.990–0.997 | 0.998, 0.989 |  |
| vec.iterate | 0.03356 | 0.03341 | 0.996 | 0.991–1.000 | 1.000, 0.991 |  |
| vec.mid_erase | 40.46 | 40.54 | 1.002 | 1.001–1.003 | 1.007, 0.997 |  |
| vec.mid_insert | 40.51 | 40.63 | 1.003 | 1.002–1.004 | 1.003, 1.003 | worse |
| vec.push_back | 0.2764 | 0.2722 | 0.985 | 0.980–0.989 | 0.989, 0.980 |  |
| vec.push_back_grow | 0.2721 | 0.2715 | 0.998 | 0.993–1.002 | 0.996, 0.999 |  |

XOffset slower at t1a than t0a (worse by the rule): map.erase.fresh 1.008; map.erase.reused 1.018; map.insert.reused 1.007; set.find.fresh 1.015; set.insert.reused 1.015; vec.mid_insert 1.003

## layout check: what is worse at t1 in the default build, in the aligned build

| comparison | t1 / t0 | t1a / t0a | 95% interval (aligned) | aligned |
| --- | ---: | ---: | --- | --- |
| hero.mid_insert.plain (XOffset ns/op) | 1.014 | 1.000 | 0.997–1.002 | not worse |
| hero.push_back_grow.ord (XOffset ns/op) | 1.019 | 0.993 | 0.990–0.995 | not worse |
| hero.push_back_grow.plain (XOffset ns/op) | 1.027 | 0.997 | 0.995–0.999 | not worse |
| map.erase.reused (XOffset ns/op) | 1.003 | 1.018 | 1.014–1.023 | still worse |
| str.append (XOffset ns/op) | 1.026 | 0.998 | 0.991–1.006 | not worse |
| str.assign_short (XOffset ns/op) | 1.020 | 0.995 | 0.990–1.000 | not worse |
| str.assign_short.copy (XOffset ns/op) | 1.020 | 1.003 | 0.997–1.009 | not worse |
| str.assign_short.view (XOffset ns/op) | 1.026 | 0.994 | 0.990–0.997 | not worse |
| vec.iterate (XOffset ns/op) | 1.012 | 0.996 | 0.991–1.000 | not worse |
| hero.push_back_grow.ord / std::vector (G9) | 1.014 | 0.994 | 0.992–0.997 | not worse |
| hero.push_back_grow.plain / std::vector (report) | 1.017 | 1.000 | 0.998–1.003 | not worse |
| map.erase.fresh / std::flat_map (G9) | 1.003 | 0.995 | 0.991–0.999 | not worse |
| map.insert.fresh / std::map (report) | 1.006 | 1.002 | 0.997–1.007 | not worse |
| set.find.reused / std::set (report) | 1.187 | 0.976 | 0.969–0.984 | not worse |
| str.append / std::string (G9) | 1.211 | 1.024 | 1.016–1.031 | still worse |
| str.assign_short.view / std::string (G9) | 1.004 | 0.999 | 0.997–1.002 | not worse |
| vec.push_back / std::vector (G9) | 1.008 | 0.997 | 0.993–1.002 | not worse |
