## XOffset / baseline, t1 / t0 (default build)

| case | baseline | class | t0 GM | t1 GM | t1 / t0 | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.719 | 0.713 | 0.991 | 0.988–0.993 | 1.003, 0.979 |  |
| hero.mid_insert.ord | std::vector | G9 | 0.754 | 0.751 | 0.996 | 0.992–0.999 | 1.001, 0.990 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.370 | 0.364 | 0.984 | 0.980–0.988 | 0.999, 0.969 |  |
| map.erase.fresh | std::flat_map | G9 | 0.936 | 0.936 | 1.000 | 0.998–1.002 | 1.001, 0.998 |  |
| map.find.fresh | std::flat_map | G9 | 0.786 | 0.783 | 0.997 | 0.994–0.999 | 0.996, 0.998 |  |
| map.insert.fresh | std::flat_map | G9 | 0.877 | 0.873 | 0.995 | 0.993–0.998 | 0.994, 0.997 |  |
| nested.build.ord | std | G9 | 0.337 | 0.335 | 0.996 | 0.992–1.000 | 0.981, 1.012 |  |
| reset | std | G9 | 0.182 | 0.182 | 0.999 | 0.992–1.005 | 0.995, 1.003 |  |
| set.erase.fresh | std::flat_set | G9 | 1.093 | 1.090 | 0.998 | 0.995–1.000 | 0.996, 1.000 |  |
| set.find.fresh | std::flat_set | G9 | 0.754 | 0.755 | 1.002 | 0.999–1.004 | 1.001, 1.002 |  |
| set.insert.fresh | std::flat_set | G9 | 1.001 | 1.003 | 1.002 | 0.999–1.004 | 1.001, 1.003 |  |
| str.append | std::string | G9 | 0.472 | 0.422 | 0.895 | 0.891–0.899 | 0.896, 0.893 |  |
| str.assign_long | std::string | G9 | 0.798 | 0.796 | 0.997 | 0.995–0.999 | 0.997, 0.996 |  |
| str.assign_short.view | std::string | G9 | 0.341 | 0.342 | 1.005 | 1.003–1.008 | 1.011, 1.000 |  |
| vec.iterate | std::vector | G9 | 1.020 | 1.000 | 0.980 | 0.977–0.984 | 0.981, 0.980 |  |
| vec.mid_erase | std::vector | G9 | 1.015 | 1.014 | 0.998 | 0.996–1.000 | 0.994, 1.003 |  |
| vec.mid_insert | std::vector | G9 | 0.997 | 0.995 | 0.998 | 0.996–1.001 | 1.000, 0.997 |  |
| vec.push_back | std::vector | G9 | 1.099 | 1.120 | 1.019 | 1.012–1.026 | 0.990, 1.049 | worse? |
| vec.push_back_grow | std::vector | G9 | 0.766 | 0.766 | 0.999 | 0.993–1.005 | 1.003, 0.995 |  |
| hero.mid_erase.plain | std::vector | report | 4.014 | 3.981 | 0.992 | 0.988–0.996 | 1.007, 0.976 |  |
| hero.mid_insert.plain | std::vector | report | 4.227 | 4.201 | 0.994 | 0.991–0.997 | 0.996, 0.992 |  |
| hero.push_back_grow.plain | std::vector | report | 0.410 | 0.406 | 0.989 | 0.985–0.992 | 1.007, 0.971 |  |
| map.erase.fresh | std::map | report | 0.697 | 0.696 | 0.998 | 0.995–1.001 | 0.998, 0.999 |  |
| map.erase.reused | std::flat_map | report | 1.086 | 1.080 | 0.994 | 0.992–0.997 | 0.993, 0.996 |  |
| map.erase.reused | std::map | report | 1.353 | 1.326 | 0.981 | 0.975–0.987 | 0.968, 0.994 |  |
| map.find.fresh | std::map | report | 0.313 | 0.313 | 0.998 | 0.994–1.002 | 0.996, 1.001 |  |
| map.find.reused | std::flat_map | report | 0.786 | 0.786 | 1.000 | 0.997–1.003 | 1.002, 0.997 |  |
| map.find.reused | std::map | report | 0.693 | 0.700 | 1.010 | 1.006–1.013 | 1.016, 1.004 | worse |
| map.insert.fresh | std::map | report | 0.729 | 0.739 | 1.013 | 1.010–1.016 | 1.010, 1.017 | worse |
| map.insert.reused | std::flat_map | report | 1.007 | 1.011 | 1.004 | 1.003–1.006 | 1.003, 1.006 | worse |
| map.insert.reused | std::map | report | 1.703 | 1.690 | 0.992 | 0.989–0.996 | 0.995, 0.990 |  |
| nested.build.plain | std | report | 0.346 | 0.348 | 1.003 | 0.999–1.008 | 0.997, 1.010 |  |
| set.erase.fresh | std::set | report | 0.634 | 0.630 | 0.994 | 0.990–0.998 | 0.993, 0.995 |  |
| set.erase.reused | std::flat_set | report | 1.146 | 1.150 | 1.003 | 1.000–1.006 | 1.004, 1.003 | worse |
| set.erase.reused | std::set | report | 1.168 | 1.118 | 0.958 | 0.950–0.965 | 0.959, 0.957 |  |
| set.find.fresh | std::set | report | 0.300 | 0.301 | 1.004 | 1.000–1.009 | 1.002, 1.006 |  |
| set.find.reused | std::flat_set | report | 0.755 | 0.756 | 1.002 | 1.000–1.005 | 1.003, 1.002 |  |
| set.find.reused | std::set | report | 0.762 | 0.741 | 0.972 | 0.970–0.975 | 0.963, 0.981 |  |
| set.insert.fresh | std::set | report | 0.638 | 0.634 | 0.994 | 0.991–0.997 | 1.003, 0.985 |  |
| set.insert.reused | std::flat_set | report | 1.085 | 1.084 | 0.999 | 0.997–1.002 | 1.003, 0.996 |  |
| set.insert.reused | std::set | report | 1.294 | 1.308 | 1.011 | 1.002–1.019 | 1.022, 0.999 | worse? |
| str.assign_short | std::string | report | 1.834 | 1.835 | 1.001 | 0.999–1.002 | 1.001, 1.000 |  |
| str.assign_short.copy | std::string | report | 1.188 | 1.190 | 1.002 | 1.000–1.004 | 1.002, 1.001 |  |

worse at t1 than t0 (by the rule): map.find.reused / std::map (report) 1.010; map.insert.fresh / std::map (report) 1.013; map.insert.reused / std::flat_map (report) 1.004; set.erase.reused / std::flat_set (report) 1.003

above 1.01 but not worse by the rule: vec.push_back / std::vector (G9) 1.019; set.insert.reused / std::set (report) 1.011

## XOffset ns/op alone, t1 / t0 (default build)

| case | t0 ns/op | t1 ns/op | t1 / t0 | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 164.7 | 164.1 | 0.996 | 0.995–0.998 | 0.998, 0.994 |  |
| hero.mid_erase.plain | 912.1 | 910.8 | 0.999 | 0.996–1.001 | 1.004, 0.993 |  |
| hero.mid_insert.ord | 229.1 | 227.8 | 0.994 | 0.992–0.996 | 0.999, 0.989 |  |
| hero.mid_insert.plain | 1269 | 1270 | 1.000 | 0.999–1.002 | 1.002, 0.999 |  |
| hero.push_back_grow.ord | 33.13 | 33.06 | 0.998 | 0.996–1.000 | 0.997, 0.999 |  |
| hero.push_back_grow.plain | 36.53 | 36.57 | 1.001 | 0.999–1.003 | 0.998, 1.005 |  |
| map.erase.fresh | 33.04 | 32.99 | 0.999 | 0.997–1.000 | 0.999, 0.998 |  |
| map.erase.reused | 29.74 | 29.65 | 0.997 | 0.995–0.999 | 1.000, 0.994 |  |
| map.find.fresh | 5.143 | 5.131 | 0.998 | 0.996–1.000 | 0.996, 0.999 |  |
| map.find.reused | 5.171 | 5.162 | 0.998 | 0.996–1.001 | 1.000, 0.997 |  |
| map.insert.fresh | 32.26 | 32.26 | 1.000 | 0.998–1.002 | 1.000, 1.000 |  |
| map.insert.reused | 29.54 | 29.55 | 1.000 | 0.999–1.002 | 1.001, 1.000 |  |
| nested.build.ord | 290.9 | 291.1 | 1.001 | 0.998–1.004 | 0.996, 1.005 |  |
| nested.build.plain | 296.1 | 296.7 | 1.002 | 0.998–1.005 | 0.999, 1.005 |  |
| reset | 30.17 | 30.82 | 1.022 | 1.018–1.025 | 1.028, 1.015 | worse |
| set.erase.fresh | 29.82 | 29.77 | 0.998 | 0.996–1.001 | 0.999, 0.997 |  |
| set.erase.reused | 23.25 | 23.34 | 1.004 | 1.001–1.007 | 1.002, 1.006 | worse |
| set.find.fresh | 4.879 | 4.881 | 1.000 | 0.999–1.001 | 1.000, 1.001 |  |
| set.find.reused | 4.882 | 4.883 | 1.000 | 0.998–1.002 | 1.001, 0.999 |  |
| set.insert.fresh | 28.84 | 28.88 | 1.001 | 0.999–1.004 | 1.001, 1.002 |  |
| set.insert.reused | 22.84 | 22.82 | 0.999 | 0.997–1.001 | 1.003, 0.995 |  |
| str.append | 1.716 | 1.542 | 0.899 | 0.895–0.902 | 0.906, 0.891 |  |
| str.assign_long | 2.716 | 2.713 | 0.999 | 0.998–1.000 | 1.000, 0.998 |  |
| str.assign_short | 0.9297 | 0.9427 | 1.014 | 1.010–1.018 | 1.022, 1.006 | worse |
| str.assign_short.copy | 0.6196 | 0.6214 | 1.003 | 0.998–1.008 | 1.011, 0.995 |  |
| str.assign_short.view | 0.9351 | 0.9424 | 1.008 | 1.005–1.011 | 1.014, 1.001 | worse |
| vec.iterate | 0.03387 | 0.03382 | 0.998 | 0.994–1.003 | 1.001, 0.996 |  |
| vec.mid_erase | 40.52 | 40.37 | 0.996 | 0.995–0.998 | 0.995, 0.997 |  |
| vec.mid_insert | 41.2 | 40.87 | 0.992 | 0.989–0.995 | 1.000, 0.984 |  |
| vec.push_back | 0.2927 | 0.289 | 0.987 | 0.976–0.999 | 0.992, 0.982 |  |
| vec.push_back_grow | 0.282 | 0.282 | 1.000 | 0.992–1.008 | 1.001, 0.999 |  |

XOffset slower at t1 than t0 (worse by the rule): reset 1.022; set.erase.reused 1.004; str.assign_short 1.014; str.assign_short.view 1.008

## XOffset / baseline, t1a / t0a (functions aligned to 64 B, layout check)

| case | baseline | class | t0a GM | t1a GM | t1a / t0a | 95% interval | halves | note |
| --- | --- | --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | std::vector | G9 | 0.712 | 0.714 | 1.003 | 1.000–1.005 | 1.010, 0.996 |  |
| hero.mid_insert.ord | std::vector | G9 | 0.758 | 0.756 | 0.998 | 0.994–1.001 | 1.000, 0.996 |  |
| hero.push_back_grow.ord | std::vector | G9 | 0.369 | 0.371 | 1.006 | 1.002–1.009 | 1.020, 0.991 |  |
| map.erase.fresh | std::flat_map | G9 | 0.941 | 0.945 | 1.004 | 1.001–1.008 | 1.001, 1.008 | worse |
| map.find.fresh | std::flat_map | G9 | 0.786 | 0.786 | 1.000 | 0.998–1.002 | 1.000, 1.000 |  |
| map.insert.fresh | std::flat_map | G9 | 0.873 | 0.874 | 1.001 | 0.998–1.003 | 1.000, 1.002 |  |
| nested.build.ord | std | G9 | 0.340 | 0.333 | 0.980 | 0.976–0.984 | 0.984, 0.976 |  |
| reset | std | G9 | 0.181 | 0.175 | 0.967 | 0.959–0.976 | 0.997, 0.938 |  |
| set.erase.fresh | std::flat_set | G9 | 1.090 | 1.090 | 1.000 | 0.998–1.003 | 1.005, 0.995 |  |
| set.find.fresh | std::flat_set | G9 | 0.755 | 0.755 | 1.000 | 0.999–1.002 | 0.999, 1.002 |  |
| set.insert.fresh | std::flat_set | G9 | 1.000 | 1.001 | 1.002 | 1.000–1.004 | 1.002, 1.001 |  |
| str.append | std::string | G9 | 0.426 | 0.429 | 1.008 | 1.002–1.013 | 1.017, 0.998 |  |
| str.assign_long | std::string | G9 | 0.862 | 0.863 | 1.001 | 0.999–1.003 | 1.003, 1.000 |  |
| str.assign_short.view | std::string | G9 | 0.342 | 0.343 | 1.002 | 0.999–1.004 | 1.000, 1.003 |  |
| vec.iterate | std::vector | G9 | 1.035 | 1.035 | 1.000 | 0.997–1.003 | 1.000, 1.000 |  |
| vec.mid_erase | std::vector | G9 | 1.013 | 1.017 | 1.004 | 1.002–1.007 | 1.006, 1.003 | worse |
| vec.mid_insert | std::vector | G9 | 0.992 | 0.990 | 0.999 | 0.996–1.002 | 1.002, 0.995 |  |
| vec.push_back | std::vector | G9 | 1.103 | 1.115 | 1.011 | 1.004–1.018 | 1.026, 0.997 | worse? |
| vec.push_back_grow | std::vector | G9 | 0.769 | 0.775 | 1.007 | 1.003–1.011 | 1.016, 0.998 |  |
| hero.mid_erase.plain | std::vector | report | 3.987 | 4.004 | 1.004 | 1.001–1.008 | 1.009, 1.000 |  |
| hero.mid_insert.plain | std::vector | report | 4.188 | 4.180 | 0.998 | 0.995–1.001 | 1.003, 0.993 |  |
| hero.push_back_grow.plain | std::vector | report | 0.407 | 0.410 | 1.007 | 1.004–1.010 | 1.016, 0.998 |  |
| map.erase.fresh | std::map | report | 0.698 | 0.692 | 0.992 | 0.989–0.996 | 0.994, 0.991 |  |
| map.erase.reused | std::flat_map | report | 1.087 | 1.088 | 1.000 | 0.998–1.003 | 0.997, 1.004 |  |
| map.erase.reused | std::map | report | 1.319 | 1.281 | 0.972 | 0.964–0.979 | 0.960, 0.983 |  |
| map.find.fresh | std::map | report | 0.315 | 0.314 | 0.999 | 0.995–1.003 | 0.997, 1.001 |  |
| map.find.reused | std::flat_map | report | 0.786 | 0.785 | 1.000 | 0.997–1.002 | 0.997, 1.002 |  |
| map.find.reused | std::map | report | 0.699 | 0.730 | 1.044 | 1.040–1.049 | 1.062, 1.027 | worse |
| map.insert.fresh | std::map | report | 0.737 | 0.740 | 1.004 | 1.001–1.007 | 1.005, 1.003 | worse |
| map.insert.reused | std::flat_map | report | 1.008 | 1.008 | 0.999 | 0.996–1.003 | 0.994, 1.005 |  |
| map.insert.reused | std::map | report | 1.725 | 1.710 | 0.991 | 0.986–0.996 | 0.961, 1.022 |  |
| nested.build.plain | std | report | 0.346 | 0.341 | 0.984 | 0.979–0.988 | 0.987, 0.981 |  |
| set.erase.fresh | std::set | report | 0.633 | 0.630 | 0.996 | 0.993–1.000 | 1.000, 0.992 |  |
| set.erase.reused | std::flat_set | report | 1.148 | 1.148 | 1.001 | 0.998–1.003 | 0.998, 1.004 |  |
| set.erase.reused | std::set | report | 1.083 | 1.087 | 1.003 | 0.995–1.012 | 1.000, 1.006 |  |
| set.find.fresh | std::set | report | 0.299 | 0.300 | 1.003 | 0.998–1.008 | 1.002, 1.003 |  |
| set.find.reused | std::flat_set | report | 0.755 | 0.756 | 1.001 | 0.999–1.003 | 1.000, 1.002 |  |
| set.find.reused | std::set | report | 0.669 | 0.674 | 1.008 | 1.003–1.012 | 0.970, 1.047 |  |
| set.insert.fresh | std::set | report | 0.640 | 0.640 | 1.000 | 0.997–1.003 | 1.006, 0.994 |  |
| set.insert.reused | std::flat_set | report | 1.083 | 1.083 | 1.000 | 0.997–1.003 | 1.000, 1.000 |  |
| set.insert.reused | std::set | report | 1.337 | 1.319 | 0.986 | 0.978–0.994 | 0.955, 1.018 |  |
| str.assign_short | std::string | report | 1.828 | 1.828 | 1.000 | 0.998–1.003 | 0.998, 1.002 |  |
| str.assign_short.copy | std::string | report | 1.192 | 1.192 | 1.000 | 0.999–1.001 | 0.999, 1.001 |  |

worse at t1a than t0a (by the rule): map.erase.fresh / std::flat_map (G9) 1.004; vec.mid_erase / std::vector (G9) 1.004; map.find.reused / std::map (report) 1.044; map.insert.fresh / std::map (report) 1.004

above 1.01 but not worse by the rule: vec.push_back / std::vector (G9) 1.011

## XOffset ns/op alone, t1a / t0a (functions aligned to 64 B, layout check)

| case | t0a ns/op | t1a ns/op | t1a / t0a | 95% interval | halves | note |
| --- | ---: | ---: | ---: | --- | --- | --- |
| hero.mid_erase.ord | 163.2 | 163.6 | 1.002 | 1.001–1.004 | 1.004, 1.001 | worse |
| hero.mid_erase.plain | 908.3 | 912.2 | 1.004 | 1.002–1.007 | 1.003, 1.006 | worse |
| hero.mid_insert.ord | 230.1 | 229.9 | 0.999 | 0.997–1.001 | 1.000, 0.998 |  |
| hero.mid_insert.plain | 1256 | 1257 | 1.000 | 0.999–1.002 | 1.001, 1.000 |  |
| hero.push_back_grow.ord | 32.92 | 33.03 | 1.003 | 1.001–1.005 | 1.002, 1.005 | worse |
| hero.push_back_grow.plain | 36.36 | 36.4 | 1.001 | 0.999–1.003 | 1.001, 1.002 |  |
| map.erase.fresh | 33.01 | 33.18 | 1.005 | 1.002–1.008 | 1.014, 0.997 |  |
| map.erase.reused | 29.65 | 29.68 | 1.001 | 0.999–1.003 | 0.999, 1.003 |  |
| map.find.fresh | 5.135 | 5.133 | 1.000 | 0.998–1.001 | 1.000, 1.000 |  |
| map.find.reused | 5.156 | 5.156 | 1.000 | 0.998–1.002 | 0.998, 1.002 |  |
| map.insert.fresh | 32.27 | 32.27 | 1.000 | 0.998–1.002 | 1.001, 0.999 |  |
| map.insert.reused | 29.59 | 29.54 | 0.998 | 0.995–1.001 | 0.995, 1.002 |  |
| nested.build.ord | 292.5 | 293.2 | 1.002 | 1.000–1.005 | 1.000, 1.005 |  |
| nested.build.plain | 297 | 296.6 | 0.999 | 0.995–1.002 | 0.995, 1.002 |  |
| reset | 30.18 | 30.24 | 1.002 | 0.996–1.009 | 0.997, 1.007 |  |
| set.erase.fresh | 29.83 | 29.81 | 0.999 | 0.997–1.002 | 1.000, 0.999 |  |
| set.erase.reused | 23.29 | 23.26 | 0.999 | 0.996–1.001 | 0.995, 1.002 |  |
| set.find.fresh | 4.881 | 4.882 | 1.000 | 0.999–1.002 | 0.999, 1.001 |  |
| set.find.reused | 4.882 | 4.879 | 0.999 | 0.998–1.001 | 0.999, 1.000 |  |
| set.insert.fresh | 28.88 | 28.85 | 0.999 | 0.998–1.001 | 1.001, 0.997 |  |
| set.insert.reused | 22.89 | 22.92 | 1.001 | 0.999–1.004 | 1.004, 0.999 |  |
| str.append | 1.545 | 1.554 | 1.006 | 1.001–1.010 | 1.008, 1.004 | worse |
| str.assign_long | 2.942 | 2.945 | 1.001 | 0.999–1.003 | 1.002, 1.000 |  |
| str.assign_short | 0.9364 | 0.9493 | 1.014 | 1.009–1.018 | 1.007, 1.021 | worse |
| str.assign_short.copy | 0.6181 | 0.6233 | 1.008 | 1.004–1.013 | 1.000, 1.017 |  |
| str.assign_short.view | 0.9351 | 0.9426 | 1.008 | 1.005–1.011 | 0.999, 1.017 |  |
| vec.iterate | 0.03334 | 0.03323 | 0.997 | 0.994–0.999 | 0.996, 0.998 |  |
| vec.mid_erase | 40.39 | 40.58 | 1.005 | 1.003–1.007 | 1.008, 1.001 | worse |
| vec.mid_insert | 40.44 | 40.37 | 0.998 | 0.996–1.000 | 1.000, 0.997 |  |
| vec.push_back | 0.2718 | 0.2739 | 1.008 | 1.005–1.011 | 1.011, 1.004 | worse |
| vec.push_back_grow | 0.2744 | 0.2757 | 1.005 | 1.003–1.007 | 1.016, 0.994 |  |

XOffset slower at t1a than t0a (worse by the rule): hero.mid_erase.ord 1.002; hero.mid_erase.plain 1.004; hero.push_back_grow.ord 1.003; str.append 1.006; str.assign_short 1.014; vec.mid_erase 1.005; vec.push_back 1.008

## layout check: what is worse at t1 in the default build, in the aligned build

| comparison | t1 / t0 | t1a / t0a | 95% interval (aligned) | aligned |
| --- | ---: | ---: | --- | --- |
| reset (XOffset ns/op) | 1.022 | 1.002 | 0.996–1.009 | not worse |
| set.erase.reused (XOffset ns/op) | 1.004 | 0.999 | 0.996–1.001 | not worse |
| str.assign_short (XOffset ns/op) | 1.014 | 1.014 | 1.009–1.018 | still worse |
| str.assign_short.view (XOffset ns/op) | 1.008 | 1.008 | 1.005–1.011 | not worse |
| map.find.reused / std::map (report) | 1.010 | 1.044 | 1.040–1.049 | still worse |
| map.insert.fresh / std::map (report) | 1.013 | 1.004 | 1.001–1.007 | still worse |
| map.insert.reused / std::flat_map (report) | 1.004 | 0.999 | 0.996–1.003 | not worse |
| set.erase.reused / std::flat_set (report) | 1.003 | 1.001 | 0.998–1.003 | not worse |
